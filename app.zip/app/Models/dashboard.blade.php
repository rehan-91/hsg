@extends('frontend.layouts.front_layout')
<sc
@section('content')
@php
$default_locale = app()->getLocale();

@endphp


<section class="profile-details-block">
     <div class="container">
          <div class="row">
               @include('frontend.layouts.partials.navfordashboard')


               <div class="col-md-9">
               @if(count($query) > 0)
                    <div class="row side_box">
                         <div class="col-md-3">
                              <div class="card-boxes gr_pink">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-view-icon.png')}}"></div>
                                   <div class="text">Views<br /><span>{{ $stat_views }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_orange">
                                   <div class="dashboard_icon"><img
                                             src="{{ asset('frontend/images/dashboard-shortlisted-icon.png')}}"></div>
                                   <div class="text">Shortlisted<br /><span>80</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_purple">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-likes-icon.png')}}"></div>
                                   <div class="text">Likes<br /><span>{{ $stat_likes }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_green">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-clicks-icon.png')}}"></div>
                                   <div class="text">Clicks<br /><span>{{ $stat_clicks }}</span></div>
                              </div>
                         </div>
                    </div>
                   
                   
                    <div class="mt-4">
                         <div class="col-md-12 ad-status-box">
                              <div class="img_slider">
                                   <div id="demo" class="carousel slide" data-ride="carousel">
                                        <!-- Indicators -->
                                        @if(count($images) > 0)
                                        @php
                                        $i = 0;
                                        @endphp
                                        <ul class="carousel-indicators">
                                             @foreach($images as $img)
                                             <li data-target="#demo" data-slide-to="{{$i}}" class="active"></li>
                                             @php $i++; @endphp
                                             @endforeach
                                        </ul>
                                        @endif
                                        <!-- The slideshow -->

                                        <div class="carousel-inner">
                                             @if(count($images) > 0)
                                             @php
                                             $i=0;
                                             @endphp
                                             @foreach($images as $img)
                                             <div class="carousel-item {{$i == 0 ?'active': ''}}">
                                                  <img class="img-fluid" src="{{getS3ImageURL($img->media_filename,'377*625')}}" alt="">
                                                  <div class="photosVerified_aboveimg">
                                                       <img src="frontend/images/photosverified-icon.png"
                                                            alt="photosverified-icon">
                                                       <h6>Photos Verified</h6>
                                                  </div>
                                             </div>
                                             @php $i++; @endphp
                                             @endforeach
                                             @else
                                             <div class="carousel-item active">
                                                  <img class="img-fluid" src="{{url('public/images/default.png')}}"
                                                       alt="">

                                             </div>
                                             @endif
                                        </div>
                                        <!-- Left and right controls -->
                                        <a class="carousel-control-prev" href="#demo" data-slide="prev">
                                             <span class="carousel-control-prev-icon"></span>
                                        </a>
                                        <a class="carousel-control-next" href="#demo" data-slide="next">
                                             <span class="carousel-control-next-icon"></span>
                                        </a>
                                   </div>
                              </div>
                              <div class="cnt_section cnt_section_left">
                                   <div class="cnt">
                                        <div class="ad_id">#{{$query[0]->id}}</div>
                                        <h2>{{$query[0]->ad_name}}</h2>

                                        <div class="listing">
                                             <div class="list">{{ count($age)>0? getMaterData($age->meta_value):''}} Yrs
                                             </div>

                                             <div class="list"><span
                                                       class="label">Ethnicity:</span>{{ count($nationality) > 0 ? $nationality->meta_value:''}}
                                             </div>
                                        </div>

                                        @if(!empty($minRate))
                                        <div class="rate">{{$minRate}}/Hour</div>
                                        @endif
                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="frontend/images/hover-phone-icon.png"></div>
                                             <div class="phone-number"><span>Phone</span><br>{{$query[0]->ad_contactno}}
                                             </div>
                                        </div>



                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="frontend/images/email-dashboardicon.png"></div>
                                             <div class="phone-number">{{$query[0]->ad_email}}</div>
                                        </div>

                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="frontend/images/dashobar-web-icon.png"></div>
                                             <div class="phone-number">
                                                  {{!empty($website_url) && count($website_url) > 0 ? $website_url->meta_value : ''}}
                                             </div>
                                        </div>

                                        <ul class="followus mt-2 float-left">
                                             @foreach($social_links as $sl)
                                             @php
                                             $key = explode("_", $sl['meta_key']);
                                             $icon = getMaterIcon(end($key));


                                             @endphp
                                             <li><a target="_blank" href="{{$sl['meta_value']}}"><img
                                                            src="{{url('upload/'.$icon)}}"></a></li>
                                             @endforeach
                                        </ul>
                                   </div>
                              </div>
                              <div class="cnt_section cnt_section_right">
                                   <div class="cnt">
                                   
                                   @if(!empty($query[0]->plan_id))
                                   <h2>Ad Status
                                   @php
                                   $today = time();
                                   @endphp
                                   @if($today < $query[0]->plan_expired)
                                    <span class="ad-status active button button-pulse">Active</span>
                                   @else
                                   <span
                                    class="ad-status expired">Expired</span>
                                   @endif
                                   </h2>
                                  
                                        
                                         
                                   @php $plans = getPlanDetail($query[0]->plan_id); @endphp

                                        @if(count($plans) > 0)
                                        
                                        <div class="listing">

                                             <div class="list"><span class="label">Ad duration timing :</span> 4PM-8PM
                                             </div>
                                             <div class="list"><span class="label">Ad duration :</span> {{$plans->plan_duration}} {{$plans->plan_duration_unit}}</div>

                                             <div class="list"><span class="label">Smart AD Boosting :</span> 4PM-8PM
                                                  <span class="label">(Every 10 Minutes)</span></div>
                                             <div class="list"><span class="label">Date :</span> 20 August 2019</div>
                                             <div class="list"><span class="label">Ad Expiring On:</span>
											 
											<div id="clockdiv">
											<div>
												<span class="hours"></span>
												<div class="smalltext1">hours</div>
											</div>
											<div>
												<span class="minutes"></span>
												<div class="smalltext2">minutes</div>
											</div>
											<div>
												<span class="seconds"></span>
												<div class="smalltext3">seconds</div>
											</div>
											</div>
                                                  <div class="add-extend">
                                                       <span>Your Ad-on expiring soon </span>
                                                       <a href="javascript:void;"><span class="blink">extend now</span></a>
                                                  </div>
                                             </div>



                                        </div>
                                        @endif
                                        @endif
                                        @if(!empty($query[0]->plan_id))
                                        <div class="view_shorlist_section">
                                             <div class="block">
                                                  <div class="icon"><img src="frontend/images/aeroplane-icon.png"></div>
                                                  <div class="name">Touring</div>

                                             </div>

                                             <div class="block">
                                                  <div class="icon"><img src="frontend/images/calendor-icon.png"></div>
                                                  <div class="name">Calender</div>

                                             </div>

                                             <div class="block">
                                                  <div class="icon"><img src="frontend/images/verification-ok-icon.png">
                                                  </div>
                                                  <div class="name">Verification</div>

                                             </div>
                                       

                                        </div>
                                        @endif

                                        <div class="button_section">
                                             <div class="btns"><button class="btn Edit-btn"><a href="{{route('profile.', $query[0]->slug)}}"> Edit</a></button></div>
                                             @if(!empty($query[0]->plan_id))
                                             <div class="btns"><a class="btn view-btn" href="{{route('profile.', $query[0]->slug)}}">View</a></div>
                                             <div class="btns"><button class="btn renew-btn">Renew</button></div>
                                             @endif
                                        </div>

                                        <div class="clearfix"></div>
                                        @if(!empty($query[0]->plan_id))
                                        <div class="extend_time">
                                             <p>You can buy or extend your featured ad-ons here </p>

                                             <div class="dropdown dropdown-select dropdown-featuredAdOns">
                                                  <button class="btn btn-default dropdown-toggle" type="button"
                                                       id="dropdownMenu1" data-toggle="dropdown"
                                                       aria-expanded="true">Buy Featured Ad-ons
                                                       <span class="caret"></span>
                                                  </button>
                                                  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                                       <li role="presentation">
                                                            <label for="day1" class="radio">
                                                                 <input type="radio" name="rdo" id="day1"
                                                                      class="hidden">
                                                                 <span class="label"></span>1 Day - $2.99
                                                            </label>
                                                       </li>
                                                       <li role="presentation">
                                                            <label for="day2" class="radio">
                                                                 <input type="radio" name="rdo" id="day2"
                                                                      class="hidden">
                                                                 <span class="label"></span>2 Day - $4.99
                                                            </label>
                                                       </li>
                                                       <li role="presentation">
                                                            <label for="day3" class="radio">
                                                                 <input type="radio" name="rdo" id="day3"
                                                                      class="hidden">
                                                                 <span class="label"></span>3 Day - $ 6.99
                                                            </label>
                                                       </li>
                                                       <li role="presentation">
                                                            <label for="day4" class="radio">
                                                                 <input type="radio" name="rdo" id="day4"
                                                                      class="hidden">
                                                                 <span class="label"></span>4 Day - $ 7.99
                                                            </label>
                                                       </li>

                                                       <li role="presentation">
                                                            <span class="purchaseadd-btn">purchase</span>
                                                       </li>


                                                  </ul>
                                             </div>

                                        </div>
                                        @endif

                                   </div>
                              </div>
                         </div>
                      

                         <div class="clearfix"></div>

     @if (count($errors) > 0)
      <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with image please choose correct image size.<br><br>
        <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
        </ul>
      </div>
      @endif

        @if(session('success'))
        <div class="alert alert-success">
          {{ session('success') }}
        </div> 
        @endif

                         <!-- Verification block -->

                         <form action="{{ route('VerifyIdentity') }}" method="POST" enctype="multipart/form-data">
                              {{ csrf_field() }}
                         <div class="profile_photos dashboard_uploadPhotos">

                              <p class="uploadphotos-verif-text"><span>Upload Verification Photos</span> (Photo
                                   Verification Requirement - take a piece of paper hold it on front of your face (below
                                   chin) and click.
                                   Also take a couple of clear photos of wearing one of those cloths in your profile and
                                   send it us by clicking Submit Button.)</p>
                              <div class="preview-images-zone dashboard-uploadphotos-images">
                                   <fieldset class="form-group">
                                        <div class="field_set dashboard-uploadphotos">
                                             <a href="javascript:void(0)" onclick="$('#pro-image').click()">UPLOAD <span
                                                       class="pkus_icon">+</span></a>
                                             <input type="file" id="pro-image" name="image[]" style="display: none;"
                                                  class="form-control" >

                             

                                        </div>
                                   </fieldset>


                              </div>

                              <div class="clearfix"></div>

                              <div class="upload_bottomtext_button">
                                   <p>Your verification photos and videos will be visible to you and our verification
                                        team Only</p>

                                        
                                        <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                   <button class="submit-btn" type="submit">submit</button>

                              </div>

                         </div>
                    </form>
                    <!-- end verification block -->

                    </div>
                    @else
                    
                         <div class="col-md-12 ad-status-box">
                         <h2>No Post has been added yet.</h2>
                         <div class="post-ad-btn">
                              <a href='{{route("post-ad.","/")}}'>Post Ad</a>
                         </div>
                          </div>
                    
               @endif
               </div>
               
          </div>
</section>



<script>

function getTimeRemaining(endtime) {
  var t = Date.parse(endtime) - Date.parse(new Date());
  var seconds = Math.floor((t / 1000) % 60);
  var minutes = Math.floor((t / 1000 / 60) % 60);
  var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
  return {
    'total': t,
    'hours': hours,
    'minutes': minutes,
    'seconds': seconds
  };
}

function initializeClock(id, endtime) {
  var clock = document.getElementById(id);
  var hoursSpan = clock.querySelector('.hours');
  var minutesSpan = clock.querySelector('.minutes');
  var secondsSpan = clock.querySelector('.seconds');

  function updateClock() {
    var t = getTimeRemaining(endtime);

    hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
    minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
    secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

    if (t.total <= 0) {
      clearInterval(timeinterval);
    }
  }

  updateClock();
  var timeinterval = setInterval(updateClock, 1000);
}

var deadline = new Date(Date.parse(new Date()) + 15 * 24 * 60 * 60 * 1000);
initializeClock('clockdiv', deadline);
</script>

<script>
var timer;
$(function($) {
    timer = setTimeout(blnk, 0);
});


function blnk() {
    $(".blink").css({opacity: 0}).
        animate({opacity: 1}, 300, "linear").
        animate({opacity: 0}, 300, "linear", 
        function() {
            timer = setTimeout(blnk, 0);
        });
}

</script>

@endsection