<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdRate extends Model
{
	 protected $table = 'ad_rate';
	

}
