<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Modules extends Model
{
    use SoftDeletes;
	
	use \Dimsav\Translatable\Translatable;
	
    protected $table = 'modules';
	
	protected $fillable = [
        'course_id', 'code', 'counter', 'created_by', 'status'
    ];
	
	public $translatedAttributes = [ 'name' ];
	
	public $translationForeignKey = 'module_id';
	
	/**
     * The relations to eager load on every query.
     *
     * @var array
     */
    // (optionaly)
    protected $with = ['translations'];
	
	public function mod_translations() {
        return $this->hasMany('App\Models\ModulesTranslation', 'module_id');
    }
	
	public function mod_one_content() {
        return $this->hasOne('App\Models\ModulesContent', 'module_id');
    }
	
	public function mod_contents() {
        return $this->hasMany('App\Models\ModulesContent', 'module_id');
    }
	
	public function active_mod_contents() {
        return $this->mod_contents()->where('status','=', 1);
    }
	
	public static function getCourseModules($course_id, $locale = "en"){
		
		$course_modules = Modules::where("course_id", $course_id)->where("status", 1)->orderBy('counter', 'asc')->get();
		
		$module_content = array();
		if( $course_modules->count() > 0 ){
			foreach( $course_modules as $modules ){
				
				$module_name = $modules->translate( $locale )->name;
				
				$module_duration = Modules::get_module_total_duration($modules, $locale);
				
				$module_content[] = array( "id" => $modules->id, "counter" => $modules->counter, "module_duration" => $module_duration, "module_name" => $module_name );
			}
		}
		
		return $module_content;
	}
	
	public static function get_module_total_duration( $modules, $locale){
		
		$module_contents = $modules->active_mod_contents()->get();
		
		$module_duration_seconds = 0;
		foreach($module_contents as $contents){
			$duration = $contents->translate( $locale )->duration;
			if( $duration ){
				$module_duration_seconds += intval( convert_time_to_seconds( $duration ) );
			}
		}
		
		
		$module_duration_mins = floor($module_duration_seconds / 60);
		
		return $module_duration_mins;
	}
	
	public static function getTopicPreviousNextData( $course_id, $modules_data, $topics_data ){
		
		$return_data = array();
		
		$return_data["prev"] = $modules_data->getTopicCommonData( $course_id, $modules_data, $topics_data, '<', 'desc');
		
		$return_data["next"] = $modules_data->getTopicCommonData( $course_id, $modules_data, $topics_data, '>', 'asc');
		
		return $return_data;
	}
	
	public function getTopicCommonData( $course_id, $modules_data, $topics_data, $comparison, $orderBy ){
		$return_data = array();
		
		$topic_data = ModulesContent::where('counter', $comparison, $topics_data->counter)
							->where("module_id", $modules_data->id)
							->where("status", 1)->limit( 1 )->orderBy("counter", $orderBy)->get();
		
		if( count($topic_data) > 0 ){
			$return_data["module_id"] = $topic_data[0]->module_id;
			$return_data["topic_id"] = $topic_data[0]->id;
		}
		else{
			$module_data = Modules::where('counter', $comparison, $modules_data->counter)
							->where("course_id", $course_id)
							->where("status", 1)->limit( 1 )->orderBy("counter", $orderBy)->get();
			if( count($module_data) > 0 ){
				$topic_data = ModulesContent::where("module_id", $module_data[0]->id)
							->where("status", 1)->limit( 1 )->orderBy("counter", $orderBy)->get();
				if( count($topic_data) > 0 ){
					$return_data["module_id"] = $topic_data[0]->module_id;
					$return_data["topic_id"] = $topic_data[0]->id;
				}
			}
		}
		
		return $return_data;
	}
	
	public function getModelUserHistory(){
        return $this->hasMany('App\Models\ModulesUserHistory', 'module_id' );
    }
	
}
