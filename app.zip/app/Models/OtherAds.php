<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OtherAds extends Model
{
    protected $table = 'other_ads';
	protected $fillable = ['title','ad_photo','short_order'];
}
