<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Content extends Model
{
    //
    
    
    protected $table = 'content_pages';
    
    function get_all_contentpage(){
      return  Content::select('*')->get();
    }
}
