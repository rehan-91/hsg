<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ApiAuthAccessTokens extends Model
{
    use SoftDeletes;
	
	
    protected $table = 'api_auth_access_token';
	
	protected $fillable = [
        'user_id', 'access_token', 'status'
    ];
}
