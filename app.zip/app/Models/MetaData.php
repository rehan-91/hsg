<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MetaData extends Model
{
	use SoftDeletes;
	
    protected $table = 'metadata';
	
	protected $fillable = [
        'meta_key', 'meta_value'
    ];
	
		static function get_image_data($image_name, $folder_name=""){
		
		if( !empty( $image_name ) ){
				if(!empty($folder_name)){
					return url('/uploads/'.$folder_name.'/'.$image_name);
				}else{
					return url('/upload/'.$image_name);
				}
		}
		else{
			return url('/uploads/no_logo.gif');
		}
		
	}
}
