<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Eyecolor extends Model
{
    protected $table = 'master_eyecolor';
	protected $fillable = ['eyecolor_value'];
}
