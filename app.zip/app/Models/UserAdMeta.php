<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class UserAdMeta extends Model
{
    //
    protected $table = 'user_ad_meta';
	protected $fillable = ['ad_id', 'meta_key', 'meta_value'];
}
