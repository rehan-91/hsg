<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserTestAttempts extends Model
{
    use SoftDeletes;
	
	protected $table = 'user_test_attempts';
	
	protected $fillable = [
        'user_id', 'test_id', 'allowed_attempts', 'attempts_done', 'status'
    ];
	
	protected $attributes = [
        'attempts_done' => 0
    ];
	
	public function attemptTests(){
		return $this->belongsTo("App\Models\Test", "test_id");
	}
	
	public function active_attemptTests(){
		return $this->attemptTests()->where("status", 1);
	}
	
	public function testAttemptUser(){
		return $this->hasOne("App\Models\User", "id", "user_id");
	}
	
	
	public function testAttemptResult(){
		return $this->hasOne("App\Models\TestsAttemptResult", "attempt_test_id", "test_id");
	}
}
