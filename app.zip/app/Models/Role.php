<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Role extends \Spatie\Permission\Models\Role
{
	
	const ROLE_SUPERADMIN = 'super-admin';
	const ROLE_SUBADMIN = 'sub-admin';
	const ROLE_ABCUSER = 'fusers';
}
