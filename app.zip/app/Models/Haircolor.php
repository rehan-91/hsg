<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Haircolor extends Model
{
    protected $table = 'master_haircolor';
	protected $fillable = ['haircolor_value'];
}
