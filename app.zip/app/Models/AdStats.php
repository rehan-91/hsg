<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdStats extends Model
{
    protected $table = 'stats';
	protected $fillable = ['stat_ad_id','stat_likes','stat_clicks','stat_views'];
}
