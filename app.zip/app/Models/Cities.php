<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class Cities extends Model
{
    //
    protected $table = 'cities';
    
    static function getCities($state_id = 0){
        
         if($state_id > 0){
           $res = DB::table('cities')
           ->join('states','states.id','=','cities.state_id')
           ->join('countries','countries.id','=','cities.country_id')
           ->select('cities.*','states.name as state_name', 'countries.country_name')        
           ->where(['states.id' =>$state_id ])
           ->get();
        }else{
          $res =  DB::table('cities')       
           ->join('states','states.id','=','cities.state_id')
           ->join('countries','countries.id','=','cities.country_id')
          ->select('cities.*','states.name as state_name', 'countries.country_name')
           ->get();
        }
        return $res;
       
    }
            
}
