<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PermissionGroups extends Model
{
	use SoftDeletes;
	
    protected $table = 'permission_groups';
	
	protected $fillable = [
        'parents_id', 'name'
    ];
}
