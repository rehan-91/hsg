<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Traits\HasRoles;

class RolePermission extends Model
{
	use HasRoles;
	
	protected $guard_name = 'web';
	
	protected $table = 'role_has_permissions';
	
	protected $fillable = [
        'permission_id', 'role_id'
    ];
	
    /* public function rolesPermission(){
		return $this->belongsToMany('App\Models\Permission');
		//return $this->where("role_id", $role_id);
	} */
	
	/* public function rolesPermission()
	{
		return $this->hasOne('App\Models\Permission');
	} */
}
