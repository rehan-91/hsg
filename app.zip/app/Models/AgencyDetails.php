<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AgencyDetails extends Model
{
    protected $table = 'agency_details';
	protected $fillable = ['name','email','phone','location','description','logo','photo','video'];

}
