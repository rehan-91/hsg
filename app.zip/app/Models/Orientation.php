<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Orientation extends Model
{
    protected $table = 'master_orientation';
	protected $fillable = ['orientation_value'];
}
