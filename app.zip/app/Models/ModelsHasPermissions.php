<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ModelsHasPermissions extends Model
{
    protected $table = 'model_has_permissions';
	
}
