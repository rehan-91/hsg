<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdExtraServices extends Model
{
    //
    protected $table = 'ad_extra_services';
}
