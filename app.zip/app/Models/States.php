<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
class States extends Model
{
     protected $table = 'states';
     
     
      function country(){
         return $this->belongsTo('App\Models\Countries');
     }
     function getCountryName(){
         
     }
     
     static function getStates($country_id=0){
         
        if($country_id > 0){
           $res = DB::table('states')
           ->select('states.*','countries.country_name')
           ->join('countries','countries.id','=','states.country_id')
           ->where(['countries.id' =>$country_id ])
           ->get();
        }else{
          $res =  DB::table('states')
           ->select('states.*','countries.country_name')
           ->join('countries','countries.id','=','states.country_id')
           ->get();
        }
        return $res;
     }
     
     static function getCountries(){
         
         return Countries::all();
         
     }
}
