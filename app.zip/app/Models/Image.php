<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Matriphe\Imageupload\ImageuploadModel;

class Image extends Model
{
    protected $table = 'ad_media';
}
