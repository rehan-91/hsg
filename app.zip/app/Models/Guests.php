<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Guests extends Model
{
    protected $table = 'guests';
	protected $fillable = ['guest_ip_address','	visit_date','total_visit_counter'];

}
