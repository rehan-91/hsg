<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use Illuminate\Support\Facades\Mail;
use App\Mail\SendMailable;

class EmailMessage extends Model
{
    use SoftDeletes;
	
	protected $table = 'email_message_template';
	
	protected $fillable = [
        'identifier_name', 'email_subject', 'email_message', 'sms_message', 'from_address', 'from_name', 'cc_address', 'bcc_address', 'status'
    ];
	
	
	
	public function messageSendIntegration( $sent_number, $identifier_name = '', $replacers = array() ){
		
		$auth_key = '224339AKQhYbE6T5b3db486';
		$sender_id = 'BCFIIN';
		
		$message_code = EmailMessage::where( "identifier_name", $identifier_name )->first();
		
		if( $message_code && intval( $message_code->id ) > 0 ){
			$sms_message = $message_code->sms_message;
			
			if( count( $replacers ) > 0 ){
				foreach( $replacers as $key => $value ){
					$sms_message = str_replace( ":".$key.":", $value, $sms_message );
				}
			}
			
			$curl = curl_init();
	
			curl_setopt_array($curl, array(
				CURLOPT_URL => "http://api.msg91.com/api/sendhttp.php?sender=".$sender_id."&route=4&mobiles=".$sent_number."&authkey=".$auth_key."&country=91&message=".$sms_message,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_SSL_VERIFYHOST => 0,
				CURLOPT_SSL_VERIFYPEER => 0,
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);
		}
	}
	
	public function singleMailSendIntegration( $email_address, $identifier_name = '', $email_content ){
		
		$email_data = EmailMessage::where( "identifier_name", $identifier_name )->first();
		
		
		if( $email_data && intval( $email_data->id ) > 0 ){
			
			$message_content = $email_data->email_message;
			$subject = $email_data->email_subject;
			
			if( count( $email_content ) > 0 ){
				foreach( $email_content as $key => $value ){
					$message_content = str_replace( ":".$key.":", $value, $message_content );
					$subject = str_replace( ":".$key.":", $value, $subject );
				}
			}
			
			Mail::to( $email_address )->send( new SendMailable( $subject, $message_content, $email_data->from_address, $email_data->from_name, $email_data->cc_address ) );
			/* Mail::to( $email_address )
				->send( new SendMailable( $subject, $message_content, $email_data->from_address, $email_data->from_name, $email_data->cc_address ) ); */
			
		}
	}
}
