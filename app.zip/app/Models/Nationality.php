<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Nationality extends Model
{
    protected $table = 'master_nationality';
	protected $fillable = ['nationality_value'];
}
