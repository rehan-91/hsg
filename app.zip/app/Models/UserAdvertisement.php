<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserAdvertisement extends Model
{
    //
     protected $table = 'user_advertisement';
     protected $fillable = ['ad_user_id'];

     function getProfileData($slug){
        $today = time();
        $userad = UserAdvertisement::where('slug', $slug)->whereNotNull('plan_expired')
        ->whereNotNull('plan_purchased')
        ->where('status', '1')
        ->where('plan_expired','>=',$today )
        ->get();
        $res = array();
        $metadata = array();
       if(count($userad) > 0){
        foreach($userad as $r){
        $i = 0;
           $adData = \App\Models\UserAdMeta::where('ad_id', $r->id)->get();
           $services = $this->getAdServicesRates($r->id);
           $extra_services = $this->getExtraServices($r->id);
           foreach($adData as $data){
            
                $metadata[$data->meta_key][] = $data->meta_value;
            
           }
           $images = $this->getAdImages($r->id);
           $videos = $this->getAdVideos($r->id);
           $res = array(
                "adId" => $r->id,
                "adUserId" => $r->ad_user_id,
                "adListingTypeId" => $r->ad_listing_type_id,
                "adName" => $r->ad_name,
                "adEmail" => $r->ad_email,
                "adContact" => $r->ad_contactno,
                "aboutDescription" => $r->about_description,
                "adLocation" => $r->ad_location,
                'metadata' =>$metadata,
                'images' => $images,
                'videos' => $videos,
                'services' =>  $services,
                'extra_services' => $extra_services
           );
        }

       }
       return $res;
         
     }

     function getAdImages($id){
      $adImages = \App\Models\Image::where('media_ad_id',$id)->where('media_status','Verified')->where('media_type','Images')->get();
      return $adImages;
     }
     function getAdVideos($id){
          $adImages = \App\Models\Image::where('media_ad_id',$id)->where('media_status','Verified')->where('media_type','Videos')->get();
          return $adImages;
         }
     function getAdServicesRates($ad_id){
          $res = \App\Models\AdRate::where('ad_id', $ad_id)->get();
          $services= array();
          if(count($res) > 0){
               foreach($res as $r){
                         $services[]  = array(
                              'ad_time' => $r->ad_time,
                              'incall_charge' => $r->incall_charge,
                              'outcall_charge' => $r->outcall_charge,
                              'services' => $r->services
                         );         
               }
          }
          return $services;
     }
    

function getExtraServices($ad_id){
     $extra = \App\Models\AdExtraServices::where('ad_id', $ad_id)->get();
     $extraservices = array();
     if(count($extra) > 0){
          foreach($extra as $ex){
               $extraservices[] =  array(
                    'ad_fee' => $ex->ad_fee,
                    'ad_services' => $ex->ad_services
               );
          }
     }
     return $extraservices;
}

}
