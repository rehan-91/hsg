<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class Plans extends Model
{
    //
 
    protected $table = 'plans';
    

    function get_all_plans(){
      return  Plans::select('*')->get();
    }
    

}
