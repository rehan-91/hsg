<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FavouriteThings extends Model
{
     protected $table = 'master_fav_things';
}
