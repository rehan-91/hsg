<?php
namespace App\Models;

use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

use Spatie\Permission\Traits\HasRoles;
use App\Models\Permission;
use App\Models\Role;
use App\Models\RolePermission;

use Carbon\Carbon;
use DB;

/**
 * App\Models\User
 *
 * @property integer $id
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereEmail($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User wherePassword($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereRememberToken($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class User extends Authenticatable
{
	use SoftDeletes;
	
	use HasRoles;
	use HasApiTokens, Notifiable;
	
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];
	
	//protected $dates = ['deleted_at'];
	
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'users'; 
	protected $dates = ['deleted_at'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
	


	
	const ACCOUNTSTATUS = array( "active" => "Active", "inactive" => "Inactive", "blocked" => "Blocked", "blacklisted" => "Blacklisted", "pending_approval" => "Pending Approval" );
	
	const FIELDLABELS = array( "email" => "Email Address", "password" => "Password", "contact_number" => "Contact Number", "image_id" => "Profile Image", "status" => "Account Status", "first_name" => "First Name", "last_name" => "Last Name", "gender" => "Gender", "language_preferenced" => "Language Preference", "services" => "Services", "education_qualification" => "Educational Qualification", "company_name" => "Company Name", "secondary_image_id" => array( "agent" => "Store Image", "cbc" => "Company Logo" ), "dob" => "Date of Birth", "pan_number" => "Pan Number", "driving_license" => "Driving License Number", "voter_id_number" => "Voter Id", "cibil_score" => "Cibil Score", "certification_status" => "Certification Status", "examination_status" => "Examination Status", "address_latlong" => "Address Latitude & Longitude", "address_street" => "Address", "state_id" => "Address State", "district_id" => "Address District", "sub_district_id" => "Address Block/Sub-District", "block_id" => "Address Village/City", "pin_code" => "Pin Code", "parent_cbc" => "Associated User" );
	
	const IMPORTFIELDNAME = array( "first_name", "last_name", "email",  "contact_number", "gender", "educations",  "services", "pan_card", "driving_license", "voter_id", "dob", "cibil_score", "addr_street", "addr_block", "addr_sub_district", "addr_district", "addr_state", "addr_pin_code", "status" );

	
	
	/**
		* Check if user has been blacklisted
	*/
	public function isBlacklisted(){
		return ( $this->status === "blacklisted") ? true :  false;
	}
	
	/**
		* Check if user has been blocked
	*/
	public function isBlocked(){
		return ( $this->status === "blocked") ? true :  false;
	}
	
	/**
		* Check if user has been Inactive
	*/
	public function isInactive(){
		return ( $this->status == 0) ? true :  false;
	}
	
	/**
		* Check if user has been Active
	*/
	public function isActive(){
	   
		return ( $this->status == 1) ? true :  false;
	}
	
	/**
		* Sub Group's Permissions Data
	*/
	public static function subGroupPermissions($sub_group_id, $included_permissions){
		
		$sub_gp_perm = Permission::where("group_id", $sub_group_id);
		if( count($included_permissions) > 0 ){
			$sub_gp_perm->whereIn('id', $included_permissions );
		}
		
		$query_result = $sub_gp_perm->get()->toArray();
		
		return $query_result;
	}
	

	
	/**
		* Sub Group's Permissions based on Role Type
	*/
	public static function rolePermissions($role_type){
		
		$permission_array = array();
		
		$role = Role::findByName( $role_type );
	
		$role_permissions = RolePermission::where("role_id", $role["id"])->get();
		
		if( $role_permissions->count() > 0 ){
			foreach( $role_permissions as $permissions ){
				$permission_name = Permission::findOrFail($permissions["permission_id"]);
				
				$permission_array["perm_id"][] = $permissions["permission_id"];
				$permission_array["perm_name"][] = $permission_name["name"];
			}
		}
		
		return $permission_array;
	}
	
	public function get_image_data($image_id, $image_size = 'square100', $send_blank = 0){
		
		if( intval( $image_id ) > 0 ){
			$image_data = Image::find($image_id);
			
			if( $image_data ){
				return url('/').'/'.$image_data[$image_size."_filedir"];
			}
			else if( intval($send_blank) == 1 ){
				return '';
			}
			else{
				return url('/uploads/no_logo.gif');
			}
		}
		else if( intval($send_blank) == 1 ){
			return '';
		}
		else{
			return url('/uploads/no_logo.gif');
		}
		
	}

	public function userblog(){
		return $this->hasMany('App\Models\Blogs');

	}

	public function userIdentityVerification(){
		return $this->hasMany('App\Models\Verification','user_id');

	}
	
	
	
}	