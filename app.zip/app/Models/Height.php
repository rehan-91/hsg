<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Height extends Model
{
    protected $table = 'master_height';
	protected $fillable = ['height_value'];
}
