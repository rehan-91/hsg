<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Piercing extends Model
{
    //
	protected $table='master_piercing';
}
