<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServicesAvailable extends Model
{
    //
    protected $table="services_available";
}
