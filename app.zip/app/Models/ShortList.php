<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ShortList extends Model
{
    protected $table = 'shortlist';
	protected $fillable = ['short_ad_id','short_guest_id'];
   
}
