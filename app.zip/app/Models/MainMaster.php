<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class MainMaster extends Model 
{
    // it containes all the master models like age, eyes, haircolor etc...
	
	protected $table = 'master';
	protected $fillable = ['meta_name','meta_value']; // for age name and age value...
	
}
