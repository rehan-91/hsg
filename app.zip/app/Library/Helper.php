<?php

/**
 * Fetch General Settings set for whole site
 */
function generalSettings() {
	
	$general_setting = array();
	
	$get_settings = App\Models\MetaData::get();
	
	foreach( $get_settings as $setting ){
		$general_setting[ $setting["meta_key"] ] = $setting["meta_value"];
	}
	
	return $general_setting;
}

function setOptionDataListing($db_result, $key_id, $value){
	
	$master_list = array();
	
	foreach($db_result as $result){
		$master_list[] = array( "id" => $result[$key_id], "name" => $result[$value] );
	}
	
	return $master_list;
}


function convert_time_to_seconds($time){
	sscanf($time, "%d:%d:%d", $hours, $minutes, $seconds);

	return $hours * 3600 + $minutes * 60 + $seconds;
}

function convert_time_to_minutes($time){
	$time = explode(':', $time);
	return ($time[0]*60) + ($time[1]) + ($time[2]/60);
}


function convert_time_format_frontend($time, $timer_seconds = 0){
	$time = explode(':', $time);
	
	if( intval( $time[0] ) > 0 ){
		$timer = intval( $time[0] ).' '.trans('translations.frontend.time.hrs');
		if( intval( $time[1] ) > 0 ){
			$timer .= ' '.intval( $time[1] ).' '.trans('translations.frontend.time.mins');
		}
		
		if( intval( $timer_seconds ) == 1 && intval( $time[2] ) > 0 ){
			$timer .= ' '.intval( $time[2] ).' '.trans('translations.frontend.time.sec');
		}
		return $timer;
	}
	else if( intval( $time[1] ) > 0 ){
		$timer = intval( $time[1] ).' '.trans('translations.frontend.time.mins');
		if( intval( $timer_seconds ) == 1 && intval( $time[2] ) > 0 ){
			$timer .= ' '.intval( $time[2] ).' '.trans('translations.frontend.time.sec');
		}
		return $timer;
	}
	else{
		return intval( $time[2] ).' '.trans('translations.frontend.time.sec');
	}
}

function get_session_durations( $course_topics ){
	
	$total_seconds = 0;
	if( count($course_topics) > 0 ){
		foreach($course_topics as $topics){
			$total_seconds += intval( convert_time_to_seconds( $topics->duration ) );
		}
	}
	
	//$minutes = floor($total_seconds / 60);
	return $total_seconds;
}

function get_session_durations_topics( $course_topics ){
	
	$total_seconds = intval( convert_time_to_seconds( $course_topics->duration ) );

	$minutes = floor($total_seconds / 60);
	return $minutes;
}

function get_translations_trimmed( $locale, $keyword, $data ){
	
	$translation = trans("translations.frontend.".$keyword);
	
	foreach( $data as $key => $value ){
		$translation = str_replace( ":".$key.":", $value, $translation);
	}
	
	return $translation;
}

function get_progress_percentage( $value_first, $value_second ){
	
	if( intval( $value_second ) > 0 ){
		return intval( intval( $value_first ) / intval( $value_second ) * 100 ) ;
	}
	else{
		return 0;
	}
}

function generateRandomString($characters, $length = 2) {
	$randomString = $characters[0];
	
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

function convert_to_number_format( $number ){
    $len = strlen($number);
    $m = '';
    $number = strrev($number);
    for($i=0;$i<$len;$i++){
        if(( $i==3 || ($i>3 && ($i-1)%2==0) )&& $i!=$len){
            $m .=',';
        }
        $m .= $number[$i];
    }
    return strrev($m);
}

function str_truncate($text, $length) {
   $length = abs((int)$length);
   if(strlen($text) > $length) {
      $text = preg_replace("/^(.{1,$length})(\s.*|$)/s", '\\1...', $text);
   }
   
   return($text);
}

function listingtype($type_id = 0 ) {
	
	$listing_type = array();
	if($type_id > 0){
		$listing = App\Models\Usertype::where('id', $type_id)->get();	
	}else{
	$listing = App\Models\Usertype::orderBy('sort_order')->get();
	}
	foreach( $listing as $list ){
		$listing_type[ $list['id']] = array(
                   "title" => $list["title"],
				"slug" => $list['slug'],
				"icon_image" =>$list['icon'],
				"class_name" => $list['class_name']
                );
	}
	
	return $listing_type;
}

function getDay($i){

	$array  = [
		"1" => "Monday",
		"2" => "Tuesday",
		"3" => "Wednesday",
		"4" => "Thursday",
		"5" => "Friday",
		"6" => "Staurday",
		"7" => "Sunday"
	];

	return $array[$i];

}

function get_times($default='', $interval = '+15 minutes' ) {

    $output = '';

    $current = strtotime( '00:00' );
    $end = strtotime( '23:59' );

    while( $current <= $end ) {
        $time = date( 'H:i', $current );
        $sel = ( $time == $default ) ? ' selected' : '';

        $output .= "<option value=\"{$time}\"{$sel}>" . date( 'h.i A', $current ) .'</option>';
        $current = strtotime( $interval, $current );
    }
	
    return $output;
}

function get_rate_time(){

	$output = "";
	$timearray = array(
		"30 minutes"=>"30 Minutes",
		"1 hr" => "1 Hour",
		"2 hr" => "2 Hours",
		"3 hr" => "3 Hours",
		"4 hr" => "4 Hours",
		"5 hr" => "5 Hours",
		"6 hr" => "6 Hours",
		"7 hr" => "7 Hours",
		"8 hr" => "8 Hours",
		"1 day" => "1 Day",
	);

	return $timearray;
}

function price_format($price){
	$general_setting = generalSettings();
 	$currencyCode = $general_setting['selected_currency'];
	$currencySymbol = currencysymbol($currencyCode);
	return $currencySymbol.$price;
}
function currencysymbol($code){
$currency_symbols = array(
	'AED' => '&#1583;.&#1573;', // ?
	'AFN' => '&#65;&#102;',
	'ALL' => '&#76;&#101;&#107;',
	'AMD' => '',
	'ANG' => '&#402;',
	'AOA' => '&#75;&#122;', // ?
	'ARS' => '&#36;',
	'AUD' => '&#36;',
	'AWG' => '&#402;',
	'AZN' => '&#x20BC;',
	'BAM' => '&#75;&#77;',
	'BBD' => '&#36;',
	'BDT' => '&#2547;', // ?
	'BGN' => '&#1083;&#1074;',
	'BHD' => '.&#1583;.&#1576;', // ?
	'BIF' => '&#70;&#66;&#117;', // ?
	'BMD' => '&#36;',
	'BND' => '&#36;',
	'BOB' => '&#36;&#98;',
	'BRL' => '&#82;&#36;',
	'BSD' => '&#36;',
	'BTN' => '&#78;&#117;&#46;', // ?
	'BWP' => '&#80;',
	'BYR' => '&#112;&#46;',
	'BZD' => '&#66;&#90;&#36;',
	'CAD' => '&#36;',
	'CDF' => '&#70;&#67;',
	'CHF' => '&#67;&#72;&#70;',
	'CLF' => '', // ?
	'CLP' => '&#36;',
	'CNY' => '&#165;',
	'COP' => '&#36;',
	'CRC' => '&#8353;',
	'CUP' => '&#8396;',
	'CVE' => '&#36;', // ?
	'CZK' => '&#75;&#269;',
	'DJF' => '&#70;&#100;&#106;', // ?
	'DKK' => '&#107;&#114;',
	'DOP' => '&#82;&#68;&#36;',
	'DZD' => '&#1583;&#1580;', // ?
	'EGP' => '&#163;',
	'ETB' => '&#66;&#114;',
	'EUR' => '&#8364;',
	'FJD' => '&#36;',
	'FKP' => '&#163;',
	'GBP' => '&#163;',
	'GEL' => '&#4314;', // ?
	'GHS' => '&#162;',
	'GIP' => '&#163;',
	'GMD' => '&#68;', // ?
	'GNF' => '&#70;&#71;', // ?
	'GTQ' => '&#81;',
	'GYD' => '&#36;',
	'HKD' => '&#36;',
	'HNL' => '&#76;',
	'HRK' => '&#107;&#110;',
	'HTG' => '&#71;', // ?
	'HUF' => '&#70;&#116;',
	'IDR' => '&#82;&#112;',
	'ILS' => '&#8362;',
	'INR' => '&#8377;',
	'IQD' => '&#1593;.&#1583;', // ?
	'IRR' => '&#65020;',
	'ISK' => '&#107;&#114;',
	'JEP' => '&#163;',
	'JMD' => '&#74;&#36;',
	'JOD' => '&#74;&#68;', // ?
	'JPY' => '&#165;',
	'KES' => '&#75;&#83;&#104;', // ?
	'KGS' => '&#1083;&#1074;',
	'KHR' => '&#6107;',
	'KMF' => '&#67;&#70;', // ?
	'KPW' => '&#8361;',
	'KRW' => '&#8361;',
	'KWD' => '&#1583;.&#1603;', // ?
	'KYD' => '&#36;',
	'KZT' => '&#1083;&#1074;',
	'LAK' => '&#8365;',
	'LBP' => '&#163;',
	'LKR' => '&#8360;',
	'LRD' => '&#36;',
	'LSL' => '&#76;', // ?
	'LTL' => '&#76;&#116;',
	'LVL' => '&#76;&#115;',
	'LYD' => '&#1604;.&#1583;', // ?
	'MAD' => '&#1583;.&#1605;.', //?
	'MDL' => '&#76;',
	'MGA' => '&#65;&#114;', // ?
	'MKD' => '&#1076;&#1077;&#1085;',
	'MMK' => '&#75;',
	'MNT' => '&#8366;',
	'MOP' => '&#77;&#79;&#80;&#36;', // ?
	'MRO' => '&#85;&#77;', // ?
	'MUR' => '&#8360;', // ?
	'MVR' => '.&#1923;', // ?
	'MWK' => '&#77;&#75;',
	'MXN' => '&#36;',
	'MYR' => '&#82;&#77;',
	'MZN' => '&#77;&#84;',
	'NAD' => '&#36;',
	'NGN' => '&#8358;',
	'NIO' => '&#67;&#36;',
	'NOK' => '&#107;&#114;',
	'NPR' => '&#8360;',
	'NZD' => '&#36;',
	'OMR' => '&#65020;',
	'PAB' => '&#66;&#47;&#46;',
	'PEN' => '&#83;&#47;&#46;',
	'PGK' => '&#75;', // ?
	'PHP' => '&#8369;',
	'PKR' => '&#8360;',
	'PLN' => '&#122;&#322;',
	'PYG' => '&#71;&#115;',
	'QAR' => '&#65020;',
	'RON' => '&#108;&#101;&#105;',
	'RSD' => '&#1044;&#1080;&#1085;&#46;',
	'RUB' => '&#1088;&#1091;&#1073;',
	'RWF' => '&#1585;.&#1587;',
	'SAR' => '&#65020;',
	'SBD' => '&#36;',
	'SCR' => '&#8360;',
	'SDG' => '&#163;', // ?
	'SEK' => '&#107;&#114;',
	'SGD' => '&#36;',
	'SHP' => '&#163;',
	'SLL' => '&#76;&#101;', // ?
	'SOS' => '&#83;',
	'SRD' => '&#36;',
	'STD' => '&#68;&#98;', // ?
	'SVC' => '&#36;',
	'SYP' => '&#163;',
	'SZL' => '&#76;', // ?
	'THB' => '&#3647;',
	'TJS' => '&#84;&#74;&#83;', // ? TJS (guess)
	'TMT' => '&#109;',
	'TND' => '&#1583;.&#1578;',
	'TOP' => '&#84;&#36;',
	'TRY' => '&#8356;', // New Turkey Lira (old symbol used)
	'TTD' => '&#36;',
	'TWD' => '&#78;&#84;&#36;',
	'TZS' => '',
	'UAH' => '&#8372;',
	'UGX' => '&#85;&#83;&#104;',
	'USD' => '&#36;',
	'UYU' => '&#36;&#85;',
	'UZS' => '&#1083;&#1074;',
	'VEF' => '&#66;&#115;',
	'VND' => '&#8363;',
	'VUV' => '&#86;&#84;',
	'WST' => '&#87;&#83;&#36;',
	'XAF' => '&#70;&#67;&#70;&#65;',
	'XCD' => '&#36;',
	'XDR' => '',
	'XOF' => '',
	'XPF' => '&#70;',
	'YER' => '&#65020;',
	'ZAR' => '&#82;',
	'ZMK' => '&#90;&#75;', // ?
	'ZWL' => '&#90;&#36;',
);
return $currency_symbols[$code];
}
function get_currency_list(){
$currency =	array (
            'ALL' => 'Albania Lek',
            'AFN' => 'Afghanistan Afghani',
            'ARS' => 'Argentina Peso',
            'AWG' => 'Aruba Guilder',
            'AUD' => 'Australia Dollar',
            'AZN' => 'Azerbaijan New Manat',
            'BSD' => 'Bahamas Dollar',
            'BBD' => 'Barbados Dollar',
            'BDT' => 'Bangladeshi taka',
            'BYR' => 'Belarus Ruble',
            'BZD' => 'Belize Dollar',
            'BMD' => 'Bermuda Dollar',
            'BOB' => 'Bolivia Boliviano',
            'BAM' => 'Bosnia and Herzegovina Convertible Marka',
            'BWP' => 'Botswana Pula',
            'BGN' => 'Bulgaria Lev',
            'BRL' => 'Brazil Real',
            'BND' => 'Brunei Darussalam Dollar',
            'KHR' => 'Cambodia Riel',
            'CAD' => 'Canada Dollar',
            'KYD' => 'Cayman Islands Dollar',
            'CLP' => 'Chile Peso',
            'CNY' => 'China Yuan Renminbi',
            'COP' => 'Colombia Peso',
            'CRC' => 'Costa Rica Colon',
            'HRK' => 'Croatia Kuna',
            'CUP' => 'Cuba Peso',
            'CZK' => 'Czech Republic Koruna',
            'DKK' => 'Denmark Krone',
            'DOP' => 'Dominican Republic Peso',
            'XCD' => 'East Caribbean Dollar',
            'EGP' => 'Egypt Pound',
            'SVC' => 'El Salvador Colon',
            'EEK' => 'Estonia Kroon',
            'EUR' => 'Euro Member Countries',
            'FKP' => 'Falkland Islands (Malvinas) Pound',
            'FJD' => 'Fiji Dollar',
            'GHC' => 'Ghana Cedis',
            'GIP' => 'Gibraltar Pound',
            'GTQ' => 'Guatemala Quetzal',
            'GGP' => 'Guernsey Pound',
            'GYD' => 'Guyana Dollar',
            'HNL' => 'Honduras Lempira',
            'HKD' => 'Hong Kong Dollar',
            'HUF' => 'Hungary Forint',
            'ISK' => 'Iceland Krona',
            'INR' => 'India Rupee',
            'IDR' => 'Indonesia Rupiah',
            'IRR' => 'Iran Rial',
            'IMP' => 'Isle of Man Pound',
            'ILS' => 'Israel Shekel',
            'JMD' => 'Jamaica Dollar',
            'JPY' => 'Japan Yen',
            'JEP' => 'Jersey Pound',
            'KZT' => 'Kazakhstan Tenge',
            'KPW' => 'Korea (North) Won',
            'KRW' => 'Korea (South) Won',
            'KGS' => 'Kyrgyzstan Som',
            'LAK' => 'Laos Kip',
            'LVL' => 'Latvia Lat',
            'LBP' => 'Lebanon Pound',
            'LRD' => 'Liberia Dollar',
            'LTL' => 'Lithuania Litas',
            'MKD' => 'Macedonia Denar',
            'MYR' => 'Malaysia Ringgit',
            'MUR' => 'Mauritius Rupee',
            'MXN' => 'Mexico Peso',
            'MNT' => 'Mongolia Tughrik',
            'MZN' => 'Mozambique Metical',
            'NAD' => 'Namibia Dollar',
            'NPR' => 'Nepal Rupee',
            'ANG' => 'Netherlands Antilles Guilder',
            'NZD' => 'New Zealand Dollar',
            'NIO' => 'Nicaragua Cordoba',
            'NGN' => 'Nigeria Naira',
            'NOK' => 'Norway Krone',
            'OMR' => 'Oman Rial',
            'PKR' => 'Pakistan Rupee',
            'PAB' => 'Panama Balboa',
            'PYG' => 'Paraguay Guarani',
            'PEN' => 'Peru Nuevo Sol',
            'PHP' => 'Philippines Peso',
            'PLN' => 'Poland Zloty',
            'QAR' => 'Qatar Riyal',
            'RON' => 'Romania New Leu',
            'RUB' => 'Russia Ruble',
            'SHP' => 'Saint Helena Pound',
            'SAR' => 'Saudi Arabia Riyal',
            'RSD' => 'Serbia Dinar',
            'SCR' => 'Seychelles Rupee',
            'SGD' => 'Singapore Dollar',
            'SBD' => 'Solomon Islands Dollar',
            'SOS' => 'Somalia Shilling',
            'ZAR' => 'South Africa Rand',
            'LKR' => 'Sri Lanka Rupee',
            'SEK' => 'Sweden Krona',
            'CHF' => 'Switzerland Franc',
            'SRD' => 'Suriname Dollar',
            'SYP' => 'Syria Pound',
            'TWD' => 'Taiwan New Dollar',
            'THB' => 'Thailand Baht',
            'TTD' => 'Trinidad and Tobago Dollar',
            'TRY' => 'Turkey Lira',
            'TRL' => 'Turkey Lira',
            'TVD' => 'Tuvalu Dollar',
            'UAH' => 'Ukraine Hryvna',
            'GBP' => 'United Kingdom Pound',
            'USD' => 'United States Dollar',
            'UYU' => 'Uruguay Peso',
            'UZS' => 'Uzbekistan Som',
            'VEF' => 'Venezuela Bolivar',
            'VND' => 'Viet Nam Dong',
            'YER' => 'Yemen Rial',
            'ZWD' => 'Zimbabwe Dollar'
        );

	return $currency;
}

 function get_image_data_2($image_name, $folder_name=""){
		
		if( !empty( $image_name ) ){
				if(!empty($folder_name)){
					return url('/uploads/'.$folder_name.'/'.$image_name);
				}else{
					return url('/upload/'.$image_name);
				}
		}
		else{
			return url('/uploads/no_logo.gif');
		}
		
	}
	
function OtherAdsImageSettings() {
	
	$other_ads_setting = array();
	
	$get_settings = App\Models\OtherAds::get();
	
	foreach( $get_settings as $setting ){
		$other_ads_setting[ $setting["ad_photo"] ] = $setting["ad_photo"];
	}
	
	return $other_ads_setting;
}
 function get_images($image_name, $folder_name=""){
		
	if( !empty( $image_name ) ){
			if(!empty($folder_name)){
				return url('/uploads/'.$folder_name.'/'.$image_name);
			}else{
				return url('/upload/'.$image_name);
			}
	}
	else{
		return url('/uploads/no_logo.gif');
	}
	
}
function getCityCountry($cityid){
	
	$res = DB::table('cities')
	->join('countries', 'countries.id', '=', 'cities.country_id')
	->select('countries.country_name', 'cities.name')->where("cities.id", $cityid)->get();
	
	 $country_city_name  = $res[0]->name .", ". $res[0]->country_name;
	
	return $country_city_name;
}
function getDateddFormat($date){
return  \Carbon\Carbon::createFromTimestamp($date)->format('m/d/Y');
}
function getcities($id){
	$res = array();
	if($id > 0){
	$res = \App\Models\Cities::all()->where('country_id', $id);
}
	return $res;
}

function getListingType($listing_type_id){

	$res = DB::table('listing_type')
	->where("id", $listing_type_id)->get();
	return $res[0]->title;
}
function getListingId($slug){

	$res = DB::table('listing_type')
	->where("slug", $slug)->get();
	return $res[0]->id;
}
 function gravatar_image($email, $size=0, $d="") {
	$hash = md5($email);
	$image_url = 'http://www.gravatar.com/avatar/' . $hash. '?s='.$size.'&d='.$d;
	return $image_url;
   }

function getAddedItemDetail($ad_id){
	$query = "select uad.*,uam.meta_key, uam.meta_value, uam.ad_id from 
	tbl_user_advertisement uad inner join tbl_user_ad_meta uam 
	on uad.id = uam.ad_id where
	uad.id='".$ad_id."'";
	
	$res = DB::select($query);
	//print_r($res);

	$newRes = array();
	$metaData = array();
	
	//die("ee");
	foreach($res as $r){
		if(isset($metaData[$r->meta_key])) {
			
			$dada = $metaData[$r->meta_key];
			$metaData[$r->meta_key] = [];
			if(!is_array($dada)){
				$metaData[$r->meta_key] = array($dada, $r->meta_value);
				
			}else{
				$metaData[$r->meta_key] = array_merge($dada, array($r->meta_value));

			}
			
		 }else{
			  $metaData[$r->meta_key] =  $r->meta_value;
		 }
		
		
		$image = App\Models\Image::all()->where('media_ad_id', $r->ad_id)->where('media_type', 'Images');
		$video = App\Models\Image::all()->where('media_ad_id', $r->ad_id )->where('media_type', 'Videos');
		$teaservideo = App\Models\Image::all()->where('media_ad_id',$r->ad_id)->where('media_type', 'Teaser Video');
		$rate  = App\Models\AdRate::where('ad_id', $r->ad_id)->get();
		$extraService =  App\Models\AdExtraServices::where('ad_id', $r->ad_id)->get();
		$adtour =  App\Models\AdsTouring::where('ad_id', $r->ad_id)->get();
		$ad_listing_type_id =getListingType($r->ad_listing_type_id);
		$login_status=fetchLoginStatus($r->ad_user_id);

		$newRes = array(
			"adId" => $r->id,
			"adUserId" => $r->ad_user_id,
			"adListingTypeId" => $r->ad_listing_type_id,
			"adName" => $r->ad_name,
			"adEmail" => $r->ad_email,
			"adContact" => $r->ad_contactno,
			"adLocation" => $r->ad_location,
			"adSuburbs" =>$r->ad_suburbs,
			'aboutDescription' => $r->about_description,
			"adImage" => $image,
			"adVideo" => $video,
			"adTeaser" => $teaservideo,
			"rate" => $rate,
			"extraService" => $extraService,
			"touring" => $adtour,
			"metaData" => $metaData,
			"login_status" =>$login_status,
			"profile_link" => url("profile/".$r->slug),
		);
	}
	return $newRes;
}

function fetchAllMasterData(){
	$masters = \App\Models\MainMaster::all();

		foreach($masters as $key=>$m){
		
			$master_arr[$m['meta_name']][] = array(
				"id" => $m['id'],
				"value" => $m['meta_value'],
				"icon" => $m['meta_icon']
			);
		}
		return $master_arr;
}

function fetchFeatuedListing($listing_type_id = "", $cityids="", $ad_id = ""){

	$today = time();		
	$query = "select uad.* from 
	tbl_user_advertisement uad where
	uad.plan_expired IS NOT NULL and uad.plan_purchased IS NOT NULL 
	and uad.plan_expired >= '".$today."' and uad.status=1";
	if(!empty($listing_type_id)){
		$query .= " and ad_listing_type_id = '".$listing_type_id."'";
	}
	if(!empty($cityids)){
		$query .=" and ad_location in(".$cityids.")";
	}
	if(!empty($user_id)){
		$query .= " and id in (".$ad_id.")";
	}
	
	$res = DB::select($query);
	DB::connection()->enableQueryLog();
	$newRes = array();
	//$metaData = array();
	foreach($res as $r){
		$metaData = getAllMetaData($r->id);
		

		$image = App\Models\Image::where('media_ad_id', $r->id)->where('media_type','Images')
		->where('media_status', 'Verified')->where('media_is_default', 1 )->get();
		
		$rate  = App\Models\AdRate::select()->where('ad_id', $r->id)->min('incall_charge');
		$newRes[$r->id] = array(
			"adId" => $r->id,
			"slug" => $r->slug,
			"adUserId" => $r->ad_user_id,
			"adListingTypeId" => $r->ad_listing_type_id,
			"adName" => $r->ad_name,
			"adEmail" => $r->ad_email,
			"adContact" => $r->ad_contactno,
			"adLocation" => $r->ad_location,
			"adImage" => $image->first()->media_filename,
			"rate" => $rate,
			"metaData" => $metaData
		);
		
		
	}
	
	return $newRes;
    }
	function getAllMetaData($adId){
		$metaData  = array();
		$adMeta = App\Models\UserAdMeta::all()->where('ad_id', $adId);
		
		foreach($adMeta as $r){
			if(isset($metaData[$r->meta_key])) {
			$dada = $metaData[$r->meta_key];
			$metaData[$r->meta_key] = [];
			if(!is_array($dada)){
				
				$metaData[$r->meta_key] = array($dada, $r->meta_value);
				
			}else{
				$metaData[$r->meta_key] = array_merge($dada, array($r->meta_value));

			}
			
		 }else{
			  $metaData[$r->meta_key] =  $r->meta_value;
		 }
		}
		
		return $metaData;
	
	}

function fetchFeatuedListingFilter($listing_type_id, $cityids){
	
	$today = time();		
	$query = "select uad.* from 
	tbl_user_advertisement uad where
	uad.plan_expired IS NOT NULL and uad.plan_purchased IS NOT NULL 
	and uad.plan_expired >= '".$today."' and uad.status=1";
	if(!empty($listing_type_id)){
		$query .= " and ad_listing_type_id = '".$listing_type_id."'";
	}
	if(!empty($cityids)){
		$query .=" and ad_location in(".$cityids.")";
	}
	
	
	$res = DB::select($query);
	DB::connection()->enableQueryLog();
	$newRes = array();
	
	foreach($res as $r){
		
		$image = App\Models\Image::where('media_ad_id', $r->id)->where('media_type','Images')
		->where('media_status', 'Verified')->where('media_is_default', 1 )->first()->media_filename;
		$login_status=fetchLoginStatus($r->ad_user_id);
		$rate  = App\Models\AdRate::select()->where('ad_id', $r->id)->min('incall_charge');
		$ad_listing_type_id =getListingType($r->ad_listing_type_id);
		$newRes[] = array(
			"adId" => $r->id,
			"slug" => $r->slug,
			"adUserId" => $r->ad_user_id,
			"adListingTypeId" => $ad_listing_type_id,
			"adName" => $r->ad_name,
			"adEmail" => $r->ad_email,
			"adContact" => $r->ad_contactno,
			"adLocation" => getCityCountry($r->ad_location),
			"ad_small_image" => getS3ImageURL($image, '252*384'),
			"ad_large_image" => getS3ImageURL($image, '508*762'),
			"rate" => $rate,
			"login_status" => $login_status,
			"age" => getSpecificMeta('age',$r->id, true),
			"bustsize" => getSpecificMeta('bustsize', $r->id,true),
			"height" => getSpecificMeta('height', $r->id,true),
			"weight" => getSpecificMeta('weight', $r->id,true),
			"ethinicity" => getSpecificMeta('ethinicity', $r->id),
			"haircolor" => getSpecificMeta('haircolor', $r->id, true),
			"eyecolor" => getSpecificMeta('eyecolor', $r->id, true),
			"profile_link" => url("profile/".$r->slug),
		);
		
		
	}
	return $newRes;
    }
    function getMasterValue($id){

    	$res = 	\App\Models\MainMaster::all()->where('id', $id)->first()->meta_value;
    	return $res;


    }
    function getSpecificMeta($meta_key, $adid, $ismaster = false){
    	
    	$value = \App\Models\UserAdMeta::all()->where('meta_key', $meta_key)->where('ad_id', $adid)->first()->meta_value;

    	return !$ismaster ?  $value : getMasterValue($value);

    }

function getNearByCitiesByIp($lat, $lon){
	
	$res = DB::table("cities")
	->select("cities.id"
	    ,DB::raw("6371 * acos(cos(radians(" . (int)$lat . ")) 
	    * cos(radians(lattitude)) 
	    * cos(radians(longitude) - radians(" . (int)$lon . ")) 
	    + sin(radians(" .(int)$lat. ")) 
	    * sin(radians(lattitude))) AS distance"))
	    ->groupBy("cities.id")
	    ->havingRaw("distance <= 100")
	    ->orderBy("distance")
	    ->get();
	 $cityids =  $res->pluck('id')->toArray();
	 if(!empty($cityids)){
	 	 return implode(",", $cityids);
	 	}else{

			return '';
	 	}
	
}
    function getNearByCities($lat, $lon){
	
	$res = DB::table("cities")
	->select("cities.id"
	    ,DB::raw("6371 * acos(cos(radians(" . (int)$lat . ")) 
	    * cos(radians(lattitude)) 
	    * cos(radians(longitude) - radians(" . (int)$lon . ")) 
	    + sin(radians(" .(int)$lat. ")) 
	    * sin(radians(lattitude))) AS distance"))
	    ->groupBy("cities.id")
	    ->havingRaw("distance <= 100")
	    ->orderBy("distance")
	    ->get();
	 $cityids =  $res->pluck('id')->toArray();

	$listRes = fetchFeatuedListing("", implode(",", $cityids));
	return $listRes;
	}
	function getWishlist(){
		$shortlist = array();
		$user= Auth::user();
		//$guestid = "";
		if(!empty($user)){
			$guestid = $user->id;

		}else{

		$guest_ip_address = Request::getClientIp();

			//$guest_ip_address='122.176.59.133';
			$guests = \App\Models\Guests::where('guest_ip_address', $guest_ip_address)->get();
			if(count($guests) > 0){
			$guestid = $guests[0]->guest_id;
			}
		}
		if(!empty($guestid)){
		$shortlist = \App\Models\ShortList::where('short_guest_id', $guestid)->get();
		}
		
		return $shortlist;
	}
	

	
	
	function getAdName($id){
		$res  =\App\Models\UserAdvertisement::select('ad_name')->where('id', $id)->get();
		return $res[0]->ad_name;

	}
	function getAdImage($id){
		$res = \App\Models\Image::select('media_filename')
		->where('media_ad_id', $id)->where('media_is_default', '1')->where('media_status', 'Verified')->get();
		return $res[0]->media_filename;
	}
	function getMaterData($id){
		$res = \App\Models\MainMaster::where('id', $id)->get();
		return $res[0]->meta_value;
	}
	function getMaterIcon($id){
		$res = \App\Models\MainMaster::where('id', $id)->get();
		return $res[0]->meta_icon;
	}
	function getPlanDetail($plan_id){
		$res = \App\Models\Plans::where('id', $plan_id)->first();
		return $res;
	}
    function getAllTestimonials(){
	    $user = Auth::user();
	    print_r($user);
    }
 function createEditLink($listing_type_id, $slug){
 	$data = array();
	
	$listing_slug = \DB::table('listing_type')->where('id', $listing_type_id)->first()->slug;
	
	$editLink = route('edit-profile', ['slug1' => $listing_slug,'slug2'=>$slug]);
	return $editLink;

 }
    function getUserDashboardData($user_data){
	$data = array();
	$data['query'] = array();
	$data['query'] = \DB::table("user_advertisement")->where('ad_user_id', $user_data->id)->limit(1)
	->orderBy('id', 'desc')->get();
	$data['stat_views'] = 100;
	$data['stat_likes'] = 100;
	$data['stat_clicks'] = 100;
	$data['age'] = '';
	$data['nationality'] = '';
	$data['images'] = array();
	$listing_slug = \DB::table('listing_type')->where('id', $data[query][0]->ad_listing_type_id)->first()->slug;
	
	$data['editLink'] = route('edit-profile', ['slug1' => $listing_slug,'slug2'=>$data[query][0]->slug]);
	$data['profile_images'] = array();
	if(count($data['query']) > 0){
		
		$ad_statss = \App\Models\AdStats::all()->where('stat_ad_id',$data['query'][0]->id);
		
		$data['stat_views'] = (int)$ad_statss[0]->stat_views;
		$data['stat_likes'] = (int)$ad_statss[0]->stat_likes;
		$data['stat_clicks'] = (int)$ad_statss[0]->stat_clicks;
		$data['age'] = \App\Models\UserAdMeta::where('ad_id', $data['query'][0]->id)->where('meta_key','age')->first();
		
		$data['minRate'] = \App\Models\AdRate::where('ad_id', $data['query'][0]->id)->min('incall_charge');
		
		$data['nationality'] = \App\Models\UserAdMeta::where('ad_id', $data['query'][0]->id)->where('meta_key','ethinicity')->first();
		$data['website_url'] = \App\Models\UserAdMeta::where('ad_id', $data['query'][0]->id)->where('meta_key','website_url')->first();
		///$data['profile_images'] =  \App\Models\Image::where('media_ad_id', $data['query'][0]->id)->where('media_status', 'Verified')->where('media_type', 'Images')->where('media_is_default', '1')->first();
		$data['images'] =  \App\Models\Image::where('media_ad_id', $data['query'][0]->id)->where('media_status', 'Verified')->where('media_type', 'Images')->get();
		$data['social_links'] = \App\Models\UserAdMeta::where('ad_id', $data['query'][0]->id)->where('meta_key', 'like', '%social_links_%')->get();
	}
	return $data;
    }

 
    function getS3VideoURL($name){
	    return "https://hosg.s3.amazonaws.com/videos/".$name;
    }

    function getS3ImageURL($name, $dimension){
	    $namew = explode(".",$name);
	
	   $image_name = $namew[0];
	   
	return "https://hosg.s3.amazonaws.com/ad_images/".$name."_".$dimension.".jpg";
}

function getTeaserVideo(){
	 if(!empty($_COOKIE['user_latitude']) && $_COOKIE['user_longitude']){
	$locations = getNearByCitiesByIp($_COOKIE['user_latitude'], $_COOKIE['user_longitude']);
	}
	$today = time();		
	$query = "select uad.* from 
	tbl_user_advertisement uad where
	uad.plan_expired IS NOT NULL and uad.plan_purchased IS NOT NULL 
	and uad.plan_expired >= '".$today."' and uad.status=1";
	if(!empty($locations) > 0){

			$query .= " and  uad.ad_location in(".$locations.")";
		}
	$res = DB::select($query);
	
	$teservideoarr = array();
	if(count($res) > 0){
		foreach($res as $rs){
			$teaservideo = \App\Models\Image::where('media_type', 'Teaser Video')->where('media_status', 'Verified')->where('media_ad_id', $rs->id)->first();
			$rate  = \App\Models\AdRate::select()->where('ad_id', $rs->id)->min('incall_charge');
	
			if(count($teaservideo) > 0){
				$teservideoarr[] = array(
					'name' => $rs->ad_name,
					'location' => getCityCountry($rs->ad_location),
					'listingtype' => getListingType($rs->ad_listing_type_id),
					'age'=>\App\Models\UserAdMeta::all()->where('meta_key', 'age')->where('ad_id', $rs->id)->first()->meta_value,
					'bustsize'=>\App\Models\UserAdMeta::all()->where('meta_key', 'bustsize')->where('ad_id', $rs->id)->first()->meta_value,
					'height'=>\App\Models\UserAdMeta::all()->where('meta_key', 'height')->where('ad_id', $rs->id)->first()->meta_value,
					'contact' => $rs->ad_contactno,
					'ad_id'=>$rs->id,
					'rate'=>$rate,
					'teaservideo'=>getS3VideoURL($teaservideo->media_filename),
					'viewlink'=>route('profile.', ['slug' => $rs->slug])
				);

			} 



		}
	}
	

	return $teservideoarr;
}
function getServiceName($id){
	return $data = \App\Models\MainMaster:: all()->where('id', $id)->first()->meta_value;
}

function sendRequesToServer($requestdata = array()){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://13.236.176.232/socket/ws_client.php");
	// SSL important
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLINFO_HEADER_OUT, true);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $requestdata);
	$output = curl_exec($ch);
	if($output === false)
		{
		echo 'Curl error: ' . curl_error($ch);
		}else{
			echo $output;
		}
	curl_close($ch);

    }
    function createSlug($title, $b_model, $fieldname, $id = 0)
    {
	  
        // Normalize the title
        $slug = str_slug($title);

        // Get any that could possibly be related.
        // This cuts the queries down by doing it once.
	   $allSlugs = getRelatedSlugs($slug, $b_model, $fieldname, $id);
	  
		
			// If we haven't used it before then we are all good.
			if (! $allSlugs->contains('slug', $slug)){
				return $slug;
			}

			// Just append numbers like a savage until we find not used.
			for ($i = 1; $i <= 10; $i++) {
				$newSlug = $slug.'-'.$i;
				if (! $allSlugs->contains('slug', $newSlug)) {
				return $newSlug;
				}
			}

		

    }

    function getRelatedSlugs($slug, $b_model, $fieldname, $id = 0)
    {
	    
	 $models = 'App\\Models\\'.$b_model;
	
     $ss = $models::select($fieldname)->where($fieldname, 'like', $slug.'%')
            ->where('id', '<>', $id)
		  ->get();
		  
		  return $ss;
    }

    function boostingProfiles(){
	    $today = time();		
	    if(!empty($_COOKIE['user_latitude']) && !empty($_COOKIE['user_longitude'])){
		$locations = getNearByCitiesByIp($_COOKIE['user_latitude'], $_COOKIE['user_longitude']);
		}
		$query = "select uad.*,  abl.total_boost, abl.boost_done from tbl_user_advertisement uad inner join tbl_ad_boost_log abl on abl.ad_id = uad.id  where uad.plan_expired IS NOT NULL and uad.plan_purchased IS NOT NULL and uad.plan_expired >= '".$today."' and uad.status=1 and abl.next_boost_time IS NULL or abl.next_boost_time > '".$today."' and abl.boost_done < abl.total_boost and uad.ad_listing_type_id=1";
		if(!empty($locations) > 0){

			$query .= " and  uad.ad_location in(". $locations.")";
		}
		
		$data = array();
		$res = DB::select($query);
		
		if(count($res) > 0){
			foreach($res as $r){
				$image = App\Models\Image::where('media_ad_id', $r->id)->where('media_type','Images')->where('media_status', 'Verified')->where('media_is_default', 1 )->get()->first()->media_filename;
				$data[] = array(
					'image_url' => getS3ImageURL($image,'377*625'),
					'login_status'=>fetchLoginStatus($r->ad_user_id),
					'profile_link' => url('profile/'.$r->slug),
				);
			}
		}

		return $data;
		

    }
    function fetchLoginStatus($userId){

    	$userdata = \App\Models\User::all()->where('id', $userId)->first()->login_status;
    	return $userdata;

    }

    function getfilterlocation(){
 		if(!empty($_COOKIE['user_latitude']) && !empty($_COOKIE['user_longitude'])){
		$locations = getNearByCitiesByIp($_COOKIE['user_latitude'], $_COOKIE['user_longitude']);
		}
DB::connection()->enableQueryLog();
		if(!empty($locations)){
			$data = DB::table('user_advertisement')
    	->join('cities', 'user_advertisement.ad_location', '=', 'cities.id')
    	->whereIn('cities.id',explode(',', $locations))
    	->groupBy('user_advertisement.ad_location')->select('cities.name', 'cities.id')->get();
    
    }else{
    	$data = DB::table('user_advertisement')
    	->join('cities', 'user_advertisement.ad_location', '=', 'cities.id')
    	->groupBy('user_advertisement.ad_location')->select('cities.name', 'cities.id')->get();
    	
    }
    $queries = DB::getQueryLog();
      //  return dd($queries);
    //print_r($data);
    return $data;


    }
function updateStats($field, $ad_id){

	if(!empty($field) && !empty($ad_id)){
	$res = App\Models\Stats::where('stat_ad_id', $ad_id)->firstOrFail();
		if(count($res) > 0){
			$res->$field = (int)$res->$field + 1;
			$res->save();
		}else{
			$stat = new App\Models\Stats();
			$stat->$field = 1;
			$stat->save();
		}

	}
}
