<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use Auth;
use Input;
use Hash;

use App\Models\User;
use App\Models\Role;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/* For Login throttling - learn more about this 
use Illuminate\Foundation\Auth\ThrottlesLogins;*/
/* use Illuminate\Foundation\Auth\RegistersUsers; */
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class AuthenticationController extends Controller
{
	/* use AuthenticatesUsers, RegistersUsers {
		AuthenticatesUsers::redirectPath insteadof RegistersUsers;
		AuthenticatesUsers::guard insteadof RegistersUsers;
	} */
    use AuthenticatesUsers;
    //use ThrottlesLogins;
	
	protected $loginPath = 'admin/';
	
	protected $redirectPath = 'admin/dashboard';
	
	protected $redirectAfterLogout = 'admin/';
	
     /**
	 * Show Login form for letting Super Admin's login to system
	 * GET /sessions/create
	 *
	 * @return Response
	 */
	public function showLoginForm()
	{	
		return view('bracket-admin.login.admin-login');
	}
	
    /**
	 * Authenticate Login User's
	 * GET /sessions/create
	 *
	 * @return Response
	 */
	public function login(Request $request)
	{
		$this->validate($request, [
			'email' => 'required',
			'password' => 'required',
        ], [
            'email.required' => 'Please enter your Email Id.',
            'password.required' => 'Please Enter your Password.'
        ]);
		
		/* 
		Code could only be used till laravel 5.2
		//Check if Laravel Throttling is enabled or not for brute force attacks
        $throttles_enabled = $this->isUsingThrottlesLoginsTrait();

        if ($throttles_enabled && $this->hasTooManyLoginAttempts($request)) {
            return $this->sendLockoutResponse($request);
        }
		*/
		$login_cred = $request->only( 'email', 'password');
		
		if ($this->hasTooManyLoginAttempts($request)) {
			$this->fireLockoutEvent($request);
			return $this->sendLockoutResponse($request);
		}
		
		if (Auth::attempt($login_cred, $request->has('remember'))) {
            return $this->sendLoginResponse($request);
        }
		else{
			$this->incrementLoginAttempts($request);
		}
		
		return redirect()->back()
            ->withInput($request->only( $request->input("email"), 'remember'))
            ->withErrors([
                'email' => trans('auth.failed'),
            ]);
	}
	
	public function logout(Request $request){
		Auth::logout();
		
        $request->session()->flush();
        $request->session()->regenerate();
		
		return redirect('admin/')->with("logout_message", 'Logout Successfull' );
	}
	
	/**
     * set Login Redirect Path
     *
     * @return string
     */
    public function redirectPath()
    {
        return 'admin/dashboard';
    }
	
	
	public function forgotPassword(Request $request){
		$this->validate( $request, [
			'forgot_email' => 'required|email|min:3|max:255',
		  ],[
			'forgot_email.required' => 'Please enter Email Address.',
			'forgot_email.email' => 'Please Enter Valid Email.',
			'forgot_email.min' => 'Email Address should be atleast 4 Characters Long.',
			'forgot_email.max' => 'Email Address shouldn\'t exceed more than 255 Characters.',
		]);
		
		$email_address = $request->input( 'forgot_email' );
		
		$user_data = User::role( [ Role::ROLE_SUPERADMIN, Role::ROLE_SUBADMIN, Role::ROLE_CBCUSER ] )->where("email", $email_address)->first();
		
		if( $user_data && intval( $user_data->id ) > 0 ){
			
			$password = 'Admin@123';//str_random(8);

			$user_data->password = Hash::make( $password );
			$user_data->save();
			
			$email_content = array();
			$email_content["user_name"] = $user_data->name;
			$email_content["new_password"] = $password;
			
			/* $email_message = new EmailMessage();
			$email_message->singleMailSendIntegration( $user_data->email, "ForgotPassword", $email_content ); */
			
			return redirect()->back()
				->withInput( $request->only('shown_container') )
				->with("forgot_message" , "Verification code has been sent to Email Address.");
		}
		else{
			return redirect()->back()
					->withInput( $request->all() )
					->withErrors([
						"forgot_email" => "Email Address not found.",
					]);
		}
	}
}
