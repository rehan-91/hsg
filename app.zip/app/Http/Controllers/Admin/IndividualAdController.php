<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Hash;
use Auth;
use Session;
use DB;

use App\Models\User;
use App\Models\MainMaster;

use App\Models\Role;
use App\Models\VerifyUser;
use App\Models\UserOtps;
use App\Models\EmailMessage;
use App\Models\MetaData;
use App\Models\Plans;
use App\Models\Image;
use App\Models\Cities;
use App\Models\Countries;
use App\Models\AdRate;
use App\Models\AdMeta;
use App\Models\OtherAds;
use App\Models\UserAdvertisement;
use App\Models\AdExtraServices;
use App\Models\UserAdMeta;
use App\Models\AdsTouring;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests;
use Imageupload;
use Carbon\Carbon;

class IndividualAdController extends Controller
{
    //
    
    function index(){

        $indpendent = UserAdvertisement::where('ad_listing_type_id','1')->get();
        return view('bracket-admin.ads.independent-escort.index', compact('indpendent'));
    }
    
    
    function edit($id){

        $listdata  = array();
        $ad_listing_type_id = UserAdvertisement::all()->where('id', $id)->first(); 
        $user_ad_id = UserAdvertisement::all()->where('id', $id)->first();
        if(!empty($user_ad_id)){
            
            $listdata = getAddedItemDetail($user_ad_id);
        }
        
        
            $data = UserAdvertisement::all()->where('id', $id);
            
            if(count($data) > 0){
                $user_ad_id = $data->first()->id;
                UserAdvertisement::all()->put('user_ad_id', $user_ad_id);
                
            $listdata = getAddedItemDetail($data->first()->id);

            }
        

        $master_arr = fetchAllMasterData();

        $age = $master_arr['age'];
        $social_media_links = $master_arr['social_media_link'];
        $generalsettings = $this->generalSettings;
        $height = $master_arr['height'];
        $weight = $master_arr['weight'];
        $orientation = $master_arr['orientation'];
        $nationality = $master_arr['nationality'];
        $haircolor = $master_arr['haircolor'];
        $hairlength = $master_arr['hairlength'];
        $dresssize = $master_arr['dresssize'];
        $shoessize = $master_arr['shoessize'];
        $eyecolor = $master_arr['eyecolor'];
        $bustsize = $master_arr['bustsize'];
        $serviceavailablefor =  $master_arr['service-available-for'];
        $servicesavailable =  $master_arr['service-available'];
        $servicetype =$master_arr['service-type'];
        $bodytype = $master_arr['body-type'];
        $personal = $master_arr['personal'];
        $piercing = $master_arr['piercing'];
        $wishlistthings = $master_arr['wishlist-things'];
        $favthings = $master_arr['fav_things'];
        $plans = Plans::all()->where('listing_type_id', '1');
        $cities = Cities::all();
        $countries = Countries::all();
        return view('bracket-admin.ads.independent-escort.edit', compact('age','generalsettings','height','weight','haircolor','hairlength','dresssize','shoessize','eyecolor','nationality','orientation','bodytype','serviceavailablefor','servicesavailable','servicetype','piercing','personal','wishlistthings','bustsize','favthings','plans','countries','countries',
         'social_media_links','listdata','cities','user_ad_id','listdata','ad_listing_type_id'));
    }


    function updateIndividualDetails(Request $request){



          // $validator = Validator::make( $request->all(),
          $this->validate($request, [
                "ad_name" => 'required|min:3',
                "ad_email" =>'required',
                "ad_contactno" => 'required',
                'country_name' => 'required',
                'city_name' => 'required',
                'suburbs' => 'required',
                'additional_information' => 'required|min:50',
                'rdo' => 'required',
                'booking_method' => 'required',
                'personal' => 'required',
                'age' => 'required',
                'bustsize' => 'required',
                'gender' => 'required',
                'weight' => 'required',
                'nationality' => 'required',
                'height' => 'required',
                'orientation' => 'required',
                'eyecolor' => 'required',
                'haircolor' => 'required',
                'hairlength' => 'required',
                'dresssize' => 'required',
                'shoessize' => 'required'
                
            ],[
                "ad_name.required" => "Please enter name.",
                "ad_email.required" => "Please enter email.",
                "ad_contactno.required" => "Please enter phone number.",
                "country_name.required" => "Please choose country.",
                "city_name.required" => "Please choose city name.",
                "suburbs.required" => "Please enter Suburbs/Local area.",
                "additional_information.required" => "Please write addtional information,",
                "additional_information.min" => "Please write in 50 words atleast.",
                "rdo.required" => "Please choose gender type.",
                "booking_method.required" => "Please choose booking method.",
                "personal.required" => "Please choose one personal type.",
                'age.required' => 'Enter your age.',
                'bustsize.required' => ' Please Choose your bustsize.',
                'gender.required' => 'Please select your gender.',
                'weight.required' => 'Enter your weight.',
                'nationality.required' => 'Please Choose nationality.',
                'eyecolor.required' => 'Please choose eye color.',
                'haircolor.required' => 'Please choose hair color.',
                'hairlength.required' => 'Please choose hair length .',
                'dresssize.required' => 'Please choose dress size .',
                'shoessize.required' => 'Please choose shoes size .'
               
                
            ]);
        //   if ($validator->fails()) {
            
        //     return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
               
        // }


        if(empty($request->input('ad_name'))){
            
            return;
        }

        \DB::enableQueryLog();
        $user_data = UserAdvertisement::all()->where('id', $id);
        
        if(empty($request->input("ad_listing_type_id"))){

            return;
        }
        $listingExistOrNot = listingtype($request->input("ad_listing_type_id"));
        if(count($listingExistOrNot) == 0){
            return;
        }
        
        if(!empty($request->input('user_ad_id'))){
            $userAd = new UserAdvertisement();
            $ad_id = $request->input('user_ad_id');
            $userAd = UserAdvertisement::findOrFail($ad_id);
            $userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
            $userAd->ad_name = $request->input("ad_name");
            $userAd->ad_email = $request->input("ad_email");
            $userAd->ad_contactno = $request->input("ad_contactno");
            $userAd->ad_country = $request->input("country_name");
            $userAd->ad_location = $request->input("city_name");
            $userAd->ad_suburbs = $request->input("suburbs");
            $userAd->about_description = $request->input("about_description");
            $userAd->save();
            
        }else{          
            $userAd = new UserAdvertisement();
            $userAd->ad_user_id = $user_data->id;

            $userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
            $userAd->ad_name = $request->input("ad_name");
            $userAd->ad_email = $request->input("ad_email");
            $userAd->ad_contactno = $request->input("ad_contactno");
            $userAd->ad_country = $request->input("country_name");
            $userAd->ad_location = $request->input("city_name");
            $userAd->ad_suburbs = $request->input("suburbs");
            $userAd->about_description = $request->input("about_description");
            $userAd->status = 0;
            $userAd->save();
            $ad_id = $userAd->id;
        }
        $request->session()->put('user_ad_id', $ad_id);
        $requestData = $request->all();
        unset($requestData['ad_listing_type_id']);
        unset($requestData['ad_name']);
        unset($requestData['ad_email']);
        unset($requestData['ad_contactno']);
        unset($requestData['country_name']);
        unset($requestData['city_name']);
        unset($requestData['suburbs']);
        unset($requestData['about_description']);
        unset($requestData['_token']);
        if(!empty($requestData['custom_fav_things'])){
            
            
            foreach($requestData['custom_fav_things'] as $custkey=>$fav){               
                    $masterObjArray = [
                        'meta_name' => 'fav_things',
                        'meta_value' => $fav['label']
                    ];
                
                    $mainMaster = MainMaster::updateOrCreate([
                    ['meta_name', '=', 'fav_things'],
                    ['meta_value', '=', $fav['label']]
                    ],$masterObjArray );
                    $masterid = $mainMaster->id;
                $key = "fav_things_".$masterid;
                $favValue = $fav['value'];              
                $data_array = [
                    'meta_key' => $key,
                    'meta_value' => $favValue,
                    'ad_id'=> $ad_id
                 ];
                 
                $fetchExistData  = UserAdMeta::updateOrCreate([
                    ['meta_key', '=', $key],
                    ['ad_id', '=', $ad_id],
                ], $data_array);
                
            }
        }
    

        if(!empty($requestData['custom_wish_things'])){
            
            foreach($requestData['custom_wish_things'] as $wishkey=>$cusw){
                $masterObjArray = [
                    'meta_name' => 'wishlist-things',
                    'meta_value' => $cusw['label']
                ];
            
                $mainMaster = MainMaster::updateOrCreate([
                ['meta_name', '=', 'wishlist-things'],
                ['meta_value', '=', $cusw['label']]
                ],$masterObjArray );
                $wmasterid = $mainMaster->id;
                $wkey = "wish_things_".$wmasterid;
                $wishValue = $cusw['value'];
                $data_array = [
                    'meta_key' => $wkey,
                    'meta_value' => $wishValue,
                    'ad_id'=> $ad_id
                 ];
                 
                $fetchExistData  = UserAdMeta::updateOrCreate([
                    ['meta_key', '=', $wkey],
                    ['ad_id', '=', $ad_id],
                ], $data_array);
            }
        }
        unset($requestData['custom_fav_things']);
        unset($requestData['custom_wish_things']);
        foreach($requestData as $key => $req){
            $fetchExistData  = UserAdMeta::select()->where([
                ['meta_key', '=', $key],
                ['ad_id', '=', $ad_id],
            ]); 
            if(count($fetchExistData) > 0){
                    $fetchExistData->delete();
            }
                if(is_array($requestData[$key])){
                
                    foreach($req as $r){
                        if(!empty($r)){
                        $user_ad_meta = new UserAdMeta();
                        $user_ad_meta->meta_key = $key;
                        $user_ad_meta->meta_value = $r;
                        $user_ad_meta->ad_id = $ad_id;
                        //print_r($user_ad_meta);
                        $user_ad_meta->save();
                        //$query = \DB::getQueryLog();
                        //print_r(end($query));
                        }
                        
                    }
                }else{
                    
                        if(!empty($req)){
                        $user_ad_meta = new UserAdMeta();
                        $user_ad_meta->meta_key = $key;
                        $user_ad_meta->meta_value = $req;
                        $user_ad_meta->ad_id = $ad_id;
                        $user_ad_meta->save();
                        //$query = \DB::getQueryLog();
                        //print_r(end($query));
                        }
            }

        }
    
        return redirect()->route('admin.individual.index')->withsuccess('Updated');

    }
    
} 
