<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\MainMaster;
use App\Http\Requests;
use App\Http\Controllers\Controller;


use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;

class MastersController extends Controller
{
       use HasRoles;
	
	protected $guard_name = 'web';
	
	protected $generalSettings;
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
		
		//For fetching translations in defined locale for whole controller
		app()->setLocale('en');
    }
    
    //Master Tab 
    public function mastertab(){

      return view('bracket-admin.masters.index');
    }

//--Age settings--//

    public function age() {
          $data = MainMaster::all();
              return view('bracket-admin.masters.age.index');
      }
      public function ageCreate(){
          
          return view('bracket-admin.masters.age.create');
      }
      public function ageEdit($id){
          
          
            $age = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.age.edit', compact('age'));
			
        
      }
    public function ageStore(Request $request){
        
    $this->validate($request, [
			'age_value' => 'required'	
        ], [
            'age_value.required' => 'Please enter age value.',
        ]);
          
        $objAge = new MainMaster;
        $objAge->meta_name = $request->input('meta_name');
		    $objAge->meta_value = $request->input('age_value');
		    $objAge->save();
        return redirect()->route('admin.masters.age')->withsuccess('Age  Added Successfully.');
          
    }
     public function ageUpdate(Request $request,$id){
        
    $this->validate($request, [
			'age_value' => 'required'	
        ], [
            'age_value.required' => 'Please enter age value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('age_value');
        $objAge->save();
         return redirect()->route('admin.masters.age')->withinfo('Age updated Successfully.');
          
    }
    
    public function ageAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','age');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
    //--Age End--->


    //--Height Setting--->
    public function height() {

              return view('bracket-admin.masters.height.index');
      }
      public function heightCreate(){
          
          return view('bracket-admin.masters.height.create');
      }
      public function heightEdit($id){
          
          
            $height = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.height.edit')
			->with('height', $height)
			->withModel($height);
        
      }
    public function heightStore(Request $request){
        
    $this->validate($request, [
			'height_value' => 'required'	
        ], [
            'height_value.required' => 'Please enter height value.',
        ]);
          
        $objHeight = new MainMaster;
		$objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('height_value');
        $objHeight->save();
        return redirect()->route('admin.masters.height')->withsuccess('Height  Added Successfully.');
          
    }
     public function heightUpdate(Request $request,$id){
        
    $this->validate($request, [
			'height_value' => 'required'	
        ], [
            'height_value.required' => 'Please enter height value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('height_value');
        $objAge->save();
         return redirect()->route('admin.masters.height')->withinfo('Height updated Successfully.');
          
    }
    
    public function heightAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','height');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.heightedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.heightedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
    //--end height---//

    //--Weight -- setting-->
     public function weight() {

              return view('bracket-admin.masters.weight.index');
      }
      public function weightCreate(){
          
          return view('bracket-admin.masters.weight.create');
      }
      public function weightEdit($id){
          
          
            $weight = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.weight.edit', compact('weight'));
			
        
      }
    public function weightStore(Request $request){
        
    $this->validate($request, [
			'weight_value' => 'required'	
        ], [
            'weight_value.required' => 'Please enter weight value.',
        ]);
          
        $objHeight = new MainMaster;
		$objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('weight_value');
        $objHeight->save();
        return redirect()->route('admin.masters.weight')->withsuccess( 'Weight  Added Successfully.');
          
    }
     public function weightUpdate(Request $request, $id){
        
    $this->validate($request, [
			'weight_value' => 'required'	
        ], [
            'weight_value.required' => 'Please enter weight value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('weight_value');
        $objAge->save();
         return redirect()->route('admin.masters.weight')->withinfo('message', 'Weight updated Successfully.');
          
    }
    
    public function weightAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','weight');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.weightedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.weightedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
    //--Weight end-->

    //--Orientation setting--//
    
     public function orientation() {

              return view('bracket-admin.masters.orientation.index');
      }
      public function orientationCreate(){
          
          return view('bracket-admin.masters.orientation.create');
      }
      public function orientationEdit($id){
          
          
            $orientation = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.orientation.edit' , compact('orientation'));
        
      }
    public function orientationStore(Request $request){
        
    $this->validate($request, [
			'orientation_value' => 'required'	
        ], [
            'orientation_value.required' => 'Please enter orientation value.',
        ]);
          
        $objHeight = new MainMaster;
		$objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('orientation_value');
        $objHeight->save();
        return redirect()->route('admin.masters.orientation')->withsuccess('orientation  Added Successfully.');
          
    }
     public function orientationUpdate(Request $request, $id){
        
    $this->validate($request, [
			'orientation_value' => 'required'	
        ], [
            'orientation_value.required' => 'Please enter orientation value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('orientation_value');
        $objAge->save();
         return redirect()->route('admin.masters.orientation')->withinfo('Orientation updated Successfully.');
          
    }
    
    public function orientationAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','orientation');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.orientationedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.orientationedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
    //--Orientation end--//


         public function nationality() {

              return view('bracket-admin.masters.nationality.index');
      }
      public function nationalityCreate(){
          
          return view('bracket-admin.masters.nationality.create');
      }
      public function nationalityEdit($id){
          
          
            $nationality = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.nationality.edit', compact('nationality'));  
      }
    public function nationalityStore(Request $request){
        
    $this->validate($request, [
			'nationality_value' => 'required'	
        ], [
            'nationality_value.required' => 'Please enter nationality value.',
        ]);
          
        $objHeight = new MainMaster;
		$objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('nationality_value');
        $objHeight->save();
        return redirect()->route('admin.masters.nationality')->withsuccess('nationality  Added Successfully.');
          
    }
     public function nationalityUpdate(Request $request, $id){
        
    $this->validate($request, [
			'nationality_value' => 'required'	
        ], [
            'nationality_value.required' => 'Please enter nationality value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('nationality_value');
        $objAge->save();
         return redirect()->route('admin.masters.nationality')->withinfo('Nationality updated Successfully.');
          
    }
    
    public function nationalityAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','nationality');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.nationalityedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.nationalityedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
//--End nationality--//

    //--Hair Color Setting--//
         public function haircolor() {

              return view('bracket-admin.masters.haircolor.index');
      }
      public function haircolorCreate(){
          
          return view('bracket-admin.masters.haircolor.create');
      }
      public function haircolorEdit($id){
          
          
            $haircolor = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.haircolor.edit', compact('haircolor'));
        
      }
    public function haircolorStore(Request $request){
        
    $this->validate($request, [
			'haircolor_value' => 'required'	
        ], [
            'haircolor_value.required' => 'Please enter haircolor value.',
        ]);
          
        $objHeight = new MainMaster;
		$objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('haircolor_value');
        $objHeight->save();
        return redirect()->route('admin.masters.haircolor')->withsuccess('Haircolor  Added Successfully.');
          
    }
     public function haircolorUpdate(Request $request, $id){
        
    $this->validate($request, [
			'haircolor_value' => 'required'	
        ], [
            'haircolor_value.required' => 'Please enter haircolor value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('haircolor_value');
        $objAge->save();
         return redirect()->route('admin.masters.haircolor')->withinfo('Haircolor updated Successfully.');
          
    }
    
    public function haircolorAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','haircolor');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.haircoloredit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.haircoloredit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
    //--Hair Color end--//

    //--Eye color setting-->
         public function eyecolor() {

              return view('bracket-admin.masters.eyecolor.index');
      }
      public function eyecolorCreate(){
          
          return view('bracket-admin.masters.eyecolor.create');
      }
      public function eyecolorEdit($id){
          
          
            $eyecolor = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.eyecolor.edit', compact('eyecolor'));
			  
      }
    public function eyecolorStore(Request $request){
        
    $this->validate($request, [
			'eyecolor_value' => 'required'	
        ], [
            'eyecolor_value.required' => 'Please enter eyecolor value.',
        ]);
          
        $objHeight = new MainMaster;
		$objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('eyecolor_value');
        $objHeight->save();
        return redirect()->route('admin.masters.eyecolor')->withsuccess('Eyecolor  Added Successfully.');
          
    }
     public function eyecolorUpdate(Request $request, $id){
        
    $this->validate($request, [
			'eyecolor_value' => 'required'	
        ], [
            'eyecolor_value.required' => 'Please enter eyecolor value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('eyecolor_value');
        $objAge->save();
         return redirect()->route('admin.masters.eyecolor')->withinfo('Eyecolor updated Successfully.');
          
    }
    
    public function eyecolorAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','eyecolor');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.eyecoloredit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.eyecoloredit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
    //--End Eye Color--//

    //--service available For --//
    public function serviceAvailableFor() {

              return view('bracket-admin.masters.service_available_for.index');
      }
      public function serviceAvailableForCreate(){
          
          return view('bracket-admin.masters.service_available_for.create');
      }
      public function serviceAvailableForEdit($id){
          
          
            $data = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.service_available_for.edit', compact('data'));  
      }
    public function serviceAvailableForStore(Request $request){
        
    $this->validate($request, [
			'service_value' => 'required'	
        ], [
            'service_value.required' => 'Please enter value.',
        ]);
          
        $objHeight = new MainMaster;
        $objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('service_value');
        $objHeight->save();
        return redirect()->route('admin.masters.service-available-for')->withsuccess('Added Successfully.');
          
    }
     public function serviceAvailableForUpdate(Request $request, $id){
        
    $this->validate($request, [
			'service_value' => 'required'	
        ], [
            'service_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('service_value');
        $objAge->save();
         return redirect()->route('admin.masters.service-available-for')->withinfo('Updated Successfully.');
          
    }
    
      public function serviceAvailableForAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','service-available-for');

            return Datatables::of($data)
      ->addColumn('title', function ($data) {
        
        return $data->meta_value;
      })
      
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
    
    
      ->addColumn('action', function ($data) {
        
        $user_data = Auth::user();
        
        $image_name = 'red-pencil.png';
        $link_title = 'Edit';
        
        return  '<span> <a href="' . route("admin.masters.service-available-for-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>  <a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> </span>';
        
        //return '<span>  <a href="' . route("admin.masters.service-available-for-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span> ';
      })
      ->rawColumns(['action'])
      ->make(true);
    }
    
   //--End Service  available for--//
    
   //--Service available setting--// 
    public function servicesAvailable() {

              return view('bracket-admin.masters.services_available.index');
      }
      public function servicesAvailableCreate(){
          
          return view('bracket-admin.masters.services_available.create');
      }
      public function servicesAvailableEdit($id){
          
          
            $data = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.services_available.edit',compact('data'));
			  
      }
      
      
    public function servicesAvailableStore(Request $request){
        
    $this->validate($request, [
			'service_value' => 'required'	
        ], [
            'service_value.required' => 'Please enter value.',
        ]);
          
        $objHeight = new MainMaster;
        $objHeight->meta_name = $request->input('meta_name');
		$objHeight->meta_value = $request->input('service_value');
        $objHeight->save();
        return redirect()->route('admin.masters.services-available')->withsuccess('Added Successfully.');
          
    }
     public function servicesAvailableUpdate(Request $request, $id){
        
    $this->validate($request, [
			'service_value' => 'required'	
        ], [
            'service_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('service_value');
        $objAge->save();
         return redirect()->route('admin.masters.services-available')->withinfo('Updated Successfully.');
          
    }
    public function servicesAvailableAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','service-available');

            return Datatables::of($data)
      ->addColumn('title', function ($data) {
        
        return $data->meta_value;
      })
      
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
    
    
      ->addColumn('action', function ($data) {
        
        $user_data = Auth::user();
        
        $image_name = 'red-pencil.png';
        $link_title = 'Edit';
        
        return  '<span> <a href="' . route("admin.masters.services-available-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>   <a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> </span>';
        
        //return '<span>  <a href="' . route("admin.masters.services-available-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>  ';
      })
      ->rawColumns(['action'])
      ->make(true);
    }
    //--end service vailable--//
    
    //--Service type setting----// 
    public function  serviceType() {

              return view('bracket-admin.masters.service_type.index');
      }
      public function  serviceTypeCreate(){
          
          return view('bracket-admin.masters.service_type.create');
      }
      public function  serviceTypeEdit($id){
          
          
            $data = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.service_type.edit', compact('data'));  
      }
      
      
    public function  serviceTypeStore(Request $request){
        
    $this->validate($request, [
			'service_value' => 'required'	
        ], [
            'service_value.required' => 'Please enter value.',
        ]);
          
        $objHeight = new MainMaster;
        $objHeight->meta_name = $request->input('meta_name');
		$objHeight->meta_value = $request->input('service_value');
        $objHeight->save();
        return redirect()->route('admin.masters.service-type')->withsuccess('Added Successfully.');
          
    }
     public function  serviceTypeUpdate(Request $request, $id){
        
    $this->validate($request, [
			'service_value' => 'required'	
        ], [
            'service_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('service_value');
        $objAge->save();
         return redirect()->route('admin.masters.service-type')->withinfo('Updated Successfully.');
          
    }

public function serviceTypeAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','service-type');

            return Datatables::of($data)
      ->addColumn('title', function ($data) {
        
        return $data->meta_value;
      })
      
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
    
    
      ->addColumn('action', function ($data) {
        
        $user_data = Auth::user();
        
        $image_name = 'red-pencil.png';
        $link_title = 'Edit';
        
        return  '<span> <a href="' . route("admin.masters.service-type-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>   <a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> </span>';
        
        //return '<span>  <a href="' . route("admin.masters.service-type-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>  ';
      })
      ->rawColumns(['action'])
      ->make(true);
    }
   //--end service Type--//	
//--favourite things---//

	 
	     public function  favouriteThings() {

              return view('bracket-admin.masters.favourite_things.index');
      }
      public function  favouriteThingsCreate(){
          
          return view('bracket-admin.masters.favourite_things.create');
      }
      public function  favouriteThingsEdit($id){
          
          
            $data = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.favourite_things.edit' , compact('data'));  
      }
      
      
    public function  favouriteThingsStore(Request $request){
        
    $this->validate($request, [
			'fav_things_value' => 'required'	
        ], [
            'fav_things_value.required' => 'Please enter value.',
        ]);
          
        $objHeight = new MainMaster();
		$objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('fav_things_value');
        $objHeight->save();
        return redirect()->route('admin.masters.favourite-things')->withsuccess('Added Successfully.');
          
    }
    public function  favouriteThingsUpdate(Request $request, $id){
        
    $this->validate($request, [
			'fav_things_value' => 'required'	
        ], [
            'fav_things_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('fav_things_value');
        $objAge->save();
         return redirect()->route('admin.masters.favourite-things')->withinfo('Updated Successfully.');
          
    }
	
  public function favouriteThingsAjaxData(){
     
     
     $data = MainMaster::all()->where('meta_name','fav_things');

            return Datatables::of($data)
      ->addColumn('title', function ($data) {
        
        return $data->meta_value;
      })
      
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
    
    
      ->addColumn('action', function ($data) {
        
        $user_data = Auth::user();
        
        $image_name = 'red-pencil.png';
        $link_title = 'Edit';
        
        return  '<span> <a href="' . route("admin.masters.favourite-things-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>   <a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> </span>';
        
        //return '<span>  <a href="' . route("admin.masters.services-available-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>  ';
      })
      ->rawColumns(['action'])
      ->make(true);
     
   }
   //--End Favourite--//

	 


    //--Wishlist setting--//
    
    public function  wishlist() {

              return view('bracket-admin.masters.wishlist.index');
      }
      public function  wishlistCreate(){
          
          return view('bracket-admin.masters.wishlist.create');
      }
      public function  wishlistEdit($id){
          
          
            $data = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.wishlist.edit', compact('data'));  
      }
      
      
    public function  wishlistStore(Request $request){
        
    $this->validate($request, [
			'wishlist_value' => 'required'	
        ], [
            'wishlist_value.required' => 'Please enter value.',
        ]);
          
        $objHeight = new MainMaster;
        $objHeight->meta_name = $request->input('meta_name');
        $objHeight->meta_value = $request->input('wishlist_value');
        $objHeight->save();
        return redirect()->route('admin.masters.wishlist')->withsuccess('Added Successfully.');
          
    }
     public function  wishlistUpdate(Request $request, $id){
        
    $this->validate($request, [
			'wishlist_value' => 'required'	
        ], [
            'wishlist_value.required' => 'Please enter value.',
        ]);
          
        $objAge = 	MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('wishlist_value');
        $objAge->save();
         return redirect()->route('admin.masters.wishlist')->withinfo('Updated Successfully.');
          
    }

     public function wishlistAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','wishlist-things');

            return Datatables::of($data)
      ->addColumn('title', function ($data) {
        
        return $data->meta_value;
      })
      
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
    
    
      ->addColumn('action', function ($data) {
        
        $user_data = Auth::user();
        
        $image_name = 'red-pencil.png';
        $link_title = 'Edit';
        
                return  '<span> <a href="' . route("admin.masters.wishlist-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>   <a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> </span>';
        
      })
      ->rawColumns(['action'])
      ->make(true);
    }
   //--End wishlist--//


	//--personal setting--//
	    public function personal() {

              return view('bracket-admin.masters.personal.index');
      }
      public function personalCreate(){
          
          return view('bracket-admin.masters.personal.create');
      }
      public function personalEdit($id){
          
          
            $personal = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.personal.edit' , compact('personal'));
        
      }
    public function personalStore(Request $request){
        
    $this->validate($request, [
			'personal_value' => 'required'	
        ], [
            'personal_value.required' => 'Please enter value.',
        ]);
          
        $objAge = new MainMaster;
		$objAge->meta_name = $request->input('meta_name');
        $objAge->meta_value = $request->input('personal_value');
        $objAge->save();
        return redirect()->route('admin.masters.personal')->withsuccess('Value  Added Successfully.');
          
    }
     public function personalUpdate(Request $request,$id){
        
    $this->validate($request, [
			'personal_value' => 'required'	
        ], [
            'personal_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('personal_value');
        $objAge->save();
         return redirect()->route('admin.masters.personal')->withinfo('Updated Successfully.');
          
    }
    
    public function personalAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','personal');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.personaledit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }

    //---End Personal--//
	
	// body type setting---//
	    public function bodyType() {

              return view('bracket-admin.masters.body_type.index');
      }
      public function bodyTypeCreate(){
          
          return view('bracket-admin.masters.body_type.create');
      }
      public function bodyTypeEdit($id){
          
          
            $bodytype = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.body_type.edit' , compact('bodytype'));  
      }
    public function bodyTypeStore(Request $request){
        
    $this->validate($request, [
			'body_type_value' => 'required'	
        ], [
            'body_type_value.required' => 'Please enter value.',
        ]);
          
        $objAge = new MainMaster;
		$objAge->meta_name = $request->input('meta_name');
        $objAge->meta_value = $request->input('body_type_value');
        $objAge->save();
        return redirect()->route('admin.masters.body-type')->withsuccess('Value  Added Successfully.');
          
    }
     public function bodyTypeUpdate(Request $request,$id){
        
    $this->validate($request, [
			'body_type_value' => 'required'	
        ], [
            'body_type_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('body_type_value');
        $objAge->save();
         return redirect()->route('admin.masters.body-type')->withinfo('Updated Successfully.');
          
    }
    
    public function bodyTypeAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','body-type');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.body-type-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
	
		// end body type master--//
		
    //--Piercing Setting---//
	    public function piercing() {

              return view('bracket-admin.masters.piercing.index');
      }
      public function piercingCreate(){
          
          return view('bracket-admin.masters.piercing.create');
      }
      public function piercingEdit($id){
          
          
            $piercing = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.piercing.edit', compact('piercing'));  
      }
    public function piercingStore(Request $request){
        
    $this->validate($request, [
			'piercing_value' => 'required'	
        ], [
            'piercing_value.required' => 'Please enter value.',
        ]);
          
        $objAge = new MainMaster;
		$objAge->meta_name = $request->input('meta_name');
        $objAge->meta_value = $request->input('piercing_value');
        $objAge->save();
        return redirect()->route('admin.masters.piercing')->withsuccess('Value  Added Successfully.');
          
    }
     public function piercingUpdate(Request $request,$id){
        
    $this->validate($request, [
			'piercing_value' => 'required'	
        ], [
            'piercing_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('piercing_value');
        $objAge->save();
         return redirect()->route('admin.masters.piercing')->withinfo('Updated Successfully.');
          
    }
    
    public function piercingAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','piercing');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.piercingedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
	//---end piercing--//

    //---Bust size--//
	
	    public function bustsize() {

              return view('bracket-admin.masters.bustsize.index');
      }
      public function bustsizeCreate(){
          
          return view('bracket-admin.masters.bustsize.create');
      }
      public function bustsizeEdit($id){
          
          
            $bustsize = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.bustsize.edit' , compact('bustsize'));
        
      }
    public function bustsizeStore(Request $request){
        
    $this->validate($request, [
			'bustsize_value' => 'required'	
        ], [
            'bustsize_value.required' => 'Please enter value.',
        ]);
          
        $objAge = new MainMaster;
		$objAge->meta_name = $request->input('meta_name');
        $objAge->meta_value = $request->input('bustsize_value');
        $objAge->save();
        return redirect()->route('admin.masters.bustsize')->withsuccess('Value  Added Successfully.');
          
    }
     public function bustsizeUpdate(Request $request,$id){
        
    $this->validate($request, [
			'bustsize_value' => 'required'	
        ], [
            'bustsize_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('bustsize_value');
        $objAge->save();
         return redirect()->route('admin.masters.bustsize')->withinfo('Updated Successfully.');
          
    }
    
    public function bustsizeAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','bustsize');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.bustsizeedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
	
	//......bustsize  end....//
	
	//....hair length....//
	
		    public function hairlength() {

              return view('bracket-admin.masters.hair_length.index');
      }
      public function hairlengthCreate(){
          
          return view('bracket-admin.masters.hair_length.create');
      }
      public function hairlengthEdit($id){
          
          
            $hairlength = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.hair_length.edit', compact('hairlength'));
      }
    public function hairlengthStore(Request $request){
        
    $this->validate($request, [
			'hairlength_value' => 'required'	
        ], [
            'hairlength_value.required' => 'Please enter value.',
        ]);
          
        $objAge = new MainMaster;
		$objAge->meta_name = $request->input('meta_name');
        $objAge->meta_value = $request->input('hairlength_value');
        $objAge->save();
        return redirect()->route('admin.masters.hairlength')->withsuccess('Value  Added Successfully.');
          
    }
     public function hairlengthUpdate(Request $request,$id){
        
    $this->validate($request, [
			'hairlength_value' => 'required'	
        ], [
            'hairlength_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('hairlength_value');
        $objAge->save();
         return redirect()->route('admin.masters.hairlength')->withinfo('Updated Successfully.');
          
    }
    
    public function hairlengthAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','hairlength');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.hairlengthedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
	
	//.....hair length end....//
	
	
	//....dress size....//
	
		    public function dresssize() {

              return view('bracket-admin.masters.dress_size.index');
      }
      public function dresssizeCreate(){
          
          return view('bracket-admin.masters.dress_size.create');
      }
      public function dresssizeEdit($id){
          
          
            $dresssize = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.dress_size.edit', compact('dresssize'));
			}

    public function dresssizeStore(Request $request){
        
    $this->validate($request, [
			'dresssize_value' => 'required'	
        ], [
            'dresssize_value.required' => 'Please enter value.',
        ]);
          
        $objAge = new MainMaster;
		$objAge->meta_name = $request->input('meta_name');
        $objAge->meta_value = $request->input('dresssize_value');
        $objAge->save();
        return redirect()->route('admin.masters.dresssize')->withsuccess('Value  Added Successfully.');
          
    }
     public function dresssizeUpdate(Request $request,$id){
        
    $this->validate($request, [
			'dresssize_value' => 'required'	
        ], [
            'dresssize_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('dresssize_value');
        $objAge->save();
         return redirect()->route('admin.masters.dresssize')->withinfo('Updated Successfully.');
          
    }
    
    public function dresssizeAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','dresssize');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.dresssizeedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
	
	//.....dress size end....//
	
	
	//....shoes size....//
	
		    public function shoessize() {

              return view('bracket-admin.masters.shoes_size.index');
      }
      public function shoessizeCreate(){
          
          return view('bracket-admin.masters.shoes_size.create');
      }
      public function shoessizeEdit($id){
          
          
            $shoesize = MainMaster::findOrFail($id);
             
           return view('bracket-admin.masters.shoes_size.edit', compact('shoesize'));  
      }
    public function shoessizeStore(Request $request){
        
    $this->validate($request, [
			'shoessize_value' => 'required'	
        ], [
            'shoessize_value.required' => 'Please enter value.',
        ]);
          
        $objAge = new MainMaster;
		$objAge->meta_name = $request->input('meta_name');
        $objAge->meta_value = $request->input('shoessize_value');
        $objAge->save();
        return redirect()->route('admin.masters.shoessize')->withsuccess('Value  Added Successfully.');
          
    }
     public function shoessizeUpdate(Request $request,$id){
        
    $this->validate($request, [
			'shoessize_value' => 'required'	
        ], [
            'shoessize_value.required' => 'Please enter value.',
        ]);
          
        $objAge = MainMaster::findOrFail($id);  
        $objAge->meta_value = $request->input('shoessize_value');
        $objAge->save();
         return redirect()->route('admin.masters.shoessize')->withinfo('Updated Successfully.');
          
    }
    
    public function shoessizeAjaxData(){
       
         
            $data = MainMaster::all()->where('meta_name','shoessize');

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->meta_value ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.masters.shoessizeedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
	
	//.....shoes size end....//

		//....socialmedia setting....//
	
    public function socialMediaLinks() {

            return view('bracket-admin.masters.social_media.index');
    }
    public function socialMediaLinksCreate(){
        
        return view('bracket-admin.masters.social_media.create');
    }
    public function socialMediaLinksEdit($id){
        
        
          $social_media_links = MainMaster::findOrFail($id);
           
         return view('bracket-admin.masters.social_media.edit', compact('social_media_links'));
    }
  public function socialMediaLinksStore(Request $request){
      
  $this->validate($request, [
          'social_media_links_value' => 'required',
      ], [
          'social_media_links_value.required' => 'Please enter value.',
      ]);
        
      $objSocial = new MainMaster;
      $objSocial->meta_name = $request->input('meta_name');
      $objSocial->meta_value = $request->input('social_media_links_value');
    
      if($filename_name = $request->file('social_media_icon')->getClientOriginalName()) {
        $objSocial->meta_icon = time().$request->file('social_media_icon')->getClientOriginalName();
         $request->file('social_media_icon')->move(public_path('upload/'), time().$filename_name);
        
     }
      $objSocial->save();
      return redirect()->route('admin.masters.social-media-links')->withsuccess( 'Added Successfully.');
        
  }
   public function socialMediaLinksUpdate(Request $request,$id){
      
  $this->validate($request, [
          'social_media_links_value' => 'required'	
      ], [
          'social_media_links_value.required' => 'Please enter value.',
      ]);
        
      $objSocial = MainMaster::findOrFail($id);  
      $objSocial->meta_value = $request->input('social_media_links_value');
      if( $request->file('social_media_icon')){
      if($filename_name = $request->file('social_media_icon')->getClientOriginalName()) {
        $objSocial->meta_icon = time().$request->file('social_media_icon')->getClientOriginalName();
         $request->file('social_media_icon')->move(public_path('upload/'),time().$filename_name);
         if($request->input('old_social_media_icon')){
            @unlink(public_path('upload/'.$request->input('old_social_media_icon')));
        }
     }
    }
      $objSocial->save();
       return redirect()->route('admin.masters.social-media-links')->withinfo('Updated Successfully.');
        
  }
  
  public function socialMediaLinksAjaxData(){
     
       
          $data = MainMaster::all()->where('meta_name','social_media_link');

          return Datatables::of($data)
          ->addColumn('title', function ($data) {
              
              return $data->meta_value ;
          })
          
                      ->addColumn('created_at', function ($data) {
              return $data->created_at ? with( new Carbon($data->created_at) ): '';
          })
      
      
          ->addColumn('action', function ($data) {
              
              $user_data = Auth::user();
              
              $image_name = 'red-pencil.png';
              $link_title = 'Edit';
              
              return  '<span>	<a href="' . route("admin.masters.social-media-links-edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
              
              //return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
          })
          ->rawColumns(['action'])
          ->make(true);
  }
  
  //.....end social media links....
}
