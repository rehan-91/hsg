<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\EmailMessage;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;
use Exporter;

class EmailTemplateController extends Controller
{
       public function index() {
         
    
		return view('bracket-admin.email.index');
	}
        
        
        
        
        function create(){
            
            
            return view('bracket-admin.email.create');          
        }
        
        public function edit($id)
        {
            $content = EmailMessage::findOrFail($id);
           
           return view('bracket-admin.email.edit', compact('content'));
			
        }
        
        public function store(Request $request){
        
       
	$this->validate($request, [
			'template_name' => 'required',
                        'email_subject' => 'required',
                        'from_email' => 'required|email',
                        'to_address' => 'required',
                        'mail_html_content' =>'required',
			
        ], [
            'template_name.required' => 'Please enter template name.',
            'email_subject.required' => 'Please enter Email Subject.',
            'from_email.required' => 'Please enter From Email.',
            'to_address.required' => 'Please enter To Address.',
            'mail_html_content.required' => 'Please enter To Mail HTML.',
          
            
            
        ]);
     
      
        
        $email = new EmailMessage();
      
        $email->identifier_name = $request->input("template_name");
       
        $email->email_subject = $request->input("email_subject");
        $email->email_message = $request->input("mail_html_content");
        $email->from_address = $request->input("from_email");
		 $email->to_address = $request->input("to_address");
        $email->cc_address = $request->input("cc_address");
        $email->bcc_address = $request->input("cc_address");
        $email->from_name = $request->input("from_name");
        $email->status = $request->input("status");
        $email->save();
        return redirect()->route('admin.email-templates.index')->withsuccess('Added Successfully.');
    }
    
      public function update(Request $request, $id){
          
        $email = EmailMessage::findOrFail($id);  
            
	$this->validate($request, [
			'template_name' => 'required',
                        'email_subject' => 'required',
                         'from_email' => 'required|email',
                        'to_address' => 'required',
                        'mail_html_content' =>'required',
			
        ], [
            'template_name.required' => 'Please enter template name.',
            'email_subject.required' => 'Please enter Email Subject.',
            'from_email.required' => 'Please enter From Email.',
            'to_address.required' => 'Please enter To Address.',
            'mail_html_content.required' => 'Please enter To Mail HTML.',
          
            
            
        ]);
          
                
              
        
        
      
        $email->identifier_name = $request->input("template_name");
       
        $email->email_subject = $request->input("email_subject");
        $email->email_message = $request->input("mail_html_content");
        $email->from_address = $request->input("from_email");
        $email->from_address = $request->input("from_email");
        $email->to_address = $request->input("to_address");
        $email->bcc_address = $request->input("cc_address");
        $email->from_name = $request->input("from_name");
        $email->status = $request->input("status");
        $email->save();
        return redirect()->route('admin.email-templates.index')->withinfo('Updated Successfully.');      
            
        }

             public function ajaxData()
    {
           
            $data = array();
            $data = EmailMessage::all();

            return Datatables::of($data)
            ->addColumn('name', function ($data) {
                
                return $data->identifier_name ;
            })
            ->addColumn('subject', function ($data) {
                
                return $data->email_subject;
            })
                       ->addColumn('from_address', function ($data) {
                
                return $data->from_address;
            })
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
            ->addColumn('status', function ($data) {
                $status_txt = '';
                if( intval( $data->status ) == 1 ){
                    $status_txt = ' checked';
                }
                
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
             
                //return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
        
            ->addColumn('action', function ($data) {
                
                $user_data = Auth::user();
                
                $image_name = 'red-pencil.png';
                $link_title = 'Edit';
                
                
                return '<span>  <a href="' . route("admin.email-templates.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span> ';
            })
            ->rawColumns(['status', 'action'])
            ->make(true);
            
    }
   
}
