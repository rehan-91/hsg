<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\States;
use App\Http\Requests;
use App\Http\Controllers\Controller;


use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;


class StatesController extends Controller
{
    //
        use HasRoles;
	
	protected $guard_name = 'web';
        public function __construct( ) {
        $this->generalSettings = generalSettings();
		
		//For fetching translations in defined locale for whole controller
		app()->setLocale('en');
        }
        
        function index(){
            return view('bracket-admin.location.states.index');
        }
        
        function ajaxData(){
            
            $data = States::getStates();
            return Datatables::of($data)
			->addColumn('name', function ($data) {
				
				return $data->name ;
			})
			->addColumn('country_name', function ($data) {
				
				return $data->country_name;
			})
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('status', function ($data) {
				$status_txt = '';
				if( intval( $data->status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.states.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['status', 'action'])
			->make(true);
			
        }
        
        function create(){
            $countries = States::getCountries();
            return view('bracket-admin.location.states.create')
            ->with("countries", $countries);
            
        }
        
         function edit($id){
            $countries = States::getCountries();
            $data = States::findOrFail($id); 
            return view('bracket-admin.location.states.edit')
             ->with("countries", $countries)
            ->with('data', $data);
            
        }
        
        function store(Request $request){
            
            $this->validate($request, [
                "state_name" => 'required',
                "country_id" =>'required',
            ],[
                "country_name.required" => "Please enter state name",
                "country_id.required" => "Please select country name"
            ]);
            
            
            $state = new States();
            $state->name = $request->input("state_name");
            $state->country_id = $request->input("country_id");
            $state->status = $request->input("status");
			$state->notice = $request->input("notice");
            $state->save();
            return redirect()->route('admin.states.index')->withsuccess('State added Successfully');
            
        }
        
        function update(Request $request, $id){
            $this->validate($request, [
                "state_name" => 'required',
                "country_id" =>'required',
            ],[
                "country_name.required" => "Please enter state name",
                "country_id.required" => "Please select country name"
            ]);
            
            $state = States::findOrFail($id);
         
            $state->name = $request->input("state_name");
            $state->country_id = $request->input("country_id");
            $state->status = $request->input("status");
			$state->notice = $request->input("notice");
            $state->save();
            
            return redirect()->route('admin.states.index')->withinfo("State updated successfully");
        }
}   
