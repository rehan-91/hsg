<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Plans;
use App\Models\Usertype;
use App\Http\Requests;
use App\Http\Controllers\Controller;


use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;

class AdsController extends Controller
{
    //
    public function index(){
    }
}
