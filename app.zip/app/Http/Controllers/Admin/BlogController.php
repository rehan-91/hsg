<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Blogs;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;
class BlogController extends Controller
{
    public function index() {
        
		return view('bracket-admin.blogs.index');
	}


	public function create(){
		$data = User::select([ 'id', 'email', 'status'])->where('status', '1')->get();
		return view('bracket-admin.blogs.create')->with('users', $data);
	}
	

	public function edit($id) {
        
		$users = User::select([ 'id', 'email', 'status'])->where('status', '1')->get();
		$data = Blogs::findOrFail($id);
		return view('bracket-admin.blogs.edit', compact('users','data'));
			}
	
	
	public function store(Request $request){
		
		$this->validate($request, [
			'blog_title' => 'required|unique:blogs,blog_title|min:3|max:255',
			'blog_desc' => 'required|min:255',
			'user_id' => 'required',
        ], [
            'blog_title.required' => 'Please enter title.',
            'blog_desc.required' => 'Please enter description.',
            'user_id.required' => 'Please select posted by.',
        ]);
		
		$objBlog = new Blogs();
		$objBlog->blog_title = $request->input('blog_title');
		$objBlog->blog_desc = $request->input('blog_desc');
		$vimageName = NULL;
		if($request->file('blog_featured_image')){
		 if($request->file('blog_featured_image')->getClientOriginalName()) {
             
           $vimageName = time().$request->file('blog_featured_image')->getClientOriginalName().'.'.$request->file('blog_featured_image')->getClientOriginalExtension();
           $request->file('blog_featured_image')->move('uploads/blogs/', $vimageName);
		 }
		}
		$objBlog->blog_featured_img = $vimageName;
		$objBlog->blog_status= $request->input('status');
		$objBlog->blog_category= $request->input('blog_category');
		$objBlog->blog_tags = $request->input('blog_tags');
		$objBlog->blog_meta_title = $request->input('blog_meta_title');
		$objBlog->blog_meta_description = $request->input('blog_meta_description');
		$objBlog->blog_meta_keywords = $request->input('blog_meta_keywords');
		$objBlog->user_id = $request->input('user_id');
		$objBlog->blog_slug = str_slug($request->input("blog_title"));
		$objBlog->sort_order = $request->input("sort_order");	
		$objBlog->save();
		
		return redirect()->route('admin.blog.index')->withsuccess('Blog Added Successfully.');
	}
	
		public function update(Request $request, $id){
		
		$this->validate($request, [
			//'blog_title' => 'sometimes|min:3|max:255|unique:blogs,blog_title,'.$id,
			'blog_title' => 'sometimes|min:3|max:255|unique:blogs,blog_title,'.$id,
			'blog_desc' => 'required|min:255',
        ], [
            'blog_title.required' => 'Please enter title.',
           'blog_desc.required' => 'Please enter description.',
        ]);
		
		$objBlog = Blogs::findOrFail($id);
		$objBlog->blog_title = $request->input('blog_title');
		$objBlog->blog_desc = $request->input('blog_desc');
		
		$vimageName = NULL;
		if($request->file('blog_featured_image')){
		 if($request->file('blog_featured_image')->getClientOriginalName()) {
             
           $vimageName = time().$request->file('blog_featured_image')->getClientOriginalName().'.'.$request->file('blog_featured_image')->getClientOriginalExtension();
           $request->file('blog_featured_image')->move('uploads/blogs/', $vimageName);
		 }
		}
		 $objBlog->blog_featured_img = $vimageName;
		
		$objBlog->blog_status= $request->input('status');
		$objBlog->blog_category= $request->input('blog_category');
		$objBlog->blog_tags = $request->input('blog_tags');
		$objBlog->blog_meta_title = $request->input('blog_meta_title');
		$objBlog->blog_meta_description = $request->input('blog_meta_description');
		$objBlog->blog_meta_keywords = $request->input('blog_meta_keywords');
		$objBlog->user_id = $request->input('user_id');
		$objBlog->blog_slug = str_slug($request->input("blog_title"));
		$objBlog->save();
		return redirect()->route('admin.blog.index')->withinfo('Blog Updated Successfully.');
	}
	
	public function ajaxData(){
			
            $data = array();
            $data = Blogs::all();
			
            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->blog_title ;
			})
			->addColumn('page_slug', function ($data) {
				
				return $data->blog_slug;
			})
			->addColumn('blog_category', function ($data) {
				
				return $data->blog_category;
			})
			->addColumn('blog_tags', function ($data) {
				
				return $data->blog_tags;
			})
                       
            ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('blog_status', function ($data) {
				$status_txt = '';
				if( intval( $data->blog_status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.blog.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['blog_status', 'action'])
			->make(true);
	}
	
}
