<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Cities;
use App\Models\RolePermission;
use App\Models\UserAdvertisement;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;
use Exporter;

class PhotographersController extends Controller
{
     function index(){
         $id = request()->segment(3);
       
        return view('admin.photographers.index')->with('id', $id);
    }
    
    function store(Request $request){
      
       
       $this->validate($request, [
                        'user_id'=>['required'],
			'name' => [ 'required', 'min:3' , 'max:255'],
			'email' => ['required','email'],
			'phone' => ['required'],
			'location' => ['required'],
                        'fees_charges' =>'required',
                        'description' =>[ 'required', 'min:100'],
                        'nz_proof' =>['required']
        ], [
            'user_id.required'=>'Please select user',
            'name.required' => 'Please enter name.',
            'email.required' => 'Please enter email.',
            'phone.required' => 'Please enter phone.',
            'location.required' => 'Please enter location.',
            'fees_charges.required' => 'Please enter fees and charges.',
            'description.required' => 'Please enter description.',
            'nz_proof.required' => 'Please upload any NZ ID.',
     
        ]);
        
       
        $userAd = new UserAdvertisement();
        $userAd->ad_user_id = $request->input('user_id');
        $userAd->ad_listing_type_id = $request->input('ad_listing_type_id');
        $userAd->ad_name = $request->input('name');
        $userAd->ad_location = $request->input('location');
        $userAd->ad_email = $request->input('email');
        $userAd->ad_contactno = $request->input('phone');
        $userAd->fees_charges = $request->input('fees_charges');
        $userAd->about_description = $request->input('description');
        
          if($request->file('nz_proof')->getClientOriginalName()) {
             
           $vimageName = time().$request->file('nz_proof')->getClientOriginalName().'.'.$request->file('nz_proof')->getClientOriginalExtension();
           $request->file('nz_proof')->move('uploads/photographer_ids/', $vimageName);
           
        }
        $userAd->logo = $vimageName;
        $userAd->status = $request->input('status');
        $userAd->save();
        return redirect()->route('admin.photographers.index',[$request->input('ad_listing_type_id')])->with('message', 'Added Successfully.');
        
    }
    
    
    function create(){
        $id = request()->segment(4);
        $cities = Cities::all();
        $data = User::role(ROLE::ROLE_ABCUSER)->select([ 'id', 'email', 'status'])->where('status', '1')->get();
              return view('admin.photographers.create')->with('ad_listing_type_id', $id)->with("users", $data)->with('cities',$cities);
    }
    
    function edit($id){
        
        $adData = UserAdvertisement::findOrFail($id);
        $cities = Cities::all();
        $data = User::role(ROLE::ROLE_ABCUSER)->select([ 'id', 'email', 'status'])->where('status', '1')->get();
        return view('admin.photographers.edit')->with('adData', $adData)->with("users", $data)->with('cities',$cities);
    }
    
        public function ajaxData()
	{
           $id = request()->segment(4);
          
            $data = array();
            $data = UserAdvertisement::where('ad_listing_type_id', $id)->get();
              
      
            return Datatables::of($data)
			->addColumn('name', function ($data) {
				
				return $data->ad_name ;
			})
			->addColumn('email', function ($data) {
				
				return $data->ad_email;
			})
                        ->addColumn('phone', function ($data) {
				
				return $data->ad_contactno;
			})
                        ->addColumn('location', function ($data) {
				
				return $data->location;
			})
                       
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('status', function ($data) {
				$status_txt = '';
				if( intval( $data->status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.photographers.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['status', 'action'])
			->make(true);
			
	}



    function update(Request $request, $id){
      
      
       $this->validate($request, [
                        'user_id'=>['required'],
			'name' => [ 'required', 'min:3' , 'max:255'],
			'email' => ['required','email'],
			'phone' => ['required'],
			'location' => ['required'],
                        'fees_charges' =>'required',
                        'description' =>[ 'required', 'min:100'],
                    
        ], [
            'user_id.required'=>'Please select user',
            'name.required' => 'Please enter name.',
            'email.required' => 'Please enter email.',
            'phone.required' => 'Please enter phone.',
            'location.required' => 'Please enter location.',
            'fees_charges.required' => 'Please enter fees and charges.',
            'description.required' => 'Please enter description.',
          
     
        ]);
       
        $userAd = UserAdvertisement::findOrFail($id);
        $userAd->ad_user_id = $request->input('user_id');
        $userAd->ad_name = $request->input('name');
        $userAd->ad_location = $request->input('location');
        $userAd->ad_email = $request->input('email');
        $userAd->ad_contactno = $request->input('phone');
        $userAd->fees_charges = $request->input('fees_charges');
        $userAd->about_description = $request->input('description');
       
          if($request->file('nz_proof')) {
           $vimageName = time().$request->file('nz_proof')->getClientOriginalName().'.'.$request->file('nz_proof')->getClientOriginalExtension();
           $request->file('nz_proof')->move('uploads/photographer_ids/', $vimageName);
           $userAd->logo = $vimageName;
        }
        
        $userAd->status = $request->input('status');
        $userAd->save();
        return redirect()->route('admin.photographers.index',[$userAd->ad_listing_type_id])->with('message', 'Updated Successfully.');
       
    }
}