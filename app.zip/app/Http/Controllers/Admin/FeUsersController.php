<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Hash;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\RolePermission;
use App\Models\EmailMessage;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;

class FeUsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.feusers.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.feusers.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   	public function store(Request $request)
	{
		$name_regex = "/^[\pL\s]+$/u";
		
		$this->validate($request, [
			'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
			'email' => 'required|email|min:3|max:255|unique:users,email,NULL,id,deleted_at,NULL',
			'password' => ['required','min:8']
        ], [
            'name.required' => 'Please enter Name.',
            'name.regex' => 'Enter only characters',
            'email.required' => 'Please Enter Email Id.',
            'password.required' => 'Please Enter Your Password.',
           'password.digits' => 'Password length is less than 8.'
        ]);
	    
		$status = $request->input('status');
		
		
		$user = new User();
		
		$user->name = $request->input("name");
        $user->email = $request->input("email");
        $user->password = $request->input("password");
        $user->password = Hash::make( $request->input("password") );
        $user->status = $status;
		$user->save();
		$user->assignRole(ROLE::ROLE_ABCUSER);
		return redirect()->route('admin.fe-users.index')->with('message', 'User Created Successfully.');
	}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   public function ajaxData()
	{
            
            $data =User::role( Role::ROLE_ABCUSER );
         
            return Datatables::of($data)
			->addColumn('name', function ($data) {
				
				return $data->name ;
			})
			->addColumn('email', function ($data) {
				
				return $data->email;
			})
            ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('status', function ($data) {
				$status_txt = '';
				if( intval( $data->status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.fe-users.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['status', 'action'])
			->make(true);
			
	}
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
        {
            $users = User::findOrFail($id);
           
           return view('admin.feusers.edit')    
			->with('users', $users)
			->withModel($users);
	
        }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
      public function update(Request $request, $id){
            
       
		$name_regex = "/^[\pL\s]+$/u";
		
			$this->validate($request, [
				'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
				'email' => 'sometimes|email|min:3|max:255|unique:users,email,'.$id,
				'password' => 'sometimes|nullable|min:8'
			], [
				'name.required' => 'Please enter Name.',
				'name.regex' => 'Enter only characters',
				'email.required' => 'Please Enter Email Id.',
			   'password.digits' => 'Password length is less than 8.'
			]);
                
			$user = User::findOrFail($id);        
         
			$status = $request->input("status");
			$user->name = $request->input("name");
			$user->email = $request->input("email");
			if(!empty($request->input("password"))){
			$user->password = $request->input("password");
			$user->password = Hash::make( $request->input("password") );
			}
			
			$user->status = $status;
			$user->save();
			return redirect()->route('admin.fe-users.index')->with('message', 'User Updated Successfully.');
            
            
        }
	

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
