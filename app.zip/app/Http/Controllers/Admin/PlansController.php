<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Plans;
use App\Models\Usertype;
use App\Http\Requests;
use App\Http\Controllers\Controller;


use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;

class PlansController extends Controller
{
    use HasRoles;
	
	protected $guard_name = 'web';
	
	protected $generalSettings;
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
		
		//For fetching translations in defined locale for whole controller
		app()->setLocale('en');
    }
	
	/* 
	 * Nodal User's Listing page
	*/
    public function index() {
        $usertype=Usertype::all();
		return view('bracket-admin.plans.index', compact('usertype'));
	}
    public function store(Request $request){
       $regex = "/^(?=.+)(?:[1-9]\d*|0)?(?:\.\d+)?$/";
		
		$this->validate($request, [
			'title' => [ 'required', 'min:3' , 'max:255'],
			'base_price' => ['required', 'regex:'.$regex],
			'boost_price' => ['required', 'regex:'.$regex],
			'featured_price' => ['required', 'regex:'.$regex],
            'allowed_photos' =>'required|numeric|min:0',
            'allowed_photos' =>'numeric|min:0',
            'duration'=>'required|numeric|min:1',
        ], [
            'title.required' => 'Please enter title.',
            'base_price.required' => 'Please enter base price.',
            'boost_price.required' => 'Please enter boost price.',
            'featured_price.required' => 'Please enter featured price.',
            'base_price.regex' => 'Please enter valid base price.',
            'boost_price.regex' => 'Please enter valid boost price.',
            'featured_price.regex' => 'Please enter valid featured price.',
            'allowed_photos.integer' => 'Please enter number of allowed photos in number only.',
            'duration.required'=>'Please enter duration.',
            'duration.integer' => 'Please enter duration in number only.',
        ]);
                
        $status = 0;
        if( $request->input("status") && intval( $request->input("status") ) == 1 ){
                $status = 1;
        }       
        $recommended = 0;
        if( $request->input("recommended") && intval( $request->input("recommended") ) == 1 ){
                $recommended = 1;
        }
        
        $objPlans = new Plans;
        $objPlans->plan_name = $request->input("title");
        $objPlans->plan_price_base = $request->input("base_price");
        $objPlans->plan_price_boost = $request->input("boost_price");
        $objPlans->plan_price_featured = $request->input("featured_price");
        $objPlans->plan_allowed_photos = (int)$request->input("allowed_photos");
        $objPlans->plan_allowed_videos = (int)$request->input("allowed_videos");
        $objPlans->plan_status = $status;
        $objPlans->listing_type_id = $request->input("user_type_id");
		$objPlans->plan_features = $request->input("plan_features");
        
        if(!empty($request->input('addon_features'))){

        $objPlans->addon_features = json_encode($request->input("addon_features"));

        }

        $objPlans->plan_is_recommended = $recommended;
        $objPlans->plan_duration = $request->input("duration");
        $objPlans->plan_duration_unit = $request->input("plan_duration_unit");

        $objPlans->save();
		
      return redirect()->route('admin.plans.index')->withsuccess('Plan Added Successfully.');
    }
	public function ajaxData()
	{
            $objPlans = new Plans;
            $data = array();
            $data = $objPlans->get_all_plans();
              
            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->plan_name ;
			})
			->addColumn('base_price', function ($data) {
				
				return $data->plan_price_base;
			})
                        ->addColumn('boost_price', function ($data) {
				
				return $data->plan_price_boost;
			})
                        ->addColumn('featured_price', function ($data) {
				
				return $data->plan_price_featured;
			})
                        ->addColumn('photos_allowed', function ($data) {
				
				return $data->plan_allowed_photos;
			})
                        ->addColumn('videos_allowed', function ($data) {
				
				return $data->plan_allowed_videos;
			})
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('plan_status', function ($data) {
				$status_txt = '';
				if( intval( $data->plan_status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="enabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.plans.edit", [$data->id]) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['plan_status', 'action'])
			->make(true);
			
	}
        function create(){
           $usertype = Usertype::all();
            
           return view('bracket-admin.plans.create')->with('usertype', $usertype);
        }
        
        public function edit($id)
        {
            $usertype = Usertype::all();
            $plans = Plans::findOrFail($id);
             
           return view('bracket-admin.plans.edit')
                        ->with('usertype', $usertype)
			->with('plans', $plans)
			->withModel($plans);
	
        }
	
        public function update(Request $request, $id){
            
       
            $regex = "/^(?=.+)(?:[1-9]\d*|0)?(?:\.\d+)?$/";
		
		$this->validate($request, [
			'title' => [ 'required', 'min:3' , 'max:255'],
			'base_price' => ['required', 'regex:'.$regex],
			'boost_price' => ['required', 'regex:'.$regex],
			'featured_price' => ['required', 'regex:'.$regex],
                        'allowed_photos' =>'required|numeric|min:0',
                        'allowed_photos' =>'numeric|min:0',
                    'duration'=>'required|numeric|min:1',
        ], [
            'title.required' => 'Please enter title.',
            'base_price.required' => 'Please enter base price.',
            'boost_price.required' => 'Please enter boost price.',
            'featured_price.required' => 'Please enter featured price.',
            'base_price.regex' => 'Please enter valid base price.',
            'boost_price.regex' => 'Please enter valid boost price.',
            'allowed_photos.integer' => 'Please enter number of allowed photos in number only.',
            'duration.required'=>'Please enter duration.',
            'duration.integer' => 'Please enter duration in number only.',
            
            
            
        ]);
                
        $plans = Plans::findOrFail($id);        
         
        $status = 0;
        if( $request->input("status") && intval( $request->input("status") ) == 1 ){
                $status = 1;
        }       
        $recommended = 0;
        if( $request->input("recommended") && intval( $request->input("recommended") ) == 1 ){
                $recommended = 1;
        }
        
        $plans->plan_name = $request->input("title");
        $plans->plan_price_base = $request->input("base_price");
        $plans->plan_price_boost = $request->input("boost_price");
        $plans->plan_price_featured = $request->input("featured_price");
        $plans->plan_allowed_photos = (int)$request->input("allowed_photos");
        $plans->plan_allowed_videos = (int)$request->input("allowed_videos");
		$plans->plan_features = $request->input("plan_features");
        $plans->listing_type_id = $request->input("user_type_id");
        $plans->plan_status = $status;
        $plans->plan_is_recommended = $recommended;
        $plans->plan_duration = $request->input("duration");
        $plans->plan_duration_unit = $request->input("plan_duration_unit");
        $plans->save();
        return redirect()->route('admin.plans.index')->withinfo('Plan updated Successfully.');       
            
        }
	
}
