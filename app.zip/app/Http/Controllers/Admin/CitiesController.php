<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Cities;
use App\Models\States;
use App\Http\Requests;
use App\Http\Controllers\Controller;


use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;


class CitiesController extends Controller
{
    //
        use HasRoles;
	
	protected $guard_name = 'web';
        public function __construct( ) {
        $this->generalSettings = generalSettings();
		
		//For fetching translations in defined locale for whole controller
		app()->setLocale('en');
        }
        
        function index(){
             
            return view('bracket-admin.location.cities.index');
        }
        
        function ajaxData(){
            
            $data = Cities::getCities();
            
            return Datatables::of($data)
			->addColumn('name', function ($data) {
				
				return $data->name ;
			})
			->addColumn('state_name', function ($data) {
				
				return $data->state_name;
			})
                        ->addColumn('country_name', function ($data) {
				
				return $data->country_name;
			})
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('status', function ($data) {
				$status_txt = '';
				if( intval( $data->status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.cities.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['status', 'action'])
			->make(true);
			
        }
        
        function create(){
            $countries = States::getCountries();
            return view('bracket-admin.location.cities.create')
            ->with("countries", $countries);
            
        }
        
         function edit($id){
            $countries = States::getCountries();
            $data = Cities::findOrFail($id);
          
            $states = States::getStates($data->country_id);
            return view('bracket-admin.location.cities.edit')
             ->with("countries", $countries)
            ->with('data', $data)
            ->with('states', $states);
            
        }
        
        function store(Request $request){
            
            $this->validate($request, [
                "city_name" => 'required',
                "country_id" =>'required',
                "state_id" => 'required',
                'status' => 'required',
                'image' => 'mimes:jpeg,png,jpg|max:300kb',
            ],[
                "city_name.required" => "Please enter city name",
                "country_id.required" => "Please select country name",
                "state_id.required" => "Please select state name",
                
                'image.max' =>'Image  must be under 300kb.'
            ]);
            
             
            $cities = new Cities();
            $cities->name = $request->input("city_name");
            $cities->country_id = $request->input("country_id");
            $cities->state_id = $request->input("state_id");
            $cities->status = $request->input("status");
			$cities->notice = $request->input("notice");
			$cities->lattitude = $request->input("lattitude");
			$cities->longitude = $request->input("longitude");


    //image upload
                
        if ($request->hasFile('image')) {
        $file = $request->file('image');
        $filename =time().'.'.$file->getClientOriginalName();
        $location =public_path('uploads/ads_image/');
        $file->move($location, $filename);
        $cities->image = $filename;
        
       }
            $cities->save();
            return redirect()->route('admin.cities.index')->withsuccess('City added Successfully');
            
        }
        
        function update(Request $request, $id){
           $this->validate($request, [
                "city_name" => 'required',
                "country_id" =>'required',
                "state_id" => 'required',
            ],[
                "city_name.required" => "Please enter city name",
                "country_id.required" => "Please select country name",
                "state_id.required" => "Please select state name"
            ]);
            $cities = Cities::findOrFail($id);
         
            $cities->name = $request->input("city_name");
            $cities->country_id = $request->input("country_id");
            $cities->state_id = $request->input("state_id");
            $cities->status = $request->input("status");
			$cities->notice = $request->input("notice");
			$cities->lattitude = $request->input("lattitude");
			$cities->longitude = $request->input("longitude");
//image upload new
        if ($request->hasFile('image')) {
        $file = $request->file('image');
        $filename =time().'.'.$file->getClientOriginalName();
        $location =public_path('uploads/ads_image/');
        $file->move($location, $filename);
        $blogsObj->blog_featured_img = $filename;
        if($request->input('old_image')){
            @unlink(public_path('uploads/ads_image/'.$request->input('old_image')));
        }
        
       }

            $cities->save();
            
            return redirect()->route('admin.cities.index')->withinfo("City updated successfully");
        }
        
        function fetchStates(Request $request){
            
             $data = States::getStates($request['id']);
             
             $html = '<option value="">Select State</option>';
             if(count($data) > 0){
                 
                
                 foreach($data as $d){
                     
                     $html .= '<option value="'.$d->id.'">'.$d->name.'</option>';
                 }
             }
             echo $html;
            
        }
}