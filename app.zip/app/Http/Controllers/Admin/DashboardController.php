<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Input;
use Auth;
use Hash;

use App\Models\User;
use App\Models\Role;
use App\Models\MetaData;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use Yajra\Datatables\Datatables;
use Imageupload;
use Carbon\Carbon;
use Exporter;

class DashboardController extends Controller
{
	public function __construct( ) {
        $this->generalSettings = generalSettings();
    }

    public function index(){
		
		$user_data = Auth::user();
		
		$assigned_role = $user_data->getRoleNames();
		
		
		
		$overview_data["users_data"] ='';
		$activity_log ='';
		$dashboard_chart ='';
		
		return view('bracket-admin.index')
				->with("dashboard_chart", $dashboard_chart)
				->with("activity_log", $activity_log)
				->with("overview_data", $overview_data);
				
	}
	
	public function generalSettingShow(){
		
		$compressionrr = array(
                '240p (424x240, 0.10 megapixels)',
                '360p (640x360, 0.23 megapixels)',
                '432p (768x432, 0.33 megapixels)',
                '480p (848x480, 0.41 megapixels, "SD" or "NTSC widescreen")',
                '576p (1024x576, 0.59 megapixels, "PAL widescreen")',
                '720p (1280x720, 0.92 megapixels, "HD")',
                '1080p (1920x1080, 2.07 megapixels, "Full HD")',
            );
            
            $resolutionarr = array(
                "2160p: 3840x2160",
                "1440p: 2560x1440",
                "1080p: 1920x1080",
                "720p: 1280x720",
               "480p: 854x480",
                "360p: 640x360",
                "240p: 426x240"
            );

		$model = new MetaData;
		$currencylist = get_currency_list();
		$watermark_image_position = array("Top"=>"top","Bottom"=>"bottom","Left"=>"left","Right"=>"right");
		$date_format_arr = array( "jS F, Y" => "9th May, 2018 (jS F, Y)", "d M, Y" => "21 Jun, 2018 (j F, Y)" );
		$time_format_arr = array( "h:i A" => "09:00 PM (h:i A)", "H:i:s" => "10:43:01 (H:i:s)" );
		 $active_tab = 'general';
		return view('bracket-admin.settings.general')->with('models',$model)
			->with("generalsettings", $this->generalSettings)
			->with("active_tab", $active_tab)
			->with("date_format_arr", $date_format_arr)
			->with("currency_arr", $currencylist)
			->with("time_format_arr", $time_format_arr)
			->with("watermark_image_position_arr",$watermark_image_position)
			->with("resolutionarr", $resolutionarr)
             ->with("compressionrr", $compressionrr);
			
	}
	
	public function updateGeneralSetting(Request $request){
		          
		$this->validate($request, [
			'master_agency_name' => 'required|min:3|max:255',
			'master_agency_email' =>  'required|email|min:3|max:255',
			'master_agency_contact_number' => 'required',
			'master_agency_address' => 'required|min:3|max:255',
			'website_logo' => 'mimes:jpeg,png,gif,jpg|dimensions:min_width=456,min_height=281', //only allow this type extension file.
			'website_favicon' => 'mimes:jpeg,png,ico,jpg|dimensions:max_width=16,max_height=16', //only allow this type extension file.
			'website_watermark' => 'mimes:jpeg,png,jpg', //only allow this type extension file.
			'home_page_video' => 'mimes:mp4,3gp,ogg,wmv',
        ], [
            'master_agency_name.required' => 'Please enter Agency Name.',
            'master_agency_email.required' => 'Please Enter Agency Email Id.',
            'master_agency_email.email' => 'Please Enter Valid Agency Email Id.',
			'master_agency_contact_number.required' => 'Please Enter Agency Contact number.',
            'master_agency_address.required' => 'Please Enter Agency Address.',
			'website_logo.mimes'=>'Invalid image type. Allowed type(jpeg,png,gif,jpg)',
			'website_favicon.mimes'=>'Invalid image type. Allowed type(jpeg,png,ico,jpg)',
			'website_watermark.mimes'=>'Invalid image type. Allowed type(jpeg,png,jpg)',
			'website_logo.dimensions' =>"The website logo has invalid image dimensions.min dimensions(450 X 281)",
			'website_favicon.dimensions' =>"The website logo has invalid image dimensions.max dimensions(16 X 16)",
			'home_page_video.mimes' =>"Invalid video type. Allowed type(mp4,3gp,ogg,wmv)"
			
        ]);
		
		
        $settingsArray =  $request->all();
            
        unset($settingsArray['_token']);
		foreach( $settingsArray as $key => $meta_settings ){
			if(!empty($meta_settings)){
						
			if($key == 'website_logo'){
			if($request->file('website_logo')->getClientOriginalName()) {
				    $websitelogoname = time().$request->file('website_logo')->getClientOriginalName();
					$request->file('website_logo')->move(public_path('upload/'), $websitelogoname);
					if(!empty($settingsArray['old_website_logo'])){
							if(file_exists(public_path('upload/'.$settingsArray['old_website_logo']))){
							  @unlink(public_path('upload/'.$settingsArray['old_website_logo']));
							}
						}
			  }
		
			$setting_meta = MetaData::firstOrNew([
			'meta_key' => 'website_logo'
			]);
			  
			  
			 $setting_meta->meta_value = $websitelogoname; 
			}else if($key == 'website_favicon')
			{
				
				if($request->file('website_favicon')->getClientOriginalName()) {
				    $websitefaviconname = time().$request->file('website_favicon')->getClientOriginalName();
					$request->file('website_favicon')->move(public_path('upload/'), $websitefaviconname);
					
					if(!empty($settingsArray['old_website_favicon'])){
							if(file_exists(public_path('upload/'.$settingsArray['old_website_favicon']))){
							  @unlink(public_path('upload/'.$settingsArray['old_website_favicon']));
							}
						}
					
			  }
			
			$setting_meta = MetaData::firstOrNew([
			'meta_key' => 'website_favicon'
			]);
			  
			  
			 $setting_meta->meta_value = $websitefaviconname; 
				
			}else if($key == 'watermark_image'){
				
			
				if($request->file('watermark_image')->getClientOriginalName()) {
						$watermarkimagename = time().$request->file('watermark_image')->getClientOriginalName();
						$request->file('watermark_image')->move(public_path('upload/'), $watermarkimagename);
					
						if(!empty($settingsArray['old_watermark_image'])){
							if(file_exists(public_path('upload/'.$settingsArray['old_watermark_image']))){
							  @unlink(public_path('upload/'.$settingsArray['old_watermark_image']));
							}
						}
				  }
		
				$setting_meta = MetaData::firstOrNew([
				'meta_key' => 'watermark_image'
				]);
			  
			  
				$setting_meta->meta_value = $watermarkimagename; 
			
			}elseif($key == 'home_page_video'){
				
				if($request->file('home_page_video')->getClientOriginalName()) {
					$file = $request->file('home_page_video');
						$homepagevideo = time().$request->file('home_page_video')->getClientOriginalName();
						//$request->file('home_page_video')->move(public_path('upload/'), $homepagevideo);
						$filePath = 'videos/' . $homepagevideo;
						$ss = Storage::disk('s3')->put($filePath, file_get_contents($file),'public');
						/*if(!empty($settingsArray['old_home_page_video'])){
							if(file_exists(public_path('upload/'.$settingsArray['old_home_page_video']))){
							  @unlink(public_path('upload/'.$settingsArray['old_home_page_video']));
							}
						}*/
				  }
		
				$setting_meta = MetaData::firstOrNew([
				'meta_key' => 'home_page_video'
				]);
			  
			  
				$setting_meta->meta_value = $homepagevideo; 
			}else{
			
				
				if($key != 'old_watermark_image' && $key != 'old_website_logo' && $key != 'old_website_favicon' && $key != 'old_home_page_video' && $key != 'old_watermark_image_position'){
					
					$setting_meta = MetaData::firstOrNew([
						'meta_key' => $key
					]);
						
					$setting_meta->meta_value = $meta_settings;	
				}
				
			
			}
			$setting_meta->save();
                   
		}
		}
		
	return redirect()->route('admin.settings.general')->withinfo('Settings Updated Successfully.');
		
	}
        
        
       public function updateConfigSetting(Request $request){
             $settingsArray =  $request->all();
               
              
               unset($settingsArray['_token']);
		foreach( $settingsArray as $key => $meta_settings ){
                    if(!empty($meta_settings)){
			$setting_meta = MetaData::firstOrNew([
				'meta_key' => $key
			]);
			
			$setting_meta->meta_value = $meta_settings;
			$setting_meta->save();
                    }
		}
		
	//return redirect()->route('admin.settings.configuration')->withinfo('Settings Updated Successfully.');

	//return redirect()->route('admin.settings.general')->withinfo('ConfigurationSettings Updated Successfully.');
		//return back in specific tab
return back()->withInput(['tab'=>'tab2'])->withinfo('Configuration Settings Updated Successfully ');
		
	}
        
         public function updateVideoSetting(Request $request){
             $settingsArray =  $request->all();
               
          
               unset($settingsArray['_token']);
		foreach( $settingsArray as $key => $meta_settings ){
                    if(!empty($meta_settings)){
			$setting_meta = MetaData::firstOrNew([
				'meta_key' => $key
			]);
			
			$setting_meta->meta_value = $meta_settings;
			$setting_meta->save();
                    }
		}
		
	//return redirect()->route('admin.settings.video')->with('message', 'Settings Updated Successfully.');
	//return redirect()->route('admin.settings.general')->withinfo('Video Settings Updated Successfully.');
		//return to specific tab
		return back()->withInput(['tab'=>'tab3'])->withinfo('Video Settings Updated Successfully ');

		
	}
	
	
	
	public function changePassword(Request $request){
		return view('admin.changepassword');
	}
	
	
	public function changePasswordSave(Request $request){
		
		$this->validate($request, [
			'old_password' => 'required|min:6',
			'new_password' => 'required|min:6',
			'confirm_new_password' => 'required|min:6|same:new_password',
        ], [
		"old_password.required" => "Please enter your Current Password.",
		"old_password.min" => "Current Password must be at least 6 characters.",
		"new_password.required" => "Please enter your New Password.",
		"new_password.min" => "New Password must be at least 6 characters.",
		"confirm_new_password.required" => "Please Enter Confirm Password.",
		"confirm_new_password.min" => "Confirm Password must be at least 6 characters.",
		"confirm_new_password.same" => "Confirm Password must be Same.",
		] );
		
		$old_password = $request->input('old_password');
		$new_password = $request->input('new_password');
		
		$current_user = Auth::user();
		
		if( Hash::check( $old_password, $current_user->password )){
			
			$user_data = User::find( $current_user->id );
			$user_data->password = Hash::make( $new_password );
			$user_data->save();
			
			return redirect()->back()->with('message', "Password Updated Successfully" );
		}
		else{
			return redirect()->back()
            ->withErrors( [
                'old_password' => "Please Enter Correct Password.",
            ] );
		}
	}
	
	public function editProfile(Request $request){
		$user_data = Auth::user();
		
		$set_design_limiter = 0;
		$user_xprofile_data = array();
		
		
		$states = State::getActiveStateRecords(1);
		
		return view('admin.editprofile')
				->with("set_design_limiter", $set_design_limiter)
				->with("user_data", $user_data)
				->with("user_xprofile_data", $user_xprofile_data)
				->with("states", $states);
	}
	
	public function editProfileSave(Request $request){
		
		$name_regex = "/^[\pL\s]+$/u";
		
		$user_data = Auth::user();
		
	
			$this->validate($request, [
				'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
				'email' => 'required|email|min:3|max:255|unique:users,email,'.$user_data->id.',id,deleted_at,NULL',
				
			], [
				'name.required' => 'Please enter Name.',
				'name.regex' => 'Enter only characters',
				'email.required' => 'Please Enter Email Id.'
			]);
			
			$user_data->name = $request->input("name");
			$user_data->email = $request->input("email");
			$user_data->contact_number = $request->input("contact");
			
			if ( $request->hasFile('profile_img') ) {
				$image_result = Imageupload::upload( $request->file('profile_img'));
				
				$user_data->image_id = $image_result['id'];
			}
			else if( $request->input("hidden_image_id") == "" && !$request->hasFile('profile_img') ){
				$user_data->image_id = null;
			}
			
			$user_data->save();
			
			return redirect()->back()->with("message", "Your Profile Information has been Updated Successfully.");
		
	}
	
//commented for single tab accordition
       /* 
        function configuration(){
            $active_tab = 'configuration';
            return view('admin.settings.configuration')
             ->with("generalsettings", $this->generalSettings)
            ->with("active_tab", $active_tab);
        }
	
	 function video(){
             
           
            $active_tab = 'video';
            $compressionrr = array(
                '240p (424x240, 0.10 megapixels)',
                '360p (640x360, 0.23 megapixels)',
                '432p (768x432, 0.33 megapixels)',
                '480p (848x480, 0.41 megapixels, "SD" or "NTSC widescreen")',
                '576p (1024x576, 0.59 megapixels, "PAL widescreen")',
                '720p (1280x720, 0.92 megapixels, "HD")',
                '1080p (1920x1080, 2.07 megapixels, "Full HD")',
            );
            
            $resolutionarr = array(
                "2160p: 3840x2160",
                "1440p: 2560x1440",
                "1080p: 1920x1080",
                "720p: 1280x720",
               "480p: 854x480",
                "360p: 640x360",
                "240p: 426x240"
            );
            
            return view('admin.settings.videosetting')
             ->with("generalsettings", $this->generalSettings)
             ->with("resolutionarr", $resolutionarr)
             ->with("compressionrr", $compressionrr)
            ->with("active_tab", $active_tab);
        }
	*/
}
