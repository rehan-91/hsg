//     function updateIndividualDetails(Request $request, $id){
// return;

        
//         if(empty($request->input('ad_name'))){
            
//             return;
//         }

//         \DB::enableQueryLog();
//         $user_data = Auth::user();
        
//         if(empty($request->input("ad_listing_type_id"))){

//             return;
//         }
//         $listingExistOrNot = listingtype($request->input("ad_listing_type_id"));
//         if(count($listingExistOrNot) == 0){
//             return;
//         }
        
//         if(!empty($request->input('user_ad_id'))){
//             $userAd = new UserAdvertisement();
//             $ad_id = $request->input('user_ad_id');
//             $userAd = UserAdvertisement::findOrFail($ad_id);
//             $userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
//             $userAd->ad_name = $request->input("ad_name");
//             $userAd->ad_email = $request->input("ad_email");
//             $userAd->ad_contactno = $request->input("ad_contactno");
//             //$userAd->ad_country = $request->input("country_name");
//             $userAd->ad_location = $request->input("city_name");
//             $userAd->ad_suburbs = $request->input("suburbs");
//             $userAd->about_description = $request->input("about_description");
//             $userAd->save();
            

//         }else{          
//             $userAd = new UserAdvertisement();
//             $userAd->ad_user_id = $user_data->id;

//             $userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
//             $userAd->ad_name = $request->input("ad_name");
//             $userAd->ad_email = $request->input("ad_email");
//             $userAd->ad_contactno = $request->input("ad_contactno");
//             //$userAd->ad_country = $request->input("country_name");
//             $userAd->ad_location = $request->input("city_name");
//             $userAd->ad_suburbs = $request->input("suburbs");
//             $userAd->about_description = $request->input("about_description");
//             $userAd->status = 0;
//             $userAd->save();
//             $ad_id = $userAd->id;
//         }
//         $request->session()->put('user_ad_id', $ad_id);
//         $requestData = $request->all();
//         unset($requestData['ad_listing_type_id']);
//         unset($requestData['ad_name']);
//         unset($requestData['ad_email']);
//         unset($requestData['ad_contactno']);
//         unset($requestData['country_name']);
//         unset($requestData['city_name']);
//         unset($requestData['suburbs']);
//         unset($requestData['about_description']);
//         unset($requestData['_token']);
//         if(!empty($requestData['custom_fav_things'])){
            
            
//             foreach($requestData['custom_fav_things'] as $custkey=>$fav){               
//                     $masterObjArray = [
//                         'meta_name' => 'fav_things',
//                         'meta_value' => $fav['label']
//                     ];
                
//                     $mainMaster = MainMaster::firstOrCreate([
//                     ['meta_name', '=', 'fav_things'],
//                     ['meta_value', '=', $fav['label']]
//                     ],$masterObjArray );
//                     $masterid = $mainMaster->id;
//                 $key = "fav_things_".$masterid;
//                 $favValue = $fav['value'];              
//                 $data_array = [
//                     'meta_key' => $key,
//                     'meta_value' => $favValue,
//                     'ad_id'=> $ad_id
//                  ];
                 
//                 $fetchExistData  = UserAdMeta::firstOrCreate([
//                     ['meta_key', '=', $key],
//                     ['ad_id', '=', $ad_id],
//                 ], $data_array);
                
//             }
//         }
    

//         if(!empty($requestData['custom_wish_things'])){
            
//             foreach($requestData['custom_wish_things'] as $wishkey=>$cusw){
//                 $masterObjArray = [
//                     'meta_name' => 'wishlist-things',
//                     'meta_value' => $cusw['label']
//                 ];
            
//                 $mainMaster = MainMaster::firstOrCreate([
//                 ['meta_name', '=', 'wishlist-things'],
//                 ['meta_value', '=', $cusw['label']]
//                 ],$masterObjArray );
//                 $wmasterid = $mainMaster->id;
//                 $wkey = "wish_things_".$wmasterid;
//                 $wishValue = $cusw['value'];
//                 $data_array = [
//                     'meta_key' => $wkey,
//                     'meta_value' => $wishValue,
//                     'ad_id'=> $ad_id
//                  ];
                 
//                 $fetchExistData  = UserAdMeta::firstOrCreate([
//                     ['meta_key', '=', $wkey],
//                     ['ad_id', '=', $ad_id],
//                 ], $data_array);
//             }
//         }
//         unset($requestData['custom_fav_things']);
//         unset($requestData['custom_wish_things']);
//         foreach($requestData as $key => $req){
//             $fetchExistData  = UserAdMeta::select()->where([
//                 ['meta_key', '=', $key],
//                 ['ad_id', '=', $ad_id],
//             ]); 
//             if(count($fetchExistData) > 0){
//                     $fetchExistData->delete();
//             }
//                 if(is_array($requestData[$key])){
                
//                     foreach($req as $r){
//                         if(!empty($r)){
//                         $user_ad_meta = new UserAdMeta();
//                         $user_ad_meta->meta_key = $key;
//                         $user_ad_meta->meta_value = $r;
//                         $user_ad_meta->ad_id = $ad_id;
//                         //print_r($user_ad_meta);
//                         $user_ad_meta->save();
//                         //$query = \DB::getQueryLog();
//                         //print_r(end($query));
//                         }
                        
//                     }
//                 }else{
                    
//                         if(!empty($req)){
//                         $user_ad_meta = new UserAdMeta();
//                         $user_ad_meta->meta_key = $key;
//                         $user_ad_meta->meta_value = $req;
//                         $user_ad_meta->ad_id = $ad_id;
//                         $user_ad_meta->save();
//                         //$query = \DB::getQueryLog();
//                         //print_r(end($query));
//                         }
//             }

//         }
    
//         return $ad_id;
//     }