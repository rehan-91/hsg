<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Countries;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Usertype;

use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;


class CountriesController extends Controller
{
    //
        use HasRoles;
	
	protected $guard_name = 'web';
        public function __construct( ) {
        $this->generalSettings = generalSettings();
		
		//For fetching translations in defined locale for whole controller
		app()->setLocale('en');
        }
        
        function index(){
            $usertype=Usertype::all();
            return view('bracket-admin.location.countries.index' , compact('usertype'));
        }
        
        function ajaxData(){
            
            $data = Countries::all();
             return Datatables::of($data)
			->addColumn('name', function ($data) {
				
				return $data->country_name ;
			})
			->addColumn('sort_name', function ($data) {
				
				return $data->country_sort_name;
			})
                        ->addColumn('phone_code', function ($data) {
				
				return $data->country_phone_code;
			})
                       
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('status', function ($data) {
				$status_txt = '';
				if( intval( $data->status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.countries.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['status', 'action'])
			->make(true);
			
        }
        
        function create(){
            
            return view('bracket-admin.location.countries.create');
            
        }
        
         function edit($id){
            
            $data = Countries::findOrFail($id); 
            return view('bracket-admin.location.countries.edit')
            ->with('data', $data);
            
        }
        
        function store(Request $request){
            
            $this->validate($request, [
                "country_name" => 'required|unique:countries,country_name',
                "country_sort_name" =>'required|max:3',
            ],[
                "country_name.required" => "Please enter country name",
                "country_sort_name.required" => "Please enter country sort name"
            ]);
            
            
            $country = new Countries();
            $country->country_name = $request->input("country_name");
            $country->country_sort_name = $request->input("country_sort_name");
            $country->country_phone_code = $request->input("country_phone_code");
            $country->status = $request->input("status");
            $country->save();
            return redirect()->route('admin.countries.index')->withsuccess('Country added Successfully');
            
        }
        
        function update(Request $request, $id){
            $this->validate($request, [
                "country_name" => 'sometimes|unique:countries,country_name,'.$id,
                "country_sort_name" =>'required|max:3',
            ],[
                "country_name.required" => "Please enter country name",
                "country_sort_name.required" => "Please enter country sort name"
            ]);
            
            $country = Countries::findOrFail($id);
         
            $country->country_name = $request->input("country_name");
            $country->country_sort_name = $request->input("country_sort_name");
            $country->country_phone_code = $request->input("country_phone_code");
            $country->status = $request->input("status");
            $country->save();
            
            return redirect()->route('admin.countries.index')->withinfo("Country updated successfully");
        }
}   
