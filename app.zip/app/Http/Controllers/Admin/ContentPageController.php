<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Content;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;
use Exporter;

class ContentPageController extends Controller
{
    //
    
     public function index() {
             
		return view('bracket-admin.contentpage.index');
	}
       
        function create(){
            
            
            return view('bracket-admin.contentpage.create');
			
           
        }
        
        public function edit($id)
        {
            $content = Content::findOrFail($id);
            
           return view('bracket-admin.contentpage.edit' , compact('content'));
	
        }
        
        public function store(Request $request){
        	
		$this->validate($request, [
			'content_title' => 'required|unique:content_pages|min:3|max:255',
            'content_short_desc' => 'required|min:3',
             'content_long_desc' => 'required|min:3|max:255',
			
        ], [
            'content_title.required' => 'Please enter title.',
            'content_short_desc.required' => 'Please enter short description.',
            'content_long_desc.required' => 'Please enter long description.',
        ]);

        $status = 0;
        if( $request->input("status") && intval( $request->input("status") ) == 1 ){
                $status = 1;
        }       
         $objContent = new Content;
      
        $objContent->content_title = $request->input("content_title");      
        $objContent->content_meta_title = $request->input("content_meta_title");
        $objContent->content_meta_keywords = $request->input("content_meta_keywords");
        $objContent->content_meta_description = $request->input("content_meta_description");
        $objContent->content_short_desc = $request->input("content_short_desc");
        $objContent->content_long_desc = $request->input("content_long_desc");
        $objContent->content_status = $status;
        $objContent->content_page_slug = str_slug($request->input("content_title"));
        
        $objContent->save();
      return redirect()->route('admin.content.index')->withsuccess('Content Added Successfully.');
    }
    
      public function update(Request $request, $id){
          
            $objContent = Content::findOrFail($id);  
            if($objContent->content_title != $request->input("content_title")){
                 $this->validate($request, [
			'content_title' => 'required|unique:content_pages|min:3|max:255',
			
                    ], [
                        'content_title.required' => 'Please enter title.',

                    ]);        
            }
                
        $status = 0;
        if( $request->input("status") && intval( $request->input("status") ) == 1 ){
                $status = 1;
        }       
         
        $objContent->content_title = $request->input("content_title");      
        $objContent->content_meta_title = $request->input("content_meta_title");
        $objContent->content_meta_keywords = $request->input("content_meta_keywords");
        $objContent->content_meta_description = $request->input("content_meta_description");
        $objContent->content_long_desc = $request->input("content_long_desc");
        $objContent->content_status = $status;
        $objContent->content_page_slug = str_slug($request->input("content_title"));
        
        $objContent->save();
        return redirect()->route('admin.content.index')->withinfo('Page updated Successfully.');       
            
        }
           public function ajaxData()
    {
            $objcontent = new Content;
            $data = array();
            $data = $objcontent->get_all_contentpage();

            return Datatables::of($data)
            ->addColumn('title', function ($data) {
                
                return $data->content_title ;
            })
            ->addColumn('page_slug', function ($data) {
                
                return $data->content_page_slug;
            })
                       
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
            ->addColumn('content_status', function ($data) {
                $status_txt = '';
                if( intval( $data->content_status ) == 1 ){
                    $status_txt = ' checked';
                }
                
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
        
            ->addColumn('action', function ($data) {
                
                $user_data = Auth::user();
                
                $image_name = 'red-pencil.png';
                $link_title = 'Edit';
                
                
                return '<span>  <a href="' . route("admin.content.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span> ';
            })
            ->rawColumns(['content_status', 'action'])
            ->make(true);
            
    }
     
}
