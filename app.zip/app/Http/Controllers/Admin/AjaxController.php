<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Input;
use Hash;

use App\Models\Usertype;
use App\Models\Age;
use App\Models\Height;
use App\Models\Weight;
use App\Models\Orientation;
use App\Models\Nationality;
use App\Models\Haircolor;
use App\Models\Eyecolor;
use App\Models\ServiceAvailableFor;
use App\Models\ServicesAvailable;
use App\Models\ServiceType;

class AjaxController extends Controller
{
	protected $generalSettings;
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
        }
	
	public function destroyData(Request $request)
	{
            
                if(empty($request->input('model_id')) && empty($request->input('id'))){
                    
                    echo json_encode( array( 'error' => "Invalid Action" ) );
                    return;
                }
                $model = 'App\\Models\\'.$request->input('model_id');
		$data = $model::findOrFail($request->input('id'));
               
                $data->delete();

                echo json_encode(array( 'success' => "Deleted Successfully." ) );
                 return;
		
	}
}
