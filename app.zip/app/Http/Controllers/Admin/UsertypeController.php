<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Usertype;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;
use Exporter;

class UsertypeController extends Controller
{
    use HasRoles;
	
	protected $guard_name = 'web';
	
	protected $generalSettings;
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
		
		//For fetching translations in defined locale for whole controller
		app()->setLocale('en');
    }
	
	/* 
	 * Nodal User's Listing page
	*/
    public function index() {
        
		return view('bracket-admin.usertype.index');
	}
    public function store(Request $request){

		$this->validate($request, [
			'title' => [ 'required', 'min:3' , 'max:255'],
			'class_name' => [ 'required'],
			'listing_type_icon' => 'required|image|mimes:ico,jpeg,jpg,png,gif|max:2048',
		'listing_type_banner' => 'image|mimes:ico,jpeg,jpg,png,gif|max:2048',
		
        ], [
            'title.required' => 'Please enter title.',
		  'class_name.required' => 'Please enter class name',
            
        ]);
                
                
     
        $usertypeObj = new Usertype;
        $usertypeObj->title = $request->input("title");
		$usertypeObj->slug = str_slug($request->input("title"));

		//icon	
		if($usertypeObj_name = $request->file('listing_type_icon')->getClientOriginalName()) {
				    $usertypeObj->icon = time().$request->file('listing_type_icon')->getClientOriginalName();
					 $request->file('listing_type_icon')->move(public_path('upload/'), time().$usertypeObj_name);
					
			  }	
	 //Banner
	 if($request->file('listing_type_banner')){	  
	  if($usertypeObj_name = $request->file('listing_type_banner')->getClientOriginalName()) {
		    $usertypeObj->banner = time().$request->file('listing_type_banner')->getClientOriginalName();
			 $request->file('listing_type_banner')->move(public_path('upload/'), time().$usertypeObj_name);
			
	  }
	}
		$usertypeObj->class_name = $request->input('class_name');
		$usertypeObj->sort_order = (int)$request->input('sort_order');
		$usertypeObj->disclaimer = !empty($request->input('listing_type_disclaimer'))?$request->input('listing_type_disclaimer'):'';
        $usertypeObj->save();
      return redirect()->route('admin.usertype.index')->withsuccess('Listing Added Successfully.');
    }
	
        function create(){
           $usertype = Usertype::all();
            
           return view('bracket-admin.usertype.create' , compact('usertype'));
        }
        
        public function edit($id)
        {
            $usertype = Usertype::findOrFail($id);
        
           return view('bracket-admin.usertype.edit', compact('usertype'));
		
                            
        }
	
        public function update(Request $request, $id){       
		
		$this->validate($request, [
			'title' => [ 'required', 'min:3' , 'max:255'],
			'class_name' => [ 'required'],
		
			
        ], [
		  'title.required' => 'Please enter title.',
		  'class_name.required' => 'Please enter class name',
		
  
        ]);
                
        $usertype = Usertype::findOrFail($id);        
         
      
	   $usertype->title = $request->input("title");
	   //icon
	   if($request->file('listing_type_icon')){
        if($usertype_name = $request->file('listing_type_icon')->getClientOriginalName()) {
				    $usertype->icon = time().$request->file('listing_type_icon')->getClientOriginalName();
					 $request->file('listing_type_icon')->move(public_path('upload/'),  time().$usertype_name);
					 if($request->input('old_image_name')){
						 @unlink(public_path('upload/'.$request->input('old_image_name')));
					 }
					
			  }
			}
//banner
	 if($request->file('listing_type_banner')){
        if($usertype_name = $request->file('listing_type_banner')->getClientOriginalName()) {
				    $usertype->banner = time().$request->file('listing_type_banner')->getClientOriginalName();
					 $request->file('listing_type_banner')->move(public_path('upload/'),  time().$usertype_name);
					 if($request->input('old_image_banner')){
						 @unlink(public_path('upload/'.$request->input('old_image_banner')));
					 }
					
			  }
			}

		$usertype->class_name = $request->input('class_name');
		$usertype->sort_order = $request->input('sort_order');
		$usertype->disclaimer = $request->input('listing_type_disclaimer');
		$usertype->save();
        return redirect()->route('admin.usertype.index')->withinfo('Listing updated Successfully.');       
            
        }


        public function ajaxData(){
          
            $data = array();
            $data = Usertype::all();
            
            
            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->title ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.usertype.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'Usertype\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
			})
			->rawColumns(['action'])
			->make(true);
			
	}
        
        
	
}
