<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Auth;

use App\Models\User;
use App\Models\Role;
use App\Models\Testimonials;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Carbon\Carbon;

class TestimonialsController extends Controller
{
    //
	  public function index() {
        
		return view('bracket-admin.testimonials.index');
	}

	public function create(){
		$data = User::select([ 'id', 'email', 'status'])->where('status', '1')->get();
		return view('bracket-admin.testimonials.create')->with('users', $data);
	}
	

	public function edit($id) {
        
		$userdata = User::select([ 'id', 'email', 'status'])->where('status', '1')->get();
		$data = Testimonials::findOrFail($id);
		return view('bracket-admin.testimonials.edit')
		->with('data', $data)
		->with('users', $userdata);
	}
	
	
	public function store(Request $request){
		
		$this->validate($request, [
			//'test_ad_id' => 'required',
			'test_user_name' => 'required|min:3|max:255',
			'test_user_email' => 'required|min:3|max:255',
			'test_user_msg' => 'required|min:15|max:255',
        ], [
            //'test_ad_id.required' => 'Please select an ad.',
            'test_user_name.required' => 'Please enter name.',
            'test_user_email.required' => 'Please enter email.',
            'test_user_msg.required' => 'Please enter message.',
        ]);
		
		$objTestimonial = new Testimonials();
		$objTestimonial->test_user_email = $request->input('test_user_email');
		$objTestimonial->test_user_location = $request->input('test_user_location');
		$objTestimonial->test_user_name = $request->input('test_user_name');
		$objTestimonial->test_user_contactno = $request->input('test_user_contactno');
		$objTestimonial->test_user_msg = $request->input('test_user_msg');
		
		$vimageName = NULL;
		if($request->file('test_user_img')){
		 if($request->file('test_user_img')->getClientOriginalName()) {
             
           $vimageName = time().$request->file('test_user_img')->getClientOriginalName().'.'.$request->file('test_user_img')->getClientOriginalExtension();
           $request->file('test_user_img')->move('uploads/testimonials/', $vimageName);
		 }
		}
		$objTestimonial->test_user_img = $vimageName;
		$objTestimonial->status= $request->input('status');
		$objTestimonial->test_ad_id = 1;//$request->input('ad_id');
		
		$objTestimonial->save();
		
		return redirect()->route('admin.testimonials.index')->withsuccess('Testimonial Added Successfully.');
	}
	
		public function update(Request $request, $id){
		
		$this->validate($request, [
			//'test_ad_id' => 'required',
			'test_user_name' => 'required|min:3|max:255',
			'test_user_email' => 'required|min:3|max:255',
			'test_user_msg' => 'required|min:15|max:255',
        ], [
            //'test_ad_id.required' => 'Please select an ad.',
            'test_user_name.required' => 'Please enter name.',
            'test_user_email.required' => 'Please enter email.',
            'test_user_msg.required' => 'Please enter message.',
        ]);
		
		$objTestimonial = Testimonials::findOrFail($id);
		
		$objTestimonial->test_user_email = $request->input('test_user_email');
		$objTestimonial->test_user_location = $request->input('test_user_location');
		$objTestimonial->test_user_name = $request->input('test_user_name');
		$objTestimonial->test_user_contactno = $request->input('test_user_contactno');
		
		$objTestimonial->test_user_msg = $request->input('test_user_msg');
		
		$vimageName = NULL;
		if($request->file('test_user_img')){
		 if($request->file('test_user_img')->getClientOriginalName()) {
             
           $vimageName = time().$request->file('test_user_img')->getClientOriginalName().'.'.$request->file('test_user_img')->getClientOriginalExtension();
           $request->file('test_user_img')->move('uploads/testimonials/', $vimageName);
		 }
		}
		$objTestimonial->test_user_img = $vimageName;
		$objTestimonial->status= $request->input('status');
		$objTestimonial->test_ad_id = 1;//$request->input('ad_id');
		
		$objTestimonial->save();
		return redirect()->route('admin.testimonials.index')->withinfo('Testimonials Updated Successfully.');
	}
	
	public function ajaxData(){
			
            $data = array();
            $data = Testimonials::all();
			
            return Datatables::of($data)
			->addColumn('name', function ($data) {
				
				return $data->test_user_name ;
			})
			->addColumn('email', function ($data) {
				
				return $data->test_user_email;
			})
			->addColumn('phone', function ($data) {
				
				return $data->test_user_contactno;
			})
			->addColumn('location', function ($data) {
				
				return $data->test_user_location;
			})

			->addColumn('message', function ($data) {
				
				return $data->test_user_msg;
			})
            
                       
            ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
			->addColumn('blog_status', function ($data) {
				$status_txt = '';
				if( intval( $data->blog_status ) == 1 ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$data->id.'" disabled="disabled" name="status_'.$data->id.'" value="1" '.$status_txt.' class="cbx hidden"> <label for="status_'.$data->id.'" class="switch-box"></label>';
                })
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				
				return '<span>	<a href="' . route("admin.testimonials.edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['blog_status', 'action'])
			->make(true);
	}
}
