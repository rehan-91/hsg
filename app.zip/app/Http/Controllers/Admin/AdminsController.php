<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Hash;
use Auth;
use Imageresize;
use App\Models\User;
use App\Models\Role;
use App\Models\RolePermission;
use App\Models\PermissionGroups;
use App\Models\EmailMessage;
use App\Models\OtherAds;


use App\Http\Requests;
use App\Http\Controllers\Controller;

use Spatie\Permission\Traits\HasRoles;
use Yajra\Datatables\Datatables;
use Imageupload;
use Carbon\Carbon;
use Exporter;

class AdminsController extends Controller
{
	use HasRoles;
	
	protected $guard_name = 'web';
	
	protected $generalSettings;
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
    }
	
	/* 
	 * Admin User's Listing page
	*/
    public function index() {
		return view('admin.admins.index');
	}
	
	/* 
	 * Create form Admin User's
	*/
	public function create() {
		
		$permission_groups = $this->userPermissionFetch(ROLE::ROLE_SUBADMIN);
		
		return view('admin.admins.create')
			->with('permission_groups', $permission_groups);
	}
	
	
	/**
	 * Store a newly created resource in storage.
	 *
	 * @param Request $request
	 * @return Response
	 */
	public function store(Request $request)
	{
		$name_regex = "/^[\pL\s]+$/u";
		
		$this->validate($request, [
			'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
			'email' => 'required|email|min:3|max:255|unique:users,email,NULL,id,deleted_at,NULL',
			'contact' => 'required|digits:10|unique:users,contact_number,NULL,id,deleted_at,NULL'
        ], [
            'name.required' => 'Please enter Name.',
            'name.regex' => 'Enter only characters',
            'email.required' => 'Please Enter Email Id.',
            'contact.required' => 'Please Enter Contact number.',
            'contact.digits' => 'Please Enter only Numbers(0-9).'
        ]);
		
		$status = "inactive";
		if( $request->input("status") && intval( $request->input("status") ) == 1 ){
			$status = "active";
		}
		
		$password = 'Admin@123';//str_random(8);
		
		$user = new User();
		$user->name = $request->input("name");
        $user->email = $request->input("email");
        $user->contact_number = $request->input("contact");
		
		if ( $request->hasFile('profile_img') ) {
			$image_result = Imageupload::upload( $request->file('profile_img'));
			
			$user->image_id = $image_result['id'];
		}
		
        $user->password = Hash::make( $password );
        $user->status = $status;
		$user->save();
		
		$user->assignRole(ROLE::ROLE_SUBADMIN);
		
		if( $request->has("permissions") && count( $request->input("permissions") ) > 0 ){
			$user->givePermissionTo( $request->input("permissions") );
		}
		
		$email_content = array();
		$email_content["user_name"] = ucwords( $user->name );
		$email_content["user_email"] = $user->email;
		$email_content["user_password"] = $password;
	
		$email_message = new EmailMessage();
		$email_message->singleMailSendIntegration($user->email, "AdminRegistration", $email_content );
		
		$email_content = array();
		$email_content["user_name"] = ucwords( $user->name );
		$email_content["user_email"] = $user->email;
		$email_content["login_link"] = '<a href="'.route('admin.loginForm').'" target="_blank">Click Here</a>';
	
		$email_message = new EmailMessage();
		$email_message->singleMailSendIntegration( $user->email, "Account-".$status, $email_content );
		
		return redirect()->route('admin.admins.index')->with('message', 'Admin Added Successfully.');
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($user_id)
	{
		$user_data = Auth::user();
		if( $user_data->hasAnyRole( Role::ROLE_SUBADMIN ) ){
			if( intval( $user_id ) == 1 ){
				return redirect()->back()->with("access_error_msg", "Sorry, You Don't have permission to access this.");
			}
		}
		
		$user = User::findOrFail($user_id);
		
		$user_permissions = $this->userSavedPermissionFetch($user);
		
		$permission_groups = $this->userPermissionFetch( $user->roles[0]["name"] );
		
		return view('admin.admins.edit')
			->with('user', $user)
			->withModel($user)
			->with('user_permissions', $user_permissions)
			->with('permission_groups', $permission_groups);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @param Request $request
	 * @return Response
	 */
	public function update(Request $request, $user_id)
	{
		$name_regex = "/^[\pL\s]+$/u";
		
		$this->validate($request, [
			'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
			'email' => 'required|email|min:3|max:255|unique:users,email,'.$user_id.',id,deleted_at,NULL',
			//'contact' => 'required|digits:10|unique:users,contact_number,'.$user_id.',id,deleted_at,NULL'
        ], [
            'name.required' => 'Please enter Name.',
			'name.regex' => 'Enter only characters',
            'email.required' => 'Please Enter Email Id.',
		//	'contact.required' => 'Please Enter Contact number.',
            //'contact.digits' => 'Please Enter only Numbers(0-9).'
        ]);
		
		$status = "inactive";
		if( $request->input("status") && intval( $request->input("status") ) == 1 ){
			$status = "active";
		}
		
		$user = User::findOrFail($user_id);
		
		$user->name = $request->input("name");
        $user->email = $request->input("email");
		//$user->contact_number = $request->input("contact");
		
		if ( $request->hasFile('profile_img') ) {
			$image_result = Imageupload::upload( $request->file('profile_img'));
			
			$user->image_id = $image_result['id'];
		}
		else if( $request->input("hidden_image_id") == "" && !$request->hasFile('profile_img') ){
			$user->image_id = null;
		}
		
        $user->status = $status;
		
		if( count( $user->getDirty() ) > 0 ){
			foreach( $user->getDirty() as $updated_field => $value ){
				if( $updated_field == "email" ){
					$email_content = array();
					$email_content["user_name"] = ucwords( $user->name );
					$email_content["user_email"] = $request->input("email");
				
					$email_message = new EmailMessage();
					$email_message->singleMailSendIntegration( $request->input("email"), "EmailUpdated", $email_content );
				}
				else if( $updated_field == "status" ){
					$email_content = array();
					$email_content["user_name"] = ucwords( $user->name );
					$email_content["user_email"] = $request->input("email");
					$email_content["login_link"] = '<a href="'.route('admin.loginForm').'" target="_blank">Click Here</a>';
				
					$email_message = new EmailMessage();
					$email_message->singleMailSendIntegration( $user->email, "Account-".$status, $email_content );
				}
			}
		}
		
		$user->save();
		
		if( $request->has("permissions") && count( $request->input("permissions") ) > 0 ){
			$user->syncPermissions( $request->input("permissions") );
		}
		else{
			$user->syncPermissions( [] );
		}
		
		return redirect()->route('admin.admins.index')->with('message', 'Admin Updated Successfully.');
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($user_id)
	{
		$user = User::findOrFail($user_id);
		
		if( $user->hasAnyRole( [Role::ROLE_SUPERADMIN] ) ){
			return Response::json( array( 'error' => "Super Admin cannot be deleted." ) );
		}
		else{
			$email_content = array();
			$email_content["user_name"] = ucwords( $user->name );
			$email_content["user_email"] = $user->email;
		
			$email_message = new EmailMessage();
			$email_message->singleMailSendIntegration($user->email, "DeleteAccount", $email_content );
			
			$user->delete();

			return Response::json( array( 'success' => "Admin Deleted Successfully." ) );
		}
	}
	
	
	public function ajaxData()
	{
		$user_data = Auth::user();
		
		$user_grouped_data = User::role( [ Role::ROLE_SUPERADMIN, Role::ROLE_SUBADMIN ] );
		if( $user_data->hasAnyRole( Role::ROLE_SUBADMIN ) ){
			$user_grouped_data = User::role( [ Role::ROLE_SUBADMIN ] );
		}
		
		return Datatables::of( $user_grouped_data )
			->addColumn('name_data', function (User $user) {
				$return_text = '<span class="table-auth"><img src="'.$user->get_image_data($user->image_id, 'size100').'" alt="'.$user->name.'"> </span>' . $user->name;
				
				return $return_text ;
			})
			->editColumn('status', function ($user) {
                $status_txt = '';
				if( $user->status == 'active' ){
					$status_txt = ' checked';
				}
				
                return '<input type="checkbox" id="status_'.$user->id.'" name="status_'.$user->id.'" value="1" '.$status_txt.' disabled="disabled" class="cbx hidden"> <label for="status_'.$user->id.'" class="switch-box"></label>';
            })
			->editColumn('created_at', function ($user) {
                return $user->created_at ? with( new Carbon($user->created_at) )->format( $this->generalSettings["date_format"]." ".$this->generalSettings["time_format"] ) : '';
            })
			->filterColumn('created_at', function ($query, $keyword) {
                $query->whereRaw("DATE_FORMAT(created_at,'%D %M, %Y %h:%i %p') like ?", ["%$keyword%"]);
            })
			->addColumn('action', function ($query) {
				return '<span>	<a href="' . route("admin.admins.edit", $query->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="delete_admins(\''.route("admin.admins.destroy", $query->id).'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
			})
			->rawColumns(['name_data', 'status', 'action'])
			->make(true);
	}
	
	/**
		* List of Permissions Groups for users
	*/
	/* Custom function for fetching User Permisssion list's */
	public function userPermissionFetch($role_type){
		
		$role_based_permissions = User::rolePermissions( $role_type ); 
		
		$permission_lists = array();
		$permission_groups = PermissionGroups::where("parents_id", 0)->where("status", 1)->get();
		
		if( count($permission_groups) > 0 ){
			$primary_counter = 0;
			foreach( $permission_groups as $groups ){
				$permission_lists[$primary_counter]["label_id"] = $groups["id"];
				$permission_lists[$primary_counter]["label_name"] = $groups["name"];
				
				$permission_sub_groups = PermissionGroups::where("parents_id", $groups["id"])->where("status", 1)->get();
				
				if( count($permission_sub_groups) > 0 ){
					$sub_counter = 0;
					foreach( $permission_sub_groups as $sub_groups ){
						
						$sub_group_permissions = User::subGroupPermissions($sub_groups["id"], $role_based_permissions["perm_id"]);
						if( count( $sub_group_permissions ) > 0 ){
							
							$permission_names = array();
							foreach( $sub_group_permissions as $permission ){
								$permission_names[] = $permission["name"];
							}
							
							$sub_group_data = array();
							$sub_group_data["sub_label_id"] = $sub_groups["id"];
							$sub_group_data["sub_label_name"] = $sub_groups["name"];
							$sub_group_data["sub_group_permissions"] = $sub_group_permissions;
							$sub_group_data["permission_names"] = $permission_names;
							$permission_lists[$primary_counter]["sub_groups"][$sub_counter] = $sub_group_data;
						
							$sub_counter++;
						}
					}
				}
				$primary_counter++;
			}
		}
		
		return $permission_lists;
	}
	/**
		* Saved User Permission Array Generation
	*/
	public function userSavedPermissionFetch( $user ){
		
		$user_perm_arr = array();
		
		$user_permissions = $user->permissions->toArray();
		
		foreach($user_permissions as $permission){
			$user_perm_arr[] =  $permission["name"];
		}
		
		return $user_perm_arr;
	}
	
	
	
	//........other ads .......
	public function OtherAdsView()
	{
		return view('bracket-admin.other-ads.index');
	}


		public function OtherAdsCreate()
	{
		return view('bracket-admin.other-ads.create');
	}
	public function OtherAdsEdit($id){
          
          
            $other_ads = OtherAds::findOrFail($id);
           return view('bracket-admin.other-ads.edit')
			->with('other_ads',$other_ads)
			->withModel($other_ads);
        
      }

public function OtherAdsStore(Request $request){
        
    $this->validate($request, [
		'other_ads_title' => 'required',
          'other_ads_photo' => 'mimes:jpeg,png,jpg', //only allow this type extension file.
			
        ], [
            'other_ads_title.required' => 'Please enter value.',
            'other_ads_photo.mimes'=>'Invalid image type. Allowed type(jpeg,png,jpg)',	
        ]);
     $objOtherAds = new OtherAds;
		
	$objOtherAds->title = $request->input('other_ads_title');
        
     $settingsArray =  $request->all();
     foreach( $settingsArray as $key => $meta_settings ){
	if(!empty($meta_settings)){		
		if($key == 'other_ads_photo'){
		if($request->file('other_ads_photo')->getClientOriginalName()) {
			$otheradsphotoname = time().$request->file('other_ads_photo')->getClientOriginalName();
				$img = Imageresize::make($request->file('other_ads_photo')->getRealPath());
				$img->resize(434, null, function ($constraint) {
					$constraint->aspectRatio();
					})->save('uploads/other_ads_photos/'.$otheradsphotoname);
			$objOtherAds->ad_photo = $otheradsphotoname;		
			$objOtherAds->sort_order = $request->input('other_ads_sort_order');
			$objOtherAds->save();
			}
		}

	}
}

     return redirect()->route('admin.OtherAds')->withsuccess('Value  Added Successfully.');
}
     public function OtherAdsUpdate(Request $request,$id){
		
    $this->validate($request, [
		  'other_ads_title' => 'required'	,
            'other_ads_sort_order' => 'required',
            'other_ads_photo' => 'mimes:jpeg,png,jpg', //only allow this type extension file.
			
        ], [
            'other_ads_title.required' => 'Please enter value.',
            'other_ads_sort_order.required' => 'Please Enter A Sort Order Number For Home Screen Ad',
            'other_ads_photo.mimes'=>'Invalid image type. Allowed type(jpeg,png,jpg)',	
        ]);
        $objOtherAds = OtherAds::findOrFail($id);
		$objOtherAds->title = $request->input('other_ads_title');
        
        $settingsArray =  $request->all();
        foreach( $settingsArray as $key => $meta_settings ){
			if(!empty($meta_settings)){
			
       if($key == 'other_ads_photo'){
        if($request->file('other_ads_photo')->getClientOriginalName()) {
						$otheradsphotoname = time().$request->file('other_ads_photo')->getClientOriginalName();
						$img = Imageresize::make($request->file('other_ads_photo')->getRealPath());
						$img->resize(434, null, function ($constraint) {
							$constraint->aspectRatio();
						 })->save(public_path('uploads/other_ads_photos/'.$otheradsphotoname));
			
					      $objOtherAds->ad_photo = $otheradsphotoname;
					
						if(!empty($settingsArray['old_other_ads_photos'])){
							if(file_exists(public_path('other_ads_photos/'.$settingsArray['old_other_ads_photos']))){
								@unlink(public_path('uploads/other_ads_photos/'.$settingsArray['old_other_ads_photos']));
							}
						}
						
					}
				   
				   $objOtherAds->sort_order = $request->input('other_ads_sort_order');
       

       $objOtherAds->save();
 }
		}

}

         return redirect()->route('admin.OtherAds')->withinfo('Updated Successfully.');
          
    }
    
    public function OtherAdsAjaxData(){
       
         
            $data = OtherAds::all();

            return Datatables::of($data)
			->addColumn('title', function ($data) {
				
				return $data->title ;
			})
			
                        ->addColumn('created_at', function ($data) {
                return $data->created_at ? with( new Carbon($data->created_at) ): '';
            })
		
		
			->addColumn('action', function ($data) {
				
				$user_data = Auth::user();
				
				$image_name = 'red-pencil.png';
				$link_title = 'Edit';
				
				return  '<span>	<a href="' . route("admin.other_ads_edit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="Edit"><img src="'. asset('admin-vendors/images/red-pencil.png') .'" alt="small eyes" class="img-responsive small-eyes"></a> 	<a href="Javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Delete" onclick="deleteAction(\'MainMaster\', \''.$data->id.'\');" ><img src="'. asset('admin-vendors/images/red-delete.png') .'" alt="small eyes" class="img-responsive small-eyes"></a>	</span>';
				
				//return '<span>	<a href="' . route("admin.masters.ageedit", $data->id) . '" data-toggle="tooltip" data-placement="top" title="'.$link_title.'" ><img src="'. asset('admin-vendors/images/'. $image_name) .'" alt="small eyes" class="img-responsive small-eyes"></a>   </span>	';
			})
			->rawColumns(['action'])
			->make(true);
    }
	

	
	
	

}