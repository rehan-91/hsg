<?php

namespace App\Http\Controllers\Frontend;

use Response;
use Auth;

use App\Models\Courses;
use App\Models\Modules;
use App\Models\ModulesContent;
use App\Models\ModulesUserHistory;
use App\Models\ModulesUserWatchTimeLog;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class FTrainingController extends Controller
{
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
    }
    public function index($course_id){
		
		$courses = Courses::find($course_id);
		
		if( $courses != "" && isset($courses->id) ){
			$default_locale = app()->getLocale();
			
			$user_data = Auth::user();
			$master_courses = Courses::translatedIn($default_locale)->where('status','=', 1)->get();
			
			$current_course = Courses::getUserCourseRolledData($user_data->id, $course_id);
			
			$default_selected_module = $current_course[0]["course_modules"][0]->id;
			
			$default_selected_topic = 0;
			if( count( $current_course[0]["course_last_viewed_module"] ) > 0 ){
				$default_selected_module = $current_course[0]["course_last_viewed_module"][0]->module_id;
				$default_selected_topic = $current_course[0]["course_last_viewed_module"][0]->content_id;
			}
			
			$selected_module_data = $courses->course_translation_modules( $course_id, $default_locale, $default_selected_module  );
			
			$selected_topic_data = $courses->course_translation_singular_topic( $default_selected_module, $default_locale, $default_selected_topic  );
			
			return view('frontend.courses')
				->with("courses", $courses)
				->with("current_course", $current_course)
				->with("master_courses", $master_courses)
				->with("view_increment_counter", $this->generalSettings['view_increment_counter'])
				->with("selected_topic", $selected_topic_data)
				->with("selected_module", $selected_module_data);
		}
		else{
			return redirect('dashboard');
		}
	}
	
	public function moduleTopics(Request $request){
		$locale = $request->input("locale");
		$course_id = $request->input("course_id");
		$module_id = $request->input("module_id");
		
		$courses = Courses::find($course_id);
		
		$user_id = Auth::user()->id;
		
		if( $courses != "" && isset($courses->id) ){
			
			$module_data = $courses->course_translation_modules($course_id, $locale, $module_id);
			
			$module_topics = $courses->course_translation_modules_topics($courses->id, $locale, $module_id);
			foreach($module_topics as $topic){
				$topic->video_duration = get_session_durations_topics($topic);
				
				$total_topic_views = $topic->topic_history_per_user($user_id, $module_id, $locale)->get();
				
				$total_views = get_translations_trimmed($locale, "viewed_time", array( "view_count" => count($total_topic_views) ) );
				
				$topic->view_counter = $total_views;
				$topic->total_topic_views = count( $total_topic_views );
			}
			
			return Response::json( array( 'success' => "Topic Data Found.", "module_data" => $module_data, "module_topics" => $module_topics ) );
		}
		else{
			return Response::json( array( 'error' => "Data not Found" ) );
		}
	}
	
	public function moduleTopicsContent(Request $request){
		$locale = $request->input("locale");
		$course_id = $request->input("course_id");
		$module_id = $request->input("module_id");
		$topic_id = $request->input("topic_id");
		
		$reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
		
		$topics_data = ModulesContent::where("id", $topic_id)->where("module_id", $module_id)
				->with( 'translations' )
				->whereHas('translations', function($query) use ($locale) {
					$query->where('locale', $locale);
				})
				->where('status','=', 1)
				->first();
		
		$user_id = Auth::user()->id;
		
		if( $topics_data != "" && isset($topics_data->id) ){
			
			$modules_data = Modules::find( $module_id );
			
			$topic_prev_next_data = Modules::getTopicPreviousNextData($course_id, $modules_data, $topics_data);
			
			$topics_data->video_duration = get_session_durations_topics($topics_data);
			
			$topics_data->module_name = $modules_data->name;
			$topics_data->modules_counter = $modules_data->counter;
			
			$total_topic_views = $topics_data->topic_history_per_user($user_id, $module_id, $locale)->get();
			
			$total_views = get_translations_trimmed($locale, "viewed_time", array( "view_count" => count($total_topic_views) ) );
			
			$topics_data->view_counter = $total_views;
			
			if( preg_match($reg_exUrl, $topics_data->short_description, $url) ) {
				$topics_data->short_description =  preg_replace($reg_exUrl, '<a href="'.$url[0].'" rel="nofollow">'.$url[0].'</a>', $topics_data->short_description );
			}
			
			$seekTime = 0;
			$topic_seekdata = $topics_data->topicSeekTime($user_id, $locale);
			if( count($topic_seekdata) > 0 ){
				
				$difference_results = array(0, 1);
				
				$video_duration = convert_time_to_seconds( $topics_data->duration );
				
				$topic_last_seentime = $seekTime = $topic_seekdata[0]->seektime;
				
				$difference_in_time = intval( $video_duration ) - intval( $topic_last_seentime );
				
				if( in_array( intval($difference_in_time), $difference_results) ){
					$seekTime = 0;
				}
			}
			
			$topics_data->seekTime = $seekTime;
			
			return Response::json( array( 'success' => "Topic Data Found.", "topic_data" => $topics_data, "topics_next_previous" => $topic_prev_next_data ) );
		}
		else{
			return Response::json( array( 'error' => "Data not Found" ) );
		}
	}
	
	function addTopicsViewWatchCounter(Request $request){
		
		$user_id = $request->input( 'user_id' );
		$course_id = $request->input( 'course_id' );
		$module_id = $request->input( 'module_id' );
		$content_id = $request->input( 'content_id' );
		$locale = $request->input( 'locale' );
		$seek_time = $request->input( 'seek_time' );
		$watchtime_id = $request->input( 'watchtime_id' );
		$watchtime_counter = $request->input( 'watchtime_counter' );
		
		$view_id = 0;
		$watchtime_log_id = 0;
		
		$module_views = new ModulesUserHistory();
		$module_views->user_id = $user_id;
		$module_views->course_id = $course_id;
		$module_views->module_id = $module_id;
		$module_views->content_id = $content_id;
		$module_views->locale = $locale;
		$module_views->status = 1;
		$module_views->save();
		
		$view_id = $module_views->id;
		
		if( intval($watchtime_id) > 0 ){
			$module_watchtime_log = ModulesUserWatchTimeLog::find($watchtime_id);
			$module_watchtime_log->watchtime = intval( $watchtime_counter);
			$module_watchtime_log->seektime = intval( $seek_time );
			$module_watchtime_log->save();
			
			$watchtime_log_id = $watchtime_id;
		}
		else{
			$module_watchtime_log = new ModulesUserWatchTimeLog();
			$module_watchtime_log->user_id = $user_id;
			$module_watchtime_log->course_id = $course_id;
			$module_watchtime_log->module_id = $module_id;
			$module_watchtime_log->content_id = $content_id;
			$module_watchtime_log->locale = $locale;
			$module_watchtime_log->watchtime = intval( $watchtime_counter);
			$module_watchtime_log->seektime = intval( $seek_time );
			$module_watchtime_log->status = 1;
			$module_watchtime_log->save();
			
			$watchtime_log_id = $module_watchtime_log->id;
		}
		
		return Response::json( array( 'success' => "Course View Counter Incremented.", "view_id" => $view_id, "watchtime_log_id" => $watchtime_log_id ) );
	}
	
	function addTopicWatchTimeLog(Request $request){
		
		$user_id = $request->input( 'user_id' );
		$course_id = $request->input( 'course_id' );
		$module_id = $request->input( 'module_id' );
		$content_id = $request->input( 'content_id' );
		$locale = $request->input( 'locale' );
		$seek_time = $request->input( 'seek_time' );
		$watchtime_id = $request->input( 'watchtime_id' );
		$watchtime_counter = $request->input( 'watchtime_counter' );
		
		$view_id = 0;
		$watchtime_log_id = 0;
		
		if( intval($watchtime_id) > 0 ){
			$module_watchtime_log = ModulesUserWatchTimeLog::find($watchtime_id);
			$module_watchtime_log->watchtime = intval( $watchtime_counter);
			$module_watchtime_log->seektime = intval( $seek_time );
			$module_watchtime_log->save();
			
			$watchtime_log_id = $watchtime_id;
		}
		else{
			$module_watchtime_log = new ModulesUserWatchTimeLog();
			$module_watchtime_log->user_id = $user_id;
			$module_watchtime_log->course_id = $course_id;
			$module_watchtime_log->module_id = $module_id;
			$module_watchtime_log->content_id = $content_id;
			$module_watchtime_log->locale = $locale;
			$module_watchtime_log->watchtime = intval( $watchtime_counter);
			$module_watchtime_log->seektime = intval( $seek_time );
			$module_watchtime_log->status = 1;
			$module_watchtime_log->save();
			
			$watchtime_log_id = $module_watchtime_log->id;
		}
		
		return Response::json( array( 'success' => "Course Watch Time Log Updated.", "view_id" => $view_id, "watchtime_log_id" => $watchtime_log_id ) );
	}
}
