<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Spatie\Permission\Traits\HasRoles;
use Validator;
use Auth;
use Hash;
use Redirect;
use Response;
use Session;
use File; 
use DB;
use App\Models\Blogs;
use App\Models\State;
use App\Models\User;
use App\Models\Cities;
use App\Models\Role;
use App\Models\RolePermission;
use App\Models\Testimonials;
use Illuminate\Support\Facades\Storage;
use View;
use FFMpeg;

use Carbon\Carbon;

class AjaxController extends Controller
{
	use HasRoles;
	
	protected $guard_name = 'web';

	
	protected $generalSettings;
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
    }
	

	function savePostData(Request $request){
		print_r($request->all());
	}
	

	function adImageUpload(Request $request){
		$url = "";
	
		
		if($request->input('action')== 'blur'){

		$image_name =str_replace("s3.",'.',$request->input("image_file_name"));
		$x1 = $request->input("x1");
		$y1 = $request->input("y1");
		$x2 = $request->input("x2");
		$y2 = $request->input("y2");
		$path = exec('python3'.' '.public_path('photoscript/blur.py ').' '.$image_name.','.$x1.','.$y1.','.$x2.','.$y2);
		return $url = url('/uploads/ads_image/'.$path);

		}else if($request->input('action')== 'crop'){

			$image_name = str_replace("s3.",'.',$request->input("image_file_name"));
			$x1 = $request->input("x1");
			$y1 = $request->input("y1");
			$x2 = $request->input("x2");
			$y2 = $request->input("y2");
			$path = exec('python3'.' '.public_path('photoscript/crop.py ').' '.$image_name.','.$x1.','.$y1.','.$x2.','.$y2);
			return $url = url('/uploads/ads_image/'.$path);
			
		}
		else if($request->input('action')== 'reset'){
			
			$image_file_name = explode(".", $request->input('image_file_name'))[0];
		
			if(file_exists(public_path('uploads/ads_image/'.$image_file_name."s3.jpg"))){

				unlink(public_path('uploads/ads_image/'.$image_file_name."s3.jpg"));
		    
			   }
			return;

		}
		else if($request->input('action')== 'save'){


			$image_thumb_width =  $this->generalSetting['ad_image_thumb_width'];
			$image_thumb_height =  $this->generalSetting['image_thumb_height'];
			$image_large_width = $this->generalSettings['image_large_width'];
			$image_large_height = $this->generalSettings['image_large_height'];
			$watermark_image = $this->generalSettinngs['watermark_image'];
			$watermark_position = $this->generalSettinngs['watermark_position'];
			$image_name = str_replace("s3.",'.',$request->input("image_file_name"));
			$path = exec('python3'.' '.public_path('photoscript/script.py ').' '.$image_name.','.$image_large_width.','.$image_large_height.','.$image_thumb_height.','.$image_thumb_height.','.$watermark_image.','.$watermark_position);
			return $url = url('/uploads/ads_image/'.$path);
			
		}else{

			if($request->file('pro-image')){
				if($request->file('pro-image')->getClientOriginalName()) {
					
					$vimageName = time().$request->file('pro-image')->getClientOriginalName();
					$request->file('pro-image')->move(public_path('uploads/ads_image/'), $vimageName);
					$url = url('/uploads/ads_image/'.$vimageName);
			}

		}
	
			   return $url;

		}

		
		   

	}
	function fetchcitiesbycountry(Request $request){
		$country_id = $request->post('country_id');
		$country = Cities::where('country_id', $country_id)->get();
		$html = "<option value=''>City</option>";
		
		if(count($country) > 0){
			foreach($country as $cou){
				$html .= "<option value='".$cou['id']."'>".$cou['name']."</option>";
			}
		}
		return $html;
	}
	function addTestimonials(Request $request){
	// print_r($request->all());
		$name_regex = "/^[\pL\s]+$/u";
		$user = Auth::user();
		$ad_id = $request->post('test_ad_id');
		$user_id = $request->post('test_user_id');
		$name = $request->post('name');
		$email = $request->post('email');
		$contact = $request->post('contact');
		$message = $request->post('message');
		$rating =  $request->post('rating_value');
		$getTestimonials = Testimonials::where('test_ad_id', $ad_id)->where('test_user_email', $email)->get();
		if(count($getTestimonials) > 0){
			return Response::json( array( 'errors' => 'Already reviewed.' ) );	
		}

		$validator = Validator::make( $request->all(), [
			'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
			'email' => 'required|email|min:3|max:255',
			'contact' => ['required'],
			'message'=>'required|min:50',
			 'g-recaptcha-response' => 'required|captcha',
			'rating_value' => 'required'
                    ], [
				'name.required' => 'Please enter Name.',
				'name.regex' => 'Enter only characters',
				'email.required' => 'Please Enter a valid Email Id.',
				'contact.required' => 'Please Enter Your Contact.',
				'message.required' => 'Please Enter your message.',
				'message.min' => 'Please enter at least 50 character .',
				'rating_value.required' => 'Rating is mandatory',
				'g-recaptcha-response.required' => 'Before you proceed to the add testimonial, please complete the captcha.'	
		]);
		if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			   
		}else{
			$testimonials = new Testimonials();
			$testimonials->test_ad_id = $ad_id;
			$testimonials->test_user_id = $user_id;
			$testimonials->test_user_name = $name;
			$testimonials->test_user_email = $email;
			$testimonials->test_user_contactno = $contact;
			$testimonials->test_user_msg = $message;
			$testimonials->test_user_rating = $rating;
			$testimonials->save();
			
			
			// $email_content_admin = array();
			// $email_content_admin["user_name"] = ucwords( $name );
			// $email_content_admin["user_email"] = $email;
			// $email_content_admin["user_contact"] = $contact;
			// $email_content_admin["user_message"] = $message;
			// $email_content_admin["view_testimonial_link"] = '<a href="'.url('/').'" target="_blank">Click Here</a>';
			// $email_message_admin = new EmailMessage();
			// $email_message_admin->singleMailSendIntegration( $user->email, "NewTestimonialAdmin", $email_content_admin );
				
			// $email_content_aduser = array();
			// $email_content_aduser["user_name"] = ucwords( $name );
			// $email_content_aduser["user_email"] = $email;
			// $email_content_aduser["user_contact"] = $contact;
			// $email_content_aduser["user_message"] = $message;
			// $email_content_aduser["view_testimonial_link"] = '<a href="'.url('/').'" target="_blank">Click Here</a>';
			// $email_message_aduser = new EmailMessage();
			// $email_message_aduser->singleMailSendIntegration( $user->email, "NewTestimonialAdUser", $email_content_aduser );
			
			// $email_content_user = array();
			// $email_content_user["user_name"] = ucwords( $name );
			// $email_message_user = new EmailMessage();
			// $email_message_user->singleMailSendIntegration( $user->email, "NewTestimonialUser", $email_content_aduser );
				
			return Response::json( array( 'success' =>'Testimonial has been saved. Please cheack you email.'));	

		}
	}

	function uploadVideo(Request $request){
		if($request->file('pro-video')){
		
			$file = $request->file('pro-video');
			if($request->file('pro-video')->getClientOriginalName()) {
				
				$vimageName = time().$request->file('pro-video')->getClientOriginalName();
				$filePath = 'videos/' . $vimageName;
				
				$ss = Storage::disk('s3')->put($filePath, file_get_contents($file),'public');
			//	ffmpeg -i INPUT -vf trim=duration=1
				
				/*FFMpeg::fromDisk('s3')
				->open($vimageName)
				->getFrameFromSeconds(10)
				->export()
				->toDisk('s3')
				->save('FrameAt10sec.png');
				*/
				$array = array(
				'videopath'=>'https://hosg.s3.amazonaws.com/videos/'.$vimageName,
				'file_name' => $vimageName);
				return json_encode($array);
		    }
	    }
	}
	function uploadTeaserVideo(Request $request){
		if($request->file('teaser-video')){
		
			$file = $request->file('teaser-video');
			if($request->file('teaser-video')->getClientOriginalName()) {
				
				$vimageName = time()."teaser_".$request->file('teaser-video')->getClientOriginalName();
				$filePath = 'videos/' . $vimageName;
				
				$ss = Storage::disk('s3')->put($filePath, file_get_contents($file),'public');
			//	ffmpeg -i INPUT -vf trim=duration=1
				
				/*FFMpeg::fromDisk('s3')
				->open($vimageName)
				->getFrameFromSeconds(10)
				->export()
				->toDisk('s3')
				->save('FrameAt10sec.png');
				*/
				$array = array(
				'videopath'=>'https://hosg.s3.amazonaws.com/videos/'.$vimageName,
				'file_name' => $vimageName);
				return json_encode($array);
		    }
	    }
	}

	
	function saveblog(Request $request){

		$requestedData = $request->all();

		$user = Auth::user();
		$validator = Validator::make( $request->all(), [
			'blog_title' => [ 'required', 'min:3' , 'max:255'],
			'ckdemo' => 'required|min:300',
			'featured_image' => 'required|file|max:5000|mimes:jpeg,png,jpg,gif',
			
                    ], [
				'blog_title.required' => 'Please enter Title.',
				'ckdemo.required' => 'Please enter Description',
				'featured_image.required' => "You must use the 'Choose file' button to select which file you wish to upload",
				'featured_image.max' => "Maximum file size to upload is 5000KB . If you are uploading a photo, try to reduce its resolution to make it under 5000KB",

		]);

		if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			   
		}
	    $status = 0;
        if( $request->input("status") && intval( $request->input("status") ) == 1 ){
                $status = 1;
        }  

			$blogsObj = new Blogs();
			$blogsObj->user_id = $user->id;
			$blogsObj->blog_title = $requestedData['blog_title'];
			$blogsObj->blog_desc = $requestedData['ckdemo'];
			$blogsObj->blog_status = $status;
			$blogsObj->blog_meta_title = $requestedData['blog_meta_title'];
			$blogsObj->blog_meta_keywords = $requestedData['blog_meta_keywords'];
			$blogsObj->blog_meta_description = $requestedData['blog_meta_description'];
			$slug = createSlug($requestedData['blog_title'],'Blogs', 'blog_slug');
			$blogsObj->blog_slug = $slug;

	//image upload
				
		if ($request->hasFile('featured_image')) {
        $file = $request->file('featured_image');
        $filename =time().'.'.$file->getClientOriginalName();
        $location =public_path('uploads/ads_image/');
        $file->move($location, $filename);
        $blogsObj->blog_featured_img = $filename;
        
       }

			$blogsObj->save();

			DB::table('activity_log')->insert(
				['user_id' => $user->id, 'activity_message'=>$user->name." added a new story."]
			);
			$request_data['user_lattitude'] = $_COOKIE['user_latitude'];
			$request_data['user_longitude'] = $_COOKIE['user_longitude'];
			$request_data['action'] = 'updateactivity';
			sendRequesToServer($request_data);
			return Response::json( array( 'success' =>'Story Added successfully.', 'redirect_url'=> route('blogIndex')));
		
		 
	 } 
 


	 function updateBlog(Request $request){
		$requestedData = $request->all();
		$user = Auth::user();
		$validator = Validator::make( $request->all(), [
			'blog_title' => [ 'required', 'min:3' , 'max:255'],
			'ckdemo' => 'required|min:300',
			'featured_image' => 'file|max:200|mimes:jpeg,png,jpg,gif',
			
			
                    ], [
				'blog_title.required' => 'Please enter Title.',
				'ckdemo.required' => 'Please enter Description',
				
				'featured_image.max' => "Maximum file size to upload is 200KB . If you are uploading a photo, try to reduce its resolution to make it under 200KB",				
		]);

		if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			   
		}

		$status = 0;
        if( $request->input("status") && intval( $request->input("status") ) == 1 ){
                $status = 1;
        } 

		$blogsObj = Blogs::findOrFail($requestedData['blog_id']);

		$blogsObj->user_id = $user->id;
		$current_title = $blogsObj->blog_title;
		$blogsObj->blog_title = $requestedData['blog_title'];
		$blogsObj->blog_desc = $requestedData['ckdemo'];
		$blogsObj->blog_status = $status;
		$blogsObj->blog_meta_title = $requestedData['blog_meta_title'];
		$blogsObj->blog_meta_description = $requestedData['blog_meta_description'];

		//image upload new
		if ($request->hasFile('featured_image')) {
        $file = $request->file('featured_image');
        $filename =time().'.'.$file->getClientOriginalName();
        $location =public_path('uploads/ads_image/');
        $file->move($location, $filename);
        $blogsObj->blog_featured_img = $filename;
        if($request->input('old_blog_featured_img')){
            @unlink(public_path('uploads/ads_image/'.$request->input('old_blog_featured_img')));
        }
        
       }

		


		if($current_title != $requestedData['blog_title']){
		$slug = createSlug($requestedData['blog_title'],'Blogs', 'blog_slug');
		$blogsObj->blog_slug = $slug;		
		}else{
			$blogsObj->blog_slug = $current_title;
		}
		$blogsObj->save();	
		return Response::json( array( 'success' =>'Story updated successfully.', 'redirect_url'=> route('blogIndex')));
	}
//live update status
	function updateMyStatus(Request $request){

	}
//end live staus
	function viewtestimonial(){
		$user = Auth::user();
		$data = Testimonials::all()->where('test_user_id',$user->id);
		$dashboardData = getUserDashboardData($user);
		$dashboardData['generalsettings']  = $this->generalSettings;
		return view('frontend.testimonial', $dashboardData)->with('users', $userdata)->with('data', $data);		
	}

	function updateTestimonialStatus(Request $request){
		$id = $request->post('id');
		$action = $request->post('action');
		$data = Testimonials::findOrFail($id);
		if($action == 'delete'){
			$data->destroy();
		}else{
			$data->status = 1;
		$data->save();
		} 
		
	}

	function updateTestimonialSetting(Request $request){
		$user = Auth::user();
		$data = User::findOrFail($user->id);
		if(count($data) > 0){
			$data->testimonial_show = $request->post('status');
			$data->save();
		}
	}
	function filterfeaturedads(Request $request){
		$listing_type_id = !empty($request->post('listing_type_id'))?$request->post('listing_type_id'):'';
		$cityids=!empty($request->post('cityid'))?$request->post('cityid'):'';
		if(empty($listing_type_id) && empty($cityids)){

			return json_encode(array('errors'=>'Please select filter', 'count'=>0));
		}

		$res = fetchFeatuedListingFilter($listing_type_id, $cityids);
		if(count($res) == 0){
			return json_encode(array('success'=>"no records found", 'count'=>0));
		}
		$res['count'] = count($res);
		return json_encode($res);
	}

} 