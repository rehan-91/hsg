<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use Response;
use Input;
use Auth;
use DB;
Use Redirect;

use App\Models\User;
use App\Models\Role;
use App\Models\RolePermission;
use App\Models\MainMaster;
use App\Models\Guests;
use App\Models\MetaData;
use App\Models\Plans;
use App\Models\Cities;
use App\Models\ShortList;
use App\Models\AdRate;
use App\Models\AdMeta;
use App\Models\UserAdvertisement;
use App\Models\UserAdMeta;
use App\Models\OtherAds;


use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;

use Carbon\Carbon;


class ShortListController extends Controller
{
	public function __construct( ) {
        $this->generalSettings = generalSettings();
    }
	
    
	
	public function addtowishlist(Request $request){
		$user= Auth::user();
		if(!empty($user)){
			$guestid = $user->id;

		}else{

			$guest_ip_address = $request->getClientIp();
			//$guest_ip_address='122.176.59.133';
			$guests = Guests::where('guest_ip_address', $guest_ip_address)->get();
			
			$guestid = $guests[0]->guest_id;
		}
		$res = ShortList::where('short_ad_id', $request->input('ad_id'))->where('short_guest_id', $guest_ip_address)->get();
		if(count($res) == 0){
		$shortlist = new ShortList;
		$shortlist->short_ad_id = $request->input('ad_id');
		$shortlist->short_guest_id = $guestid;
		$shortlist->save();
		}

	    
	}
	public function removeFromWishlist(Request $request){
		$user= Auth::user();
		if(!empty($user)){
			$guestid = $user->id;

		}else{ 

			$guest_ip_address = $request->ip();
			$guest_ip_address='122.176.59.133';
			$guests = Guests::where('guest_ip_address', $guest_ip_address)->get();
			$guestid = $guests[0]->guest_id;
		}
		
		$shortListExist = ShortList::where('short_ad_id', $request->input('ad_id'))->where('short_guest_id', $guestid)->delete();
		
	}

	public function comparelist(){
		$user= Auth::user();
		$getWishlist = getWishlist();
		if(count($getWishlist) < 2){
		return view('frontend.compare')->with('list', array())
		->with('generalsettings', $this->generalSettings );
		}
		if(count($getWishlist) > 0){

			foreach ($getWishlist as $key => $value) {
				# code...
				$list[] = getAddedItemDetail($value->short_ad_id);
			}
			return view('frontend.compare')->with('list', $list)
		->with('generalsettings', $this->generalSettings );
		}
	
		
		
		
	} 
	
	
}
