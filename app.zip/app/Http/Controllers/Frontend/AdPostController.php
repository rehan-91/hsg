<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Hash;
use Auth;
use Session;
use DB;

use App\Models\User;
use App\Models\MainMaster;

use App\Models\Role;
use App\Models\VerifyUser;
use App\Models\UserOtps;
use App\Models\EmailMessage;
use App\Models\MetaData;
use App\Models\Plans;
use App\Models\Image;
use App\Models\Cities;
use App\Models\Countries;
use App\Models\AdRate;
use App\Models\AdMeta;
use App\Models\OtherAds;
use App\Models\UserAdvertisement;
use App\Models\AdExtraServices;
use App\Models\UserAdMeta;
use App\Models\AdsTouring;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Carbon\Carbon;
class AdPostController extends Controller
{
    //
	public function __construct( ) {
	   $this->generalSettings = generalSettings();
	   $this->middleware(function ($request, $next) {
		$this->user= Auth::user();
  
		return $next($request);
	 });
    }
    
	function ads(){
			
		$listingtype = listingtype();
		
		return view('frontend.ads.listings')->with('listingtype', $listingtype)->with("generalsettings", $this->generalSettings );
	}
	function index(){
	
		$slug = \Request::segment(2);
		$slug2 = \Request::segment(3);
		if(!view()->exists('frontend.ads.'.$slug.'.index')){
			return abort(404);
		}
		$listdata  = array();
		$ad_listing_type_id = getListingId($slug);
		$user_ad_id = \Request::session()->get('user_ad_id');
		if(!empty($user_ad_id)){
			
			$listdata = getAddedItemDetail($user_ad_id);
		}
		
		if(!empty($slug2)){
			$slugdata = UserAdvertisement::all()->where('slug', $slug2);
			
			if(count($slugdata) > 0){
				$user_ad_id = $slugdata->first()->id;
				\Request::session()->put('user_ad_id', $user_ad_id);
				
			$listdata = getAddedItemDetail($slugdata->first()->id);
			}
		}
		

		
		$master_arr = fetchAllMasterData();
		$age = $master_arr['age'];
		$social_media_links = $master_arr['social_media_link'];
		$generalsettings = $this->generalSettings;
		$height = $master_arr['height'];
		$weight = $master_arr['weight'];
		$orientation = $master_arr['orientation'];
		$nationality = $master_arr['nationality'];
		$haircolor = $master_arr['haircolor'];
		$hairlength = $master_arr['hairlength'];
		$dresssize = $master_arr['dresssize'];
		$shoessize = $master_arr['shoessize'];
		$eyecolor = $master_arr['eyecolor'];
		$bustsize = $master_arr['bustsize'];
		$serviceavailablefor =  $master_arr['service-available-for'];
		$servicesavailable =  $master_arr['service-available'];
		$servicetype =$master_arr['service-type'];
		$bodytype = $master_arr['body-type'];
		$personal = $master_arr['personal'];
		$piercing = $master_arr['piercing'];
		$wishlistthings = $master_arr['wishlist-things'];
		$favthings = $master_arr['fav_things'];
		$plans = Plans::all()->where('listing_type_id', '1');
		$cities = Cities::all();
		$countries = Countries::all();
		

		 return view('frontend.ads.'.$slug.'/index', compact('age','generalsettings','height','weight','haircolor',
		 'hairlength','dresssize','shoessize','eyecolor','nationality','orientation','bodytype','serviceavailablefor','servicesavailable',
		 'servicetype','servicetype','piercing','personal','wishlistthings','bustsize','favthings','plans','countries','countries',
		 'social_media_links','ad_listing_type_id','listdata','cities','user_ad_id'));
	
	}
	public function viewProfile($slug){
		$slug = \Request::segment(2);
		$userad = new UserAdvertisement();
		$profileData = $userad->getProfileData($slug);
		if(count($profileData) == 0){

			return back();
		} else{
		$social_media_links = MainMaster::all()->where('meta_name','social_media_link');
		$fav_things = MainMaster::all()->where('meta_name','fav_things');
		
		$listing_type_id = $profileData['adListingTypeId'];
		$slug = listingtype($listing_type_id);
 
		
		$tourData = AdsTouring::all()->where('ad_id',  $profileData['adId']  );
		
		return view("frontend.ads.".$slug[$listing_type_id]['slug'].".ad_profile", compact('tourData'))
		->with('social_media_links', $social_media_links)
		->with('data', $profileData)->with("generalsettings", $this->generalSettings )
		->with('fav_things',$fav_things);
	}
	} 
	 
	
	function saveIndividualDetails(Request $request){
return;

		
		if(empty($request->input('ad_name'))){
			
			return;
		}

		\DB::enableQueryLog();
		$user_data = Auth::user();
		
		if(empty($request->input("ad_listing_type_id"))){

			return;
		}
		$listingExistOrNot = listingtype($request->input("ad_listing_type_id"));
		if(count($listingExistOrNot) == 0){
			return;
		}
		
		if(!empty($request->input('user_ad_id'))){
			$userAd = new UserAdvertisement();
			$ad_id = $request->input('user_ad_id');
			$userAd = UserAdvertisement::findOrFail($ad_id);
			$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
			$userAd->ad_name = $request->input("ad_name");
			$userAd->ad_email = $request->input("ad_email");
			$userAd->ad_contactno = $request->input("ad_contactno");
			//$userAd->ad_country = $request->input("country_name");
			$userAd->ad_location = $request->input("city_name");
			$userAd->ad_suburbs = $request->input("suburbs");
			$userAd->about_description = $request->input("about_description");
			$userAd->save();
			

		}else{			
			$userAd = new UserAdvertisement();
			$userAd->ad_user_id = $user_data->id;

			$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
			$userAd->ad_name = $request->input("ad_name");
			$userAd->ad_email = $request->input("ad_email");
			$userAd->ad_contactno = $request->input("ad_contactno");
			//$userAd->ad_country = $request->input("country_name");
			$userAd->ad_location = $request->input("city_name");
			$userAd->ad_suburbs = $request->input("suburbs");
			$userAd->about_description = $request->input("about_description");
			$userAd->status = 0;
			$userAd->save();
			$ad_id = $userAd->id;
		}
		$request->session()->put('user_ad_id', $ad_id);
		$requestData = $request->all();
		unset($requestData['ad_listing_type_id']);
		unset($requestData['ad_name']);
		unset($requestData['ad_email']);
		unset($requestData['ad_contactno']);
		unset($requestData['country_name']);
		unset($requestData['city_name']);
		unset($requestData['suburbs']);
		unset($requestData['about_description']);
		unset($requestData['_token']);
		if(!empty($requestData['custom_fav_things'])){
			
			
			foreach($requestData['custom_fav_things'] as $custkey=>$fav){				
					$masterObjArray = [
						'meta_name' => 'fav_things',
						'meta_value' => $fav['label']
					];
				
					$mainMaster = MainMaster::firstOrCreate([
					['meta_name', '=', 'fav_things'],
					['meta_value', '=', $fav['label']]
					],$masterObjArray );
					$masterid = $mainMaster->id;
				$key = "fav_things_".$masterid;
				$favValue = $fav['value'];				
				$data_array = [
					'meta_key' => $key,
					'meta_value' => $favValue,
					'ad_id'=> $ad_id
				 ];
				 
				$fetchExistData  = UserAdMeta::firstOrCreate([
					['meta_key', '=', $key],
					['ad_id', '=', $ad_id],
				], $data_array);
				
			}
		}
	

		if(!empty($requestData['custom_wish_things'])){
			
			foreach($requestData['custom_wish_things'] as $wishkey=>$cusw){
				$masterObjArray = [
					'meta_name' => 'wishlist-things',
					'meta_value' => $cusw['label']
				];
			
				$mainMaster = MainMaster::firstOrCreate([
				['meta_name', '=', 'wishlist-things'],
				['meta_value', '=', $cusw['label']]
				],$masterObjArray );
				$wmasterid = $mainMaster->id;
				$wkey = "wish_things_".$wmasterid;
				$wishValue = $cusw['value'];
				$data_array = [
					'meta_key' => $wkey,
					'meta_value' => $wishValue,
					'ad_id'=> $ad_id
				 ];
				 
				$fetchExistData  = UserAdMeta::firstOrCreate([
					['meta_key', '=', $wkey],
					['ad_id', '=', $ad_id],
				], $data_array);
			}
		}
		unset($requestData['custom_fav_things']);
		unset($requestData['custom_wish_things']);
		foreach($requestData as $key => $req){
			$fetchExistData  = UserAdMeta::select()->where([
				['meta_key', '=', $key],
				['ad_id', '=', $ad_id],
			]);	
			if(count($fetchExistData) > 0){
					$fetchExistData->delete();
			}
				if(is_array($requestData[$key])){
				
					foreach($req as $r){
						if(!empty($r)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = $ad_id;
						//print_r($user_ad_meta);
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));
						}
						
					}
				}else{
					
						if(!empty($req)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->ad_id = $ad_id;
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));
						}
			}

		}
	
		return $ad_id;



	}

	function saveIndividualServices(Request $request){
		return;

		$questdata = $request->all();
		$user_ad_id = $request->session()->get('user_ad_id');
		unset($questdata['_token']);
		$serviceData = AdRate::select()->where('ad_id', $user_ad_id);
		$serviceData->delete();
		
		DB::connection()->enableQueryLog();
		
		foreach($questdata['service'] as $serv){
			$service_rates_obj = new AdRate();
			$service_rates_obj->ad_id = $user_ad_id;
			$service_rates_obj->ad_time = $serv['service_time'];
			$service_rates_obj->incall_charge = $serv['service_incall_charge'];
			$service_rates_obj->outcall_charge = $serv['service_outcall_charge'];
			$service_rates_obj->ad_services = $serv['service_name'];
			$service_rates_obj->save();
			
			
		}

		unset($questdata['service']);
		

		$extraServiceData = AdExtraServices::select()->where('ad_id', $user_ad_id);
		$extraServiceData->delete();
		
		foreach($questdata['extra_services'] as $serv){
			$extra_services_obj = new AdExtraServices();
			$extra_services_obj->ad_id = $user_ad_id;
			$extra_services_obj->ad_fee = $serv['price'];
			$extra_services_obj->ad_services = $serv['service_name'];
			$extra_services_obj->save();
		}

		unset($questdata['extra_services']);
	
		$tourData = AdsTouring::select()->where('ad_id', $user_ad_id);
		$tourData->delete();
		
		foreach($questdata['tour'] as $tour){
			$adtour_obj = new AdsTouring();
			$adtour_obj->ad_id = $user_ad_id;
			$adtour_obj->from_date = strtotime($tour['startdate']);
			$adtour_obj->city_id = $tour['city'];
			$adtour_obj->country_id = $tour['country'];
			$adtour_obj->to_date = strtotime($tour['enddate']);
			$adtour_obj->save();

			}
		unset($questdata['tour']);
		unset($questdata['user_ad_id']);
		foreach($questdata as $key => $req){
			
			
				
				if(is_array($questdata[$key])){

					$fetchExistData  = UserAdMeta::select()->where([
						['meta_key', '=', $key],
						['ad_id', '=', $user_ad_id],
					]);
								if(count($fetchExistData) > 0){
									$fetchExistData->delete();
								}
					
					
					foreach($questdata[$key] as $r){
						if(!empty($r)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = $user_ad_id;
						$user_ad_meta->save();
						}
					}
				}else{
					
					

						
						if(!empty($req)){
						
						$data_array = array(
							"meta_key" => $key,
							"meta_value" => $req,
							"ad_id" =>$user_ad_id
						);

						$user_ad_meta = UserAdMeta::firstOrCreate([
							['meta_key', '=', $key],
							['ad_id', '=', $user_ad_id],
						], $data_array);

						//$user_ad_meta->meta_key = $key;
						//$user_ad_meta->meta_value = $req;
						//$user_ad_meta->ad_id = $user_ad_id;
						//$user_ad_meta->save();
						}
					
				}

			
				
			

		}

	}

	function saveIndividualImages(Request $request){
		
		$data = $request->all();
		$images  = $data['imageurl'];
		$videos = $data['videourl'];
		$teaservideo = $data['teaservideourl'];
		$user_ad_id = $request->session()->get('user_ad_id');
		$image_thumb_width =  $this->generalSettings['ad_image_thumb_width'];
		$image_thumb_height =  $this->generalSettings['ad_image_thumb_height'];
		$image_large_width = $this->generalSettings['ad_image_large_width'];
		$image_large_height = $this->generalSettings['ad_image_large_height'];
		$watermark_image = $this->generalSettings['watermark_image'];
		$watermark_position = $this->generalSettings['watermark_image_position'];
		if(count($images) > 0){
		$imagesExists = Image::where('media_ad_id', $user_ad_id)
		->where("media_type", "Images");
		
			if(count($imagesExists) > 0){
			$imagesExists->delete();
			}
		
		
		
		
		foreach($images as $img){
			$image_name = $img;
			$pathinfo = pathinfo($img);
			$filename =  $pathinfo['filename'].'.'.$pathinfo['extension'];
			//echo 'python3'.' '.public_path('photoscript/script.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position;

			$path = exec('python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position);	
			
			$imageObj = new Image();
			$imageObj->media_filename = $filename;
			$imageObj->media_type = "Images";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
		}
	}
	
		if(count($videos) > 0){
			$videosExists = Image::where('media_ad_id', $user_ad_id)->where("media_type", "Videos");
			
		if(count($videosExists) > 0){
			$videosExists->delete();
		}
		foreach($videos as $vid){
			$imageObj = new Image();
			$imageObj->media_filename = $vid;
			$imageObj->media_type = "Videos";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
		}
	}
		if(count($teaservideo) > 0){
			$videosExists = Image::where('media_ad_id', $user_ad_id)->where("media_type", "Teaser Video");
			
		if(count($videosExists) > 0){
			$videosExists->delete();
		}
		foreach($teaservideo as $tvid){
			$imageObj = new Image();
			$imageObj->media_filename = $tvid;
			$imageObj->media_type = "Teaser Video";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
		}
	}
		return;
	}

	function AdListing(){
		$type = $request->input->post('listing_type');
		//$query = UserAdvertisement::all()->where

	}
	
	//......end of individualad....
	
	
	
	//.....photographerad....
	
	
	function photographerAd(){
		$model = new MetaData;
		//return view('frontend.ads.individualad_step_1')->with('models', $model)->with("generalsettings", $this->generalSettings );
		$masters = MainMaster::all();
		$cities = Cities::all();
		$arr = array();
		$arraykey = array();
		foreach($masters as $key=>$m){
		
			$master_arr[$m['meta_name']][] = array(
				"id" => $m['id'],
				"value" => $m['meta_value'],
			);
		}
		
		$age = $master_arr['age'];
		$height = $master_arr['height'];
		$weight = $master_arr['weight'];
		$orientation = $master_arr['orientation'];
		$nationality = $master_arr['nationality'];
		$haircolor = $master_arr['haircolor'];
		$eyecolor = $master_arr['eyecolor'];
		$bustsize = $master_arr['bustsize'];
		$serviceavailablefor =  $master_arr['service-available-for'];
		$servicesavailable =  $master_arr['service-available'];
		$servicetype =$master_arr['service-type'];
		$bodytype = $master_arr['body-type'];
		$personal = $master_arr['personal'];
		$piercing = $master_arr['piercing'];
		$extraservices = $master_arr['extra-services'];
		$model = new MetaData;
		$favthings = $master_arr['fav_things'];
		$plans = Plans::all()->where('listing_type_id', '1');
		
	
		 return view('frontend.photographer.photographerad')->with("generalsettings", $this->generalSettings )
			->with('models', $model)
			->with('age', $age)
			->with('height', $height)
			->with('weight', $weight)
			->with('haircolor', $haircolor)
			->with('eyecolor', $eyecolor)
			->with('haircolor', $haircolor)
			->with('nationality', $nationality)
			->with('orientation', $orientation)
			->with('bodytype', $bodytype)
			->with('serviceavailablefor', $serviceavailablefor)
			->with('servicesavailable', $servicesavailable)
			->with('servicetype', $servicetype)
			->with('piercing', $piercing)
			->with('personal', $personal)
			->with('extraservices', $extraservices)
			->with('bustsize',$bustsize)
			->with('favthings', $favthings)
			->with('plans', $plans)
			->with('cities',$cities);
	
	}
	
	function savePhotographerDetails(Request $request){
		return;
		$user_data = Auth::user();
		$userAd = new UserAdvertisement();
		$userAd->ad_user_id = $user_data->id;
		$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
		$userAd->ad_name = $request->input("name");
		$userAd->ad_email = $request->input("email");
		$userAd->ad_contactno = $request->input("contact_number");
		$userAd->ad_location = $request->input("location");
		$userAd->about_description = $request->input("description");
		$userAd->status = 'Pending';
		$userAd->save();
		$ad_id = $userAd->id;

		$user_ad_meta = new UserAdMeta();
		foreach($request->all() as $key => $req){

			if($key != 'ad_listing_type_id' && $key != 'name' && $key != 'email' && $key != 'contact_number' && $key != 'location' && $key != 'description'){
				
				$fetchExistData  = UserAdMeta::findOrFail()->where('meta_key', $key);
				if(count($fetchExistData) > 0){
					$fetchExistData->delete();
				}
				$user_ad_meta->meta_key = $key;
				$user_ad_meta->meta_value = value;
				$user_ad_meta->ad_id = $ad_id;
				$user_ad_meta->save();
			}

		}
	
		return $ad_id;



	}

	function savePhotographerServices(Request $request){
		return;
		//$ad_id = $request->input("ad_id");
		$user_ad_meta = new UserAdMeta();
		$quesdata = $request->all();
		print_r($quesdata);
		unset($quesdata['_token']);
		unset($quesdata['ad_id']);
		foreach($quesdata as $key => $req){

			
				
				if(is_array($quesdata[$key])){
					
					$fetchExistData  = UserAdMeta::select()->where('meta_key', $key);
						if(count($fetchExistData) > 0){
							$fetchExistData->delete();
						}
					foreach($req as $r){
					
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = 1;
						$user_ad_meta->save();
					}
				}else{
					
					

						$fetchExistData  = UserAdMeta::select()->where('meta_key', $key);
						if(count($fetchExistData) > 0){
							$fetchExistData->delete();
						}
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->ad_id = 1;
						$user_ad_meta->save();
					
				}

			
				
			

		}

	}
	
	//....end of photographerad.....
	
	//.....photographerad....
	
	
	function agencyAd(){
		$model = new MetaData;
		//return view('frontend.ads.individualad_step_1')->with('models', $model)->with("generalsettings", $this->generalSettings );
		$masters = MainMaster::all();
		$cities = Cities::all();
		$arr = array();
		$arraykey = array();
		foreach($masters as $key=>$m){
		
			$master_arr[$m['meta_name']][] = array(
				"id" => $m['id'],
				"value" => $m['meta_value'],
			);
		}
		
		$age = $master_arr['age'];
		$height = $master_arr['height'];
		$weight = $master_arr['weight'];
		$orientation = $master_arr['orientation'];
		$nationality = $master_arr['nationality'];
		$haircolor = $master_arr['haircolor'];
		$eyecolor = $master_arr['eyecolor'];
		$bustsize = $master_arr['bustsize'];
		$serviceavailablefor =  $master_arr['service-available-for'];
		$servicesavailable =  $master_arr['service-available'];
		$servicetype =$master_arr['service-type'];
		$bodytype = $master_arr['body-type'];
		$personal = $master_arr['personal'];
		$piercing = $master_arr['piercing'];
		$extraservices = $master_arr['extra-services'];
		$model = new MetaData;
		$favthings = $master_arr['fav_things'];
		$plans = Plans::all()->where('listing_type_id', '1');
		
	
		 return view('frontend.agency.agencyad')->with("generalsettings", $this->generalSettings )
			->with('models', $model)
			->with('age', $age)
			->with('height', $height)
			->with('weight', $weight)
			->with('haircolor', $haircolor)
			->with('eyecolor', $eyecolor)
			->with('haircolor', $haircolor)
			->with('nationality', $nationality)
			->with('orientation', $orientation)
			->with('bodytype', $bodytype)
			->with('serviceavailablefor', $serviceavailablefor)
			->with('servicesavailable', $servicesavailable)
			->with('servicetype', $servicetype)
			->with('piercing', $piercing)
			->with('personal', $personal)
			->with('extraservices', $extraservices)
			->with('bustsize',$bustsize)
			->with('favthings', $favthings)
			->with('plans', $plans)
			->with('cities', $cities);
	
	}
	
	function saveAgencyDetails(Request $request){
		return;
		$user_data = Auth::user();
		$userAd = new UserAdvertisement();
		$userAd->ad_user_id = $user_data->id;
		$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
		$userAd->ad_name = $request->input("name");
		$userAd->ad_email = $request->input("email");
		$userAd->ad_contactno = $request->input("contact_number");
		$userAd->ad_location = $request->input("location");
		$userAd->about_description = $request->input("description");
		$userAd->status = 'Pending';
		$userAd->save();
		$ad_id = $userAd->id;

		$user_ad_meta = new UserAdMeta();
		foreach($request->all() as $key => $req){

			if($key != 'ad_listing_type_id' && $key != 'name' && $key != 'email' && $key != 'contact_number' && $key != 'location' && $key != 'description'){
				
				$fetchExistData  = UserAdMeta::findOrFail()->where('meta_key', $key);
				if(count($fetchExistData) > 0){
					$fetchExistData->delete();
				}
				$user_ad_meta->meta_key = $key;
				$user_ad_meta->meta_value = value;
				$user_ad_meta->ad_id = $ad_id;
				$user_ad_meta->save();
			}

		}
	
		return $ad_id;



	}

	function saveAgencyServices(Request $request){
		return;
		//$ad_id = $request->input("ad_id");
		$user_ad_meta = new UserAdMeta();
		$quesdata = $request->all();
		print_r($quesdata);
		unset($quesdata['_token']);
		unset($quesdata['ad_id']);
		foreach($quesdata as $key => $req){

			
				
				if(is_array($quesdata[$key])){
					
					$fetchExistData  = UserAdMeta::select()->where('meta_key', $key);
						if(count($fetchExistData) > 0){
							$fetchExistData->delete();
						}
					foreach($req as $r){
					
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = 1;
						$user_ad_meta->save();
					}
				}else{
					
					

						$fetchExistData  = UserAdMeta::select()->where('meta_key', $key);
						if(count($fetchExistData) > 0){
							$fetchExistData->delete();
						}
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->ad_id = 1;
						$user_ad_meta->save();
					
				}

			
				
			

		}

	}
	
	//....end of agencyad.....
	

	function postListing(){
		$gender = \Request::query('gender');
		
		$model = new MetaData;
		$master_age = MainMaster::all()->where('meta_name','age');
		$master_body_type = MainMaster::all()->where('meta_name','body-type');
		$master_nationality = MainMaster::all()->where('meta_name','nationality');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		$cities = new Cities;
		$cities_list = Cities::all();
		

		$slug = \Request::segment(2);
	/*	if(!view()->exists('frontend.ads.'.$slug.'.post_listing')){
			return abort(404);
		}
*/

		$res = DB::table('listing_type')->where("slug", $slug)->get();
		if(count($res == 0)){
			$list = array();
		}else{
		if(!empty($gender)){
			$records = UserAdMeta::all()->where("meta_key","gender")->where('meta_value', $gender);
			$ad_ids = array();
			if(count($records) > 0){
				foreach($records as $rs){
					$ad_ids[] = $rs['ad_id'];
				}
				$list = fetchFeatuedListing(implode(',',$ad_ids));
			}else{
				$list = array();
			}

		}else{
			$list = fetchFeatuedListing($res[0]->id);
		}
		
	 }
		$other_ads = new OtherAds;
		$otherAds = OtherAds::select()
		->orderBy('sort_order')->skip(0)
		->take(4)->get();
		return view('frontend.ads.post_listing')->with('list', $list)
		->with('generalsettings', $this->generalSettings )->with('master_age',$master_age)
		->with('master_body_type',$master_body_type)
		->with('master_service_type',$master_service_type)
		->with('master_nationality',$master_nationality)
		->with('cities_list',$cities_list)
		->with('other_ads',$otherAds);
	}

	
}
