<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Input;
use App\Models\User;
use DB;
use Session;

use Response;
use Hash;

use App\Models\Role;
use App\Models\VerifyUser;
use App\Models\UserOtps;
use App\Models\EmailMessage;
use App\Models\MetaData;


use Illuminate\Foundation\Auth\AuthenticatesUsers;

class FAuthenticationController extends Controller
{
	use AuthenticatesUsers;

	protected $loginPath = '/';

	protected $redirectPath = 'dashboard';

	protected $redirectAfterLogout = '/';

	/**
	 * Show Login form for letting Super Admin's login to system
	 * GET /sessions/create
	 *
	 * @return Response
	 */
	public function showloginform()
	{
		return view('frontend.layouts.front_login');
	}

	public function showforgotpassword()
	{
		return view('frontend.layouts.front_forgot_password');
	}
/* 
	public function f()
	{
		return view('frontend.dashboard');		
	}
 */

	/**
	 * Authenticate Login User's
	 * GET /sessions/create
	 *
	 * @return Response
	 */
	public function login(Request $request)
	{

		/* 	$email=$request->email;
    $password=$request->password;

            if (Auth::attempt(array('email' => $email, 'password' => $password))){
            return view('frontend.layouts.front_login');
            }
            else {        
                return "Wrong Credentials";
            }
	 */

		$login_error_rules = $this->getLoginErrorByLocale();

		$this->validate($request, [
			'email' => 'required',
			'password' => 'required',
		], $login_error_rules);

		$field = 'email';

		$request->session()->flush();

		$request->merge([$field => $request->input('email')]);

		$login_cred = $request->only($field, 'password');
		//$login_cred['user_is_email_verified'] = 1;
		//$login_cred['status'] = 1;


		if ($this->hasTooManyLoginAttempts($request)) {
			$this->fireLockoutEvent($request);
			return $this->sendLockoutResponse($request);
		}
		if (Auth::attempt($login_cred, $request->has('remember'))) {
			return $this->sendLoginResponse($request);
		} else {
			$this->incrementLoginAttempts($request);
		}
		return redirect()->back()
			->withInput($request->only($request->input("email"), 'remember'))
			->withErrors([
				'email' => trans('translations.frontend.rules.credential_error'),
			]);
	}


	
	public function logout(Request $request)
	{
		$users = User::findOrFail(Auth::user()->id);
		$users->login_status = 0;
		$users->save();
		Auth::logout();

		$request->session()->flush();
		$request->session()->regenerate();

		return redirect('/')->with("logout_message", trans('translations.frontend.logout_msg'));
	}

	/**
	 * set Login Redirect Path
	 *
	 * @return string
	 */
	public function redirectPath()
	{
		return route('dashboard');
	}

	public function getLoginErrorByLocale()
	{
		$rules = array();

		$rules["email.required"] = trans('translations.frontend.rules.email_required');
		$rules["password.required"] = trans('translations.frontend.rules.password_required');

		return $rules;
	}
}
