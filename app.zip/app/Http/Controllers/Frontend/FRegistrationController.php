<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Hash;
use Auth;
use Session;

use App\Models\User;

use App\Models\Role;
use App\Models\VerifyUser;
use App\Models\UserOtps;
use App\Models\EmailMessage;
use App\Models\MetaData;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Carbon\Carbon;

class FRegistrationController extends Controller
{
	
		public function __construct( ) {
        $this->generalSettings = generalSettings();
    }
    public function index(){
		
		$default_locale = app()->getLocale();
		
		app()->setLocale( 'en' );
		 return view('frontend/registration');
	} 
	
	public function saveRegistration(Request $request){
	
		$name_regex = "/^[\pL\s]+$/u";
		
			$usertype = $request->has('usertype');
		 if(!$usertype){
		$validator = Validator::make( $request->all(), [
			'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
			'email' => 'required|email|min:3|max:255|unique:users,email,NULL,id,deleted_at,NULL',
			'phone' => 'required|unique:users',
			'password' => ['required','min:8'],
			'g-recaptcha-response' => 'required|captcha',
			'usertype'=>'required'
                    ], [
                        'name.required' => 'Please enter Name.',
                        'name.regex' => 'Enter only characters',
                        'phone.required' => 'Enter  phone number',
                        'email.required' => 'Please Enter Email Id.',
                        'password.required' => 'Please Enter Your Password.',
						'password.digits' => 'Password length is less than 8.',
						'g-recaptcha-response.required' => 'Before you proceed to the registration, please complete the captcha.',
						'usertype.required' => 'Please select who you are?'
                    ]);
		 }else{
			 $validator = Validator::make( $request->all(), [
			'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
			'email' => 'required|email|min:3|max:255|unique:users,email,NULL,id,deleted_at,NULL',
			'phone' => 'required|unique:users',
			'password' => ['required','min:8'],
                    ], [
                        'name.required' => 'Please enter Name.',
                        'name.regex' => 'Enter only characters',
                        'email.required' => 'Please Enter Email Id.',
                         'phone.required' => 'Enter  Numbers Only',
                        'password.required' => 'Please Enter Your Password.',
						'password.digits' => 'Password length is less than 8.',
					
                    ]);
			 
		 }
		if ($validator->fails()) {
			
            return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			
        }else{
			$password = $request->input('password');
			$user = new User();
			$user->name = $request->input('name');
			$user->email = $request->input('email');
			$user->phone = $request->input('phone');
			$user->password = Hash::make( $password );
			$user->usertype = $request->input('usertype');
			$user->status = 0;
			$user->user_is_email_verified = 0;
			
			$user->save();
			
			$user->assignRole(ROLE::ROLE_ABCUSER);
			// Verification Email send functionality start here
			
				$verification_token = str_random(40);
				
				$verifyuser = new VerifyUser();
				$verifyuser->user_id = $user->id;
				$verifyuser->token = $verification_token;
				$verifyuser->status = 1;
				$verifyuser->save();
				
				if($verifyuser && intval( $verifyuser->id ) > 0 ){
				
				$verification_link = url('verify', $verification_token);
				$email_content = array();
				$email_content["user_name"] = ucwords( $user->name );
				$email_content["user_email"] = $user->email;
				$email_content["user_password"] = $password;
				$email_content["login_button"] = '<a href="'.url('/').'" target="_blank">Click Here</a>';
				$email_content["verify_url_code"] = $verification_token;
				$email_content["verify_button"] = '<a href="'.$verification_link.'" target="_blank" style="border:none; text-decoration:none; padding:15px 30px; font-size:24px; background:#1a2166; color:#fff;">Verify Now</a>';
				$email_message = new EmailMessage();
				$email_message->singleMailSendIntegration( $user->email, "AccountCreatedFrontend", $email_content );
				
				
			}
			
			return Response::json( array( 'success' => "Registered successfully.", "redirect_response" => route('success') ) );
				
		}
                
	
	}
	    function login(){
	   return view('frontend/layouts/front_login');
    }
	// Login Submit....
	public function loginSubmit(Request $request){
		$field = 'email';
		
		$request->merge( [ $field => $request->input('email') ] );
		$login_cred = $request->only( $field, 'password');
		
		if( Auth::attempt( $login_cred ) ) {
			$user_data = Auth::user();
			if( $user_data->hasAnyRole( [ Role::ROLE_ABCUSER ] ) ){
				if( intval( $user_data->user_is_email_verified ) != 1 ){
					return response()->json( [ 'status' => 0, 'error' => 'Please Verify Your Email Address first.' ]);
				}
				
				if( !$user_data->isActive()){
					return response()->json( [ 'status' => 0, 'error' => "Sorry, Your Account is not active." ]);
				}
				

				$otp_code_id = 0;
				if( intval( $user_data->enble_2fa) == 1){
					$otp_code_id = $this->sendOtpMessage( $user_data->id);
					//$this->updateLoginStatus();
					 return response()->json( [ 'status' => 1, 'success' => "OTP Sent"]);
				}
				$this->updateLoginStatus( $user_data->id);
			    return response()->json( [ 'status' => 1, 'success' => "Login Successful", "redirect_url" => route('dashboard')]);
			}
			else{
				return response()->json( [ 'status' => 0, 'error' => "Sorry, You don't have access to this feature of the application." ]);
			}
        }else{
			return response()->json( [ 'status' => 0, 'error' => "These credentials do not match our records." ]);
		}
    }
	public function updateLoginStatus($user_id){
		$users = User::findOrFail($user_id);
		$users->login_status = 1;
		$users->save();
	}
	public function sendOtpMessage( $user_id ){
		$otp_code = mt_rand(1000, 9999);
		
		
		$userotp = User::findOrFail($user_id);
		$userotp->otp_value = $otp_code;
		$userotp->otp_expires = Carbon::now()->addMinutes(30);
		$userotp->save();

		$this->messageSend( $userotp->email, $userotp->phone, $otp_code);
		
		return $userotp->id;
	}
	
	function messageSend($email, $phone, $otp_code){
		$email_content= array();
		$email_content['otp'] = $otp_code;
		$email_message = new EmailMessage();
		$email_message->singleMailSendIntegration( $email, "EmailOTP", $email_content );
		if(!empty($phone)){
			$this->send_otp_to_mobile($phone, $otp_code);
		}
	}
	function send_otp_to_mobile(){

	}

	function verifyOtp(Request $request){
		$otp = $request->post('otp');
		$today =  Carbon::now()->toDateTimeString();
		if(empty($otp)){
			 return response()->json( [ 'status' => 0, 'error' => "Please enter otp"]);
		}
		$res = User::where('otp', $otp)->get();

		if(count($res) == 0){
			return response()->json( [ 'status' => 0, 'error' => trans('translations.frontend.wrong_otp')  ]);
		}

		if(count($res) > 0 && $res->otp_expires < $today){
			return response()->json( [ 'status' => 0, 'error' => trans('translations.frontend.otp_expired')  ]);
		}
	$this->updateLoginStatus( $res->id);
		return response()->json( [ 'status' => 1, 'success' => 'Verified Successfully','redirect_url'=> route('dashboard')  ]);

	}
	public function resendEmailShow()
	{
		$model = new MetaData;
		return view('frontend/auth/resend_email_verificatoin')->with('models',$model)->with("generalsettings", $this->generalSettings);
	}
	public function resendEmailToken(Request $request){
		$this->validate( $request, [
			'resend_email' => 'required|email',
		  ],[
			'resend_email.required' => trans('translations.frontend.rules.email_required'),
			'resend_email.email' => trans('translations.frontend.rules.email_valid'),
		]);
		
		$email_address = $request->input( 'resend_email' );
		
		$user_data = User::role( Role::ROLE_ABCUSER )->where("email", $email_address)->first();
		
		if( $user_data && intval( $user_data->id ) > 0 ){
			if( intval( $user_data->email_verified ) == 1 ){
				return redirect()->back()
					->withInput( $request->all() )
					->withErrors([
						"resend_email" => trans('translations.frontend.resend_error_verified'),
					]);
			}
			else{
				// Verification Email send functionality start here
				$verification_token = str_random(40);
				
				VerifyUser::where( "user_id", $user_data->id )->delete();
				
				$verifyuser = new VerifyUser();
				$verifyuser->user_id = $user_data->id;
				$verifyuser->token = $verification_token;
				$verifyuser->status = 1;
				$verifyuser->save();
				
				if( $verifyuser && intval( $verifyuser->id ) > 0 ){
					$verification_link = url('verify', $verification_token);
					
					$email_content = array();
					$email_content["user_name"] = ucwords( $user_data->name );
					$email_content["user_email"] = $user_data->email;
					$email_content["user_password"] = $user_data->password;
					$email_content["login_button"] = '<a href="'.url('/').'" target="_blank">Click Here</a>';
					$email_content["verify_url_code"] = $verification_link;
					$email_content["verify_button"] = '<a href="'.$verification_link.'" target="_blank" style="border:none; text-decoration:none; padding:15px 30px; font-size:24px; background:#1a2166; color:#fff;">Verify Now</a>';
					
					$email_message = new EmailMessage();
					$email_message->singleMailSendIntegration( $user_data->email, "ResendVerificationLink", $email_content );	
				}
				$request->session()->flash('alert-success', 'New Verification Code Has Been Sent Successful!');
				return redirect()->back()
					/* ->withInput( $request->only('shown_container') )
					->with("resend_message" , trans('translations.frontend.resend_success_msg')) */;
			}
		}
		else{
			return redirect()->back()
					->withInput( $request->all() )
					->withErrors([
						"resend_email" => trans('translations.frontend.resend_email_not_found'),
					]);
		}
	}
	
	public function verifyUser($token){
		
		$message_type = 0;
		$verify_token = VerifyUser::where('token', $token)->where('status',1)->first();
		if( $verify_token && intval( $verify_token->id ) > 0 ){
			$user_data = User::find( $verify_token->user_id );
			$user_data->user_is_email_verified = 1;
			$user_data->status = 1;
			$message_type = 1;
		
				$email_content = array();
				$email_content["user_name"] = ucwords( $user_data->name );
				$email_content["login_button"] = '<a href="'.route('login').'" target="_blank" style="border:none; text-decoration:none; padding:15px 30px; font-size:24px; background:#1a2166; color:#fff;">Login Now</a>';
				
				$email_message = new EmailMessage();
				$email_message->singleMailSendIntegration( $user_data->email, "UserEmailVerified", $email_content );
			
			$user_data->save();
			
			$verify_token->status = 0;
			$verify_token->save();
		}
		else{
			$message_type = 0;
		}
		
		$is_user_logged = 0;
		$header_layout = "front_login";
		if( Auth::check() ){
			$is_user_logged = 1;
			$header_layout = "default_layout";
		}
		$model = new MetaData;
		return view('frontend.auth.email_verification')
			->with( "is_user_logged", $is_user_logged )
			->with( "header_layout", $header_layout )
			->with( "message_type", $message_type )
			->with('models',$model)->with("generalsettings", $this->generalSettings);
    }
	
	public function registrationSuccess(Request $request){
		$mail_sent_to = "dd";
		$model = new MetaData;
		return view('frontend.auth.register_success')
			->with( "mail_sent_to", $mail_sent_to )
			->with("generalsettings", $this->generalSettings )
			->with('models', $model);
	}
	



	
	public function forgotpassprocess(Request $request){
		 
		 		$email = $request->forgot_email;
				
		 $this->validate( $request, [
			'forgot_email' => 'required|email|min:3|max:255',
		  ],[
			'forgot_email.required' => trans('translations.frontend.rules.email_required'),
			'forgot_email.email' => trans('translations.frontend.rules.email_valid'),
			'forgot_email.min' => trans('translations.frontend.rules.email_min'),
			'forgot_email.max' => trans('translations.frontend.rules.email_max'),
		]);
		
		$email_address = $request->input( 'forgot_email' );
		
		$user_data = User::role( Role::ROLE_ABCUSER )->where("email", $email_address)->first();
		
		if( $user_data && intval( $user_data->id ) > 0 ){
			
			$password = str_random(8);

			$user_data->password = Hash::make( $password );
			
			//$user_data->add_user_log( $user_data->id, "profile_update", "", "", "", $user_data->id, array( ), "password" );
			
			$user_data->save();
			
			$email_content = array();
			$email_content["user_name"] = ucwords( $user_data->name );
			$email_content["new_password"] = $password;
			$email_content["login_button"] = '<a style="font-size:18px;" href="'.route('login').'" target="_blank" >For Login Click Here</a>';
			$email_message = new EmailMessage();
			$email_message->singleMailSendIntegration( $user_data->email, "ForgotPassword", $email_content );
			 
			// \Session::flash('flash_message','successfully saved.');
			 $request->session()->flash('alert-success', 'Email Send Successfully! Check Your Email For New Password');
			return redirect()->back()
				->withInput( $request->only('shown_container') )
				->with("forgot_message" , trans('translations.frontend.forgot_password_success_msg'));
		}
		else{
			return redirect()->back()
					->withInput( $request->all() )
					->withErrors([
						"forgot_email" => trans('translations.frontend.resend_email_not_found'),
					]);
		}
	}
}
