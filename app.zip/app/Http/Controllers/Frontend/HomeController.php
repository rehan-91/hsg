<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use Response;
use Input;
use Auth;
use DB;
use Location;
use App\Models\User;
use App\Models\Role;
use App\Models\RolePermission;
use App\Models\MetaData;
use App\Models\MainMaster;
use App\Models\Guests;
use App\Models\UserAdMeta;
use App\Models\Cities;
use App\Models\ShortList;
use App\Models\OtherAds;
use App\Models\AdRate;
use App\Models\Image;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;
use Imageresize;
use Carbon\Carbon;
use App\Models\Blogs;


class HomeController extends Controller
{
    //
    
	protected $generalSettings;
	function __construct(){
		$this->generalSettings = generalSettings();
	}
    function index(Request $request){
	
		//visitor's count....
		$guest_ip_address = $request->getClientIp();
		
		//$guest_ip_address='122.176.59.133';
	
		//$location = Location::get($guest_ip_address);
		
		$guests = Guests::all()->where('guest_ip_address',$guest_ip_address);
		$c = count($guests);
		
		$featuredListRes = getNearByCities(!empty($_COOKIE['user_latitude'])?!empty($_COOKIE['user_latitude']):'', !empty($_COOKIE['user_longitude'])? $_COOKIE['user_longitude']:'');
		
		$teaservideo =	getTeaserVideo();
		if($c==0)
		{
			$guests = new Guests;
			$guests->guest_ip_address = $guest_ip_address;
			$guests->save();
		}
		//...end of visitor's count...
		
     	$ss = boostingProfiles();

$boostprofiles = array_chunk($ss, ceil(count($ss)/4));

		$model = new MetaData;
		$master_age = MainMaster::all()->where('meta_name','age');
		$master_body_type = MainMaster::all()->where('meta_name','body-type');
		$master_nationality = MainMaster::all()->where('meta_name','nationality');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		
		$my_short_list = new ShortList;
		$my_total_short_list = ShortList::all()->where('short_guest_id','5');
		
		$cities = new Cities;
		$cities_list = Cities::all();

		$other_ads = new OtherAds;
		$otherAds = OtherAds::select()
		->orderBy('sort_order')->skip(0)
		->take(4)->get();
		
		$activity = DB::table('activity_log')->skip(0)
		->take(10)->get();
		
        return view('frontend/index')
		->with("generalsettings", $this->generalSettings)
		->with('models',$model)
		->with('master_age',$master_age)
		->with('master_body_type',$master_body_type)
		->with('master_service_type',$master_service_type)
		->with('master_nationality',$master_nationality)
		->with('my_total_short_list',$my_total_short_list)
		->with('cities_list',$cities_list)
		->with('featured_profile_list', $featuredListRes)
		->with('teaservideo', $teaservideo)
		->with('activity', $activity)
		->with('boostprofiles', $boostprofiles)
		->with('other_ads',$otherAds);

	}
    
    function login(){
	   return view('frontend/layouts/front_login');
    }
    
    function register(){
        return view('frontend/registration');
    }
	
	
    public function fsearchData(Request $request)
    {

    	$input = $request->all();
    	
    	$master_age = MainMaster::all()->where('meta_name','age');
		$master_body_type = MainMaster::all()->where('meta_name','body-type');
		$master_nationality = MainMaster::all()->where('meta_name','nationality');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		$cities = new Cities;
		$cities_list = Cities::all();
    	
		
	    $today = time();		
	    $query = "select uad.* from tbl_user_advertisement uad where uad.plan_expired IS NOT NULL and uad.plan_purchased IS NOT NULL 
	    and uad.plan_expired >= '".$today."' and uad.status=1";
	    $filterquery ="";
	  	if(!empty($input['name'])){
	    $filterquery .= " and uad.ad_name like '%".$input['name']."%'";
		}
	    if(!empty($input['gender'])){
		    $gender = $input['gender'];
		$filterquery .= ' and uad.id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $gender) . '") and meta_key="gender")';
	    }

	    if(count($input['age']) > 0){
		    $age = implode(", ", $input['age']);
		    $filterquery .=" and uad.id in(select ad_id from tbl_user_ad_meta where meta_value in(".$age.") and meta_key='age')";
	    }


	    if(!empty($input['location'])){
		$location = implode(", ", $input['location']);
		$filterquery .=" and uad.ad_location in(".$location.")";
		}


		if(!empty($input['bodytype'])){
			$bodytype = implode(", ", $input['bodytype']);
			$filterquery .=" and uad.id in(select ad_id from tbl_user_ad_meta where meta_value in(".$bodytype.") and  meta_key='body-type')";
		}
		
		if(!empty($input['ethnicity'])){
			$ethnicity = implode(", ", $input['ethnicity']);
			$filterquery .=" and uad.id in(select ad_id from tbl_user_ad_meta where meta_value in(".$ethnicity.") and meta_key='nationality')";
		}
		
		if(!empty($input['services'])){
			$services = implode(", ", $input['services']);
			$filterquery .=" and uad.id in(select ad_id from tbl_user_ad_meta where meta_value in(".$services.") and meta_key='service-type')";
		}


		if(!empty($input['price'])){
			$price =  explode("-", $input['price']);
			$price1 = $price[0];
			$price2 = $price[1];
			if($price2=='over'){
				$filterquery .=" and  uad.id in(select ad_id from tbl_ad_rate where incall_charge > ".$price1." or outcall_charge > ".$price2.")";
			}else{
				$filterquery .=" and  uad.id in(select ad_id from tbl_ad_rate where (incall_charge between ".$price1." and ".$price2.") or  (outcall_charge between ".$price1." and ".$price2."))";
			}
		}

		if($filterquery){

			$newQuery = $query.$filterquery;

		}
		 \DB::connection()->enableQueryLog();
		$res = DB::select($newQuery);
	

	if(!empty($input['type'])){
		if(count($res) == 0){
			return json_encode(array('success'=>"no records found", 'count'=>0));
		}
		foreach($res as $r){
				$image = Image::where('media_ad_id', $r->id)->where('media_type','Images')
		->where('media_status', 'Verified')->where('media_is_default', 1 )->first()->media_filename;
		$login_status=fetchLoginStatus($r->ad_user_id);
		$rate  = AdRate::select()->where('ad_id', $r->id)->min('incall_charge');
		$ad_listing_type_id =getListingType($r->ad_listing_type_id);
			$newRes[] = array(
				
					"adId" => $r->id,
					"slug" => $r->slug,
					"adUserId" => $r->ad_user_id,
					"adListingTypeId" => $ad_listing_type_id,
					"adName" => $r->ad_name,
					"adEmail" => $r->ad_email,
					"adContact" => $r->ad_contactno,
					"adLocation" => getCityCountry($r->ad_location),
					"ad_small_image" => getS3ImageURL($image, '252*384'),
					"ad_large_image" => getS3ImageURL($image, '508*762'),
					"rate" => $rate,
					"login_status" => $login_status,
					"age" => getSpecificMeta('age',$r->id, true),
					"bustsize" => getSpecificMeta('bustsize', $r->id,true),
					"height" => getSpecificMeta('height', $r->id,true),
					"weight" => getSpecificMeta('weight', $r->id,true),
					"ethinicity" => getSpecificMeta('ethinicity', $r->id),
					"haircolor" => getSpecificMeta('haircolor', $r->id, true),
					"eyecolor" => getSpecificMeta('eyecolor', $r->id, true),
					"profile_link" => url("profile/".$r->slug),
				);
			}
		$newRes['count'] = count($res);
		return json_encode($newRes);

			
	}else{

				foreach($res as $r){
			
			$metaData = getAllMetaData($r->id);
		$login_status=fetchLoginStatus($r->ad_user_id);
			$image = Image::where('media_ad_id', $r->id)->where('media_type','Images')
		->where('media_status', 'Verified')->where('media_is_default', 1 )->get();
			$rate  = AdRate::select()->where('ad_id', $r->id)->min('incall_charge');
			$newRes[$r->id] = array(
				"adId" => $r->id,
				"slug" => $r->slug,
				"adUserId" => $r->ad_user_id,
				"adListingTypeId" => $r->ad_listing_type_id,
				"adName" => $r->ad_name,
				"adEmail" => $r->ad_email,
				"adContact" => $r->ad_contactno,
				"adLocation" => $r->ad_location,
				"adImage" => $image->first()->media_filename,
				"rate" => $rate,
				"metaData" => $metaData,
				"login_status" => $login_status,
			);
		}
		return view('frontend.ads.post_listing')
		->with("generalsettings", $this->generalSettings)
		->with('master_age',$master_age)
		->with('master_body_type',$master_body_type)
		->with('master_service_type',$master_service_type)
		->with('master_nationality',$master_nationality)
		->with('list', $newRes)
		->with('title', 'Search Result')
		->with('inputdata', $input)
		->with('cities_list',$cities_list);

	}
		

    }



	function frontbloglist(Request $request){

//visitor's count....
		$guest_ip_address = $request->getClientIp();
		
		//$guest_ip_address='122.176.59.133';
	
		//$location = Location::get($guest_ip_address);
		
		$guests = Guests::all()->where('guest_ip_address',$guest_ip_address);
		$c = count($guests);
		
		$featuredListRes = getNearByCities(!empty($location->latitude)?$location->latitude:'', !empty($location->longitude)?$location->longitude:'');
		
		if($c==0)
		{
			$guests = new Guests;
			$guests->guest_ip_address = $guest_ip_address;
			$guests->save();
		}
		//...end of visitor's count...
		
		$model = new MetaData;
		$master_age = MainMaster::all()->where('meta_name','age');
		$master_body_type = MainMaster::all()->where('meta_name','body-type');
		$master_nationality = MainMaster::all()->where('meta_name','nationality');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		
		$my_short_list = new ShortList;
		$my_total_short_list = ShortList::all()->where('short_guest_id','5');
		
		$cities = new Cities;
		$cities_list = Cities::all();

		$other_ads = new OtherAds;
		$otherAds = OtherAds::select()
		->orderBy('sort_order')->skip(0)
		->take(4)->get(); 
		$blogdata = Blogs::all();
        return view('frontend.front_blog_list',compact('blogdata'))
		->with("generalsettings", $this->generalSettings)
		->with('models',$model)
		->with('master_age',$master_age)
		->with('master_body_type',$master_body_type)
		->with('master_service_type',$master_service_type)
		->with('master_nationality',$master_nationality)
		->with('my_total_short_list',$my_total_short_list)
		->with('cities_list',$cities_list)
		->with('featured_profile_list', $featuredListRes)
		->with('other_ads',$otherAds);
		
	}

	function readblog($slug){

			 $blogdata = Blogs::all()->where('blog_slug', $slug)->where('blog_status', 1)->first();
		
		$model = new MetaData;
		$master_age = MainMaster::all()->where('meta_name','age');
		$master_body_type = MainMaster::all()->where('meta_name','body-type');
		$master_nationality = MainMaster::all()->where('meta_name','nationality');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		
		$my_short_list = new ShortList;
		$my_total_short_list = ShortList::all()->where('short_guest_id','5');
		
		$cities = new Cities;
		$cities_list = Cities::all(); 

		$other_ads = new OtherAds;
		$otherAds = OtherAds::select()
		->orderBy('sort_order')->skip(0)
		->take(4)->get(); 

 
			 return view('frontend.read_front_blog', compact('blogdata'))
			 ->with("generalsettings", $this->generalSettings)
			->with('models',$model)
			->with('master_age',$master_age)
			->with('master_body_type',$master_body_type)
			->with('master_service_type',$master_service_type)
			->with('master_nationality',$master_nationality)
			->with('my_total_short_list',$my_total_short_list)
			->with('cities_list',$cities_list)
			->with('featured_profile_list', $featuredListRes)
			->with('other_ads',$otherAds);

	}
	
	
}
