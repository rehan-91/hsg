<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Hash;
use Auth;
use DB;
use App\Models\User;
use App\Models\UserOtps;
use App\Models\VerifyUser;
use App\Models\Role;
use App\Models\Service;
use App\Models\Image;
use App\Models\EmailMessage;
use App\Models\MetaData;
use App\Models\AdStats;
use App\Models\AdRate;
use App\Models\UserAdMeta;
use App\Models\AgencyDetails;
use Session;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Blogs;

use Imageupload;
use Spatie\Permission\Traits\HasRoles;
use Carbon\Carbon;
use App\Models\Verification;

class FDashboardController extends Controller
{
	use HasRoles;
	
	protected $guard_name = 'web';
	
	protected $generalSettings;
	
	public function __construct( ) {
        $this->generalSettings = generalSettings();
    }
	
    public function index(){
		
		
		$user_data = Auth::user();
		$dashboardData = getUserDashboardData($user_data);
	
		$dashboardData['generalsettings']  = $this->generalSettings;
		return view('frontend.dashboard', $dashboardData);
		
	}
	

	public function setAppLocale($language){
		
		if( Auth::check() ){
			$user_data = Auth::user();
			
			$user_xprofile = $user_data->userxprofile;
			$user_xprofile->language_preferenced = $language;
			
			$user_data->add_user_log( $user_data->id, "profile_update", "", $user_xprofile->language_preferenced, $language, $user_data->id, array( ), "language_preferenced" );
			
			$user_xprofile->save();
		}
		
		Session::put('app_locale', $language);

		return redirect()->back();
	}
	
	
	
	
	
	
	public function changePassword(){
		
		$model = new MetaData;
        return view('frontend.changepassword')->with("generalsettings", $this->generalSettings)->with('models',$model);
	}
	
	public function changePasswordSave(Request $request){
		
		$changepassword_form_rules = $this->getChangePasswordErrorByLocale();
		
		$this->validate($request, [
			'old_password' => 'required|min:6',
			'new_password' => 'required|min:6',
			'confirm_new_password' => 'required|min:6|same:new_password',
        ], $changepassword_form_rules );
		
		$old_password = $request->input('old_password');
		$new_password = $request->input('new_password');
		
		$current_user = Auth::user();
		
		if( Hash::check( $old_password, $current_user->password )){
			
			if( Hash::check( $new_password, $current_user->password ) ){
				return redirect()->back()
				->withErrors( [
					'new_password' => trans('translations.frontend.cpassword_rules.same_password_error'),
				] );
			}
			else{
				
				$user_data = User::find( $current_user->id );
				$user_data->password = Hash::make( $new_password );
				$user_data->save();
				
				//$user_data->add_user_log( $user_data->id, "profile_update", "", "", "", $user_data->id, array( ), "password" );
				
				$email_content = array();
				$email_content["user_name"] = ucwords( $user_data->name );
				
				$email_message = new EmailMessage();
				$email_message->singleMailSendIntegration( $user_data->email, "ChangePassword", $email_content );
				
				return redirect()->back()->with('message', trans('translations.frontend.change_password_success') );
			}
			
		}
		else{
			return redirect()->back()
            ->withErrors( [
                'old_password' => trans('translations.frontend.cpassword_rules.password_incorrect'),
            ] );
		}
	}
	
	public function getChangePasswordErrorByLocale(){
		$rules = array();
		
		$rules[ "old_password.required" ] = trans('translations.frontend.cpassword_rules.old_p_required');
		$rules[ "old_password.min" ] = trans('translations.frontend.cpassword_rules.old_p_min');
		$rules[ "new_password.required" ] = trans('translations.frontend.cpassword_rules.new_p_required');
		$rules[ "new_password.min" ] = trans('translations.frontend.cpassword_rules.new_p_min');
		$rules[ "confirm_new_password.required" ] = trans('translations.frontend.cpassword_rules.conf_p_required');
		$rules[ "confirm_new_password.min" ] = trans('translations.frontend.cpassword_rules.conf_p_min');
		$rules[ "confirm_new_password.same" ] = trans('translations.frontend.cpassword_rules.conf_p_same');
			
		return $rules;
	}
	
	
	
	
	public function profileImageUpload(Request $request){
		
		$validator = Validator::make( $request->all(), [
			'img_uploader' => 'required|mimes:jpeg,png|max:5120',
		], [
			'img_uploader.required' => 'required',
            'img_uploader.image' => 'image',
            'img_uploader.max' => 'size',
            'img_uploader.mimes' => 'mimes',
		]);
		if ($validator->fails()) {
			return Response::json( array( 'error' => $validator->getMessageBag()->toArray()["img_uploader"][0] ) );
		} else {
			$image_result = Imageupload::upload( $request->file('img_uploader'));
			
			$image_size_400 = url('/').'/'.$image_result["size400_filedir"];
			
			return Response::json( array( 'success' => "File Uploaded Successfully", "image_id" => $image_result['id'], "image_size_400" => $image_size_400 ) );
		}
	}
	
	public function redoMobileOtp(Request $request){
		if( Auth::check() ){
			if( $request->session()->exists('otp_id') ){
				return redirect( route('verifymobile') ); 
			}
			else{
				$user_data = Auth::user();
				$otp_code_id = $this->sendOtpMessage( $user_data->id );

				if( $otp_code_id && intval( $otp_code_id ) > 0 ){
					$request->session()->put('otp_id', $otp_code_id);
					$request->session()->put('otp_is_updatable', 1 );
					
					return redirect( route('verifymobile') ); 
				}
			}
		}
		else{
			return redirect("/");
		}
	}
	
	public function verifyMobileNumber(Request $request){
		if( Auth::check() ){
			$user_data = Auth::user();
			if( $request->session()->exists('otp_id') ){
				$otp_id = Session::get('otp_id');
				$otp_user_id = $user_data->id;
				
				$user_data = User::find($otp_user_id);
			
				$contact_number = $user_data->contact_number;
				if( intval( Session::get('otp_is_updatable') ) == 0 ){
					$mobile_update_present = UserProfileUpdates::where( "user_id", $otp_user_id )->where("field_name", "contact_number")->where( "status", 1 )->orderBy("created_at", "desc")->first();
					if( $mobile_update_present && intval( $mobile_update_present->id ) > 0 ){
						$contact_number = $mobile_update_present->field_data;
					}
				}
				
				return view('frontend.login_verify_otp')
						->with('user_data', $user_data)
						->with('is_success', 0)
						->with('contact_number', $contact_number)
						->with('otp_is_updatable', Session::get('otp_is_updatable') );
			}
			else{
				return redirect("dashboard");
			}
		}
		else{
			return redirect("/");
		}
		
	}
	
	public function sendOtpMessage( $user_id ){
		$otp_code = mt_rand(1000, 9999);
		
		UserOtps::where("user_id", $user_id)->delete();
		
		$userotp = new UserOtps();
		$userotp->user_id = $user_id;
		$userotp->otp_value = $otp_code;
		$userotp->save();
		
		$userotp->messageForOtpAgent( $user_id, $userotp->id, 1 );
		
		return $userotp->id;
	}
	
	public function agentMobileVerification(Request $request){
		if( Auth::check() ){
			$user_data = Auth::user();
			
			$this->validate( $request, [
				'otp_code' => 'required|min:4|max:4|digits:4',
			  ],[
				'otp_code.required' => trans('translations.frontend.otp_required_error'),
				'otp_code.digits' => trans('translations.frontend.otp_digits_error'),
				'otp_code.min' => trans('translations.frontend.otp_min_error'),
				'otp_code.max' => trans('translations.frontend.otp_max_error'),
			]);
			
			if( $request->session()->exists('otp_id') ) {
			}
			else{
				return redirect("/");
			}
			
			$otp_id = Session::get('otp_id');
			$otp_user_id = $user_data->id;
			
			$check_otp_valid = UserOtps::where( "id", $otp_id )->where( "user_id", $otp_user_id )->where("otp_value", $request->input("otp_code") )->where( 'created_at', '>=', Carbon::now()->subMinutes(30)->toDateTimeString() )->first();
			
			if( $check_otp_valid && intval( $check_otp_valid->id ) > 0 ){
				$message_type = 0;
				if( intval( $check_otp_valid->has_validated ) == 1 ){
					$message_type = 0;
				}
				else{
					$check_otp_valid->has_validated = 1;
					$check_otp_valid->validated_on = Carbon::now();
					$check_otp_valid->save();
					
					$user_data->mobile_verified = 1;

					$mobile_update_present = UserProfileUpdates::where( "user_id", $user_data->id )->where("field_name", "contact_number")->where( "status", 1 )->orderBy("created_at", "desc")->first();
					
					$message_type = 1;
					if( $mobile_update_present && intval( $mobile_update_present->id ) > 0 ){						$user_data->add_user_log( $user_data->id, "profile_update", "", $user_data->contact_number, $mobile_update_present->field_data, $user_data->id, array( ), "contact_number" );						
						$message_type = 2;
						$user_data->contact_number = $mobile_update_present->field_data;
						$user_data->save();
						$check_otp_valid->messageMobileVerified( $user_data, "ModileUpdated" );
						
						$mobile_update_present->status = 0;
						$mobile_update_present->save();
					}
					else{
						$user_data->save();
						
						$check_otp_valid->messageMobileVerified( $user_data, "MobileVerified" );
						
						$user_data->add_user_log( $user_data->id, "mobile_verify", UserAuditLog::LOG_CONTACTVERIFY, "", "", $user_data->id, array( ) );
					}
					
					
					Session::forget('otp_id');
					Session::forget('otp_is_updatable');
				}
				
				$request->session()->put('otp_message_type', $message_type );
				
				return view('frontend.login_verify_otp')
						->with('user_data', $user_data)
						->with('is_success', 1)
						->with('otp_is_updatable', 0 );
			}
			else{
				$check_otp_incorrect = UserOtps::where( "id", $otp_id )->where( "user_id", $otp_user_id )->where( 'created_at', '>=', Carbon::now()->subMinutes(30)->toDateTimeString() )->first();
				if( $check_otp_incorrect && intval( $check_otp_incorrect->id ) > 0 ){
					return redirect()->back()
						->withErrors([
							'otp_code' => trans('translations.frontend.wrong_otp') ,
						]);
				}
				else{
					return redirect()->back()
						->withErrors([
							'otp_code' => trans('translations.frontend.otp_expired'),
						]);
				}
			}
		}
		else{
			return redirect("/");
		}
	}
	
	public function agentVerificationSuccess(Request $request){
		return view('frontend.auth.register_success');
	}
	
	public function resendAgentOtp(Request $request){
		if( Auth::check() ){
			if( $request->session()->exists('otp_id') ) {
				$user_data = Auth::user();
				
				$otp_id = Session::get('otp_id');
				$otp_user_id = $user_data->id;
				
				$check_otp_valid = UserOtps::where( "id", $otp_id )->where( "user_id", $otp_user_id )->where( 'created_at', '>=', Carbon::now()->subMinutes(30)->toDateTimeString() )->first();
				if( $check_otp_valid && intval( $check_otp_valid->id ) > 0 ){
					$check_otp_valid->messageForOtpAgent( $otp_user_id, $otp_id, 1 );
					return Response::json( array( 'success' => trans('translations.frontend.otp_resend_success') ) );
				}
				else{
					$otp_code_id = $this->sendOtpMessage($otp_user_id);
					$request->session()->put('otp_id', $otp_code_id);
					return Response::json( array( 'success' => trans('translations.frontend.otp_resend_success') ) );
				}
			}
			else{
				return Response::json( array( 'errors' => trans('translations.frontend.otp_session_expired') ) );
			}
		}
		else{
			return Response::json( array( 'errors' => trans('translations.frontend.otp_agent_loggedout') ) );
		}
	}
	
	public function updateAgentMobile(Request $request){
		if( Auth::check() ){
			$user_data = Auth::user();
			
			$validator = Validator::make( $request->all(), [
				'agent_contact_number' => 'required|digits:10|unique:users,contact_number,'.$user_data->id.',id,deleted_at,NULL',
			], [
				'agent_contact_number.required' => trans('translations.frontend.agent_contact_number_required'),
				'agent_contact_number.digits' => trans('translations.frontend.agent_contact_number_digits'),
				'agent_contact_number.unique' => trans('translations.frontend.agent_contact_number_unique'),
			]);
			if ($validator->fails()) {
				return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			} else {
				$user_data->contact_number = $request->input("agent_contact_number");
				
				$user_data->add_user_log( $user_data->id, "profile_update", "", $user_data->contact_number, $request->input("agent_contact_number"), $user_data->id, array( ), "contact_number" );
				
				$user_data->save();
				
				$otp_code_id = $this->sendOtpMessage( $user_data->id );
				$request->session()->put('otp_id', $otp_code_id);
				return Response::json( array( 'success' => trans('translations.frontend.otp_resend_success') ) );
			}
		}
		else{
			return Response::json( array( 'errors' => trans('translations.frontend.otp_agent_loggedout') ) );
		}
	}
	
	function blogindex(){
			$user_data = Auth::user()->id;
			$dashboardData = getUserDashboardData($user_data);
			$dashboardData['generalsettings']  = $this->generalSettings;
			$dashboardData['blogdata']=Blogs::all()->where('user_id', Auth::user()->id);
			return view('frontend.blog_index', $dashboardData);
		}

	function blogAdd(){
		$user_data = Auth::user();
		$dashboardData = getUserDashboardData($user_data);
		$dashboardData['generalsettings']  = $this->generalSettings;
		return view('frontend.blog_post', $dashboardData);
	}

	function blogEdit($slug){
		$user_data = Auth::user();
		$dashboardData = getUserDashboardData($user_data);
		$dashboardData['generalsettings']  = $this->generalSettings;	
		$blog = Blogs::all()->where('blog_slug', $slug)->first();
		return view('frontend.blog_post_edit', compact('blog'),$dashboardData);
		
	}
	
	function blogDelete($slug){	
 
		$blog = Blogs::all()->where('blog_slug', $slug)->first();
		$blog->delete();
		return redirect()->route('blogIndex');		
	}

	function accountsetting(){

			$user_data = Auth::user();
			$dashboardData = getUserDashboardData($user_data);
			$dashboardData['generalsettings']  = $this->generalSettings;
		return view('frontend.account-setting',$dashboardData);

	} 
  

	function accountupdate(Request $request,$id){

			$name_regex = "/^[\pL\s]+$/u";
		
		$validator = Validator::make( $request->all(), [
			'name' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
			'email' => 'sometimes|email|min:3|max:255|unique:users,email,'.$id,
			'user_image' => 'max:200|mimes:jpeg,png',
			'phone' => 'required|unique:users,phone,'.$id,
                    ], [
                        'name.required' => 'Please enter Name.',
                        'name.regex' => 'Enter only characters',
                        'phone.required' => 'Enter  Numbers Only',
                        'email.required' => 'Please Enter Email Id.',
                        
						'user_image.max' => "Maximum file size to upload is 200KB . If you are uploading a photo, try to reduce its resolution to make it under 200KB."
                        
                    ]);
		if ($validator->fails()) {
			
            return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			
        }else{
			
			$user = User::findorfail($id);
			$user->name = $request->input('name');
			$user->email = $request->input('email');
			$user->phone = $request->input('phone');
	//image upload		
	if ($request->hasFile('user_image')) {
        $file = $request->file('user_image');
        $filename =time().'.'.$file->getClientOriginalName();
        $location =public_path('uploads/users/');
        $file->move($location, $filename);
        $user->user_image = $filename;
        if($request->input('old_user_image')){
            @unlink(public_path('uploads/users/'.$request->input('old_user_image')));
        }
        
       }

			$user->save();

			return Response::json( array( 'success' => "Registered successfully.", "redirect_response" => route('accountSetting') ) );
				
		}
	}

 function accountdestroy(Request $request, $id){
 	// $user = Auth::user();
	$validator = Validator::make( $request->all(), [
                'reason' => 'required'
                
            ],[
                "reason.required" => "Please choose atleast one option for deleting your account."
               
            ]);

	if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			   
		}

	// $saveReason = User::updateOrCreate(
	// 	    [ $user->id ],
	// 	    [ $user->id, 'reason' => $request->input('reason')],
	// 	    [ $user->id, 'delete_description' => $request->input('delete_description')]);
 //  	print_r($saveReason);
 //  	die('dd');
 //  	$saveReason->save();

 
  	$users = User::findorfail($id);
  	$users->delete();
  	return redirect()->route('index')->with('message','Account Deleted Successfully');

  }


  function verifyIdentity(Request $request){
  	
  	$this->validate($request, [
			
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
			'user_id' => 'required'
        ], [
            'image.required' => 'Please Chose an image .',
            'image.max' => 'Image should not be grater than 2MB.'
        ]);

  	   
         $identity= new Verification();
         $identity->user_id = $request->input('user_id');
         $identity->status=0;
         

		 if($request->hasfile('image'))
         {
            foreach($request->file('image') as $image)
            {
                $filename=time().'.'.$image->getClientOriginalName();
                $image->move(public_path('uploads/verify/', $filename));               
               
                 $identity->identity_details = $filename;
         		 
            }
         }


          $identity->save();

        return back()->with('success', 'successfully uploaded.');
	
  }

  


 


}
