<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Hash;

use App\Models\Languages;
use App\Models\User;
use App\Models\UserXprofile;
use App\Models\UserAuditLog;
use App\Models\UserProfileUpdates;
use App\Models\Role;
use App\Models\Service;
use App\Models\State;
use App\Models\District;
use App\Models\SubDistricts;
use App\Models\Blocks;
use App\Models\Qualification;
use App\Models\Courses;
use App\Models\Modules;
use App\Models\ModulesContent;
use App\Models\Test;
use App\Models\UserOtps;
use App\Models\EmailMessage;
use App\Models\VerifyUser;
use App\Models\ApiAuthAccessTokens;
use App\Models\ModulesUserHistory;
use App\Models\ModulesUserWatchTimeLog;

use Illuminate\Support\Facades\Auth;
use Spatie\Permission\Traits\HasRoles;
use Carbon\Carbon;
use Response;

class ApiController extends Controller
{
	public $successStatus = 200;
	use HasRoles;
 
 
    public function __construct( ) {
        $this->generalSettings = generalSettings();
    }
	
	public function authenticateAgent(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){
			return response()->json( [ 'status' => 1, 'error' => "Valid Authentication Code." ]);
		}
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ]);
		}
	}
 
    //Login API
    public function login(Request $request){
		$field = 'email';
		if( is_numeric( $request->input('email') ) ){
			$field = 'contact_number';
		}
		
		$request->merge( [ $field => $request->input('email') ] );
		$login_cred = $request->only( $field, 'password');
		
		if( Auth::attempt( $login_cred ) ) {
			$user_data = Auth::user();
			if( $user_data->hasAnyRole( [ Role::ROLE_ABCUSER ] ) ){
				if( intval( $user_data->email_verified ) != 1 ){
					return response()->json( [ 'status' => 0, 'error' => 'Please Verify Your Email Address first.' ]);
				}
				
				if( !$user_data->isActive()){
					return response()->json( [ 'status' => 0, 'error' => "Sorry, Your Account is not active." ]);
				}
				
				$token_access = ApiAuthAccessTokens::where('user_id', $user_data->id)->where('status', 1)->first();
				if( $token_access ){
					$token_access->status = 0;
					$token_access->save();
				}	
		
				$tokenResult = $user_data->createToken('ttc_portal')->accessToken;
				
				$token_access = new ApiAuthAccessTokens();
				$token_access->user_id = $user_data->id;
				$token_access->access_token = $tokenResult;
				$token_access->status = 1;
				$token_access->save();
				
				$otp_code_id = 0;
				if( intval( $user_data->mobile_verified ) == 0 ){
					$otp_code_id = $this->sendOtpMessage( $user_data->id );
				}
				
				$certification_level = $user_data->getUserCertificationLevel( $user_data );
				
				$user_data->certification_img = "";
				if( count( $certification_level ) > 0 ){
					$user_data->certification_img = asset( $certification_level[0]->test_passing_logo );
				}
				
			    $user_data->profile_image = $user_data->get_image_data( $user_data->image_id, 'size50' );
			    $user_xprofile = $user_data->userxprofile;
			    $user_xprofile->store_image = $user_data->get_image_data( $user_xprofile->secondary_image_id, 'size50' );
				$user_xprofile->cbc_name = "";
				if( intval($user_xprofile->parent_cbc) > 0 ) {
					$cbc_data = $user_xprofile->parent_users->userxprofile;
					
					$user_xprofile->cbc_name = ucwords($cbc_data->company_name);
				}
				
			    return response()->json( [ 'status' => 1, 'success' => "Login Successfull", "access_token" => $tokenResult, 'userData'=> $user_data, "otp_code_id" => $otp_code_id ] );
			}
			else{
				return response()->json( [ 'status' => 0, 'error' => "Sorry, You don't have access to this feature of the application." ]);
			}
        }else{
			return response()->json( [ 'status' => 0, 'error' => "These credentials do not match our records." ]);
		}
    }
	
	//API for sending message
	public function sendOtpMessage( $user_id ){
		$otp_code = mt_rand(1000, 9999);
		
		UserOtps::where("user_id", $user_id)->delete();
		
		$userotp = new UserOtps();
		$userotp->user_id = $user_id;
		$userotp->otp_value = $otp_code;
		$userotp->save();
		
		$userotp->messageForOtpAgent( $user_id, $userotp->id, 0 );
		
		return $userotp->id;
	}
	
	//API for Updating agent contact number while Mobile Verification
	public function contactUpdate(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){
			$user_data = User::find( $user_id );
			
			$validator = Validator::make( $request->all(), [
				'contact_number' => 'required|digits:10|unique:users,contact_number,'.$user_data->id.',id,deleted_at,NULL',
			], [
				'contact_number.required' => trans('translations.frontend.agent_contact_number_required'),
				'contact_number.digits' => trans('translations.frontend.agent_contact_number_digits'),
				'contact_number.unique' => trans('translations.frontend.agent_contact_number_unique'),
			]);
			if ($validator->fails()) {
				$validation_error = $validator->getMessageBag()->toArray();
				return response()->json( [ 'status' => 0, 'error' => $validation_error["contact_number"][0] ]);
			} else {
				$user_data->contact_number = $request->input("contact_number");
				
				$user_data->add_user_log( $user_data->id, "profile_update", "", $user_data->contact_number, $request->input("contact_number"), $user_data->id, array( ), "contact_number" );
				
				$user_data->save();
				
				$otp_code_id = $this->sendOtpMessage( $user_data->id );
				
				return response()->json( [ 'status' => 1, 'success' => 'Otp has been sent Successfully', 'otp_code_id' => $otp_code_id ]);
			}
		}
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ]);
		}
	}
	
	//Resend Message OTP API
    public function resendOtp(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){
			$user_data = User::find( $user_id );			
			$otp_id = $request->input('otp_id');

			$otp_user_id = $user_data->id;
			
			$check_otp_valid = UserOtps::where( "id", $otp_id )->where( "user_id", $otp_user_id )->where( 'created_at', '>=', Carbon::now()->subMinutes(30)->toDateTimeString() )->first();
			if( $check_otp_valid && intval( $check_otp_valid->id ) > 0 ){
				$check_otp_valid->messageForOtpAgent( $otp_user_id, $otp_id, 0 );
				
				return response()->json( [ 'status' => 1, 'success' => 'Otp has been sent Successfully', 'otp_code_id' => $otp_id ]);
			}
			else{
				$otp_code_id = $this->sendOtpMessage($otp_user_id);
				
				return response()->json( [ 'status' => 1, 'success' => 'Otp has been sent Successfully', 'otp_code_id' => $otp_code_id ]);
			}
		}
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ]);
		}
	}
	
	// Verify OTP API functionality here
    public function verifyMobileOtp(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){
			$otp_id = $request->input('otp_id');
			
			if( intval( $otp_id ) > 0 ){
				$validator = Validator::make( $request->all(), [
					'otp_code' => 'required|min:4|max:4|digits:4',
				  ],[
					'otp_code.required' => trans('translations.frontend.otp_required_error'),
					'otp_code.digits' => trans('translations.frontend.otp_digits_error'),
					'otp_code.min' => trans('translations.frontend.otp_min_error'),
					'otp_code.max' => trans('translations.frontend.otp_max_error'),
				]);
				if ($validator->fails()) {
					$validation_error = $validator->getMessageBag()->toArray();
					return response()->json( [ 'status' => 0, 'error' => $validation_error["otp_code"][0] ]);
				}
				else{
					$user_data = User::find( $user_id );
					
					$check_otp_valid = UserOtps::where( "id", $otp_id )->where( "user_id", $user_id )->where("otp_value", $request->input("otp_code") )->where( 'created_at', '>=', Carbon::now()->subMinutes(30)->toDateTimeString() )->first();
					if( $check_otp_valid && intval( $check_otp_valid->id ) > 0 ){
						$check_otp_valid->has_validated = 1;
						$check_otp_valid->validated_on = Carbon::now();
						$check_otp_valid->save();
						
						$user_data->mobile_verified = 1;
						$user_data->save();
						
						$check_otp_valid->messageMobileVerified( $user_data, "MobileVerified" );
						
						$user_data->add_user_log( $user_data->id, "mobile_verify", UserAuditLog::LOG_CONTACTVERIFY, "", "", $user_data->id, array( ) );
						
						return response()->json( [ 'status' => 1, 'success' => "Mobile Verification Successfull" ]);
					}
					else{
						$check_otp_incorrect = UserOtps::where( "id", $otp_id )->where( "user_id", $user_id )->where( 'created_at', '>=', Carbon::now()->subMinutes(30)->toDateTimeString() )->first();
						if( $check_otp_incorrect && intval( $check_otp_incorrect->id ) > 0 ){
							return response()->json( [ 'status' => 0, 'error' => trans('translations.frontend.wrong_otp') ]);
						}
						else{
							return response()->json( [ 'status' => 0, 'error' => trans('translations.frontend.otp_expired') ]);
						}
					}
				}
			}
			else{
				return response()->json( [ 'status' => 0, 'error' => "Otp Authentication Failed!" ]);
			}
		}
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ]);
		}
    }
	
	//Validate Agent login status
	public function checkAgentAccessValidation( $access_token, $user_id ){
		
		$user_data = User::find( $user_id );
		if( $user_data && intval( $user_data->id ) > 0 ){
		}
		else{
			return false;
		}
		
		$token_access = ApiAuthAccessTokens::where( 'access_token', $access_token )->where( "user_id", $user_id )->where( 'status', 1 )->first();
		if( $token_access && intval( $token_access->id ) > 0 ){
			return true;
		}
		else{
			return false;
		}
	}
	
	//API for Agent Logout
	public function logout(Request $request){
		$access_token = $request->input('access_token');
		if( $access_token != ""){
			$token_access = ApiAuthAccessTokens::where('access_token', $access_token)->where('status', 1)->first();
			if( $token_access ){
				$token_access->status = 0;
				$token_access->save();
				
				return response()->json( [ 'status' => 1, 'success' => "Logout Successfull" ] , $this->successStatus );
			}
			else{
				return response()->json( [ 'status' => 0, 'error' => "Invalid access token" ]);
			}
		}
		else{
			return response()->json( [ 'status' => 0, 'error' => "Invalid access token" ]);
		}
    }
 
	// Resend Email Verification link API
	public function resendVerificationLink(Request $request){
		$validator = Validator::make( $request->all(), [
			'email' => 'required|email|min:3|max:255',
		  ],[
			'email.required' => trans('translations.frontend.rules.email_required'),
			'email.email' => trans('translations.frontend.rules.email_valid'),
			'email.min' => trans('translations.frontend.rules.email_min'),
			'email.max' => trans('translations.frontend.rules.email_max'),
		]);
		
		if( $validator->fails() ) {
			$validation_error = $validator->getMessageBag()->toArray();
			return response()->json( [ 'status' => 0, 'error' => $validation_error["email"][0] ]);
		}
		else{
			$email_address = $request->input( 'email' );
			$user_data = User::role( Role::ROLE_ABCUSER )->where("email", $email_address)->first();
			
			if( $user_data && intval( $user_data->id ) > 0 ){
				if( intval( $user_data->email_verified ) == 1 ){
					return response()->json( [ 'status' => 0, 'error' => trans('translations.frontend.resend_error_verified') ]);
				}
				else{
					$verification_token = str_random(40);
					VerifyUser::where( "user_id", $user_data->id )->delete();
					
					$verifyuser = new VerifyUser();
					$verifyuser->user_id = $user_data->id;
					$verifyuser->token = $verification_token;
					$verifyuser->status = 1;
					$verifyuser->save();
					
					if( $verifyuser && intval( $verifyuser->id ) > 0 ){
						$verification_link = url('verify', $verification_token);
						
						$email_content = array();
						$email_content["user_name"] = ucwords( $user_data->name );
						$email_content["verify_url_code"] = $verification_link;
						$email_content["verify_button"] = '<a href="'.$verification_link.'" target="_blank" style="border:none; text-decoration:none; padding:15px 30px; font-size:24px; background:#1a2166; color:#fff;">Verify Now</a>';
						
						$email_message = new EmailMessage();
						$email_message->singleMailSendIntegration( $user_data->email, "ResendVerificationLink", $email_content );	
					}
					
					return response()->json( [ 'status' => 1, 'success' => trans('translations.frontend.resend_success_msg') ]);
				}
			}
			else{
				return response()->json( [ 'status' => 0, 'error' => trans('translations.frontend.resend_email_not_found') ]);
			}
		}
	}
 
	//Forgot Password
	public function forgotPassword(Request $request){
		$validator = Validator::make( $request->all(), [
			'email' => 'required|email|min:3|max:255',
		  ],[
			'email.required' => trans('translations.frontend.rules.email_required'),
			'email.email' => trans('translations.frontend.rules.email_valid'),
			'email.min' => trans('translations.frontend.rules.email_min'),
			'email.max' => trans('translations.frontend.rules.email_max'),
		]);
		
		if( $validator->fails() ) {
			$validation_error = $validator->getMessageBag()->toArray();
			return response()->json( [ 'status' => 0, 'error' => $validation_error["email"][0] ]);
		}
		else{
			$email_address = $request->input( 'email' );
			$user_data = User::role( Role::ROLE_ABCUSER )->where("email", $email_address)->first();
			
			if( $user_data && intval( $user_data->id ) > 0 ){
				
				$password = 'Admin@123';//str_random(8);
				$user_data->password = Hash::make( $password );
				
				$user_data->add_user_log( $user_data->id, "profile_update", "", "", "", $user_data->id, array( ), "password" );
				$user_data->save();
				
				$email_content = array();
				$email_content["user_name"] = ucwords( $user_data->name );
				$email_content["new_password"] = $password;
				$email_message = new EmailMessage();
				$email_message->singleMailSendIntegration( $user_data->email, "ForgotPassword", $email_content );
				
				return response()->json( [ 'status' => 1, 'success' => trans('translations.frontend.forgot_password_success_msg') ]);
			}
			else{
				return response()->json( [ 'status' => 0, 'error' => trans('translations.frontend.resend_email_not_found') ]);
			}
		}
	}
	
	//Agent Default Language
	public function updateUserLocale(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){
			$locale = $request->input('lang');
			
			$user_data = User::find( $user_id );
			
			$user_xprofile = $user_data->userxprofile;
			$user_xprofile->language_preferenced = $locale;
			
			$user_data->add_user_log( $user_data->id, "profile_update", "", $user_xprofile->language_preferenced, $locale, $user_data->id, array( ), "language_preferenced" );
			
			$user_xprofile->save();
			
			return response()->json( [ 'status' => 1, 'success' => 'Locale Updated.' ]);
		}
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ]);
		}
    }
	
	//Change Password Functionality
	public function changePassword(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		/* 
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){ */
			$validator = Validator::make( $request->all(), [
				'old_password' => 'required|min:6',
				'new_password' => 'required|min:6',
				'confirm_new_password' => 'required|min:6|same:new_password',
			  ],[
				'old_password.required' => trans('translations.frontend.cpassword_rules.old_p_required'),
				'old_password.min' => trans('translations.frontend.cpassword_rules.old_p_min'),
				'new_password.required' => trans('translations.frontend.cpassword_rules.new_p_required'),
				'new_password.min' => trans('translations.frontend.cpassword_rules.new_p_min'),
				'confirm_new_password.required' => trans('translations.frontend.cpassword_rules.conf_p_required'),
				'confirm_new_password.min' => trans('translations.frontend.cpassword_rules.conf_p_min'),
				'confirm_new_password.min' => trans('translations.frontend.cpassword_rules.conf_p_same'),
			]);
			
			if( $validator->fails() ) {
				$validation_error = $validator->getMessageBag()->toArray();
				
				$change_password_errors = array();
				if( isset( $validation_error["old_password"] ) ){
					$change_password_errors["old_password"] = $validation_error["old_password"][0];
				}
				if( isset( $validation_error["new_password"] ) ){
					$change_password_errors["new_password"] = $validation_error["new_password"][0];
				}
				if( isset( $validation_error["confirm_new_password"] ) ){
					$change_password_errors["confirm_new_password"] = $validation_error["confirm_new_password"][0];
				}
				
				return response()->json( [ 'status' => 0, 'error' => $change_password_errors ]);
			}
			else{
				$old_password = $request->input('old_password');
				$new_password = $request->input('new_password');
				$current_user = User::find( $user_id );
				
				if( Hash::check( $old_password, $current_user->password )){
					
					if( Hash::check( $new_password, $current_user->password ) ){
						return response()->json( [ 'status' => 0, 'error' => array( "old_password" => trans('translations.frontend.cpassword_rules.same_password_error') ) ]);
					}
					else{
						
						$user_data = User::find( $current_user->id );
						$user_data->password = Hash::make( $new_password );
						$user_data->save();
						
						$user_data->add_user_log( $user_data->id, "profile_update", "", "", "", $user_data->id, array( ), "password" );
						
						$email_content = array();
						$email_content["user_name"] = ucwords( $user_data->name );
						
						$email_message = new EmailMessage();
						$email_message->singleMailSendIntegration( $user_data->email, "ChangePassword", $email_content );
						
						return response()->json( [ 'status' => 1, 'success' => trans('translations.frontend.change_password_success') ] );
					}
					
				}
				else{
					return response()->json( [ 'status' => 0, 'error' => array( "old_password" => trans('translations.frontend.cpassword_rules.password_incorrect') ) ]);
				}
			}
		/* }
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ], 401);
		} */
	}
	
	/* Add User Watchtime and seektime in DB */
	function addTopicWatchTimeLog(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		/* 
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){ */
			$course_id = $request->input( 'course_id' );
			$module_id = $request->input( 'module_id' );
			$content_id = $request->input( 'content_id' );
			$locale = $request->input( 'locale' );
			$seek_time = $request->input( 'seek_time' );
			$watchtime_id = $request->input( 'watchtime_id' );
			$watchtime_counter = $request->input( 'watchtime_counter' );
			
			$view_id = 0;
			$watchtime_log_id = 0;
			
			if( intval($watchtime_id) > 0 ){
				$module_watchtime_log = ModulesUserWatchTimeLog::find($watchtime_id);
				$module_watchtime_log->watchtime = intval( $watchtime_counter);
				$module_watchtime_log->seektime = intval( $seek_time );
				$module_watchtime_log->save();
				
				$watchtime_log_id = $watchtime_id;
			}
			else{
				$module_watchtime_log = new ModulesUserWatchTimeLog();
				$module_watchtime_log->user_id = $user_id;
				$module_watchtime_log->course_id = $course_id;
				$module_watchtime_log->module_id = $module_id;
				$module_watchtime_log->content_id = $content_id;
				$module_watchtime_log->locale = $locale;
				$module_watchtime_log->watchtime = intval( $watchtime_counter);
				$module_watchtime_log->seektime = intval( $seek_time );
				$module_watchtime_log->status = 1;
				$module_watchtime_log->save();
				
				$watchtime_log_id = $module_watchtime_log->id;
			}
			
			return response()->json( [ 'status' => 1, 'success' => "Course Watch Time Log Updated.", "view_id" => $view_id, "watchtime_log_id" => $watchtime_log_id ] );
		/* }
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ], 401);
		} */
	}
	
	/* Update Topic view counter per course */
	function addTopicsViewWatchCounter(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		/* 
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){ */
			$course_id = $request->input( 'course_id' );
			$module_id = $request->input( 'module_id' );
			$content_id = $request->input( 'content_id' );
			$locale = $request->input( 'locale' );
			$seek_time = $request->input( 'seek_time' );
			$watchtime_id = $request->input( 'watchtime_id' );
			$watchtime_counter = $request->input( 'watchtime_counter' );
			
			$view_id = 0;
			$watchtime_log_id = 0;
			
			$module_views = new ModulesUserHistory();
			$module_views->user_id = $user_id;
			$module_views->course_id = $course_id;
			$module_views->module_id = $module_id;
			$module_views->content_id = $content_id;
			$module_views->locale = $locale;
			$module_views->status = 1;
			$module_views->save();
			
			$view_id = $module_views->id;
			
			if( intval($watchtime_id) > 0 ){
				$module_watchtime_log = ModulesUserWatchTimeLog::find($watchtime_id);
				$module_watchtime_log->watchtime = intval( $watchtime_counter);
				$module_watchtime_log->seektime = intval( $seek_time );
				$module_watchtime_log->save();
				
				$watchtime_log_id = $watchtime_id;
			}
			else{
				$module_watchtime_log = new ModulesUserWatchTimeLog();
				$module_watchtime_log->user_id = $user_id;
				$module_watchtime_log->course_id = $course_id;
				$module_watchtime_log->module_id = $module_id;
				$module_watchtime_log->content_id = $content_id;
				$module_watchtime_log->locale = $locale;
				$module_watchtime_log->watchtime = intval( $watchtime_counter);
				$module_watchtime_log->seektime = intval( $seek_time );
				$module_watchtime_log->status = 1;
				$module_watchtime_log->save();
				
				$watchtime_log_id = $module_watchtime_log->id;
			}
			
			return response()->json( [ 'status' => 1, 'success' => "Course View Counter Incremented.", "view_id" => $view_id, "watchtime_log_id" => $watchtime_log_id ] );
		/* }
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ], 401);
		} */
	}
	
	
	/* Course Content API */
	public function getTrainingContents(Request $request){
		$access_token = $request->input('access_token');
		$user_id = $request->input('user_id');
		
		$languages = Languages::all();
		
		/* 
		$access_validation = $this->checkAgentAccessValidation( $access_token, $user_id );
		if( $access_validation ){ */
		
			$user_data = User::find($user_id);
			
			$reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
		
			$courses = Courses::where( 'status', 1)->with( 'translations' )->get();
			
			if($courses->count() > 0){
				foreach($courses as $course){
					
					$current_course_data = $course->getUserCourseRolledData($user_id, $course->id);
					
					$course->view_count = $course->course_view_history_without_locale( $course->id, $user_id);
					
					$default_selected_module = $current_course_data[0]["course_modules"][0]->id;
			
					$default_selected_topic = 0;
					if( count( $current_course_data[0]["course_last_viewed_module"] ) > 0 ){
						$default_selected_module = $current_course_data[0]["course_last_viewed_module"][0]->module_id;
						$default_selected_topic = $current_course_data[0]["course_last_viewed_module"][0]->content_id;
					}
					
					$selected_module_data = $course->course_translation_modules( $course->id, 'en', $default_selected_module  );
					$selected_topic_data = $course->course_translation_singular_topic( $default_selected_module, 'en', $default_selected_topic  );
					
					if( intval( $current_course_data[0]["course_view_counter"] ) > 0 ){
						$course->is_resumed_training = 1;
					}
					else{
						$course->is_resumed_training = 0;
					}
					
					$course->default_module = $selected_module_data[0]->id;
					$course->default_topic = $selected_topic_data[0]->id;
					
					$total_topics_count = 0;
					
					$course_modules = Modules::where("course_id", $course->id)->where('status', 1)->orderBy('counter', 'asc')->get();
					
					if( count( $course_modules ) > 0 ){
						foreach( $course_modules as $modules ){
							
							$module_topics = ModulesContent::where( "module_id", $modules->id )->where('status', 1)->orderBy('counter', 'asc')->get();
							
							if( count( $module_topics ) > 0 ){
								foreach( $module_topics as $topics ){
									
									/* print_r( $topics->translations );
									
									die(); */
									$topics->total_views = count( $topics->topic_history_per_user( $user_id, $topics->module_id , 'en')->get() );
									
									$topics->next_previous_data = Modules::getTopicPreviousNextData( $course->id, $modules, $topics);
									
									if( preg_match($reg_exUrl, $topics->short_description, $url) ) {
										$topics->short_description =  preg_replace($reg_exUrl, '<a href="'.$url[0].'" rel="nofollow">'.$url[0].'</a>', $topics->short_description );
									}
									
									$seekTime = 0;
									$topic_seekdata = $topics->topicSeekTime($user_id, 'en');
									if( count($topic_seekdata) > 0 ){
										
										$difference_results = array(0, 1);
										
										$video_duration = convert_time_to_seconds( $topics->duration );
										
										$topic_last_seentime = $seekTime = $topic_seekdata[0]->seektime;
										
										$difference_in_time = intval( $video_duration ) - intval( $topic_last_seentime );
										
										if( in_array( intval($difference_in_time), $difference_results) ){
											$seekTime = 0;
										}
									}
									
									$topics->seekTime = $seekTime;
								}
							}
							
							
							$modules->course_topics = $module_topics;
							
							$total_topics_count += count( $module_topics );
						}
					}
					
					$stats_translation = array();
					$total_duration = gmdate("H:i:s", get_session_durations( $current_course_data[0]["course_modules_topics"] ) );
					foreach( $languages as $lang ){
						app()->setLocale( $lang->locale );
						
						$stats_translation[ "modules_counter" ] [ $lang->locale ] = count( $course_modules )." ".trans('translations.frontend.modules');
						$stats_translation[ "topic_counter" ] [ $lang->locale ] = $total_topics_count." ".trans('translations.frontend.sessions');
						
						$stats_translation[ "duration_counter" ] [ $lang->locale ] = convert_time_format_frontend( $total_duration );
					}
					
					$course->total_topics = $total_topics_count;
					$course->stats_translation = $stats_translation;
					
					$course->course_modules = $course_modules;
					
				}
			} 
			
			return response()->json( [ 'status' => 1, 'success' => "Course Data Found.", 'courses' => $courses, 'view_increment_counter' => $this->generalSettings['view_increment_counter'] ] );
		/* }
		else{
			return response()->json( [ 'status' => 2, 'error' => "Invalid Authentication Code." ], 401);
		} */
    }
	
	function addOfflineVideoLog(Request $request){
		
		$user_id = $request->input('user_id');
		$view_log = $request->input('addviewwatchercounter_offline_array');
		$watch_log = $request->input('addwatchtimelog_offline_array');
		
		$view_log_data = json_decode( $view_log );
		$watch_log_data = json_decode( $watch_log );
		
		if( intval( $user_id ) > 0 ){
			if( count( $view_log_data ) > 0 ){
			  foreach( $view_log_data as $topic_views ){
				$view_time = with( new Carbon( trim( $topic_views->currentDateandTime ) ) )->format( "Y-m-d H:i:s" );
				$module_views = new ModulesUserHistory();
				$module_views->user_id = $user_id;
				$module_views->course_id = $topic_views->course_id;
				$module_views->module_id = $topic_views->module_id;
				$module_views->content_id = $topic_views->content_id;
				$module_views->locale = $topic_views->locale;
				$module_views->status = 1;
				$module_views->created_at = $view_time;
				$module_views->updated_at = $view_time;
				$module_views->save();
			  }
			}
			
			if( count( $watch_log_data ) > 0 ){
			  foreach( $watch_log_data as $topic_watchlog ){
				$watchlog_time = with( new Carbon( trim( $topic_watchlog->currentDateandTime ) ) )->format( "Y-m-d H:i:s" );
				$module_watchtime_log = new ModulesUserWatchTimeLog();
				$module_watchtime_log->user_id = $user_id;
				$module_watchtime_log->course_id = $topic_watchlog->course_id;
				$module_watchtime_log->module_id = $topic_watchlog->module_id;
				$module_watchtime_log->content_id = $topic_watchlog->content_id;
				$module_watchtime_log->locale = $topic_watchlog->locale;
				$module_watchtime_log->watchtime = intval( $topic_watchlog->watchtime_counter );
				$module_watchtime_log->seektime = intval( $topic_watchlog->seek_time );
				$module_watchtime_log->status = 1;
				$module_watchtime_log->created_at = $watchlog_time;
				$module_watchtime_log->updated_at = $watchlog_time;
				$module_watchtime_log->save();
			  }
			}
			
			return response()->json( [ 'status' => 1, 'success' => "Offline Data Saved Successfully." ] );
		}
		else{
			return response()->json( [ 'status' => 0, 'success' => "No User Found." ] );
		}
	}
	
}
