<?php

namespace App\Http\Middleware;

use Closure;
use Response;

use Illuminate\Support\Facades\Auth;
use Spatie\Permission\Exceptions\UnauthorizedException;

use App\Models\ModelsHasPermissions;
use App\Models\Permission;

class customAdminAjaxPermissionCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $permission)
    {
        $permissions = is_array($permission)
            ? $permission
            : explode('|', $permission);
		
		$logged_user_id = app('auth')->user()->id;
        foreach ($permissions as $permission) {
            $permission_data = Permission::whereName( $permission )->first();
			
			$has_access = ModelsHasPermissions::where("model_id", $logged_user_id)->where("permission_id", $permission_data->id)->first();
			
			if ( $has_access && intval( $has_access->model_id ) > 0 ) {
                return $next($request);
            }
        }

		return Response::json( array( 'access_error_msg' => "Sorry, You Don't have permission to access this." ) );
		/*  throw UnauthorizedException::forPermissions($permissions);
		return $next($request); */
    }
}
