<?php

namespace App\Http\Middleware;

use App\Models\Role;
use Closure;
use Session;
use Illuminate\Contracts\Auth\Guard;

use Spatie\Permission\Traits\HasRoles;

class CheckAgentLoginAuthenticated
{
	use HasRoles;

	protected $guard_name = 'web';
    /**
     * The Guard implementation.
     *
     * @var Guard
     */
    protected $auth;
	
    /**
     * Create a new filter instance.
     *
     * @param  Guard  $auth
     * @return void
     */
    public function __construct(Guard $auth)
    {
        $this->auth = $auth;
    }
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Check user is logged in
        if (!$this->auth->guest()) {
			
            // Check user has the required role(s)
			if( $this->auth->user()->hasAnyRole( [ Role::ROLE_ABCUSER ] ) ){
				if( intval( $this->auth->user()->email_verified ) != 1 ){
					$this->auth->logout();
					return redirect('/')->withErrors(['email' => trans('translations.frontend.login_verify_email_error') ]);
				}
				
				if( !$this->auth->user()->isActive()){
					$this->auth->logout();
					return redirect('/')->withErrors(['email' =>  trans('translations.frontend.rules.account_inactive_error')]);
				}
			
				$language_preferenced = $this->auth->user()->userxprofile->language_preferenced;
				app()->setLocale( $language_preferenced );
				
				if( intval( $this->auth->user()->mobile_verified ) != 1 ){
					return redirect('agentverifyotp');
				}
				
				return $next($request);
			}
			else{
				$this->auth->logout();
				return redirect('/')->withErrors(['email' =>  trans('translations.frontend.rules.access_error')]);
			}
        }
		else{
			return redirect('/');
		}
    }
}
