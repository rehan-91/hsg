<?php

namespace App\Http\Middleware;

use App\Models\Role;
use Closure;
use Illuminate\Contracts\Auth\Guard;

use Spatie\Permission\Traits\HasRoles;

class CheckAdminLoginAuthenticated
{
	use HasRoles;

	protected $guard_name = 'web';
    /**
     * The Guard implementation.
     *
     * @var Guard
     */
    protected $auth;

    /**
     * Create a new filter instance.
     *
     * @param  Guard  $auth
     * @return void
     */
    public function __construct(Guard $auth)
    {
        $this->auth = $auth;
    }
	
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Check user is logged in
        if (!$this->auth->guest()) {
            
           
		
			if( !$this->auth->user()->isActive()){
	
				$this->auth->logout();
				return redirect('admin/')->withErrors(['email' =>  'Sorry, Your Account is not active.']);
			}
			
            // Check user has the required role(s)
			if( $this->auth->user()->hasAnyRole( [ Role::ROLE_SUPERADMIN, Role::ROLE_SUBADMIN ] ) ){
				return $next($request);
			}
			else{
				$this->auth->logout();
				return redirect('admin/')->withErrors(['email' =>  'Sorry, You don\'t have access to this feature of the application.']);
			}
        }
		else{
			return redirect('admin/');
		}
    }
}
