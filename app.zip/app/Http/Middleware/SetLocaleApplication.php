<?php

namespace App\Http\Middleware;

use Session;
use Closure;

class SetLocaleApplication
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
		if (Session::has('app_locale')) {
			app()->setLocale(Session::get('app_locale'));
		}
		else{
			app()->setLocale( 'en' );
		}
		
        return $next($request);
    }
}
