<?php
namespace App\Ttc\Helpers;

class SettingHelper
{
    public function index(){
		echo "gawagwagawgh";
	}
}
