function addmore(){

  var favnum =  $('.add-n-features-more').length;
 
  var html = '';
  html += '<div class="row add-n-features-more">';

  html += '<div  class="form-group col-sm-5" >';
  html += '<input type="text" name="addon_features['+favnum+'][\'feature\']" class="form-control" id="inputText" placeholder="Enter Feature" />';
  html += '</div>';
  html += '<div class="form-group col-sm-5" >';
  html += '<input type="text" name="addon_features['+favnum+'][\'price\']" class="form-control" id="inputText" placeholder="Add Price" />';
  html += '</div>';
  html += '<div class="col-sm-2">';
  html += '<a href="javascript:void(0)" class="panel-close remove-favthings" onclick="removeFavThings()" title="remove">&times;</a>';
  html += '</div>';
  $('.favthings_placeholder').append(html);
}

function removeFavThings(){
$(".add-n-features-more").last().remove();
}


              