var input = document.getElementById("pro-image");
var formdata = false;
var imageSalectionValue = '';
$(function(){
//$("#wizard").steps();

$("#next_step_1").click(function(){

var form = $("#form_step_1");
var validobj = form.validate({
    errorPlacement: function errorPlacement(error, element) {
     
     // return false;
    
      element.after(error);
     
         
    },
    rules: {
      
      name:{ required:true },
      email:{ required:true },
      contact:{ required:true },
      country_name:{ required:true },
      city_name:{ required:true },
      suburbs:{required:true},
      about_yourself:{ required : true, minlength: 200},
      

    },
    messages: {
      
      "about_yourself" : "Please describe  yourself. Minimum length should be 200.",
      "name": "Please enter your name",
      "contact" : "Please enter your contact",
      "email" :"Please enter your email",
      "suburbs" :"Please enter suburbs",
      
    }
});

if(form.valid()){

$.ajax({
  type:"POST",
  url: $("#form_step_1").attr('action'),
  data : $("#form_step_1").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
  success: function(result){
    $("#Load").fadeOut('fast');
    $(".step_2").fadeIn('slow');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');

}
});

 
}

});
$("#next_step_2").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeIn('slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
})
$("#prev_step_2").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeIn('slow');
  $(".step_3").fadeOut('fast');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.first").removeClass('disabled').addClass('current');
})


  document.getElementById('pro-image').addEventListener('change', readImage, false);



  $('img#imagepreview').imgAreaSelect({
    onSelectEnd: function (img, selection) {
      imageSalectionValue = selection;

    }
    });




if (window.FormData) {
formdata = new FormData();
}
    

});
$(document).ready(function(){
  $('.select_box').on('select2:select', function (e) {
   
    if($(this).val() != ""){
      $(this).next().find('.select2-selection--single').removeClass('error');
    }else{
      $(this).next().find('.select2-selection--single').addClass('error');
    }
    
  });
})
function cropImage(){

  if(imageSalectionValue == ""){
    
    alert("Please select image image first to crop.");
    return false;

  }
  var url = $("#imagepreview").attr('src');
  var filename = url.substring(url.lastIndexOf('/')+1);
 
        $.ajax({
          url : imagePostURL,
          type: "POST",
          data : {'image_url':url,'image_file_name':filename, 'height': imageSalectionValue.height, 'width':imageSalectionValue.width,'action' : 'crop', "_token": $('input[name="_token"]').val()},

        }).done(function(res){
          if(res != ""){
           
            }
        });     

}
function readMoreFeatures(id){
  $("#hide-more-features"+id+" .hide-more-features").toggle();
}


var current_id = 0;


$(document).on('click', '.image-cancel', function() {
    let no = $(this).data('no');
    $(".preview-image.preview-show-"+no).remove();
   });

var num = 4;


function readImage() {

  if (window.File && window.FileList && window.FileReader) {
  var files = event.target.files; //FileList object
  var output = $(".preview-images-zone");
  for (let i = 0; i < files.length; i++) {
  var file = files[i];
  if (!file.type.match('image')) continue;
  
  var picReader = new FileReader();
  
  picReader.addEventListener('load', function (event) {
  var picFile = event.target;
  
  if (formdata) {
    formdata.append("pro-image", file);
    formdata.append("_token", $('input[name="_token"]').val());
    console.log(formdata);
    $.ajax({
      url : imagePostURL,
      type: "POST",
      data : formdata,
      contentType: false,
      cache: false,
      processData:false,
      mimeType:"multipart/form-data"
    }).done(function(res){ //
      if(res != ""){
            var html =  '<div class="preview-image preview-show-' + num + '">' +
          '<div class="image-cancel" data-no="' + num + '">x</div>' +
          '<div class="image-zone"><img onclick="showImage('+num+')" id="pro-img-' + num + '" src="' + res + '"></div>' +
          '<div class="radio radio-info form-check-inlinesquarebox image-zone1"> <input type="checkbox" name="available-women" id="pro-img1-' + num + '" class="css-checkbox"><label for="pro-img1-' + num + '" class="css-label">Set as main image</label></div>'
        '</div>';
        output.append(html);
        }
    });
  }
  
  num = num + 1;
  });
  picReader.readAsDataURL(file);
  }
  $("#pro-image").val('');
  } else {
  console.log('Browser not support');
  }
  }



$(document).ready(function(){
  $('.select_box').on('select2:select', function (e) {
   
    if($(this).val() != ""){
      $(this).next().find('.select2-selection--single').removeClass('error');
    }else{
      $(this).next().find('.select2-selection--single').addClass('error');
    }
    
  });
})

function showImage(id){
  $('#imagepreview').attr('src', $("#pro-img-"+id).attr('src')); // here asign the image to the modal when the user click the enlarge link
  $('#imagemodal').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
}


function getCity(id){
  if(id !== ""){
    $.ajax({
         headers: {
            'X-CSRF-TOKEN': $('input[name="_token"]').val()
          },
       type:"post",
       url:fetchcityURL,
       data:{country_id:id},
       success: function(data){
          $("#city_name").html(data);
       }
    });
    }
  
}