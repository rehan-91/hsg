function getLocation() {
     if (navigator.geolocation) {
     //  navigator.geolocation.getCurrentPosition(showPosition);
     showPosition();
     } 
   }
   
   function showPosition(position) {

  //#setCookie('user_latitude',position.coords.latitude);
    //setCookie('user_longitude',position.coords.longitude);
      setCookie('user_latitude',28.653977599999997);
    setCookie('user_longitude',77.1833856);
     
   }

function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  var expires = "expires="+ d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
   getLocation(); 