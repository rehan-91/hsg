$(function(){
  if($("body").hasClass('ckdemo')){
CKEDITOR.replace( 'ckdemo', {
    
} );
}
$("#feature-img").change(function(){
        readURL(this);

            });

$("#user_image").change(function(){
        readURL(this);
 
            });
});

 function addToShortlist(adid){
  var shortlistcount = $(".shortlistcount").text();
  shortlistcount = parseInt(shortlistcount);
  if(shortlistcount >= 10){
    alert('Sorry! You can select upto 10 for comparision');
  }
 var ad_image = $("#ad_image"+adid).attr('src');
 var ad_name = $("#ad_name"+adid).text();

 jQuery.ajax({
        type: 'POST',
        url: addWishlistURL,
        data: {'_token': token, 'ad_id': adid},
        success: function(data) {
                      var html = "";
                      html += '<li id="ad_shorlist'+adid+'">';
                      html += '<figure><img class="figure-img img-fluid" src="'+ad_image+'" alt="">';
                      html +='<span class="imagehover-black"><i class="fas fa-times" onclick="removeFromShortlist('+adid+')"></i></span></figure>';
                      html += '<figcaption class="figure-caption">'+ad_name+'</figcaption>';               
                      html += '</li>';
                      $(".escort_shortlist_list").append(html);
                      var totalshortlistcount = shortlistcount+1;
                      $(".shortlistcount").text(totalshortlistcount);
                      $('#showshortListing'+adid).hide();
                      $('#showshortListed'+adid).show();
                      $('#profile-shortlist-btn'+adid).hide();
                      $('#profile-shortlisted-btn'+adid).show();

                      $('#vn-click').show();
                      if(totalshortlistcount >= 2){
                       $('.compare-btn').show();
                      }else{
                        $('.compare-btn').hide();
                      }
                  
        }
      
 }); 
}
 $(document).ready(function() {
      var shortlistcounts = $(".shortlistcount").text();
      if(parseInt(shortlistcounts) < 2){
      $('.compare-btn').hide();
      }
     $("#vn-click").click(function(){
    jQuery("#vn-info").slideToggle(800);
  });
  $('.close-shortlist-icon').click(function(){
    jQuery("#vn-info").slideToggle(200);
  });
    $('#showshortListing').click(function() {
    $('.shorlist_div').toggleClass("show-shortlist-div");
        });
  });
function removeFromShortlist(adid, comparePage=false){
  var shortlistcount = $(".shortlistcount").text();
  shortlistcount = parseInt(shortlistcount);
  if(shortlistcount >= 10){
    alert('Sorry! You can select upto 10 for comparision');
  }
 
 jQuery.ajax({
        type: 'POST',
        url: removeWishlistURL,
        data: {'_token': token, 'ad_id': adid},
        success: function(data) {
                      $("#ad_shorlist"+adid).remove();
                      if(comparePage){
                        $("#comaprediv"+adid).remove();
                      }
                      var totalshortlistcount = shortlistcount-1;
                      $(".shortlistcount").text(totalshortlistcount);
                      $('#showshortListing'+adid).show();
                      $('#showshortListed'+adid).hide();
                      $('#profile-shortlist-btn'+adid).show();
                      $('#profile-shortlisted-btn'+adid).hide();
                      if(totalshortlistcount == 0){
                      $('#vn-click').hide();
                      jQuery("#vn-info").slideToggle(200);
                      }
                      if(totalshortlistcount >= 2){
                       $('.compare-btn').show();
                      }else{
                        $('.compare-btn').hide();
                      }
                  
        }
      
 }); 
}
   //image preview
 function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#feature-img-preview').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

     //image preview
 function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#user_image_preview').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }


 
  //save blog
  
   function saveblog() {
      $(".help1-block").addClass("hidden");
      $(".input-box").removeClass("has-error");
       for (instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].updateElement();
    }
      var blog_create = new FormData(document.getElementById("form_blog_create"));

      $.ajax({
        type: 'POST',
        dataType: "JSON",
        url:redirect_url,
        data: blog_create,
        processData: false,
        contentType: false,
        success: function(data) {
          if (data.errors) {
            $.each(data.errors, function(key, value) {
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });


            $('html, body').animate({
              scrollTop: parseInt($('.has-error:visible:first').offset().top) - 10
            }, 1000);
          } else if (data.success) {
            window.location.href = data.redirect_url;
          }
        },
      });
    } 
    $(document).ready(function() {
      $('.overlay').hide();
      });
      $(document).ready(function() {
      $('.test1').hover(function() {
      $('.overlay').show();
      },
      function() {
      $('.overlay').hide();
      });
      });
      
        $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip(); 
        });
       
       /* Set the width of the side navigation to 250px */
    function openNav() {
      document.getElementById("mySidenav").style.width = "250px";
    }
    
    /* Set the width of the side navigation to 0 */
    function closeNav() {
      document.getElementById("mySidenav").style.width = "0";
    } 

//user subscribe 

    function add_user_registration() {
      $(".help1-block").addClass("hidden");
      $(".input-box").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("register"));
      $.ajax({
        type: 'POST',
        dataType: "JSON",
        url: $("#register").attr('action'),
        data: registration_form,
        processData: false,
        contentType: false,
     success: function(data) {
          if (data.errors) {
            $.each(data.errors, function(key, value) {
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });


            $('html, body').animate({
              scrollTop: parseInt($('.has-error:visible:first').offset().top) - 10
            }, 1000);
          } else if (data.success) {
               $("#subscribeProfile-popup").modal("hide");
            $("#ThankyouNotify-popup").modal("show");
          }
        },
      });
    }
 

  //user report ad 
    function add_user_report() {
      $(".help1-block").addClass("hidden");
      $(".input-box").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("reportform"));
      $.ajax({
        type: 'POST',
        dataType: "JSON",
        url: $("#reportform").attr('action'),
        data: registration_form,
        processData: false,
        contentType: false,
        success: function(data) {
          if (data.errors) {
            $.each(data.errors, function(key, value) {
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });


            $('html, body').animate({
              scrollTop: parseInt($('.has-error:visible:first').offset().top) - 10
            }, 1000);
          } else if (data.success) {
               $("#reportThisadd").modal("hide");
            $("#report-popup").modal("show");
            
          }
        },
      }); 
    }
  //add user testimonials start

    function add_user_testimonial() {
      $(".help1-block").addClass("hidden");
      $(".input-box").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("testimonial"));
      $.ajax({
        type: 'POST',
        dataType: "JSON",
        url: $("#testimonial").attr('action'),
        data: registration_form,
        processData: false,
        contentType: false,
        success: function(data) {
          if (data.errors) {
            $.each(data.errors, function(key, value) {
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });


            $('html, body').animate({
              scrollTop: parseInt($('.has-error:visible:first').offset().top) - 10
            }, 1000);
          } else if (data.success) {
               $("#testimonial-popup").modal("hide");
            $("#testimonial-Thankyou-popup").modal("show");
            
          }
        },
      });
    }


    //user rating
     function change(id)
   {
    
      
      var cname=document.getElementById(id).className;
      var ab=document.getElementById(id+"_hidden").value;
     
      $("#rating_value").val(ab);
      //console.log(selectedstarvalue);
      var selectedstarvalue=parseInt(ab); 
      console.log(selectedstarvalue);
      for(var i=selectedstarvalue;i>=1;i--)
      {
        
        $("img#"+cname+"_"+i).attr('src', image_path +'/star2.png');
       // console.log($("img#"+cname+"_"+i));
        

      }
      var id=parseInt(ab)+1;
      for(var j=id;j<=5;j++)
      {
        $("img#"+cname+"_"+j).attr('src', image_path +'/star1.png');
      }
     

   }
 
// Applied globally on all textareas with the "autoExpand" class
$(document)
    .one('focus.autoExpand', 'textarea.autoExpand', function(){
        var savedValue = this.value;
        this.value = '';
        this.baseScrollHeight = this.scrollHeight;
        this.value = savedValue;
    })
    .on('input.autoExpand', 'textarea.autoExpand', function(){
        var minRows = this.getAttribute('data-min-rows')|0, rows;
        this.rows = minRows;
        rows = Math.ceil((this.scrollHeight - this.baseScrollHeight) / 16);
        this.rows = minRows + rows;
    });

// end user testimonials

          




 