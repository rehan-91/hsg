var input = document.getElementById("pro-image");
var formdata = false;
var imageSalectionValue = '';
$(function(){
//$("#wizard").steps();

$("#next_step_1").click(function(){

var form = $("#form_step_1");
var validobj = form.validate({
    errorPlacement: function errorPlacement(error, element) {
     
     // return false;
     if(element.is(":radio")){
      $("#personal-error2").before(error);
     
     }
     else if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
     
      element.after(error);
     }
         
    },
       rules: {
      
      name:{ required:true },
      email:{ required:true },
      contact:{ required:true },
      country_name:{ required:true },
      city_name:{ required:true },
      suburbs:{required:true},
      about_yourself:{ required : true, minlength: 200},
      

    },
    messages: {
      
      "about_yourself" : "Please describe  yourself. Minimum length should be 200.",
      "name": "Please enter your name",
      "contact" : "Please enter your contact",
      "email" :"Please enter your email",
      "suburbs" :"Please enter suburbs",
      
    }
});

if(form.valid()){

$.ajax({
  type:"POST",
  url: $("#form_step_1").attr('action'),
  data : $("#form_step_1").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
  success: function(result){
    $("#Load").fadeOut('fast');
    $(".step_2").fadeIn('slow');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_5").fadeOut('fast');
   
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');

}
});

 
}

});
$("#next_step_2").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeIn('slow');
  $(".step_4").fadeOut('fast');
  $(".step_5").fadeOut('fast');
 
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
})
$("#prev_step_2").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeIn('slow');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_5").fadeOut('fast');
 
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.first").removeClass('disabled').addClass('current');
})
$("#prev_step_3").click(function(){
  $(".step_2").fadeIn('slow');
  $(".step_1").fadeOut('slow');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_5").fadeOut('fast');
  
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');
})
$("#next_step_3").click(function(){
var form1 = $("#form_step_3");
var validobj = form1.validate({
    errorPlacement: function errorPlacement(error, element) {
      console.log(element);
     // return false;
   
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }
         
    },
    rules: {
      "service_avail_for[]" : {
        required:true,
        minlength: 1
      },
      "service_available[]" : {
        required: true,
        minlength: 1
      },
      "service_type[]" : {
        required: true,
        minlength: 1
      },
      describe_service:{ required : true, minlength: 200}
    },
    messages: {
      "service_avail_for[]":"Please choose atleast one option.",
      "service_type[]":"Please choose atleast one option.",
      "service_available[]":"Please choose atleast one option.",
      "describe_service" : "Please describe your service. Minimum length should be 200."

      
    }

    
});

if(form1.valid()){
  $.ajax({
    type:"POST",
    url: $("#form_step_3").attr('action'),
    data : $("#form_step_3").serialize(),
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeIn('slow');
      $(".step_5").fadeOut('fast');
      $(".step_6").fadeOut('fast');
      $(".step_7").fadeOut('fast');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.four").removeClass('disabled').addClass('current');
    }
  });
}
});


$("#next_step_4").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_5").fadeOut('fast');
  $(".step_6").fadeOut('fast');
  $(".step_7").fadeIn('slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.five").removeClass('disabled').addClass('current');
  });
  $("#prev_step_4").click(function(){
    $(".step_2").fadeOut('fast');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeIn('slow');
    $(".step_4").fadeOut('fast');
    $(".step_5").fadeOut('fast');
    $(".step_6").fadeOut('fast');
    $(".step_7").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
  });
  $("#next_step_5").click(function(){
    $(".step_2").fadeOut('fast');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_5").fadeOut('fast');
    $(".step_6").fadeIn('slow');
    $(".step_7").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.six").removeClass('disabled').addClass('current');
    });
    $("#prev_step_5").click(function(){
      $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeIn('slow');
      $(".step_5").fadeOut('fast');
      $(".step_6").fadeOut('fast');
      $(".step_7").fadeOut('fast');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.four").removeClass('disabled').addClass('current');
    });
    $("#next_step_6").click(function(){
      $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeOut('fast');
      $(".step_5").fadeOut('fast');
      $(".step_6").fadeOut('fast');
      $(".step_7").fadeIn('slow');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.last").removeClass('disabled').addClass('current');
      });
      $("#prev_step_6").click(function(){
        $(".step_2").fadeOut('fast');
        $(".step_1").fadeOut('fast');
        $(".step_3").fadeOut('fast');
        $(".step_4").fadeOut('fast');
        $(".step_5").fadeIn('slow');
        $(".step_6").fadeOut('fast');
        $(".step_7").fadeOut('fast');
        $('.tablist li.current').removeClass('current').addClass("disabled");
        $(".tablist li.five").removeClass('disabled').addClass('current');
      });
$.validator.setDefaults({ignore: ":hidden:not(.select_box)"});
$('.startdate').datepicker({
    uiLibrary: 'bootstrap4',
  });

  $('.enddate').datepicker({
    uiLibrary: 'bootstrap4',
  }) 
  $('a[href$="#previous"]').addClass('previous');

  $('img#imagepreview').imgAreaSelect({handles: true });
  
  $(".select_box").select2();
  $(".service_select_box").select2();

  $(".services_rates:first .remove-rate").css('display','none');
  $(".services_rates:first .add-rate").css('width','100%');


  $(".touring_girls:first .remove-tour").css('display','none');
  $(".touring_girls:first .add-tour").css('width','100%');

  document.getElementById('pro-image').addEventListener('change', readImage, false);



  $('img#imagepreview').imgAreaSelect({
    onSelectEnd: function (img, selection) {
      imageSalectionValue = selection;

    }
    });




if (window.FormData) {
formdata = new FormData();
}
    

});

function cropImage(){

  if(imageSalectionValue == ""){
    
    alert("Please select image image first to crop.");
    return false;

  }
  var url = $("#imagepreview").attr('src');
  var filename = url.substring(url.lastIndexOf('/')+1);
 
        $.ajax({
          url : imagePostURL,
          type: "POST",
          data : {'image_url':url,'image_file_name':filename, 'height': imageSalectionValue.height, 'width':imageSalectionValue.width,'action' : 'crop', "_token": $('input[name="_token"]').val()},

        }).done(function(res){
          if(res != ""){
           
            }
        });     

}
function readMoreFeatures(id){
  $("#hide-more-features"+id+" .hide-more-features").toggle();
}


var current_id = 0;
function addRate(){

  if ($('.service_select_box').data('select2')) {
    $(".service_select_box").select2("destroy");
    $('.service_select_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }


var num =  $('.services_rates').length;
var clone = $(".services_rates").first().clone();
clone.insertBefore('#tool-placeholder');
clone.attr('id', 'test'+num);
clone.find("select").attr("id", "services_rates_"+num);
$(".service_select_box").select2({}); 
$(".services_rates:last .remove-rate").css('display','inline-block');
$(".services_rates:last .add-rate").css('width','70%');
$("select").on("select2:close", function (e) {  
  $(this).valid(); 
});

}

$(document).on('click', '.image-cancel', function() {
    let no = $(this).data('no');
    $(".preview-image.preview-show-"+no).remove();
   });


function removeRate(){
$(".services_rates:last .remove-rate").closest('.services_rates').remove();
}


function addTour(){
  if ($('.select_box').data('select2')) {
    $(".select_box").select2("destroy");
    $('.select_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }
 
var num =  $('.touring_girls').length;

var clone = $(".touring_girls").first().clone();
clone.attr('id', 'touring_girls'+num);
clone.find("select").attr("id", "touring_girls_"+num);
clone.find('.enddate').val('').removeClass('hasDatepicker');
clone.find('.startdate').val('').removeClass('hasDatepicker');
clone.find(':input.startdate').attr("id", "startdate"+num);
clone.find(':input.enddate').attr("id", "enddate"+num);
clone.find('#startdate'+num).datepicker().addClass("ui-datepicker-haspicker");;
clone.insertBefore('#touring-section-placeholder');
$(".touring_girls:last .remove-tour").css('display','inline-block');
$(".touring_girls:last .add-tour").css('width','70%');
$(".select_box").select2({}); 

}
function removeTour(){
$(".touring_girls:last .remove-tour").closest('.touring_girls').remove();
}


var num = 4;


function readImage() {

  if (window.File && window.FileList && window.FileReader) {
  var files = event.target.files; //FileList object
  var output = $(".preview-images-zone");
  for (let i = 0; i < files.length; i++) {
  var file = files[i];
  if (!file.type.match('image')) continue;
  
  var picReader = new FileReader();
  
  picReader.addEventListener('load', function (event) {
  var picFile = event.target;
  
  if (formdata) {
    formdata.append("pro-image", file);
    formdata.append("_token", $('input[name="_token"]').val());
    console.log(formdata);
    $.ajax({
      url : imagePostURL,
      type: "POST",
      data : formdata,
      contentType: false,
      cache: false,
      processData:false,
      mimeType:"multipart/form-data"
    }).done(function(res){ //
      if(res != ""){
            var html =  '<div class="preview-image preview-show-' + num + '">' +
          '<div class="image-cancel" data-no="' + num + '">x</div>' +
          '<div class="image-zone"><img onclick="showImage('+num+')" id="pro-img-' + num + '" src="' + res + '"></div>' +
          '<div class="radio radio-info form-check-inlinesquarebox image-zone1"> <input type="checkbox" name="available-women" id="pro-img1-' + num + '" class="css-checkbox"><label for="pro-img1-' + num + '" class="css-label">Set as main image</label></div>'
        '</div>';
        output.append(html);
        }
    });
  }
  
  num = num + 1;
  });
  picReader.readAsDataURL(file);
  }
  $("#pro-image").val('');
  } else {
  console.log('Browser not support');
  }
  }



$(document).ready(function(){
  $('.select_box').on('select2:select', function (e) {
   
    if($(this).val() != ""){
      $(this).next().find('.select2-selection--single').removeClass('error');
    }else{
      $(this).next().find('.select2-selection--single').addClass('error');
    }
    
  });
})

function showImage(id){
  $('#imagepreview').attr('src', $("#pro-img-"+id).attr('src')); // here asign the image to the modal when the user click the enlarge link
  $('#imagemodal').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
}
