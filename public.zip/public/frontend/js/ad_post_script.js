var input = document.getElementById("pro-image");
var formdata = false;
var imageSalectionValue = '';
var $original_image;
var displayFireCrackers = false;
var date = new Date();
var d = date.getDate();
var m = date.getMonth();
var y = date.getFullYear();


$(document).ready(function(){
$(".step_3").css('display', 'block');
  
  $('.datepicker').datetimepicker({
       format: 'DD-MM-YYYY'
   });
   
 
   $('.timepicker').datetimepicker({
       format: 'HH:mm:ss'
   });
     


});
/*
document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('touring-calender');
  var calendar = new FullCalendar.Calendar(calendarEl, {
    plugins: [ 'interaction', 'resourceDayGrid', 'resourceTimeGrid' ,'timeGrid'],
    defaultView: 'dayGridMonth',
    defaultDate: new Date(),
    editable: true,
    droppable: true,
    selectable: true,
    eventLimit: true, // allow "more" link when too many events
    header: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,resourceTimelineDay'
    },
     select: function(arg) {
$("#services-addTime").modal('show');
$("#calendar_start_date").val(moment(arg.start).format('DD-MM-YYYY'));
$("#calendar_end_date").val(moment(arg.end).format('DD-MM-YYYY'));
 $("#addevent").click(function(){
if($("#title").val() == ""){
  alert("enter title");
}else if($("#calendar_start_date").val() == ""){
  alert("select start date")
}else if($("#calendar_end_date").val() == ""){
  alert("select end date")
}else{


          calendar.addEvent({
            title: $("#event_title").val(),
            start: arg.date,
            allDay: true
          });
        }
          $("#services-addTime").modal('hide');
    
});
    },

    dateClick: function(arg) {

$("#services-addTime").modal('show');
  $('.calendar-to-datepicker').datepicker();

  $('.calendar-from-datepicker').datepicker();
 $("#addevent").click(function(){
          calendar.addEvent({
            title: $("#event_title").val(),
            start: arg.date,
            allDay: true
          });
          $("#services-addTime").modal('hide');
    
});
    },
      eventClick: function(arg) { 
      console.log(arg);
    }
     
  });

  calendar.render();
});
*/








$(document).ready(function() {
    var loadURL = 'avalibility_ajax.php';
   var calendar = $('#touring-calender').fullCalendar({
    editable:true,
    header:{
     left:'prev,next today',
     center:'title',
     right:'month, agendaWeek'
    },
    events: loadURL,
    selectable:true,
    allDay: false,
    selectConstraint: {
        start: $.fullCalendar.moment().subtract(1, 'days'),
        end: $.fullCalendar.moment().startOf('month').add(1, 'month')
    },
    selectHelper:true,
    select: function(start, end, allDay)
    {
     $("#services-addTime").modal('show');
     var title="";
     var starta = $.fullCalendar.formatDate(start, "Y-MM-DD");
     var enda = $.fullCalendar.formatDate(end, "Y-MM-DD");
       var start_time = $.fullCalendar.formatDate(start, "H:i");
     var end_time = $.fullCalendar.formatDate(end, "H:i");
     console.log(start);
      $("#calendar_start_date").val(starta);
      $("#calendar_end_date").val(enda);

      $("#calendar_start_time").val(start_time);
      $("#calendar_end_time").val(end_time);
      $("#submitbutton").click(function(){
        $("input").removeClass("error");
        $("select").removeClass("error");
        var error = [];
        if($("#title").val() == ""){
          error.push('#title');

        }
        if($("#capacity").val() == ""){
          error.push('#capacity');
        }

        if($("#from_date").val() == ""){
          error.push('#from_date');
        }
        if($("#to_date").val() == ""){
          error.push('#to_date');
        }
        if($("#price").val() == ""){
          error.push('#price');
        }
        if(error.length > 0){
          for(var i=0; i<error.length; i++){
            $(error[i]).addClass('error');
          }
        }
        if(error.length == 0)
       {
     
        $.ajax({
         url:"avalibility_ajax.php",
         type:"POST",
         data:$("#avalibility_form").serialize()+'&action=insert',
         success:function()
         {
          calendar.fullCalendar('refetchEvents');
          $("#availibilityModel").modal('hide');
         }
        })
       }
      })
     
    },
    editable:true,
    eventResize:function(event)
    {
     var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");
     var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD");
     var title = event.title;
     var id = event.id;
   // $('#from_date').val(start);
    //$('#to_date').val(end);
    document.getElementById("from_date").value = start;
     document.getElementById("to_date").value = end;
     $("#availibilityModel").modal('show');
     setValues(event);

      $("#submitbutton").click(function(){
        $("input").removeClass("error");
        $("select").removeClass("error");
        var error = [];
        if($("#title").val() == ""){
          error.push('#title');

        }
        if($("#capacity").val() == ""){
          error.push('#capacity');
        }

        if($("#from_date").val() == ""){
          error.push('#from_date');
        }
        if($("#to_date").val() == ""){
          error.push('#to_date');
        }
        if($("#price").val() == ""){
          error.push('#price');
        }
        if(error.length > 0){
          for(var i=0; i<error.length; i++){
            $(error[i]).addClass('error');
          }
        }
        if(error.length == 0)
       {
     
        $.ajax({
         url:"avalibility_ajax.php",
         type:"POST",
         data:$("#avalibility_form").serialize()+'&action=update',
         success:function()
         {
          calendar.fullCalendar('refetchEvents');
          $("#availibilityModel").modal('hide');
         }
        })
       }
      })
     
    },

    eventDrop:function(event)
    {
     var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");
     var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD");
     var title = event.title;
     var id = event.id;
     document.getElementById("from_date").value = start;
     document.getElementById("to_date").value = end;
     //$('#from_date').val(start);
    //$('#to_date').val(end);
      $("#availibilityModel").modal('show');
     setValues(event);
         $("#submitbutton").click(function(){
        $("input").removeClass("error");
        $("select").removeClass("error");
        var error = [];
        if($("#title").val() == ""){
          error.push('#title');

        }
        if($("#capacity").val() == ""){
          error.push('#capacity');
        }

        if($("#from_date").val() == ""){
          error.push('#from_date');
        }
        if($("#to_date").val() == ""){
          error.push('#to_date');
        }
        if($("#price").val() == ""){
          error.push('#price');
        }
        if(error.length > 0){
          for(var i=0; i<error.length; i++){
            $(error[i]).addClass('error');
          }
        }
        if(error.length == 0)
       {
     
        $.ajax({
         url:"avalibility_ajax.php",
         type:"POST",
         data:$("#avalibility_form").serialize()+'&action=insert',
         success:function()
         {
          calendar.fullCalendar('refetchEvents');
          $("#availibilityModel").modal('hide');
         }
        })
       }
      })
    },

    eventClick:function(event)
    {
     if(confirm("Are you sure you want to remove it?"))
     {
      var id = event.id;
      $.ajax({
       url:"avalibility_ajax.php",
       type:"POST",
       data:{id:id, action:'delete'},
       success:function()
       {
        calendar.fullCalendar('refetchEvents');
        alert("Event Removed");
       }
      })
     }
    },

   });
  });

  function setValues(data){
    $('#title').val(data.title);
    $('#notes').val(data.notes);
    $('#price').val(data.price);
    $('#capacity').val(data.capacity);
    if(parseInt(data.available) == 1){
      $("#available").bootstrapSwitch('state', true);
      
  }else{
    $("#available").bootstrapSwitch('state', false);
    
  }
    $('#id').val(data.id);
  }


function readVideo(){

  if (window.File  && window.FileReader) {
   
    var files = event.target.files; //FileList object
    var output = $(".preview-video-zone");
    for (let i = 0; i < files.length; i++) {
    var file = files[i];
    if (!file.type.match('video.*')) continue;
    
    var picReader = new FileReader();
    
    picReader.addEventListener('load', function (event) {
    var picFile = event.target;
    
    if (formdata) {
      formdata.append("pro-video", file);
      formdata.append("_token", $('input[name="_token"]').val());
      console.log(formdata);
      $.ajax({
        url : videoPostURL,
        type: "POST",
        data : formdata,
        contentType: false,
        cache: false,
        processData:false,
        mimeType:"multipart/form-data",
        xhr: function () {
          var xhr = new window.XMLHttpRequest();
          xhr.upload.addEventListener("progress", function (evt) {
            $('.js-loading-bar').modal('show');
              if (evt.lengthComputable) {
                  var percentComplete = evt.loaded / evt.total;
                  percentComplete = parseInt(percentComplete * 100);
                  $('.myprogress').text(percentComplete + '%');
                  $('.myprogress').css('width', percentComplete + '%');
              }
          }, false);
          return xhr;
      },
    success:function(res1){ //
      res = JSON.parse(res1);
      $('.js-loading-bar').modal('hide');
        if(res.videopath != ""){
              var html =  '<div class="preview-image preview-show-' + num + '">' +
            '<div class="image-cancel" data-no="' + num + '">x</div>' +
            '<div class="image-zone"><video width="250" height="200"><source src="' + res.videopath + '"></video>'
            +'</div>' +
            '<div class="radio radio-info form-check-inlinesquarebox image-zone1"><input type="hidden" value="'+res.file_name+'" name="videourl[]"></div>'
          '</div>';
          
          output.append(html);
          }
        }
      });
    }
    
    num = num + 1;
    });
    picReader.readAsDataURL(file);
    }
    $("#pro-image").val('');
    } else {
    console.log('Browser not support');
    }

}


function readTeaserVideo(){

  if (window.File  && window.FileReader) {
   
    var files = event.target.files; //FileList object
    var output = $(".preview-teaservideo-zone");
    for (let i = 0; i < files.length; i++) {
    var file = files[i];
    if (!file.type.match('video.*')) continue;
    
    var picReader = new FileReader();
    
    picReader.addEventListener('load', function (event) {
    var picFile = event.target;
    
    if (formdata) {
      formdata.append("teaser-video", file);
      formdata.append("_token", $('input[name="_token"]').val());
      console.log(formdata);
      $.ajax({
        url : teaservideoPostURL,
        type: "POST",
        data : formdata,
        contentType: false,
        cache: false,
        processData:false,
        mimeType:"multipart/form-data",
        xhr: function () {
          var xhr = new window.XMLHttpRequest();
          xhr.upload.addEventListener("progress", function (evt) {
            $('.js-loading-bar').modal('show');
              if (evt.lengthComputable) {
                  var percentComplete = evt.loaded / evt.total;
                  percentComplete = parseInt(percentComplete * 100);
                  $('.myprogress').text(percentComplete + '%');
                  $('.myprogress').css('width', percentComplete + '%');
              }
          }, false);
          return xhr;
      },
    success:function(res1){ //
      res = JSON.parse(res1);
      $('.js-loading-bar').modal('hide');
        if(res.videopath != ""){
              var html =  '<div class="preview-image preview-show-' + num + '">' +
            '<div class="image-cancel" data-no="' + num + '">x</div>' +
            '<div class="image-zone"><video width="250" height="200"><source src="' + res.videopath + '"></video>'
            +'</div>' +
            '<div class="radio radio-info form-check-inlinesquarebox image-zone1"><input type="hidden" value="'+res.file_name+'" name="teaservideourl[]"></div>'
          '</div>';
          
          output.append(html);
          }
        }
      });
    }
    
    num = num + 1;
    });
    picReader.readAsDataURL(file);
    }
    $("#pro-image").val('');
    } else {
    console.log('Browser not support');
    }

}
$(function(){
 $(".step_3").css('display', 'none');
//$("#wizard").steps();
$('input[type=radio][name=rdo]').change(function() {
  if (this.value == 'male') {
      $(".personal-section").hide();
  }else{
    $(".personal-section").show();
  }
 
});

$("#next_step_1").click(function(){

var form = $("#form_step_1");
var validobj = form.validate({
    errorPlacement: function errorPlacement(error, element) {
     
     // return false;
     if(element.is(":radio")){
      $("#personal-error2").before(error);
     
     }
     else if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
     
      element.after(error);
     }
         
    },
    rules: {
      "body-type[]": {
        required: true,
        minlength: 1
      },
      personal:{ required:true },
      age:{ required:true },
      location:{ required:true },
      eyecolor:{ required:true },
      haircolor:{ required:true },
      bust_size:{ required:true },
      weight:{ required:true },
      height:{ required:true },
      nationality:{ required:true },
      orientation:{ required:true },
      gender:{ required:true },
      dresssize:{ required:true },
      shoessize:{ required:true },
      hairlength:{ required:true },
      about_description:{ required : true, minlength: 200},
      "piercing[]":{
        required: true,
        minlength: 1
      },

    },
    messages: {
      "body-type[]": "Please choose body type",
      "location":"Please select location",
      "description" : "Please describe  yourself. Minimum length should be 200.",
      "personal": "Please choose atleast one option",
      "age" : "Please select age",
      "eyecolor" :"Please select eye color",
      "haircolor" :"Please select hair color",
      "height" :"Please select height",
      "weight" : "Plese select weight",
      "nationality" :"Please select nationality",
      "orientation" :"Please select orientation",
      "gender" : "Please select gender",
      "dresssize" : "Please select dress size",
      "shoessize" : "Please select shoes size",
      "hairlength" : "Please select hair length",
      "bust_size" : "Please select bust size",
      "piercing[]":"Please choose atleast one option.",

      
    }
});

if(form.valid()){

$.ajax({
  type:"POST",
  url: $("#form_step_1").attr('action'),
  data : $("#form_step_1").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
  success: function(result){
    $("#Load").fadeOut('fast');
    $(".step_2").fadeIn('slow');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_7").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');

}
});


}

});

$("#next_step_2").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeIn('slow');
  $(".step_4").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
})
$("#prev_step_2").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeIn('slow');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.first").removeClass('disabled').addClass('current');
})
$("#prev_step_3").click(function(){
  $(".step_2").fadeIn('slow');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');
})
$("#next_step_3").click(function(){
 
var form1 = $("#form_step_3");
var validobj = form1.validate({
    errorPlacement: function errorPlacement(error, element) {
      console.log(element);
     // return false;
   
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }
         
    },
    rules: {
      "service-avail-for[]" : {
        required:true,
        minlength: 1
      },
      "service-available[]" : {
        required: true,
        minlength: 1
      },
      "service-type[]" : {
        required: true,
        minlength: 1
      },
      describe_service:{ required : true, minlength: 200}
    },
    messages: {
      "service-avail-for[]":"Please choose atleast one option.",
      "service-type[]":"Please choose atleast one option.",
      "service-available[]":"Please choose atleast one option.",
      "describe-service" : "Please describe your service. Minimum length should be 200."

      
    }

   
});

if(form1.valid()){
  $.ajax({
    type:"POST",
    url: $("#form_step_3").attr('action'),
    data : $("#form_step_3").serialize(),
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeIn('slow');
      $(".step_7").fadeOut('fast');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.four").removeClass('disabled').addClass('current');
    }
  });
}
});


$("#next_step_4").click(function(){
  var form2 = $("form_step_4");
  $.ajax({
    type:"POST",
    url: $("#form_step_4").attr('action'),
    data : $("#form_step_4").serialize(),
    beforeSend: function(){
    //  $("#Load").fadeIn('slow');
    },
    success: function(result){
     
      //$("#Load").fadeOut('fast');
    $(".step_2").fadeOut('fast');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_7").fadeIn('slow');
    let width = window.innerWidth;
  let height = window.innerHeight;
  let particles = [];
  
  // particle canvas
  const canvas = document.createElement( 'canvas' );
  const context = canvas.getContext( '2d' );
  canvas.id = 'firework-canvas';
  canvas.width = width;
  canvas.height = height;
  canvas.style.display = 'block';
  canvas.style.pointerEvents = 'none';
  canvas.style.position = 'fixed';
  canvas.style.zIndex = '1';
  canvas.style.left = '0';
  canvas.style.top = '0';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.opacity = '.85';
  document.getElementById("finished_crackerss").appendChild( canvas );
  
  // on resize 
  window.addEventListener( 'resize', e => {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;
  });
  
  // add particles slowly over time 
  const create = () => {
    if ( particles.length > 2 ) return; 
    particles.push( new FireworkParticle( context, width, height, 100 ) ); 
    setTimeout( create, 600 );  
  }; 
  
  // animation loop 
  const loop = () => {
    requestAnimationFrame( loop );
    context.fillStyle = 'rgba(0,0,0,0.2)';
    context.fillRect( 0, 0, width, height );
    
    for ( let p of particles ) {
      if ( p.complete() ) p.reset();
      p.update( width, height );
      p.draw();
    }
  };
 
  // init 
  create();
  loop();
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.five").removeClass('disabled').addClass('current');
    }
  });
  });
  $("#prev_step_4").click(function(){
    $(".step_2").fadeOut('fast');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeIn('slow');
    $(".step_4").fadeOut('fast');
    $(".step_7").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
  });

$.validator.setDefaults({ignore: ":hidden:not(.select_box)"});
$('.startdate').datepicker({
  
  });

  $('.enddate').datepicker({
   
  })

  $('a[href$="#previous"]').addClass('previous');

  $ias = $('img#imagepreview').imgAreaSelect({instance: true });
  
  $(".select_box").select2();
  $(".service_select_box").select2();
  //$(".select_country_box").select2();
  //$(".select_city_box").select2();
  $(".services_rates:first .remove-rate").css('display','none');
  $(".touring_girls:first .remove-tour").css('display','none');
  $(".extraservice_fee:first .remove-service-rate").css('display','none');
  document.getElementById('pro-image').addEventListener('change', readImage, false);
  document.getElementById('pro-video').addEventListener('change', readVideo, false);
  document.getElementById('teaser-video').addEventListener('change', readTeaserVideo, false);
  
  $('#imagemodal').on('hidden.bs.modal', function () {
    $ias.cancelSelection();
});

  $('img#imagepreview').imgAreaSelect({
    onSelectEnd: function (img, selection) {
      imageSalectionValue = selection;

    } 
    });




if (window.FormData) {
formdata = new FormData();
}
    

});

function cropImage(){

  if(imageSalectionValue == ""){
    
    alert("Please select image image first to crop.");
    return false;

  }
  var url = $("#imagepreview").attr('src');
  var filename = url.substring(url.lastIndexOf('/')+1);
    console.log(imageSalectionValue);
        $.ajax({
          url : imagePostURL,
          type: "POST",
          data : {'image_url':url,'image_file_name':filename, 'x1': imageSalectionValue.x1, 'y1':imageSalectionValue.y1, 'y2':imageSalectionValue.y2,'x2':imageSalectionValue.x2,'action' : 'crop', "_token": $('input[name="_token"]').val()},

        }).done(function(res){
          imageSalectionValue = "";
        
          $("img#imagepreview").attr('src', res+"?random="+new Date().getTime());
        });     

}

function resetChanges(){
  
  var filename = $original_image.substring($original_image.lastIndexOf('/')+1);
      $.ajax({
        url : imagePostURL,
        type: "POST",
        data : {'image_url':$original_image,'image_file_name':filename,'action' : 'reset', "_token": $('input[name="_token"]').val()},

      }).done(function(res){
        imageSalectionValue = "";
        $("#imagepreview").attr('src', $original_image);
      });  
}

function blurImage(){
  if(imageSalectionValue == ""){
    
    alert("Please select image image first to crop.");
    return false;

  }
  var url = $("#imagepreview").attr('src');
  var filename = url.substring(url.lastIndexOf('/')+1);
    console.log(imageSalectionValue);
        $.ajax({
          url : imagePostURL,
          type: "POST",
          data : {'image_url':url,'image_file_name':filename, 'x1': imageSalectionValue.x1, 'y1':imageSalectionValue.y1, 'y2':imageSalectionValue.y2,'x2':imageSalectionValue.x2,'action' : 'blur', "_token": $('input[name="_token"]').val()},

        }).done(function(res){
          imageSalectionValue = "";
        
          $("img#imagepreview").attr('src', res+"?random="+new Date().getTime());
        });     

}
function readMoreFeatures(id){
  $("#hide-more-features"+id+" .hide-more-features").toggle();
if($('#read-more-features'+id).text() == 'Read More'){
  $('#read-more-features'+id).text('Read Less');
}else{
  $('#read-more-features'+id).text('Read More');
}
  
}


var current_id = 0;
function addRate(){

  if ($('.service_select_box').data('select2')) {
    $(".service_select_box").select2("destroy");
    $('.service_select_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }


var num =  $('.services_rates').length;
var clone = $(".services_rates").first().clone();
clone.insertBefore('#tool-placeholder');
clone.attr('id', 'test'+num);
clone.find('.service_incall_charge').attr('name', "service["+num+"][service_incall_charge]").val('');;
clone.find('.service_outcall_charge').attr('name', "service["+num+"][service_outcall_charge]").val('');;
clone.find('.service_time').attr('name', "service["+num+"][service_time]");
clone.find('.service_name').attr('id', "service_name"+num).val('');;
clone.find('.service_name_hidden').attr('name', "service["+num+"][service_name]");
clone.find('.service_name_hidden').attr('id', "service_name_hidden"+num).val('');
clone.find("select").attr("id", "services_rates_"+num);
clone.find('h6.labelwhite').remove();
clone.find('.remove-rate').css("display", "inline-block");
$(".service_select_box").select2({}); 
$("select").on("select2:close", function (e) {  
  $(this).valid(); 
});

}


function setId(id){
  $('.services_include').map(function() {
      
    $(this).prop('checked', false);
  
});
  $("#service_available").val(id);
  var hiddenInputValues = id.replace('service_name', 'service_name_hidden');
  console.log($('#'+hiddenInputValues).val());
  if($('#'+hiddenInputValues).val() != ""){
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
          $(this).prop('checked', true);
      } else {
          $(this).prop('checked', false);
      }
  });
   
  }
 }
 function setValuesToTextbox(){
  var selectedValue = '';
  var selectedText = '';
  selectedValue = $('.services_include:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.services_include:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  console.log(selectedValue);
  var inputId = $('#service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('service_name', 'service_name_hidden');
  $('#'+hiddenInputValues).val(selectedValue);
  console.log(hiddenInputValues);
  console.log($('#'+hiddenInputValues).val());
 }



 //for extra services
 function setExtraId(id){
  $('.extra_services_include').map(function() {
      
    $(this).prop('checked', false);
  
});
  $("#extra_service_available").val(id);
  console.log($("#extra_service_available").val());
  var hiddenInputValues = id.replace('extra_service_name', 'extra_service_name_hidden');
  console.log(hiddenInputValues);
  if($('#'+hiddenInputValues).val() != ""){
    console.log("ddd");
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='extra-service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
        console.log("dddd");
          $(this).prop('checked', true);
      } else {
        console.log("dddddd");
          $(this).prop('checked', false);
      }
  });
   
  }
 }
 function setValuesToExtraTextbox(){
  var selectedValue = '';
  var selectedText = '';
  selectedValue = $('.extra_services_include:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.extra_services_include:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  console.log(selectedValue);
  var inputId = $('#extra_service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('extra_service_name', 'extra_service_name_hidden');
  $('#'+hiddenInputValues).val(selectedValue);
  console.log(hiddenInputValues);
  console.log($('#'+hiddenInputValues).val());
 }

function addServiceFee(){
  
  var num =  $('.extraservice_fee').length;
  var clone = $(".extraservice_fee").first().clone();
  clone.insertBefore('#service-placeholder');

  clone.find('.extraservice_price').attr('name', "extra_services["+num+"][price]").val('');
  clone.find('.extra_service_name').attr('id', "extra_service_name"+num).val('');;
  clone.find('.extra_service_name_hidden').attr('name', "extra_services["+num+"][service_name]");
  clone.find('.extra_service_name_hidden').attr('id', "extra_service_name_hidden"+num).val('');
  clone.find('h6.labelwhite').remove();
  clone.find('.remove-service-rate').css("display", "inline-block");
}
function removeServiceFee(){
  $(".extraservice_fee:last .remove-service-rate").closest('.extraservice_fee').remove();
}
$(document).on('click', '.image-cancel', function() {
    let no = $(this).data('no');
    $(".preview-image.preview-show-"+no).remove();
   });


function removeRate(){
$(".services_rates:last .remove-rate").closest('.services_rates').remove();
}

function addFavThings(){

  var favnum =  $('.favthings_addmore').length;
 
  var html = '';
  html += '<div class="row favthings_addmore">';

  html += '<div class="col-md-5 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-5 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-1 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN remove-favthings" onclick="removeFavThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.favthings_placeholder').append(html);
}

function removeFavThings(){
$(".favthings_addmore").last().remove();
}

function addWishThings(){

  var favnum =  $('.wishthings_addmore').length;
  var html = '';
  html += '<div class="row wishthings_addmore">';
  html += '<div class="col-md-5 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-5 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-12 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN" onclick="removeWishThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.wishlist_placeholder').append(html);
}
function removeWishThings(){
  $('.wishthings_addmore').last().remove();
}

function addTour(){
  if ($('.select_city_box').data('select2')) {
    $(".select_city_box").select2("destroy");
    $('.select_city_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }

 /*if ($('.select_country_box').data('select2')) {
  $(".select_country_box").select2("destroy");
  $('.select_country_box')
  .removeAttr('data-live-search')
  .removeAttr('data-select2-id')
  .removeAttr('aria-hidden')
  .removeAttr('tabindex');
}
 */
var num =  $('.touring_girls').length;

var clone = $(".touring_girls").first().clone();
clone.attr('id', 'touring_girls'+num);

clone.find(".select_city_box").attr("id", "tour_city"+num);
clone.find('.select_city_box option[value!=""]').remove();

clone.find('.select_country_box').attr('name', "tour["+num+"][country]");
clone.find('.select_city_box').attr('name', "tour["+num+"][city]");
clone.find(".select_country_box").attr("id", "tour_country"+num);

$(".select_country_box option[selected]").removeAttr("selected");    
clone.find(':input.enddate').attr("id", "").removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker();
clone.find(':input.startdate').attr("id", "").removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker();
clone.find('input.startdate').attr('name', "tour["+num+"][startdate]");
clone.find('input.enddate').attr('name', "tour["+num+"][enddate]");
clone.insertBefore('#touring-section-placeholder');
clone.find('.remove-tour').css("display", "inline-block");
//$(".select_city_box").select2();
//$(".select_country_box").select2();


}
function removeTour(){
$(".touring_girls:last .remove-tour").closest('.touring_girls').remove();
}


var num = 4;


function readImage() {

  if (window.File && window.FileList && window.FileReader) {
  var files = event.target.files; //FileList object
  var output = $(".preview-images-zone");
  for (let i = 0; i < files.length; i++) {
  var file = files[i];
  if (!file.type.match('image')) continue;
  
  var picReader = new FileReader();
  
  picReader.addEventListener('load', function (event) {
  var picFile = event.target;
  
  if (formdata) {
    formdata.append("pro-image", file);
    formdata.append("_token", $('input[name="_token"]').val());
    console.log(formdata);
    $.ajax({
      url : imagePostURL,
      type: "POST",
      data : formdata,
      contentType: false,
      cache: false,
      processData:false,
      mimeType:"multipart/form-data"
    }).done(function(res){ //
      if(res != ""){
            var html =  '<div class="preview-image preview-show-' + num + '">' +
          '<div class="image-cancel" data-no="' + num + '">x</div>' +
          '<div class="image-zone"><img onclick="showImage('+num+')" id="pro-img-' + num + '" src="' + res + '"></div>' +
          '<div class="radio radio-info form-check-inlinesquarebox image-zone1"><input type="hidden" value="'+res+'" name="imageurl[]"> <input type="checkbox" name="available-women" id="pro-img1-' + num + '" class="css-checkbox"><label for="pro-img1-' + num + '" class="css-label">Set as main image</label></div>'
        '</div>';
        
        output.append(html);
        }
    });
  }
  
  num = num + 1;
  });
  picReader.readAsDataURL(file);
  }
  $("#pro-image").val('');
  } else {
  console.log('Browser not support');
  }
  }



$(document).ready(function(){
  $('.select_box').on('select2:select', function (e) {
   
    if($(this).val() != ""){
      $(this).next().find('.select2-selection--single').removeClass('error');
    }else{
      $(this).next().find('.select2-selection--single').addClass('error');
    }
    
  });
})

function showImage(id){
 
$original_image = $("#pro-img-"+id).attr('src');

  $('img#imagepreview').attr('src', $("#pro-img-"+id).attr('src')+"?random="+new Date().getTime()); // here asign the image to the modal when the user click the enlarge link
 // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
 $("#imagemodal").modal('show');
}
function getCity(id){
  if(id !== ""){
    $.ajax({
         headers: {
            'X-CSRF-TOKEN': $('input[name="_token"]').val()
          },
       type:"post",
       url:fetchcityURL,
       data:{country_id:id},
       success: function(data){
          $("#city_name").html(data);
       }
    });
    }
  
}

function getTourCity(id, countryid){
  if(id !== ""){
    $.ajax({
         headers: {
            'X-CSRF-TOKEN': $('input[name="_token"]').val()
          },
       type:"post",
       url:fetchcityURL,
       data:{country_id:id},
       success: function(data){
         var cityid = countryid.replace("tour_country", "tour_city");
          $("#"+cityid).html(data);
       }
    });
    }
  
}

class FireworkParticle {
  
  constructor( context, width, height, total ) {
    this.context = context;  
    this.width = width;
    this.height = height;
    this.total = total;
    this.done = 0;
    this.x = 0;
    this.xTo = 0;
    this.y = 0;
    this.yTo = 0;
    this.ease = 20;
    this.size = 300;
    this.hue = 0, 
    this.particles = [];
    this.reset(); 
  }
  
  between( min, max ) {
    return Math.random() * ( max - min + 1 ) + min;
  }
  
  complete() {
    return ( this.done >= this.total );
  }
  
  reset() {
    this.particles = [];
    this.x = this.between( 100, this.width - 100 );
    this.xTo = this.between( this.x + 100, this.x - 100 );
    this.y = this.height + 10;
    this.yTo = this.height / 2 - this.between( 0, 200 );
    this.ease = this.between( 12, 20 );
    this.hue = this.between( 100, 360 );
    this.done = 0;
  }
  
  explode() {
    this.particles = [];
    this.context.clearRect( 0, 0, this.width, this.height ); // flash 
    
    for ( let i = 0; i < this.total; i++ ) {
      this.particles.push( {
        x     : this.x,
        y     : this.y,
        xTo   : this.between( this.x - this.size, this.x + this.size ),
        yTo   : this.between( this.y - this.size, this.y + this.size ),
        size  : this.between( 1, 3 ),
        ease  : this.between( 8, 28 ),
        hue   : this.between( this.hue - 100, this.hue ),
        alpha : 1
      });
    }
  }
  
  update( width, height ) {
    this.width = width || this.width;
    this.height = height || this.height;
    this.x += ( this.xTo - this.x ) / this.ease;
    this.y += ( this.yTo - this.y ) / this.ease;
  }
  
  drawBomb() {
    this.context.beginPath();
    this.context.arc( this.x, this.y, 2, 0, 2 * Math.PI, false );
    this.context.fillStyle = `hsl( ${this.hue}, 100%, 60% )`;
    this.context.fill();
  }
  
  drawParticles() {
    for ( let i = 0; i < this.particles.length; i++ ) {
      const p = this.particles[ i ];

      if ( p.alpha >= 0 ) {
        this.context.beginPath();
        this.context.arc( p.x, p.y, p.size, 0, 2 * Math.PI, false );
        this.context.fillStyle = `hsla( ${p.hue}, 100%, 60%, ${p.alpha} )`;
        this.context.fill();

        p.x += ( p.xTo - p.x ) / p.ease;
        p.y += ( p.yTo - p.y ) / p.ease;
        p.alpha -= 0.014;
        continue;
      }
      this.particles.splice( i, 1 );
      this.done += 1;
    }
  }
  
  draw() {
    if ( this.complete() ) return;
    if ( this.y > this.yTo + 20 ) { this.drawBomb(); } 
    else if ( !this.particles.length ) { this.explode(); } 
    else { this.drawParticles(); } 
  }
}

