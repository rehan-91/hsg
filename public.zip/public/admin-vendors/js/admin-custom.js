/* Valid Image file formats */
var ValidImageTypes = ["image/gif", "image/jpeg", "image/png"];

/* Firing Image field selector on clicking button */
function fire_image_selector( img_selector, preview_selector, edit_container, master_image ){
	jQuery("#"+img_selector).val(null);
	jQuery("#"+img_selector).trigger("click");
	
	jQuery("#"+img_selector).change(function(){
		read_image_file(this, preview_selector);
		
		jQuery("#"+edit_container).css("display", "block");
		jQuery("#"+master_image).css("visibility", "hidden");
	});
}

function read_image_file(input, preview_selector){
	
	if (input.files && input.files[0] ) {
		if( jQuery.inArray(input.files[0].type, ValidImageTypes) < 0 ){
		}
		else{
			var reader = new FileReader();
		
			reader.onload = function (e) {
				jQuery('#'+preview_selector).attr('src', e.target.result);
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	
}

/* Change city and district based on state */
function update_state_based_listings(state_id, district_id){
	jQuery("#addr_district").html("<option value=''>Select Districts</option>");
	jQuery("#addr_sub_district").html("<option value=''>Select Sub District</option>");
	jQuery("#addr_block").html("<option value=''>Select Block</option>");
	jQuery.ajax({
		type: 'POST',
		dataType: "JSON",
		url: state_route,
		data: {
			'_token': access_token,
			'id': state_id
		},
		success: function(data) {
			if( parseInt(data.district_data.length) > 0 ){
				var district_option_list = generate_option_list(data.district_data, "Select Districts", district_id);
				
				jQuery("#addr_district").html(district_option_list);
			}
		},
	});
}

function update_district_based_listings(district_id, sub_district_id){
	jQuery("#addr_sub_district").html("<option value=''>Select Sub District</option>");
	jQuery("#addr_block").html("<option value=''>Select Block</option>");
	jQuery.ajax({
		type: 'POST',
		dataType: "JSON",
		url: district_route,
		data: {
			'_token': access_token,
			'id': district_id
		},
		success: function(data) {
			
			if( parseInt(data.sub_district_data.length) > 0 ){
				var sub_district_option_list = generate_option_list(data.sub_district_data, "Select Sub District", sub_district_id);
				
				jQuery("#addr_sub_district").html(sub_district_option_list);
			}
			
		},
	});
}

function update_subdistrict_based_listings(sub_district_id, block_id){
	jQuery("#addr_block").html("<option value=''>Select Block</option>");
	jQuery.ajax({
		type: 'POST',
		dataType: "JSON",
		url: subdistrict_route,
		data: {
			'_token': access_token,
			'id': sub_district_id
		},
		success: function(data) {
			
			if( parseInt(data.blocks_data.length) > 0 ){
				var blocks_option_list = generate_option_list(data.blocks_data, "Select Block", block_id);
				
				jQuery("#addr_block").html(blocks_option_list);
			}
		},
	});
}

function generate_option_list(list_array, tag_text, selected_option = ""){
	var list_content = '<option value="">'+tag_text+'</option>';
	for( var i = 0; i < list_array.length ; i++ ){
		var selected_content = '';
		if( parseInt(list_array[i].id) === parseInt(selected_option) ){
			selected_content = 'selected';
		}
		
		list_content += '<option value="'+list_array[i].id+'"  '+selected_content+' >'+list_array[i].name+'</option>';
	}
	
	return list_content;
}

/* Change city and district based on state */



/****************** ADMIN PERMISSIONS FUNCTIONALITY ENDS HERE *****************/

function submit_perms_all()
{
	if( jQuery("#check_all_perms").is(":checked") ){
		jQuery("#permissions .cbx").prop("checked", true);
	}
	else{
		jQuery("#permissions .cbx").prop("checked", false);
	}
}

function check_perm_sub_group(sub_cat)
{
	if( jQuery(".perm_master_"+sub_cat).is(":checked") ){
		jQuery(".perm_child_"+sub_cat).prop("checked", true);
	}
	else{
		jQuery(".perm_child_"+sub_cat).prop("checked", false);
	}
}

function check_perm_master_group(parent_perm, cat_perm){
	var cat_checked = 0;
	var total_perms = 0;
	jQuery(".perm_child_"+parent_perm).each(function(){
		if( jQuery(this).is(":checked") ){
			cat_checked++;
		}
		total_perms++;
	});

	if( parseInt(total_perms) == parseInt(cat_checked) ){
		jQuery(".perm_master_"+parent_perm).prop("checked", true);
	}
	else{
		jQuery(".perm_master_"+parent_perm).prop("checked", false);
	}
	
}

/****************** ADMIN PERMISSIONS FUNCTIONALITY ENDS HERE *****************/

function remove_user_image( image_container, img_id_element, edit_container, master_image ){
	jQuery("#"+image_container).attr("src", "");
	jQuery("#"+img_id_element).val("");
	jQuery("#"+edit_container).css("display", "none");
	jQuery("#"+master_image).css("visibility", "visible");
}

function show_success_container( success ){
	jQuery(".successMsg").find("p").html( success );
	jQuery(".successMsg").show();
	
	setTimeout(function(){
		jQuery(".successMsg").fadeOut('slow');
	}, 4000);
}

function show_error_container( error ){
	jQuery(".errorMsg").find("p").html( error );
	jQuery(".errorMsg").show();
	
	setTimeout(function(){
		jQuery(".errorMsg").fadeOut('slow');
	}, 4000);
}

function update_address_data( state_id, district_id, sub_district_id, block_id ){
	
	jQuery("#addr_district").html("<option value=''>Select Districts</option>");
	jQuery("#addr_sub_district").html("<option value=''>Select Sub District</option>");
	jQuery("#addr_block").html("<option value=''>Select Block</option>");
	if( parseInt( state_id ) > 0 ){
		
		jQuery.ajax({
			type: 'POST',
			dataType: "JSON",
			url: state_route,
			data: {
				'_token': access_token,
				'id': state_id
			},
			success: function(data) {
				if( parseInt(data.district_data.length) > 0 ){
					var district_option_list = generate_option_list(data.district_data, "Select Districts", district_id);
					
					jQuery("#addr_district").html(district_option_list);
				}
				
				if( parseInt( district_id ) > 0 ){
					jQuery.ajax({
						type: 'POST',
						dataType: "JSON",
						url: district_route,
						data: {
							'_token': access_token,
							'id': district_id
						},
						success: function(data) {
							
							if( parseInt(data.sub_district_data.length) > 0 ){
								var sub_district_option_list = generate_option_list(data.sub_district_data, "Select Sub District", sub_district_id);
								
								jQuery("#addr_sub_district").html(sub_district_option_list);
							}
							
							if( parseInt( sub_district_id ) > 0 ){
								jQuery.ajax({
									type: 'POST',
									dataType: "JSON",
									url: subdistrict_route,
									data: {
										'_token': access_token,
										'id': sub_district_id
									},
									success: function(data) {
										
										if( parseInt(data.blocks_data.length) > 0 ){
											var blocks_option_list = generate_option_list(data.blocks_data, "Select Block", block_id);
											
											jQuery("#addr_block").html(blocks_option_list);
										}
									},
								});
							}
						},
					});
				}
			},
		});
	}
}