<?php
/* Hindi Translations - per custom requirements */

return [
	'admin' => [
		/* Module Translations */
        'training_module_title' => 'मॉड्यूल जोड़ें',
        'training_module_topic_title' => 'मॉड्यूल',
        'training_module_topic_placeholder' => 'यहाँ मॉड्यूल जोड़े',
		
		/* Module Topic Translations */
        'training_content_title' => 'विषय जोड़ें',
        'training_content_module_heading' => 'मॉड्यूल',
        'training_content_topic_title' => 'विषय',
        'training_content_topic_placeholder' => 'यहाँ विषय जोड़ें',
        'training_content_video_title' => 'वीडियो',
        'training_content_content_title' => 'कॉन्टेंट',
        'training_content_content_placeholder' => 'अपना कॉन्टेंट यहाँ लिखे',
		
		/* Question Popup Form Translations */
		'question_heading' => 'सवाल जोड़ें',
		'question_title_fieldname' => 'सवाल',
		'question_title_placeholder' => 'अपना प्रश्न टाइप करें...',
		'question_options_fieldname' => 'विकल्प',
		'question_options_placeholder' => 'विकल्प',
		
    ],
	
	/* Frontend Translations */
	'frontend' => [
		/* Common Pages Translations - start */
		
		'logo_side_heading' => 'एजेंट बिजनेस कॉरसपॉन्डेंट <br>- प्रशिक्षण, प्रमाणीकरण और पंजीकरण' ,
		'menu' => [
			'dashboard' => 'डैशबोर्ड',
			'training' => 'प्रशिक्षण',
			'tests' => 'परीक्षा',
			'certificates' => 'प्रमाणपत्र',
			'help' => 'सहायता',
			'change_password' => 'पासवर्ड बदलें',
			'edit_profile' => 'प्रोफाइल एडिट करें',
			'logout' => 'लॉग आउट करें',
		],
		'time' => [
			'hrs' => 'घंटे',
			'mins' => 'मिनट',
			'sec' => 'सेकेंड',
		],
		
		/* Common Pages Translations - end */
	
		/* Login Page - Start */
        'login_page_title' => 'एजेंट बिजनेस कॉरसपॉन्डेंट - प्रशिक्षण, प्रमाणीकरण और पंजीकरण',
        'agent_login_heading' => 'एजेंट लॉग-इन',
        'cbc_login_heading' => 'सीबीसी लॉग-इन',
        'login_welcome_text' => 'एजेंट बिजनेस कॉरसपॉन्डेंट पोर्टल में आपका स्वागत है!',
        'login_step_text' => 'यह पोर्टल आपके प्रशिक्षण एवं प्रमाणीकरण के लिए है। ',
        'login_account_text' => 'अपने अकाउंट में लॉग-इन करें',
        'login_field_username' => 'यूज़रनेम',
        'login_field_password' => 'पासवर्ड',
        'login_field_rememberme' => 'मुझे याद रखें',
        'login_field_submit' => 'लॉग-इन करें',
		
		'rules' => [
			'email_required' => "अपना ईमेल आईडी डालें",
			'password_required' => "अपना पासवर्ड डालें",
			'credential_error' => "यह जानकारी आपके रिकॉर्ड से मेल नहीं खाती",
			'account_inactive_error' => "आपका अकाउंट अभी तक आपके सीबीसी द्वारा सक्रिय नहीं किया गया है। यदि यह 1 सप्ताह के भीतर सक्रिय नहीं होता है तो कृपया अपने सीबीसी से संपर्क करें।",
			'access_error' => "क्षमा करें, इस एप्लिकेशन का यह फीचर आपके लिए उपलब्ध नहीं है",
			
			/* new */
			'email_valid' => "कृपया अपनी वैध ईमेल आईडी डालें",
			'email_min' => 'ईमेल का पता कम से कम 4 अक्षर लंबा होना चाहिए।',
			'email_max' => 'ईमेल का पता 255 से अधिक वर्णों से अधिक नहीं होना चाहिए।',
			/* new */
		],
		/* new */
		/* pending */
		'login_resend_link' => 'सत्यापन कोड पुनः भेजें',
		'login_forgot_link' => 'पासवर्ड भूल गए',
		'login_register_link' => 'पंजीकरण करें',
		'back_to_login' => 'लॉगिन पर वापस जाएं',
		'logout_msg' => 'लॉगआउट सफल',
		'login_verify_email_error' => 'पहले अपने ईमेल एड्रेस को सत्यापित करें',
		
		'resend_verification_title' => 'सत्यापन कोड दोबारा भेजें',
		'resend_submit_btn' => 'कोड दोबारा भेजें',
		'resend_error_verified' => "डाला गया ईमेल सत्यापित किया जा चुका है",
		'resend_email_not_found' => "ईमेल एड्रेस नहीं मिला",
		'resend_success_msg' => "सत्यापन कोड ईमेल एड्रेस पर भेज दिया गया है",
		
		'forgot_password_title' => 'पासवर्ड भूल गए',
		'forgot_password_submit_btn' => 'पासवर्ड रीसेट करें',
		'forgot_password_success_msg' => "पासवर्ड रीसेट हो चुका है और आपकी रजिस्टर्ड आईडी पर भेजा जा चुका है",
		/* pending */
		/* new */
		/* Login Page - End */
		
		/* Dashboard Page - Start */
		
		'video_seen_quote' => ':total_count: में से :view_count: वीडियो देखे गए',
		'test_attempt_quote' => ':allowed_attempts: में से :attempts_done: :test_name: के लिए प्रयास किये गये',
		'test_passed_quote' => ':total_tests: में से :passed_tests: परीक्षा उत्तीर्ण की गई',
		'session_completed_quote' => ':total_count: में से :view_count: <br> सेशन पूरे हुए',
		'available_training' => 'उपलब्ध प्रशिक्षण',
		'avail_trng_quote' => 'यह प्रशिक्षण सामग्री आपके लिए उपलब्ध है',
		'modules' => 'मॉड्यूल',
		'sessions' => 'सेशन',
		'minutes' => 'मिनट',
		'start_training' => 'प्रशिक्षण शुरु करें',
		'resume_training' => 'प्रशिक्षण जारी रखें',
		
		'certification_tests' => 'प्रमाणनीकरण परीक्षाएं',
		'certification_tests_quote' => 'इन परीक्षाओं के लिए प्रयास करें',
		'attempts' => 'प्रयास',
		'questions' => 'प्रश्न',
		'correct_answer' => 'सही उत्तर',
		'scored' => 'प्राप्त अंक',
		'passed' => 'उत्तीर्ण हुए',
		'failed' => 'अनुत्तीर्ण हुए',
		'start_now' => 'शुरु करें',
		'try_again' => 'दोबारा प्रयास करें',
		'remaining_attempts' => ':total_attempts: में से :pending_attempt: परीक्षण प्रयास शेष',
		'certificate_download' => 'प्रमाणपत्र डाउनलोड करें',
		
		/* Dashboard Page - End */
		
		
		/* Course Page - Start */
		
		'training_level' => 'Select Training Level', //not in use
		'resume_from' => 'ट्रेनिंग यहाँ से शुरू होगी',
		'select_module' => 'मॉड्यूल चुनें',
		'select_module_quote' => ':course_name: में :module_count: मॉड्यूल हैं',
		'viewed_time' => ':view_count: बार देखा गया',
		'training_complete' => 'आपने :training_name: पूरा कर लिया है',

		/* Course Page - End */
		
		
		/* Help Page - Start */
		
		'cbc_contact' => 'सीबीसी संपर्क विवरण',
		'form_heading' => 'कृपया अपनी प्रतिक्रिया दें',
		'form_sub_heading' => 'कृपया हमें एक संदेश भेजें और हम जल्द से जल्द उसका जवाब देंगे',
		
		
		'form_name_title' => 'पूरा नाम',
		'form_name_placeholder' => 'पूरा नाम',
		'form_message_title' => 'संदेश',
		'form_message_placeholder' => 'संदेश',
		'form_email_title' => 'कार्य ईमेल',
		'form_email_placeholder' => 'कार्य ईमेल',
		'form_submit' => 'जमा करें',
		'help_form_mail_success' => 'मेल सफलतापूर्वक भेजा गया',
		
		'help_form_rules' => [
			'name_required' => "कृपया अपना नाम डालें",
			'name_min' => "कृपया एक वैध नाम डालें",
			'email_required' => "कृपया अपनी ईमेल आईडी डालें",
			'email_valid' => "कृपया अपनी वैध ईमेल आईडी डालें",
			'message_required' => "कृपया अपना संदेश डालें",
			'message_min' => "संदेश कम से कम 3 अक्षर में होना चाहिए",
			'receiver_required' => "Atleast 1 Receiver has to be Selected.",//not is use
		],
		
		'faq_title' => 'अक्सर पूछे जाने वाले प्रश्न',
		'faq_content_title' => [ 'परीक्षाओं के लिए कितना समय दिया जाएगा?', '(बुनियादी तथा उच्च) परीक्षाओं में कितने प्रश्न पूछे जाएंगे?', 'अगर मैंने 5 प्रयासों में भी परीक्षाएं उत्तीर्ण नहीं की तो क्या होगा?', 'एजेंसी व्यवसाय चलाने के लिए क्या यह प्रमाणीकरण अनिवार्य या एक पूर्व निर्धारित आवश्यकता है?', 'इन परीक्षाओं के लिए पर्यवेक्षक कौन होगा?', 'पोर्टल में किसी प्रकार की तकनीकी समस्या आने पर मुझे किससे संपर्क करना होगा? ', 'अगर मुझे परीक्षा के दौरान तकनीकी समस्याएं पेश आती हैं और इस कारण समय का नुकसान होता है, तो क्या इसे एक असफल प्रयास माना जाएगा?', 'अगर मैंने गलत सीबीसी के साथ अपना पंजीकरण पूरा कर लिया है तो मुझे क्या करना चाहिए?' ],
		'faq_content_answers' => [ 'बुनियादी तथा उच्च परीक्षा में प्रत्येक के लिए दो घंटे का समय दिया जाएगा।', 'बुनियादी तथा उच्च परीक्षा दोनों में प्रत्येक के लिए 50 प्रश्न होंगे।', 'अगर एजेंट/बैंक मित्र 5 प्रयासों में परीक्षाओं को उत्तीर्ण नहीं कर पाता/पाती है, तो पोर्टल पर उसकी एजेंट आईडी बंद/ब्लॉक कर दी जाएगी। ऐसा होने पर एजेंट को दोबारा परीक्षा देने के लिए अपने सीबीसी/ कॉर्पोरेट बिज़नेस कोरेस्पोंडेंट से संपर्क करना होगा। ', 'हां, यह प्रमाणीकरण अनिवार्य हैं और सभी एजेंट को अपनी गतिविधियों का संचालन जारी रखने के लिए यह प्रामाणीकरण प्राप्त करना आवश्यक है।', 'एक अधिकृत व्यक्ति इनका पर्यवेक्षक बनेगा और उसके द्वारा पोर्टल में लॉग-इन करने के बाद ही एजेंट अपनी बुनियादी तथा उच्च प्रमाणीकरण परीक्षाएं शुरु कर सकेंगे। ऑनलाइन होने के बावजूद दोनों ही परीक्षाओं की निगरानी की जाएगी।', 'कृपया अपने सीबीसी/ कॉर्पोरेट बिज़नेस कोरेस्पोंडेंट पर्यवेक्षक या व्यवस्थापक से संपर्क करें।', 'नहीं, ऐसी स्थिति में, एजेंट को पर्यवेक्षक से संपर्क करना होगा। फिर पर्यवेक्षक एजेंट की मदद करेंगे और यह सुनिश्चित करेंगे कि इससे परीक्षार्थी को मिलने वाले प्रयासों की कुल संख्या में कोई नुकसान ना उठाना पड़े।', 'सहायता अनुभाग के माध्यम से एक संदेश भेजकर बीसीएफआई को सूचित करें।' ],
		
		/* Help Page - End */
		
		
		/* Change Password Page - Start */
		'changep_title' => "पासवर्ड बदलें", //not sent
		'password_field' => "पुराना पासवर्ड", //not sent
		'password_field_placeholder' => "पासवर्ड", //not sent
		'new_password_field' => "नया पासवर्ड", //not sent
		'new_password_field_placeholder' => "नया पासवर्ड", //not sent
		'confirm_password_field' => "नए पासवर्ड की पुष्टि करें", //not sent
		'confirm_password_field_placeholder' => "नए पासवर्ड की पुष्टि करें", //not sent
		'change_password_success' => "पासवर्ड सफलतापूर्वक अपडेट किया गया", //not sent
		
		'cpassword_rules' => [ //not sent
			'old_p_required' => "अपना वर्तमान पासवर्ड डालें",
			'old_p_min' => "वर्तमान पासवर्ड कम से कम 6 अक्षरों का होना चाहिए",
			'new_p_required' => "कृपया अपना नया पासवर्ड डालें",
			'new_p_min' => "नया पासवर्ड कम से कम 6 अक्षरों का होना चाहिए",
			'conf_p_required' => "कृपया पुष्टि किया गया पासवर्ड डालें",
			'conf_p_min' => "पुष्टि किया गया पासवर्ड कम से कम 6 अक्षरों का होना चाहिए",
			'conf_p_same' => "पुष्टि किया गया पासवर्ड एक जैसा होना चाहिए",
			'password_incorrect' => "कृपया सही पासवर्ड डालें",
			
			/* new */
			'same_password_error' => "क्षमा करें, आपने अपना वर्तमान पासवर्ड डाला है",
			/* new */
		],
		/* Change Password Page - End */
		
		/* Test Page - Start */
		/* new */
		/* test List - start */
		'test_attempt_log' => 'प्रयास लॉग्स',
		'test_attempt_description' => 'इस परीक्षा के लिए यह आपका अगला प्रयास है',
		'test_log_time' => 'समय (मिनट)',
		'test_submission_error' => 'प्रश्न के लिए कृपया विकल्पों को चुनें',
		/* test List - end */
		
		'attempt_exam_clear_error' => 'क्षमा करें, आप यह परीक्षा पूरी कर चुके हैं', 
		/* new */
		
		'attempt_error_heading' => 'त्रुटि',
		'attempt_error_content' => 'आपके प्रयासों की अवधि समाप्त हो चुकी है। कृपया अपने सीबीसी से संपर्क करें',
		'invigilator_as' => 'निरीक्षक<br>',
		'invigilated_by' => 'पर्यवेक्षक',
		'appearing_as' => 'एजेंट<br>',
		'current_test' => 'वर्तमान परीक्षा',
		'start_test' => 'परीक्षा शुरु करें',
		'que_in_test' => 'इस परीक्षा<br>में प्रश्न',
		'min_in_test' => 'मिनट<br>परीक्षा',
		'total_attempts' => 'कुल<br>प्रयास किये गये',
		'question_attempted'=>'प्रश्न<br> प्रयास किये गये',
		'min_rem'=>'मिनट<br> शेष',
		'invigilator_login_account_text'=> 'निरीक्षक के रूप में लॉगिन करें',
		'proceed_btn_heading'=>'आगे बढ़ने के लिए नीचे दिये गये बटन पर क्लिक करें',
		'proceed_btn_text'=>'आगे बढ़ें',
		'Q_numbering'=>'प्रश्न क्रमांक',
		'multiple_question'=>'एक से अधिक उत्तर चुने जा सकते हैं',
		'prev_btn_text'=>'पिछला',
		'next_btn_text'=>'अगला',
		'skip_btn_text'=>'अगले पर जाएं',
		'jump_btn_text'=>'सीधे पहुंचे',
		'skipped_que_text'=>'छोड़े हुए प्रश्न',
		'submit_btn_text'=>'जमा करें',
		'review_answers'=>'अपने उत्तरों की समीक्षा के लिए समीक्षा बटन पर क्लिक करें',
		'submit_test'=>'अपनी परीक्षा जमा करने के लिए सबमिट बटन पर क्लिक करें',
		'exam_text'=>'परीक्षा',
		'reviewtext' =>'समीक्षा',
		'ortext' =>'या',
		'submit_btn'=> 'जमा करें',
		'proceed_text' => 'आगे बढ़ें',
		'resume_test' =>'परीक्षा जारी रखें',
		'proceed_upper_heading'=>'आगे बढ़ने के लिए नीचे दिये बटन पर क्लिक करें',
		'question_jump_text'=>'प्रश्न',
		'unauthorized_test_attempt' => 'आप "प्रारंभिक" प्रमाणन परीक्षा उत्तीर्ण करने के बाद ही "उच्च श्रेणी" प्रमाणन परीक्षा दे सकते हैं',
		
		
		/* Test Thanks Page */
		'cbc_notify_text'=>'सीबीसी द्वारा आपका प्रमाणपत्र डाउनलोड के लिए उपलब्ध कराए जाने के बाद आपको सूचित कर दिया जाएगा.',
		'certificate_download_text'=>'कृपया अपना प्रमाणपत्र डाउनलोड करें',
		'spent_time_text'=>'खर्च हुआ समय',
		'congrate_text'=>'शुभकामनाएं',
		'cert_eligible_text'=>'आप डाउनलोड सर्टिफिकेट बटन से अपना प्रमाणपत्र डाउनलोड कर सकते हैं',
		'test_pass_text'=>'आपने हमारी परीक्षा आसानी से उत्तीर्ण कर ली है और हमारे सामने यह साबित कर दिया है कि आप हमेशा सिर्फ बड़ी बातें नहीं करते बल्कि जो कहते हैं उसे पूरा भी कर सकते हैं। आप वास्तव में काम के व्यक्ति हैं। इस कड़ी मेहनत को जारी रखें और इससे अधिक बेहतर करने का प्रयास करें।',
		'test_succ_text'=>'आपसे सफलतापूर्वक उत्तीर्ण कर लिया है',
		
		'test_fail_heading'=>'क्षमा करें, आप असफल हो गए हैं',
		'test_fail_message'=>'लेकिन यह आपके लिए अंत नहीं है, हमारा मानना है कि अगली बार आप बेहतर कर सकते हैं। बस आप दोबारा से प्रशिक्षण पाठ्यक्रम का अध्ययन करें। जब आपको खुद पर विश्वास हो जाए, तो आप दोबारा यह परीक्षा दे सकते हैं।',
		'test_fail_link'=>'यहां क्लिक करें',
		'test_fail_link_msg'=>'प्रशिक्षण पाठ्यक्रम में जाने के लिए',
		/* Test Thanks Page */
		
		/* Test Page - End */
		
		/* Certificate Page - start */
		/* new */
		'certificates' => 'प्रमाणपत्र',
		'certificates_tagline' => 'आपके लिए निम्न प्रमाणपत्र उपलब्ध हैं',
		'certificate_not_available' => 'परीक्षा उत्तीर्ण करने के उपरांत आपके प्रमाणपत्र यहाँ उपलब्ध होंगे',
		'issued_date' => 'जारी करने की तिथि',
		'valid_upto_date' => 'वैधता तिथि',
		'cert_pass_text' => ':date: के <strong class="blue">:percentage:%</strong> अंक',
		'download_btn' => 'डाउनलोड करें',
		'certificate_expire_msg' => 'प्रमाणपत्र की अवधि समाप्त हो चुकी है। कृपया अपने प्रमाणपत्र के नवीनीकरण हेतु अपने सीबीसी से आग्रह करें।',
		'certificate_issuance_msg' => 'प्रमाणपत्र जारी करने की तिथि :issued_date:, वैधता तिथि :expiry_date:.',
		'certificate_renewal_msg' => 'प्रमाणपत्र नवीनीकरण तिथि :issued_date:, वैधता तिथि :expiry_date:.',
		/* new */
		/* Certificate Page - end */
		
		/* Email Verification - start */
		'invalid_code' => 'अवैध सत्यापन कोड',
		'invalid_error_msg' => 'क्षमा करें, लगता है आपने ईमेल सत्यापन के लिए एक गलत सत्यापन कोड का प्रयोग किया है',
		'back_to_dashboard' => 'डैशबोर्ड पर वापस जाएं',
		'email_updation' => 'ईमेल सफलतापूर्वक अपडेट किया गया',
		'email_updation_msg' => 'बधाई हो, आपका ईमेल सफलतापूर्वक अपडेट हो चुका है। लॉग-इन पेज पर जाएं और सिस्टम में लॉग-इन करें',
		'email_verified' => 'ईमेल सफलतापूर्वक सत्यापित किया गया',
		'email_verified_msg' => 'बधाई हो, आपका ईमेल सफलतापूर्वक सत्यापित हो चुका है। लॉग-इन पेज पर जाएं और सिस्टम में लॉग-इन करें',
		
		/* Email Verification - end */
		
		/* Register Success - start */
		
		'register_success_title' => 'साइन अप करने के लिए धन्यवाद!',
		'register_success_profile_msg' => 'आपकी प्रोफ़ाइल <strong>:association_name:</strong> को भेजी गई है।',
		'register_success_msg' => 'एक्टिवेशन लिंक (जो आपको ईमेल पर भेजा गया है) पर क्लिक करके कृपया अपना ई-मेल सत्यापित करें।  ई-मेल के सफल सत्यापन और सीबीसी द्वारा पुष्टि के बाद आप अपना अकाउंट इस्तेमाल कर सकते है।',
		'start_journey' => 'अपनी यात्रा शुरु करें',
		
		/* Register Success - end */
		
		/* 24-jul */
		/* Footer - start */
		'rights_reserved' => '&copy; <i>MicroSave</i> <b>'.date('Y').'</b>. All rights reserved.',
		'developed_with_by' => 'Developed by',
		
		/* Footer - end */
		
		/* Verify OTP - start */
		'otp_verify_title' => 'ओटीपी सफलतापूर्वक भेजा गया। 30 मिनट के लिए मान्य',
		'otp_enter_code' => 'OTP कोड डालें',
		'didnt_receive' => 'OTP प्राप्त नहीं हुआ?',
		'resend_code' => 'दोबारा कोड भेजें',
		'otp_verify' => 'VERIFY',
		'otp_session_expired' => 'OTP सेशन की अवधि समाप्त हुई। कृपया दोबारा कोशिश करें',
		'otp_resend_success' => 'OTP सफलतापूर्वक भेजा गया',
		'otp_mobile_updated' => 'आपका मोबाइल OTP सफलतापूर्वक अपडेट किया जा चुका है।',
		
		/* Verify OTP - end */
		
		
		/* Registration - start */
		
		'registration_title' => 'एजेंट पंजीकरण',
		'edit_profile_title' => 'अपना प्रोफाइल एडिट करें',
		'registration_basic' => 'सामान्य विवरण',
		'registration_basic_desp' => 'कृपया नीचे अपना सामान्य विवरण भरें, जैसे नाम, प्रोफाइल चित्र, आउटलेट का चित्र और ईमेल पता एवं अन्य निजी विवरण।',
		'first_name_placeholder' => 'पहला/मध्य नाम दर्ज करें',
		'last_name_placeholder' => 'अंतिम नाम डालें',
		'agent_email_placeholder' => 'ईमेल पता डालें',
		'agent_contact_number_placeholder' => 'फोन नंबर डालें',
		'education_qualification_placeholder' => 'शैक्षणिक योग्यता चुनें',
		'upload_title' => 'अपना प्रोफाइल एवं आउटलेट का चित्र अपलोड करें',
		'upload_desp' => 'कृपया 5 एमबी तक आकार की .jpg या .png फ़ाइल अपलोड करें',
		'add_profile_img' => 'प्रोफाइल चित्र जोड़ें',
		'add_store_img' => 'एजेंट आउटलेट का चित्र जोड़ें',
		'advanced_title' => 'अधिक जानकारी',
		'associated_user_placeholder' => 'कृपया सीबीसी चुनें',
		'services_placeholder' => 'सेवाएं',
		'identity_title' => 'पहचान दस्तावेज़',
		'pan_card_placeholder' => 'पैन कार्ड संख्या डालें',
		'driving_license_placeholder' => 'ड्राइविंग लाइसेंस संख्या डालें',
		'dob_placeholder' => 'पैन प्रदर्शित जन्मतिथि',
		'cibil_score_placeholder' => 'सिबिल स्कोर डालें',
		'contact_title' => 'संपर्क विवरण',
		'contact_desp' => 'कृपया नीचे अपना संपर्क विवरण डालें, जैसे राज्य, जिला, उप-जिला, ब्लॉक, पिन कोड एवं अन्य जानकारी',
		'state_placeholder' => 'राज्य / संघ राज्य चुनें',
		'district_placeholder' => 'जिला चुनें',
		'sub_district_placeholder' => 'ब्लॉक / उप- जिले का चयन करें',
		'block_placeholder' => 'गांव / शहर का चयन करें',
		'street_name_placeholder' => 'पता डालें',
		'pincode_placeholder' => 'पिन कोड डालें',
		'latitude_placeholder' => 'अक्षांस डालें',
		'longitude_placeholder' => 'देशान्तर डालें',
		
		
		
		
		'first_name_required' => 'कृपया पहला/मध्य नाम डालें',
		'agent_email_required' => 'कृपया अंतिम नाम डालें',
		'agent_contact_number_required' => 'कृपया संपर्क नंबर डालें',
		'agent_contact_number_digits' => 'कृपया एक 10 अंकों वाला वैध फोन नंबर डालें',
		'education_qualification_required' => 'कृपया अपनी शैक्षणिक योग्यता चुनें',
		'profile_img_required' => 'कृपया प्रोफाइल चित्र अपलोड करें',
		'profile_store_image' => 'कृपया सिर्फ चित्र ही अपलोड करें',
		'secondary_img_required' => 'कृपया एजेंट आउटलेट का चित्र अपलोड करें',
		'services_required' => 'कृपया कम से कम एक सेवा चुनें',
		'pan_card_required' => 'कृपया पैन कार्ड संख्या डालें',
		'kyc_required' => 'दोनों में एक ही क्षेत्र भरने की आवश्यकता है।',
		'dob_required' => 'पैन कार्ड में प्रदर्शित जन्म तिथि का चयन करें',
		'cibil_score_digits_between' => 'कृपया 0 से 1000 के बीच एक संख्या डालें',
		'addr_state_required' => 'कृपया राज्य / संघ राज्य का चयन करें',
		'addr_district_required' => 'कृपया जिला चुनें.',
		'addr_sub_district_required' => 'कृपया ब्लॉक / उप- जिले चुनें',
		'addr_block_required' => 'कृपया गांव / शहर चुनें',
		'street_name_required' => 'कृपया पता डालें',
		'addr_pincode_required' => 'कृपया पिन कोड डालें',
		'addr_pincode_digits' => 'कृपया अपना  छह अंको का पिन कोड दर्ज करें (0-9)',
		'addr_latitude_regex' => '-90 से 90 के बीच अक्षांस डालें',
		'addr_latitude_max' => 'अधिकतम 9 अक्षर लंबा विवरण डाला जा सकता है',
		'addr_latitude_required_with' => 'कृपया अक्षांस भी डालें',
		'addr_longitude_max' => 'अधिकतम 9 अक्षर लंबा विवरण डाला जा सकता है',
		'addr_longitude_regex' => '-180 से 180 के बीच देशान्तर डालें',
		'addr_longitude_required_with' => 'कृपया देशान्तर भी डालें',
		
		
		'profile_update_request' => 'प्रोफाइल अपडेट करने का आग्रह सफलतापूर्वक भेजा गया',
		'pending_attempt_count' => 'शेष बचे प्रयास',
		
		/* Registration - end */
		
		'activation_message_email' => 'एक्टिवेशन लिंक इस ईमेल पर भेजा जायेगा',
		'activation_message_contact' => 'ओटीपी इस मोबाइल नंबर पर भेजा जाएगा',
		'voter_id_placeholder' => 'मतदाता आईडी दर्ज करें',
		
		'otp_required_error' => 'कृपया मोबाइल ओटीपी दर्ज करें।',
		'otp_digits_error' => 'कृपया अपना चार अंको का ओटीपी दर्ज करें',
		'otp_min_error' => 'न्यूनतम 4 अंकों का कोड आवश्यक है।',
		'otp_max_error' => 'अधिकतम 4 अंकों का कोड आवश्यक है।',
		'wrong_otp' => 'गलत ओटीपी दर्ज किया गया है।',
		'otp_expired' => 'आपका ओटीपी समाप्त हो गया है! कृपया एक नया ओटीपी उत्पन्न करें।',
		
		'first_name_min' => 'पहले/मध्य नाम में कम से कम 3 अक्षर होना चाहिए।',
		'first_name_max' => 'पहला/मध्य नाम 100 वर्णों से अधिक नहीं होना चाहिए।',
		'last_name_max' => 'अंतिम नाम 100 वर्णों से अधिक नहीं होना चाहिए।',
		'agent_email_email' => 'कृपया वैध ईमेल आईडी दर्ज करें।',
		'agent_email_min' => 'ईमेल आईडी में कम से कम 3 अक्षर होना चाहिए।',
		'agent_email_max' => 'ईमेल आईडी 255 वर्णों से अधिक नहीं होना चाहिए।',
		'agent_email_unique' => 'ईमेल आईडी पहले से ही इस्तेमाल किया जा चुका है।',
		'agent_contact_number_unique' => 'संपर्क संख्या का उपयोग पहले से ही किया जा चुका है।',
		'profile_store_mimes_image' => 'केवल जेपीजी और पीएनजी छवियों की अनुमति है।',
		'pan_card_min' => 'पैन कार्ड में 10 अक्षर होना चाहिए।',
		'pan_card_max' => 'पैन कार्ड में 10 अक्षर होना चाहिए।',
		'pan_card_regex' => 'कृपया मान्य पैन कार्ड नंबर दर्ज करें।',
		'pan_card_unique' => 'पैन कार्ड का पहले ही इस्तेमाल किया जा चुका है।',
		'driving_valid' => 'कृपया वैध ड्राइविंग लाइसेंस नंबर दर्ज करें।',
		'voter_id_valid' => 'कृपया वैध मतदाता आईडी संख्या दर्ज करें।',
		'dob_date_format' => 'जन्म प्रारूप की तारीख DD/MM/YYYY में होनी चाहिए।',
		'street_name_max' => 'सड़क का नाम 255 वर्णों से अधिक नहीं होना चाहिए।',
		'street_name_min' => 'सड़क के नाम में कम से कम 3 अक्षर होना चाहिए।',
		
		
		'otp_agent_loggedout' => 'क्षमा करें, एजेंट हमारे सिस्टम में लॉग इन नहीं है।',
		
		'profile_sizemax' => 'एजेंट का चित्र 5 एमबी से अधिक नहीं हो सकता।',
		'store_sizemax' => 'एजेंट आउटलेट का चित्र 5 एमबी से अधिक नहीं हो सकता।',
		
		'name_characters_only' => 'केवल अक्षर दर्ज करें',
		
		
		'gender_placeholder' => 'अपना लिंग चुनें',
		'gender_option_male' => 'पुरुष',
		'gender_option_female' => 'महिला',
		'gender_option_other' => 'अन्य लोग',
		'gender_required' => 'कृपया अपना लिंग चुनें',
		
		'field_not_compulsory' => '# अनिवार्य नहीं',
		
		'email_btn' => 'ईमेल',
		'print_btn' => 'प्रिंट',
    ],
];
