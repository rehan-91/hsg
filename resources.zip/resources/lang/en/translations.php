<?php
/* English Translations - per custom requirements */

return [
	'admin' => [
		/* Module Translations */
        'training_module_title' => 'Add Modules',
        'training_module_topic_title' => 'Modules',
        'training_module_topic_placeholder' => 'Add Module here',
		
		/* Module Topic Translations */
        'training_content_title' => 'Add Topic',
        'training_content_module_heading' => 'Module',
        'training_content_topic_title' => 'Topic',
        'training_content_topic_placeholder' => 'Add Topic here',
        'training_content_video_title' => 'Video',
        'training_content_content_title' => 'Content',
        'training_content_content_placeholder' => 'Type Your content here',
		
		/* Question Popup Form Translations */
		'question_heading' => 'Add Question',
		'question_title_fieldname' => 'Question',
		'question_title_placeholder' => 'Type your Question...',
		'question_options_fieldname' => 'Options',
		'question_options_placeholder' => 'Option',
		
    ],
	
	/* Frontend Translations */
	'frontend' => [
		/* Common Pages Translations - start */
		
		'logo_side_heading' => 'Agent Business Correspondent <br>- Training, Certification & Registration',
		'menu' => [
			'dashboard' => 'Dashboard',
			'training' => 'Training',
			'tests' => 'Tests',
			'certificates' => 'Certificates',
			'help' => 'Help',
			'change_password' => 'Change Password',
			'edit_profile' => 'Edit Profile',
			'logout' => 'Logout',
		],
		'time' => [
			'hrs' => 'Hours',
			'mins' => 'Minutes',
			'sec' => 'Seconds',
		],
		
		/* Common Pages Translations - end */
	
		/* Login Page - Start */
        'login_page_title' => 'Agent Business Correspondent - Training & Certification',
        'agent_login_heading' => 'Agent Login',
        'cbc_login_heading' => 'CBC Login',
        'login_welcome_text' => 'Welcome to Agent Business Correspondent Portal!',
        'login_step_text' => 'This is your portal for training and certification.',
        'login_account_text' => 'Login to your account',
        'login_field_username' => 'Username',
        'login_field_password' => 'Password',
        'login_field_rememberme' => 'Remember Me',
        'login_field_submit' => 'Log in',
		
		'rules' => [
			'email_required' => "Please Enter your Email Id.",
			'password_required' => "Please Enter your Password.",
			'credential_error' => "These credentials do not match our records.",
			'account_inactive_error' => "Your account is not active yet. Please Contact to Admin For Change",
			'access_error' => "Sorry, You don't have access to this feature of the application.",
			
			/* new */
			'email_valid' => "Please enter your Valid Email ID",
			'email_min' => 'Email Address should be atleast 4 Characters Long.',
			'email_max' => 'Email Address shouldn\'t exceed more than 255 Characters.',
			/* new */
		],
		/* new */
		/* pending */
		'login_resend_link' => 'Resend Verification Code',
		'login_forgot_link' => 'Forgot Password',
		'login_register_link' => 'Register Now',
		'back_to_login' => 'Back to Login',
		'logout_msg' => 'Logout Successfull',
		'login_verify_email_error' => 'Please Verify Your Email Address first.',
		
		'resend_verification_title' => 'Resend Verification Code',
		'resend_submit_btn' => 'Resend Code',
		'resend_error_verified' => "Entered Email is already Verified",
		'resend_email_not_found' => "Email Address not found.",
		'resend_success_msg' => "Verification code has been sent to Email Address.",
		//forgot_passwords messages..
		'forgot_passwords'=>[
		'forgot_password_title' => 'Forgot Password',
		'forgot_password_submit_btn' => 'Reset Password',
		'forgot_password_success_msg' => "Password has been Reset and sent to your registered Id.",
		'resend_email_not_found'=>"Email Not Found, or your account is not active yet. Contact Admin to activate your account.",
		
		],
		'success_fp_mail'=>[
		'forgot_password_mail_send'=>"Email has been send",
		],
		/* pending */
		/* new */
		/* Login Page - End */
		
		/* Dashboard Page - Start */
		
		'video_seen_quote' => ':view_count: of :total_count: Videos Seen',
		'test_attempt_quote' => ':attempts_done: out of :allowed_attempts: :test_name: Attempted',
		'test_passed_quote' => ':passed_tests: out of :total_tests: Tests Passed', // not in use
		'session_completed_quote' => ':view_count: out of :total_count: <br> Sessions completed',
		'available_training' => 'Available Trainings',
		'avail_trng_quote' => 'Following training content is available to you',
		'modules' => 'Modules',
		'sessions' => 'Sessions',
		'minutes' => 'Minutes',
		'start_training' => 'Start Training',
		'resume_training' => 'Resume Training',
		
		'certification_tests' => 'Certification Tests',
		'certification_tests_quote' => 'Please attempt the following tests',
		'attempts' => 'Attempts',
		'questions' => 'Questions',
		'correct_answer' => 'Correct Answers',
		'scored' => 'Scored',
		'passed' => 'Passed',
		'failed' => 'Failed',
		'start_now' => 'Start Now',
		'try_again' => 'Try Again',
		'remaining_attempts' => ':pending_attempt: test attempts remaining out of :total_attempts:',
		'certificate_download' => 'Download Certificate',
		
		/* Dashboard Page - End */
		
		
		/* Course Page - Start */
		
		'training_level' => 'Select Training Level', //not in use
		'resume_from' => 'It will resume from',
		'select_module' => 'Select Module',
		'select_module_quote' => 'There are :module_count: modules in :course_name:',
		'viewed_time' => 'Viewed :view_count: times',
		'training_complete' => 'You have completed your :training_name:', //not sent
		
		/* Course Page - End */
		
		
		/* Help Page - Start */
		
		'cbc_contact' => 'CBC Contact Details',
		'form_heading' => 'Please provide your feedback',
		'form_sub_heading' => 'Please send us a message and we’ll respond as soon as possible.',
		
		
		'form_name_title' => 'Full Name',
		'form_name_placeholder' => 'Full Name',
		'form_message_title' => 'Message', //not sent
		'form_message_placeholder' => 'Message', //not sent
		'form_email_title' => 'Work Email',
		'form_email_placeholder' => 'Work Email',
		'form_submit' => 'Submit',
		'help_form_mail_success' => 'Mail Sent Successfully.', //not sent
		
		'help_form_rules' => [
			'name_required' => "Please enter your Name.",
			'name_min' => "Please enter Valid Name.",
			'email_required' => "Please enter your Email ID",
			'email_valid' => "Please enter your Valid Email ID",
			'message_required' => "Please Enter your Message.", //not sent
			'message_min' => "Message must be at least 3 characters.", //not sent
			'receiver_required' => "Atleast 1 Receiver has to be Selected.", //not in use
		],
		
		'faq_title' => 'Frequently Asked Questions (FAQs)',
		'faq_content_title' => [ 'What will be the duration of the tests?', 'How many questions will be asked in the tests (Basic and Advanced)?', 'What happens if I don’t clear the test in 5 attempts?', 'Are the certifications mandatory or are they a pre-requisite in order for me to run the agency business?', 'Who will be the invigilator?', 'Who do I contact in case of any technical issues on the portal?', 'If I face technical issues during the test and this results in loss of time, will that be considered as an unsuccessful attempt?', 'What should I do in case I have registered with a wrong CBC?' ],
		'faq_content_answers' => [ 'Two hours each for both the Basic and the Advanced tests.', 'There will be 50 questions each in both the Basic and the Advanced tests.', 'In case the Agent business correspondent is not able to clear the tests in 5 attempts, his/her agent ID on the portal will be deactivated/blocked. In this case, the Agent business correspondent will need to contact their CBC and re-take the tests.', 'Yes, these certifications are mandated and all the agents MUST earn these certifications in order to continue operating as Agent business correspondent', 'An authorized person will be invigilator and will be required to login to enable Agent business correspondent to commence the basic or advanced certification tests. Both these tests are supervised, although they are online.', 'Please contact your CBC supervisor or manager.', 'No. In such a scenario, the Agent business correspondent will need to contact the invigilator. The invigilator will assist the Agent business correspondent and ensure that this doesn’t lead to any loss in the test-takers total number of attempts.', 'Please inform BCFI by sending a message through help section.' ],
		
		/* Help Page - End */
		
		
		/* Change Password Page - Start */
		'changep_title' => "Change Password", //not sent
		'password_field' => "Password", //not sent
		'password_field_placeholder' => "Old Password", //not sent
		'new_password_field' => "New Password", //not sent
		'new_password_field_placeholder' => "New Password", //not sent
		'confirm_password_field' => "Confirm New Password", //not sent
		'confirm_password_field_placeholder' => "Confirm New Password", //not sent
		'change_password_success' => "Password Updated Successfully", //not sent
		
		'cpassword_rules' => [ //not sent
			'old_p_required' => "Please enter your Current Password.",
			'old_p_min' => "Current Password must be at least 6 characters.",
			'new_p_required' => "Please enter your New Password.",
			'new_p_min' => "New Password must be at least 6 characters.",
			'conf_p_required' => "Please Enter Confirm Password.",
			'conf_p_min' => "Confirm Password must be at least 6 characters.",
			'conf_p_same' => "Confirm Password must be Same.",
			'password_incorrect' => "Please Enter Correct Password.",
			
			/* new */
			'same_password_error' => "Sorry, you have entered your current password.",
			/* new */
		],
		/* Change Password Page - End */
		
		/* Test Page - Start */
		/* new */
		/* test List - start */
		'test_attempt_log' => 'Attempt Logs',
		'test_attempt_description' => 'Summary of your previous test attempts ',
		'test_log_time' => 'Time (Min)',
		'test_submission_error' => 'Please Select Options for Question',
		/* test List - end */
		
		'attempt_exam_clear_error' => 'Sorry, you have already cleared this Exam.', 
		/* new */
		
		'attempt_error_heading' => 'Error', //not sent
		'attempt_error_content' => 'Your Attempts have expired. Please Contact your CBC.', //not sent
		'invigilator_as' => 'Invigilator<br>',
		'invigilated_by' => 'Invigilated By', //not sent
		'appearing_as' => 'Agent<br>',
		'current_test' => 'Current Test', //not sent
		'start_test' => 'Start Test',
		'que_in_test' => 'Questions<br> in this test',
		'min_in_test' => 'Minute<br> Test',
		'total_attempts' => 'Total<br> Attempts',
		'question_attempted'=>'Questions<br> Attempted', //not sent
		'min_rem'=>'Minutes<br> Remaining', //not sent
		'invigilator_login_account_text'=> 'Please Login As a Invigilator.',
		'proceed_btn_heading'=>'Please click the below button to proceed',
		'proceed_btn_text'=>'Proceed',
		'Q_numbering'=>'Question Number',
		'multiple_question'=>'Multiple answers can be selected',
		'prev_btn_text'=>'Previous',
		'next_btn_text'=>'Next',
		'skip_btn_text'=>'Skip to next',
		'jump_btn_text'=>'Jump To',
		'skipped_que_text'=>'Skipped Question Numbers',
		'submit_btn_text'=>'Submit',
		'review_answers'=>'Click on Review Button to Review your Answers',
		'submit_test'=>'Click on submit button to submit your test',
		'exam_text'=>'Exam.',
		'reviewtext' =>'Review',
		'ortext' =>'OR',
		'submit_btn'=>'Submit',
		'proceed_text' =>'Proceed',
		'resume_test' =>'Resume Test',
		'proceed_upper_heading'=>'Please click below button to proceed',
		'question_jump_text'=>'Question',
		'unauthorized_test_attempt' => 'You need to pass the "Basic" Certification Test before you can appear for the "Advance" Certification Test.',
		
		
		/* Test Thanks Page */
		'cbc_notify_text'=>'you will be notified when your CBC will make your certificate available for download.',
		'certificate_download_text'=>'Please download your Certificate',
		'spent_time_text'=>'Time Spent',
			'congrate_text'=>'Congratulations',
		'cert_eligible_text'=>'You can download your certificate from Download Certificate button.',
		'test_pass_text'=>'You passed the exam with ease and proved to us you are not always talking big things you can fulfill your words too. You are truly a man of work. Keep this hard work up and try to do more better than this.',
		'test_succ_text'=>'You have successfully passed the',
		
		'test_fail_heading'=>'Sorry, you have failed',
		'test_fail_message'=>'But this is not the end, we believe you can do better next time. Just go through the training course again. You may re-appear for this test once you\'re confident.',
		'test_fail_link'=>'Click here',
		'test_fail_link_msg'=>'to go to training course.',
		/* Test Thanks Page */
		
		/* Test Page - End */
		
		/* Certificate Page - start */
		/* new */
		'certificates' => 'Certificates',
		'certificates_tagline' => 'Following Certificates are available for you.',
		'certificate_not_available' => 'Your certificates will be available here after you pass the :test_name:',
		'issued_date' => 'Issue Date',
		'valid_upto_date' => 'Valid up to',
		'cert_pass_text' => ':date: with <strong class="blue">:percentage:%</strong> Marks',
		'download_btn' => 'Download',
		'certificate_expire_msg' => 'Certificate Has Expired.Please Request your CBC to renew your Certificate.',
		'certificate_issuance_msg' => 'Certicate Issued on :issued_date:, to be valid upto :expiry_date:.',
		'certificate_renewal_msg' => 'Certicate Renewed on :issued_date:, to be valid upto :expiry_date:.',
		/* new */
		/* Certificate Page - end */
		
		/* Email Verification - start */
		'invalid_code' => 'Invalid Verification Code',
		'invalid_error_msg' => 'Sorry, it seems like you have used an incorrect Verification Code for Email Verification.',
		'back_to_dashboard' => 'Back To Dashboard',
		'email_updation' => 'Email Updated Successfully',
		'email_updation_msg' => 'Congratulations, Your Email has been successfully Updated. Proceed to Login Page to Login into the system.',
		'email_verified' => 'Email Verified Successfully',
		'email_verified_msg' => 'Congratulations, Your Email has been successfully Verified. Proceed to Login Page to Login into the system.',
		
		/* Email Verification - end */
		
		/* Register Success - start */
		
		'register_success_title' => 'Thanks for signing up!',
		'register_success_profile_msg' => 'Your profile has been sent to <strong>:association_name:</strong>.',
		'register_success_msg' => 'Your profile  has been created. Please verify your e-mail by clicking on activation link which has been sent to your e-mail address.',
		'start_journey' => 'START the journey',
		
		/* Register Success - end */
		
		/* 24-jul */
		/* Footer - start */
		'rights_reserved' => '&copy; <i>MicroSave</i> <b>'.date('Y').'</b>. All rights reserved.',
		'developed_with_by' => 'Developed by',
		
		/* Footer - end */
		
		/* Verify OTP - start */
		'otp_verify_title' => 'OTP sent successfully. Valid for 30 min',
		'otp_enter_code' => 'Enter OTP CODE.',
		'didnt_receive' => 'Didn’t receive the OTP?',
		'resend_code' => 'Resend Code',
		'otp_verify' => 'VERIFY',
		'otp_session_expired' => 'Otp Session has expired.Please Try again.',
		'otp_resend_success' => 'Otp has been sent Successfully',
		'otp_mobile_updated' => 'You mobile otp is successfully updated',
		
		/* Verify OTP - end */
		
		
		/* Registration - start */
		
		'registration_title' => 'Agent Registration',
		'edit_profile_title' => 'Edit Your Profile',
		'registration_basic' => 'Basic Details',
		'registration_basic_desp' => 'Please fill your basic details below like name, profile picture, outlet picture and email address and other personal details.',
		'first_name_placeholder' => 'Enter First/Middle name',
		'last_name_placeholder' => 'Enter last name',
		'agent_email_placeholder' => 'Enter email address',
		'agent_contact_number_placeholder' => 'Enter phone number',
		'education_qualification_placeholder' => 'Please select Education',
		'upload_title' => 'Upload your profile and outlet images',
		'upload_desp' => 'Note: Please upload a .jpg or .png file of size upto 5 MB each',
		'add_profile_img' => 'Add Profile Picture',
		'add_store_img' => 'Add Agent outlet Picture',
		'advanced_title' => 'Advanced Details',
		'associated_user_placeholder' => 'Please select CBC',
		'services_placeholder' => 'Services',
		'identity_title' => 'Identity Documents',
		'pan_card_placeholder' => 'Enter PAN Card Number',
		'driving_license_placeholder' => 'Enter driving licence number',
		'dob_placeholder' => 'DoB in PAN Card',
		'cibil_score_placeholder' => 'Enter CIBIL score',
		'contact_title' => 'Contact Information',
		'contact_desp' => 'Please fill your contact details below like state, district, sub district, block, pin code and others details',
		'state_placeholder' => 'Select State / UT',
		'district_placeholder' => 'Select District',
		'sub_district_placeholder' => 'Select Block/Sub-District',
		'block_placeholder' => 'Select Village/City',
		'street_name_placeholder' => 'Address',
		'pincode_placeholder' => 'Enter PIN code',
		'latitude_placeholder' => 'Enter Latitude',
		'longitude_placeholder' => 'Enter Longitude',
		
		
		
		
		'first_name_required' => 'Please enter First/Middle Name.',
		'agent_email_required' => 'Please Enter Email Id.',
		'agent_contact_number_required' => 'Please Enter Contact number.',
		'agent_contact_number_digits' => 'Please enter a valid 10 digit phone number.',
		'education_qualification_required' => 'Please select Educational Qualifications.',
		'profile_img_required' => 'Please Upload Profile Image.',
		'profile_store_image' => 'Please Upload only Images.',
		'secondary_img_required' => 'Please Upload Agent outlet Image.',
		'services_required' => 'Please select atleast 1 Service.',
		'pan_card_required' => 'Please enter Pan Card Number.',
		'kyc_required' => 'One of the two fields are required.',
		'dob_required' => 'Select DoB as in PAN Card.',
		'cibil_score_digits_between' => 'Please enter value in between 0 to 1000.',
		'addr_state_required' => 'Please select State/UT.',
		'addr_district_required' => 'Please select District.',
		'addr_sub_district_required' => 'Please select Block/Sub-District.',
		'addr_block_required' => 'Please select Village/City.',
		'street_name_required' => 'Please enter Address.',
		'addr_pincode_required' => 'Please enter Pin Code.',
		'addr_pincode_digits' => 'Please enter six digit numeric pin code (0-9).',
		'addr_latitude_regex' => 'Please enter Latitude in between -90 to 90.',
		'addr_latitude_max' => 'Maximum 9 character long coordinate is allowed.',
		'addr_latitude_required_with' => 'Please enter Latitude also.',
		'addr_longitude_max' => 'Maximum 9 character long coordinate is allowed.',
		'addr_longitude_regex' => 'Please enter Longitude in between -180 to 180.',
		'addr_longitude_required_with' => 'Please enter Longitude also.',
		
		
		'profile_update_request' => 'Profile Update Request has been Sent Sucessfully.',
		'pending_attempt_count' => 'Attempts Pending',
		
		/* Registration - end */
		
		'activation_message_email' => 'Activation link will be sent to this email',
		'activation_message_contact' => 'OTP will be sent to this mobile number',
		'voter_id_placeholder' => 'Enter Voter Id',
		
		'otp_required_error' => 'Please enter Mobile OTP.',
		'otp_digits_error' => 'Please enter your four digit OTP.',
		'otp_min_error' => 'Minimum of 4 digit code is required.',
		'otp_max_error' => 'Maximum of 4 digit code is required.',
		'wrong_otp' => 'Wrong Otp Entered.',
		'otp_expired' => 'Your Otp has expired! Please generate a new Otp.',
		
		'first_name_min' => 'First/Middle Name should have atleast 3 characters.',
		'first_name_max' => 'First/Middle Name should not exceed 100 characters.',
		'last_name_max' => 'Last Name should not exceed 100 characters.',
		'agent_email_email' => 'Please Enter Valid Email Id.',
		'agent_email_min' => 'Email Id should have atleast 3 characters.',
		'agent_email_max' => 'Email Id should not exceed 255 characters.',
		'agent_email_unique' => 'Email Id has already been used.',
		'agent_contact_number_unique' => 'Contact Number has already been used.',
		'profile_store_mimes_image' => 'Only JPG and PNG Images are allowed.',
		'pan_card_min' => 'Pan Card should have 10 Characters.',
		'pan_card_max' => 'Pan Card should have 10 Characters.',
		'pan_card_regex' => 'Please Enter Valid Pan Card Number.',
		'pan_card_unique' => 'Pan Card has already been used.',
		'driving_valid' => 'Please enter valid Driving License Number.',
		'voter_id_valid' => 'Please enter valid Voter Id Number.',
		'dob_date_format' => 'Dob Format should be DD/MM/YYYY.',
		'street_name_max' => 'Street Name should not exceed 255 characters.',
		'street_name_min' => 'Street Name should have atleast 3 characters.',
		
		
		'otp_agent_loggedout' => 'Sorry, Agent has logged out.',
		
		'profile_sizemax' => 'The profile image may not be greater than 5 MB.',
		'store_sizemax' => 'The agent outlet image may not be greater than 5 MB.',
		
		'name_characters_only' => 'Enter only characters',
		
		
		'gender_placeholder' => 'Select Gender',
		'gender_option_male' => 'Male',
		'gender_option_female' => 'Female',
		'gender_option_other' => 'Other',
		'gender_required' => 'Please Select your gender',
		
		'field_not_compulsory' => '# Not Compulsory',
		
		'email_btn' => 'Email',
		'print_btn' => 'Print',
    ],
];
