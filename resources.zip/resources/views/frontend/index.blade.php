@extends('frontend.layouts.default_layout')
@section('content')

<section class="featured-sexy-girls-block padding-80">
<h2 class="featured-sexy-girls"><img src="{{ asset('frontend/images/featured-sgirl-title.png') }}"
alt="featured-sgirl-title" class="img-fluid"></h2>
<div class="container-fluid">

<div style="margin:0 auto; text-align:center; display:inline-block; width:100%;">


<div class="item">

@if(count($boostprofiles) > 0)

  @foreach($boostprofiles as $key => $im)
         <?php $keount = $key+1; ?> 
         <div class="box" id="box{{$keount}}">
         @foreach($boostprofiles[$key] as $bp)
             
              <div style="background:url({{ $bp['image_url'] }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;"
              class="side side1">
              <div class="live-btnpositon {{$bp['login_status'] == 0 ? 'Offliine-btnpositon':''}}"><span>{{$bp['login_status'] == 0 ? 'Offline':'Live'}}</span> </div>
             </div>
          
           @endforeach
            </div>
   @endforeach         
  @endif


    <div class="clearfix"></div>

    <div class="flipSlide-btn">
          <button class="prev"></button>
          <button class="next reverse"></button>
    </div>

</div>



</div>


</div>
</section>

<div class="clearfix"></div>
<span class="glowing-border-blue"></span>
<div class="clearfix"></div>
<section class="auckland-escorts-block">
<div class="container-fluid">
<div class="leftaucklandescrots-block">
<div class="aucklandtop-left-block">
    <div class="top-bar-sec">
          <h2 class="today-exclusive-sexy-girls"><img
                    src="{{ asset('frontend/images/todayExlusivesexy-girl-title.png') }}"
                    alt="todayExlusivesexy-girl-title" class="img-fluid"></h2>
          <div class="badges">
            @php
           $locfilter =  getfilterlocation();
            @endphp
            @if(count($locfilter) > 0)
            @foreach($locfilter as $loc)
              <div class="blue-badge">
			  <a href="javascript:void(0)" onclick="getAdbyCity({{$loc->id}},this.id)" class="button button-pulse" id="filtercountry{{$loc->id}}"></a>
			  </div>
			  
			  <div class="blue-badge independent-btn">
			  <div class="independent-cover button active button-pulse">
			     <label>{{$loc->name}} Girls</label>
			     <input type="radio" class="" name="independent-btn"  value="" >
			  </div>
			  </div>
			  
			  
              @endforeach
            @endif
			
			
			<div class="all-escorts-block">
			
			  <div class="blue-badge independent-btn">
			  <div class="independent-cover button active button-pulse">
			     <label>Independent</label>
			     <input type="radio" class="" name="independent-btn"  value="" >
			  </div>
			  </div>
			  
			  
			  <div class="blue-badge agency-btn">			  
	     		  <div class="agency-cover button active button-pulse">
			     <label>Agency</label>
			     <input type="radio" class="" name="Agency-btn"  value="" >
			  </div>
				  
			  </div>
			  
			  <div class="blue-badge club-btn">
		    	  <div class="club-cover button active button-pulse">
			     <label>Club</label>
			     <input type="radio" class="" name="Club-btn"  value="" >
			  </div>
			  </div>
			
			</div>
			
            
          </div>
    </div>
 
    <ul class="aucklandtop-leftblock-box">
          <div class="overlay">
          </div>

          @foreach($featured_profile_list as $featurelist)
          <li class="test1">


              <img class="img-fluid" src="{{getS3ImageURL($featurelist['adImage'], '252*384')}}"
                    id="ad_image{{$featurelist['adId']}}">
              <div class="live-btnpositon  {{$featurelist['login_status'] == 0 ? 'Offliine-btnpositon':''}}">
                    <span id="user_status_{{$featurelist['adId']}}">{{$featurelist['login_status'] == 0 ? 'Offline':'Live'}}</span>
              </div>

              <div class="hoverdiv">
                    <div class="img-section">
                        <img class="img-fluid"
                              src="{{getS3ImageURL($featurelist['adImage'], '508*762')}}">
                    </div>
                    <div class="cnt_section">
                        <div class="cnt">
                              <h2 id="ad_name{{$featurelist['adId']}}">
                                  {{ucwords($featurelist['adName'])}}</h2>
                              <div class="location"> {{ getCityCountry($featurelist['adLocation']) }}
                              </div>
                              <div class="private_tag">
                                  {{getListingType($featurelist['adListingTypeId'])}}</div>
                              <div class="listing">


                                  <div class="list">{{getMaterData($featurelist['metaData']['age'])}} Yrs</div>
                                  @if(!empty($featurelist['metaData']['bustsize']))
                                  <div class="list"><span class="label">Height:
                                        </span>{{getMaterData($featurelist['metaData']['height'])}}</div>
                                  <div class="list"><span class="label">Size:
                                        </span>{{getMaterData($featurelist['metaData']['bustsize'])}}
                                  </div>
                                  @endif
                                  
                                  @if(!empty($featurelist['metaData']['weight']))
                                  <div class="list"><span class="label">Weight:
                                        </span>{{getMaterData($featurelist['metaData']['weight'])}} KG
                                  </div>
                                  @endif
                                  @if(!empty($featurelist['metaData']['eyecolor']))
                                  
                                  <div class="list"><span class="label">Eye Color:
                                        </span>{{getMaterData($featurelist['metaData']['eyecolor'])}}
                                  </div>
                                  @endif
                                  @if(!empty($featurelist['metaData']['haircolor']))
                                  <div class="list"><span class="label">Hair Color:
                                        </span>{{getMaterData($featurelist['metaData']['haircolor'])}}
                                  </div>
                                  @endif
                                  @if(!empty($featurelist['metaData']['nationality']))
                                  <div class="list"><span class="label">Ethnicity:
                                        </span>{{getMaterData($featurelist['metaData']['nationality'])}}
                                  </div>
                                  @endif

                              </div>
                              <div class="contact_detail mt-3">
                                  <div class="icon"><img src="frontend/images/hover-phone-icon.png">
                                  </div>
                                  <div class="phone-number">
                                        <span>Phone</span><br />{{$featurelist['adContact']}}</div>
                              </div>
                              <div class="rate">{{ $featurelist['rate'] }} / Hour</div>
                              <div class="view-profile"><a
                                        href="{{route('profile.',$featurelist['slug'])}}">View Profile
                                        <img src="frontend/images/long-arrow.png"></a></div>
                        </div>

                        <div class="shortlist_button">
                              @php
                              $wishlist_ad_ids = array();
                              $wishlist_ad_ids = getWishlist()->pluck('short_ad_id')->toArray();
                              $style = "style=display:none;";
                              $style1 = "style=display:none;";
                              if(!in_array($featurelist['adId'], $wishlist_ad_ids)){
                              $style = "style=display:block;'";
                              }else{
                              $style1 = "style=display:block;";
                              }
                              @endphp
                              <a {{$style}} id="showshortListing{{$featurelist['adId']}}"
                                  href="javascript:void(0)"
                                  onclick="addToShortlist({{$featurelist['adId']}})"><i
                                        class="fa fa-plus"></i> Shortlist</a>


                              <a {{$style1}} class="shotlilsted-btn" href="javascript:void(0)"
                                  id="showshortListed{{$featurelist['adId']}}"><i
                                        class="fa fa-heart"></i> Shotlisted</a>

                        </div>
                    </div>
              </div>


          </li>
          @endforeach

    </ul>


</div>

<div class="aucklandtop-right-block">
  @if(count($teaservideo) > 0)
    <div class="top-bar-sec">
          <h2 class="eotd"><img class="img-fluid" src="frontend/images/eotd1.png"></h2>
    </div>

@endif


    <div class="videopop-upblock">
       
          @foreach($teaservideo as $tesv)
          <div class="videopopup-first" data-toggle="modal" data-target="#homeVideo{{$tesv['ad_id']}}">
              <video autoplay muted="" controls width="100%" height="100%">
                    <source src="{{$tesv['teaservideo']}}">
              </video>
          </div>


          <!-- Home Video Modal -->
          <div class="modal fade homeVideo" id="homeVideo{{$tesv['ad_id']}}" tabindex="-1" role="dialog"
              aria-labelledby="myModalLabel">
              <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                        </button>

                        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                              <ol class="carousel-indicators">
                                  <li data-target="#carouselExampleIndicators" data-slide-to="0"></li>
                                  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                              </ol>
                              <div class="carousel-inner">
                                  <div class="carousel-item active">
                                        <div class="videopopup-teaserblock">

                                            <video id="gossVideo" class="" autoplay loop muted=""
                                                  controls>
                                                  <source src="{{$tesv['teaservideo']}}">
                                            </video>
                                            <div class="cnt_section">

                                                  <div class="cnt">
                                                      <h2>{{$tesv['name']}}</h2>
                                                      <div class="location">{{$tesv['location']}}</div>
                                                      <div class="private_tag">{{$tesv['listingtype']}}
                                                      </div>
                                                      <div class="listing">
                                                            <div class="list">{{getMaterData($tesv['age'])}} Yrs</div>
                                                            <div class="list"><span
                                                                      class="label">Height:</span>
                                                                {{getMaterData($tesv['height'])}} CM</div>
                                                            <div class="list"><span
                                                                      class="label">Size:</span>
                                                                {{getMaterData($tesv['bustsize'])}}</div>
                                                      </div>
                                                      <div class="contact_detail mt-3">
                                                            <div class="icon"><img
                                                                      src="frontend/images/hover-phone-icon.png">
                                                            </div>
                                                            <div class="phone-number">
                                                                <span>Phone</span><br>
                                                                {{$tesv['contact']}}</div>
                                                      </div>
                                                      <div class="rate">{{$tesv['rate']}}$ / Hour</div>
                                                      <div class="view-profile"><a
                                                                href="{{$tesv['viewlink']}}">View
                                                                Profile <img
                                                                      src="frontend/images/long-arrow.png"></a>
                                                      </div>
                                                  </div>
                                                  <div class="shortlist_button"><a
                                                            href="addToShortlist({{$tesv['ad_id']}}">+
                                                            Shortlist</a></div>
                                            </div>

                                        </div>

                                  </div>
                              </div>
                             
                        </div>
                    </div>
          
              </div>


          </div>
          @endforeach
        </div>

          <div class="profile_home">
              
          </div>
    </div>
</section>

<div class="clearfix"></div>


<section class="redbar-cta text-center">
<div class="container-fluid">
<div class="row">
<div class="cta-text">
    <p>Be a proud member of <b>House of Sexy Girls</b></p><a class="post-addcta-btn" href='{{route("post-ad.","/")}}'>Post your
          ad now</a>
</div>
</div>
</div>
</section>

<div class="clearfix"></div>

<section class="bottom-advertiseblock padding-50">
<div class="container-fluid">
<div class="row">
@foreach($other_ads as $oth)
<div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
    <div class="advertise-box">
          <img src="{{ get_image_data_2($oth->ad_photo,'other_ads_photos') }}" class="img-fluid"
              alt="img">
    </div>
</div>
@endforeach
</div>

</div>
</section>

<script src="{{asset('frontend/js/detect.js')}}"></script>
<script>
// Autoplay
/*$('.box').flipbox(
  vertical: true,
  autoplay: true,
  autoplayReverse: true,
  autoplayWaitDuration: 7000,
  autoplayPauseOnHover: true
  );
  */
var boxLength = $(".box").length;
for(var j=1; j<= boxLength; j++){
  
  if(j==1 || j==4){
    var duration = 7000;
  }else{
    var duration = 6500;
  }

  $('#box'+j).flipbox({
    vertical: true,
    autoplay: true,
    autoplayReverse: true,
    autoplayWaitDuration: duration,
    autoplayPauseOnHover: true
    });
}


// Buttons
$('button.prev').click(function() {
$(this).closest('.item').find('.box').flipbox('prev', $(this).hasClass('reverse'));
});
$('button.next').click(function() {
$(this).closest('.item').find('.box').flipbox('next', $(this).hasClass('reverse'));
});
$('button.jump').click(function() {
$(this).closest('.item').find('.box').flipbox('jump', $(this).data('index'), $(this).hasClass(
'reverse'));
});
$('button.config').click(function() {
$(this).closest('.item').find('.box')
.flipbox({
animationDuration: $(this).data('duration'),
animationEasing: $(this).data('easing')
})
.flipbox('next');

});
</script>

<script type="text/javascript">
$(document).ready(function() {
$("#form_grid_2").click(function() {
$("ul").removeClass();
$("ul").addClass("aucklandtop-leftblock-box_grid_2");
});
$("#form_grid_3").click(function() {
$("ul").removeClass();
$("ul").addClass("aucklandtop-leftblock-box");
});
});

function WebSocketTest() {

if ("WebSocket" in window) {

// Let us open a web socket
//  document.getElementById("div_counter").innerHTML="initiating connection...";

var ws = new WebSocket("ws://13.236.176.232:8000/echo");
// document.getElementById("div_counter").innerHTML="connection request sent...";


ws.onopen = function() {
var datastring = {"user_latitude":"{{$_COOKIE['user_latitude']}}", "user_longitude":"{{$_COOKIE['user_longitude']}}", "action":"updateactivity"}
var datastring2 = {"user_latitude":"{{$_COOKIE['user_latitude']}}", "user_longitude":"{{$_COOKIE['user_longitude']}}", "action":"posts"}
// Web Socket is connected, send data using send()
ws.send(JSON.stringify(datastring));
ws.send(JSON.stringify(datastring2));
// document.getElementById("div_counter").innerHTML="Update requested...";

};

ws.onmessage = function(evt) {

//var received_msg = JSON.parse(evt.data);
var received_msg =JSON.parse(evt.data);

if(received_msg.type=='updateactivity'){
 
  var html = "";

delete received_msg.type;
if(received_msg.count > 0){
  
  delete received_msg.count;
  html += '<h2><img src="{{ asset('frontend/images/liveUpdate-title.png') }}" class="img-fluid"   alt="img"></h2>';
  html += '<div id="update-section">';

for (var key in received_msg) {
    html += '<div class="block1">';
    html += '<div class="image"><img src="'+received_msg[key].ad_image+'"></div>';
    html += '<div class="content">';
    html += '<h3>'+received_msg[key].ad_name+'</h3>';
    for (var s in received_msg[key].activity_message) {
      html += '<p class="content-blinktext">' + received_msg[key].activity_message[s] + '</p>';
    }
   
    html += '</div>';
    html += '</div>';
}
html += '</div>';
}
if(html !=""){
$(".profile_home").html(html);

}

}
if(received_msg.type == 'posts'){
 var html = "";
delete received_msg.type;
if(received_msg.count > 0){
  delete received_msg.count;
for (var key in received_msg) {
 html += '<li class="test1">';


var login_status_class = (received_msg[key].login_status == 0) ? 'Offliine-btnpositon':'';
var login_status_text = (received_msg[key].login_status == 0) ? 'Offliine':'Live';
html += '<img class="img-fluid" src="'+received_msg[key].ad_small_image+'" id="ad_image'+received_msg[key].adId+'">';
html += '<div class="live-btnpositon '+login_status_class+'">';
html += '<span id="user_status_'+received_msg[key].adId+'">'+login_status_text+'</span>';
html += '</div>';

html += '<div class="hoverdiv">';
html += '<div class="img-section">';
html += '<img class="img-fluid" src="'+received_msg[key].ad_large_image+'">';
html += '</div>';
html += '<div class="cnt_section">';
html += '<div class="cnt">';
html += '<h2 id="ad_name'+received_msg[key].adId+'">'+received_msg[key].adName+'</h2>';

html += '<div class="location">'+received_msg[key].adLocation+'</div>';
html += '<div class="private_tag">'+received_msg[key].adListingTypeId+'</div>';
html += '<div class="listing">';

html += '<div class="list">'+received_msg[key].age+' Yrs</div>';

if(received_msg[key].height !=''){
html += '<div class="list"><span class="label">Height:</span>'+received_msg[key].height+'</div>';
}
if(received_msg[key].bustsize !=''){
html += '<div class="list"><span class="label">Size:</span>'+received_msg[key].bustsize+'</div>';
}
if(received_msg[key].weight !=''){
html += '<div class="list"><span class="label">Weight:</span>'+received_msg[key].weight+'</div>';
}
if(received_msg[key].eyecolor !=''){
html += '<div class="list"><span class="label">Eye Color:</span>'+received_msg[key].eyecolor+'</div>';
}
if(received_msg[key].haircolor !=''){
html += '<div class="list"><span class="label">Hair Color:</span>'+received_msg[key].haircolor+'</div>';
}
if(received_msg[key].ethinicity !=''){
html += '<div class="list"><span class="label">Ethinicity:</span>'+received_msg[key].ethinicity+'</div>';
}
html += '</div>';
html += '<div class="contact_detail mt-3">';
html += '<div class="icon"><img src="{{asset('frontend/images/hover-phone-icon.png')}}">';
html += '</div>';
html += '<div class="phone-number">';
html += '<span>Phone</span><br />'+received_msg[key].adContact+' </div>';
html += '</div>';
html += '<div class="rate">'+received_msg[key].rate+' / Hour</div>';
html += '<div class="view-profile"><a href="'+received_msg[key].profile_link+'">View Profile<img src="{{asset('frontend/images/long-arrow.png')}}"></a></div>';
html += ' </div>';

html += '<div class="shortlist_button">';
if(received_msg[key].is_shortlist == 1){
var style = "style=display:block;'";
}else{
var style1 = "style=display:block;";
}

<?php
$wishlist_ad_ids = array();
$wishlist_ad_ids = getWishlist()->pluck('short_ad_id')->toArray();
?>
var style = "style=display:none;";
var style1 = "style=display:none;";
var wishlist_ad_ids = '<?php echo  $wishlist_ad_ids; ?>';
if(jQuery.inArray(received_msg[key].adId, wishlist_ad_ids) !== -1){
  style1 = "style=display:block;'";

}else{
  style = "style=display:block;";
}
html += ' <a '+style+' id="showshortListing'+received_msg[key].adId+'" href="javascript:void(0)" onclick="addToShortlist('+received_msg[key].adId+')"><i class="fa fa-plus"></i> Shortlist</a>';
html += ' <a  '+style1+' class="shotlilsted-btn" href="javascript:void(0)" id="showshortListed'+received_msg[key].adId+'"><i class="fa fa-heart"></i> Shotlisted</a>';

html += '</div>';
html += '</div>';
html += '</div>';
html += ' </li>';
}
}
if(html !=""){
$(".aucklandtop-leftblock-box").html(html);

}
}
};

ws.onclose = function() {

// websocket is closed.
// document.getElementById("div_counter").innerHTML="Connection is closed...";

};
} else {

// The browser doesn't support WebSocket
// document.getElementById("div_counter").innerHTML="WebSocket NOT supported by your Browser!";

}
}


jQuery(function() {
WebSocketTest();
//getPosts();
});
var filterURL = "{{ route('filterfeaturedads') }}";
function getAdbyCity(cityid, ele){
  var token = '{{csrf_token()}}';
  var html='';
  jQuery.ajax({
        type: 'POST',
        url:filterURL,
       data:{cityid:cityid, '_token': token},
        success: function(data) {
        	$('#'+ele).addClass("active");
          received_msg = JSON.parse(data);
          loadHtml(received_msg);
    
}

})
}

var filterURL = "{{ route('filterfeaturedads') }}";
function filterByListingType(listingtype, ele){
  var token = '{{csrf_token()}}';
  var html='';
  jQuery.ajax({
        type: 'POST',
        url:filterURL,
       data:{cityid:cityid, '_token': token},
        success: function(data) {
        	$('#'+ele).addClass("active");
          received_msg = JSON.parse(data);
          loadHtml(received_msg);
    
}

})
}

function loadHtml(received_msg){
	if (received_msg.count > 0) {
           delete received_msg.count;
for (var key in received_msg) {
 html += '<li class="test1">';


var login_status_class = (received_msg[key].login_status == 0) ? 'Offliine-btnpositon':'';
var login_status_text = (received_msg[key].login_status == 0) ? 'Offliine':'Live';
html += '<img class="img-fluid" src="'+received_msg[key].ad_small_image+'" id="ad_image'+received_msg[key].adId+'">';
html += '<div class="live-btnpositon '+login_status_class+'">';
html += '<span id="user_status_'+received_msg[key].adId+'">'+login_status_text+'</span>';
html += '</div>';

html += '<div class="hoverdiv">';
html += '<div class="img-section">';
html += '<img class="img-fluid" src="'+received_msg[key].ad_large_image+'">';
html += '</div>';
html += '<div class="cnt_section">';
html += '<div class="cnt">';
html += '<h2 id="ad_name'+received_msg[key].adId+'">'+received_msg[key].adName+'</h2>';

html += '<div class="location">'+received_msg[key].adLocation+'</div>';
html += '<div class="private_tag">'+received_msg[key].adListingTypeId+'</div>';
html += '<div class="listing">';

html += '<div class="list">'+received_msg[key].age+' Yrs</div>';

if(received_msg[key].height !=''){
html += '<div class="list"><span class="label">Height:</span>'+received_msg[key].height+'</div>';
}
if(received_msg[key].bustsize !=''){
html += '<div class="list"><span class="label">Size:</span>'+received_msg[key].bustsize+'</div>';
}
if(received_msg[key].weight !=''){
html += '<div class="list"><span class="label">Weight:</span>'+received_msg[key].weight+'</div>';
}
if(received_msg[key].eyecolor !=''){
html += '<div class="list"><span class="label">Eye Color:</span>'+received_msg[key].eyecolor+'</div>';
}
if(received_msg[key].haircolor !=''){
html += '<div class="list"><span class="label">Hair Color:</span>'+received_msg[key].haircolor+'</div>';
}
if(received_msg[key].ethinicity !=''){
html += '<div class="list"><span class="label">Ethinicity:</span>'+received_msg[key].ethinicity+'</div>';
}
html += '</div>';
html += '<div class="contact_detail mt-3">';
html += '<div class="icon"><img src="{{asset('frontend/images/hover-phone-icon.png')}}">';
html += '</div>';
html += '<div class="phone-number">';
html += '<span>Phone</span><br />'+received_msg[key].adContact+' </div>';
html += '</div>';
html += '<div class="rate">'+received_msg[key].rate+' / Hour</div>';
html += '<div class="view-profile"><a href="'+received_msg[key].profile_link+'">View Profile<img src="{{asset('frontend/images/long-arrow.png')}}"></a></div>';
html += ' </div>';

html += '<div class="shortlist_button">';
if(received_msg[key].is_shortlist == 1){
var style = "style=display:block;'";
}else{
var style1 = "style=display:block;";
}

<?php
$wishlist_ad_ids = array();
$wishlist_ad_ids = getWishlist()->pluck('short_ad_id')->toArray();
?>
var style = "style=display:none;";
var style1 = "style=display:none;";
var wishlist_ad_ids = '<?php echo  $wishlist_ad_ids; ?>';
if(jQuery.inArray(received_msg[key].adId, wishlist_ad_ids) !== -1){
  style = "style=display:block;'";

}else{
  style1 = "style=display:block;";
}
html += ' <a '+style+' id="showshortListing'+received_msg[key].adId+'" href="javascript:void(0)" onclick="addToShortlist('+received_msg[key].adId+')"><i class="fa fa-plus"></i> Shortlist</a>';
html += ' <a  '+style1+' class="shotlilsted-btn" href="javascript:void(0)" id="showshortListed'+received_msg[key].adId+'"><i class="fa fa-heart"></i> Shotlisted</a>';

html += '</div>';
html += '</div>';
html += '</div>';
html += ' </li>';
}

if(html !=""){
$(".aucklandtop-leftblock-box").html(html);

}

          }
}
</script>

<script>
jQuery('.independent-cover').click(function(){
                            
				checkBox = jQuery(this);
				checkBox.toggleClass('active');
				if(checkBox.is('.active')){
					checkBox.find('input').attr('checked','checked');
                                       
				} else {
				checkBox.find('input').removeAttr('checked');
                               
				}
			});
                        
			jQuery('.independent-cover').click(function(){
                            var yes= jQuery('.independent-cover').find(".independent-cover").hasClass("active");
                            if(yes){
                                jQuery('.independent-cover').find("input").removeAttr("required");
                            }
                    });
					
					</script>



@endsection