@extends('frontend.layouts.front_layout')

@section('content')
@php
$default_locale = app()->getLocale();

@endphp


<section class="profile-details-block">
     <div class="container">
          <div class="row">
               @include('frontend.layouts.partials.navfordashboard')


               <div class="col-md-9">
               @if(count($query) > 0)
                    <div class="row side_box">
                         <div class="col-md-3">
                              <div class="card-boxes gr_pink">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-view-icon.png')}}"></div>
                                   <div class="text">Views<br /><span>{{ $stat_views }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_orange">
                                   <div class="dashboard_icon"><img
                                             src="{{ asset('frontend/images/dashboard-shortlisted-icon.png')}}"></div>
                                   <div class="text">Shortlisted<br /><span>80</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_purple">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-likes-icon.png')}}"></div>
                                   <div class="text">Likes<br /><span>{{ $stat_likes }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_green">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-clicks-icon.png')}}"></div>
                                   <div class="text">Clicks<br /><span>{{ $stat_clicks }}</span></div>
                              </div>
                         </div>
                    </div>
          @endif
      <div id="accordion" role="tablist" class="testimonial-listing-block mt-4">

               <h2>Testimonials</h2>
               
               <div class="testimonial-status">
               <h5>Testimonial status</h5>
                <button type="button" class="btn btn-lg btn-toggle" data-toggle="button" aria-pressed="false" autocomplete="off" onchange="updateStatus(this.value)">
                  <div class="handle"></div>
                </button>
              </div>
                          
              @if(count($data) > 0)
               @foreach($data as $t)
                <div class="card">
              <div class="card-header" role="tab" id="heading{{$t->id}}">
                <h5 class="mb-0">
                  <a data-toggle="collapse" href="#collapse{{$t->id}}" aria-expanded="true" aria-controls="collapse{{$t->id}}">
                    You recived a new testimonial from {{ucfirst($t->test_user_name)}} <span>Read the full testimonial</span>
                  </a>
                    <div class="acceptdelete-btns">
                     <a class="testimonial-acceptBtn" href="#">Accept</a>       
                       <a class="testimonial-acceptBtn testimonial-deleteBtn" href="#">Delete</a>        
                    
                    </div>         
                </h5>
              </div>

              <div id="collapse{{$t->id}}" class="collapse" role="tabpanel" aria-labelledby="heading{{$t->id}}" data-parent="#accordion">
                <div class="card-body">
                  <div class="userRating">
                    <span>
                       {{ucfirst($t->test_user_name)}}
                      @for($i=1;$i<=$t->test_user_rating; $i++)
                      <i class="fa fa-star"></i>
                      @endfor
                    </span>
                  </div>
                  
                  
                    <div class="usertestimonial-time">{{date("M d, Y", strtotime($t->created_at))}} at {{date("H:m a", strtotime($t->created_at))}}</div>



                    <p>{{$t->test_user_msg}}</p>
                </div>
              </div>
              </div>
              @endforeach 
            @else
            <div class="col-md-12 ad-status-box">
                         <h2>No Testimonials has been added yet.</h2>
                       </div>
            @endif


          </div>
                   
            </div>
               
          </div>
     </div>
</section>
<script type="text/javascript">
  var testimonial_url =  "{{ route('updateTestimonialStatus') }}";
   var testimonial_setting_url =  "{{ route('updateTestimonialSetting') }}";
</script>


@endsection