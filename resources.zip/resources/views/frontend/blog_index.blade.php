@extends('frontend.layouts.front_layout')

@section('content')
@php
$default_locale = app()->getLocale();

@endphp
<section class="profile-details-block">
     <div class="container"> 
          <div class="row">
               @include('frontend.layouts.partials.navfordashboard')
               <div class="col-md-9"  id="signup-container">
               <div class="row side_box">
                         <div class="col-md-3">
                              <div class="card-boxes gr_pink">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-view-icon.png')}}"></div>
                                   <div class="text">Views<br /><span>{{ $stat_views }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_orange">
                                   <div class="dashboard_icon"><img
                                             src="{{ asset('frontend/images/dashboard-shortlisted-icon.png')}}"></div>
                                   <div class="text">Shortlisted<br /><span>80</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_purple">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-likes-icon.png')}}"></div>
                                   <div class="text">Likes<br /><span>{{ $stat_likes }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_green">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-clicks-icon.png')}}"></div>
                                   <div class="text">Clicks<br /><span>{{ $stat_clicks }}</span></div>
                              </div>
                         </div>
                    </div>
					
					
				<div class="testimonial-listing-block mt-4">	
               <h2>Blog Listing</h2>
			   <h4 class="text-success">
			   <a href="{{ route('blog-create') }}" class="add-newBlog-btn"><i class="fa fa-plus"></i>Add New Blog</a>
			   </h4>            
                                 
                    
                    
          <div class="blog-listing-main table-striped table-dark">
          <table class="table table-hover" >
              <thead>
                 <tr>
					<th>Image</th>
					<th>Title</th>
					<th>Posted By</th>
					<th>Added On</th> 
					<th>Status</th> 
					<th colspan="3">&nbsp;</th>					
                 </tr>
              </thead>

             <tbody>
            @foreach($blogdata as $data)
            <tr>
              <td> @if(!empty($data->blog_featured_img))
                    @php
                    $imageurl = url('uploads/ads_image/'.$data->blog_featured_img);
                    @endphp
					<div class="blog-featured-profileIcon">
                     <img src="{{ $imageurl }}" class="img-fluid"> 
					 </div>
					 
                    @endif</td>
              <td>{{$data->blog_title}}</td>
             <!--  <td>{{ str_limit($data->blog_desc, 100) }}</td> -->
              <td>{{ Auth::user()->name }}</td>
              <td>{{ $data->created_at->diffForHumans() }}</td>
              <td><input type="checkbox" name="status" id="status_1"value="1" @if ($data->blog_status == 1) checked @endif>
                       
				</td>
   
              <td>
			  <a data-toggle="tooltip" data-placement="top" title="view" href="{{ route('read-front-blog', $data->blog_slug) }}" class="blog-view-btn" target="_blank"><i class="fa fa-eye"></i></a>
			  
			    <a data-toggle="tooltip" data-placement="top" title="Edit" href="{{ route('blogedit', $data->blog_slug) }}" class="blog-edit-btn"><i class="fa fa-edit"></i></a>
				
				 <form action="{{route('blogdelete',$data->blog_slug)}}" method="post">
                 {{csrf_field()}}
                  {{method_field('DELETE')}}
                  <button data-toggle="tooltip" data-placement="top" title="Delete" type="submit" class="blog-delete-btn"><i class="fa fa-trash"></i></button>
               </form>
			  </td>
			   
              


            </tr>
            @endforeach
          </tbody>
             
           </table>
         </div><!-- table-responsive --> 
		 
		 </div>
                   

               </div>
               
          </div>    
</section>



@endsection