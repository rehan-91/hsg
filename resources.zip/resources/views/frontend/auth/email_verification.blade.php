@extends('frontend.layouts.front_layout')
@section('header-css')
<link href="{{ asset('registrations/css/bootstrap.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/font-awesome.min.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/responsive.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_css.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_responsive.css') }}" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
@endsection

@section('content')
@php
$default_locale = app()->getLocale();
@endphp
<section class="profile-details-block">

<div class="container">
	
            
	@if( intval($message_type) == 1 )
	<div class="content_block">
          <div class="thanks_box text-center verification_box">

	<div class="text-center success-msg invalid">
		<h2>{!! trans('translations.frontend.invalid_code') !!}</h2>
		<div class="row profile-details-form">
			<div class="form-group col-md-10 mx-auto mt-2">
				<p>{!! trans('translations.frontend.invalid_error_msg') !!}
					<br /> </p>
			</div>

			<div class="form-group col-md-10 mx-auto mt-4">
				<a class="btn btn-danger w-100 verification-btn" href="{{route('resendemail')}}">RESEND CODE</a>
			</div>


		</div>

		@if( intval( $is_user_logged ) == 0 )
		<a href="{{ route('login') }}" class="strt-btn">{!! trans('translations.frontend.back_to_login') !!}</a>
		@endif
	</div>
 </div>
</div>
	
	
	@elseif( intval($message_type) == 0 )
	<div class="content_block">
          <div class="thanks_box text-center verification_box">
	<div class="row profile-details-form">
	  <div class="text-center success-msg succes">
		<h1>{!! trans('translations.frontend.email_verified') !!}</h1>
		<p>{!! trans('translations.frontend.email_verified_msg') !!}</p>
		<a href="{{ route('login') }}" class="strt-btn">{!! trans('translations.frontend.start_journey') !!}</a>
	  </div>
	</div>
	</div>
</div>

	@elseif( intval($message_type) == 2 )
		<div class="content_block">
          <div class="thanks_box text-center verification_box">
<div class="row profile-details-form">                      
           
	<div class="text-center success-msg update">
		<h2>{!! trans('translations.frontend.email_updation') !!}</h2>
		<p>{!! trans('translations.frontend.email_updation_msg') !!}</p>
		@if( intval( $is_user_logged ) == 1 )
		<a href="{{ route('index') }}" style="color:red" class="strt-btn">{!! trans('translations.frontend.back_to_dashboard') !!}</a>
		@else
		<a href="{{ route('login') }}" class="strt-btn">{!! trans('translations.frontend.back_to_login') !!}</a>
		@endif
	</div>
   </div>	
	</div>
</div>
	@endif

</div>
</section>
@endsection