@extends('frontend.layouts.front_layout')
@section('header-css')
<link href="{{ asset('registrations/css/bootstrap.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/font-awesome.min.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/responsive.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_css.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_responsive.css') }}" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
@endsection

@section('content')
@php
$default_locale = app()->getLocale();
@endphp

   <section class="profile-details-block">
      <div class="container">
       
 
        <div class="content_block">
          <div class="thanks_box text-center verification_box">
            <h2>{!! trans('translations.frontend.register_success_title') !!}</h2>
		   <div class="row profile-details-form">                      
			<p>
				<br />
				{!! trans('translations.frontend.register_success_msg') !!}
				</p>
				<div class="form-group col-md-10 mx-auto mt-4">        
			<a href="{{ route('index') }}" class="strt-btn">{!! trans('translations.frontend.start_journey') !!}</a>
			</div>
			<div class="form-group col-md-10 mx-auto mt-4">
				<a href="{{route('resendemail')}}" style="color:red">( Resend Verificaton Code )</a>
			</div>
		   
		   </div>
		  </div>
	   </div>
	</div>
	</section>	
		
		<?php
		/*
	
  <div class="content_block">
          <div class="thanks_box text-center verification_box">
            <h2>Resend Verification Code</h2>
			<form method="post" action="{{route('resendemailtoken')}}" name="resend_email_verificationn_form">
			{{ csrf_field() }}
          <div class="row profile-details-form @if($errors->has('resend_email')) has-error @endif">                      
                      <div class="form-group col-md-10 mx-auto mt-4">
                        <input type="email" class="form-control verification1" id="resend_email" name="resend_email" placeholder="Email">
                        <!-- <sup><img src="images/red-inputstar.png" alt="red-inputstar"></sup>-->
						 @if($errors->has("resend_email"))
						<span class="help-block">{{ $errors->first("resend_email") }}</span>
					    @endif
                      </div>
					  
					  @if($errors->has("resend_message"))
						<span class="help-block">{{ $errors->first("resend_message") }}</span>
					    @endif
                      </div>
					  

                       <div class="form-group col-md-10 mx-auto mt-4">
                       <button class="btn btn-danger w-100 verification-btn" type="submit">RESEND CODE</button>
                        <!-- <sup><img src="images/red-inputstar.png" alt="red-inputstar"></sup>-->
                      </div>
                     
                    
                    </div>
					<br>
           </form>
            <div class="clearfix"></div>
           
          </div>
        </div>
		
		<br>
	</div>
	<!--end of main container-->
</div>
<!--end of container-->

		*/
		?>
@endsection