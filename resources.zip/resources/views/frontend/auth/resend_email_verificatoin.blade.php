@extends('frontend.layouts.front_layout')
@section('header-css')
<link href="{{ asset('registrations/css/bootstrap.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/font-awesome.min.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/responsive.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_css.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_responsive.css') }}" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
@endsection

@section('content')
@php
$default_locale = app()->getLocale();
@endphp
<section class="profile-details-block">
      <div class="container">
       
 
        <div class="content_block">
          <div class="thanks_box text-center verification_box">
		     <h2>Resend Verification Code</h2>
          <div class="row profile-details-form">                      
          
		  <form action="{{route('resendemailtoken')}}" method="POST">
              {{ csrf_field() }}
              <div class="form-group col-md-10 mx-auto mt-4 @if($errors->has('resend_email')) has-error @endif">
                        <input type="email" class="form-control verification1" id="resend_email" name="resend_email" placeholder="Email">
						@if($errors->has("resend_email"))
                    <span class="help-block">{{ $errors->first("resend_email") }}</span>
                    @endif

                    @if($errors->has("resend_email"))
                    <span class="help-block">{{ $errors->first("resend_email") }}</span>
                    @endif

                    <br>
					
                    <div class="flash-message" style="padding:2px;">
                      @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                      @if(Session::has('alert-' . $msg))

                      <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }} <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                      @endif
                      @endforeach
                    </div>
                    
              </div>
	
                <div class="row">
                 <div class="form-group col-md-10 mx-auto mt-4">
				 <button type="submit" class="btn btn-danger w-100 verification-btn">Send</button>
                  <hr>
				  <a href="{{route('login')}}">Back To Login?</a>
                  </div>
                </div>
            </form> 
			 </div>

            
          </div>

        </div>

      </div>
    </div>
  </section>

  <script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
  <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
@endsection