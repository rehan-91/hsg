@extends('frontend.layouts.front_layout')

@section('content')
@php
$default_locale = app()->getLocale();

@endphp

<section class="profile-details-block">
     <div class="container">
          <div class="row">
               @include('frontend.layouts.partials.navfordashboard')
               <div class="col-md-9"  id="signup-container">
               <div class="row side_box">
               <form action="{{ route('saveBlog') }}" method="post" name="form_blog_create" id="form_blog_create" enctype="multipart/form-data" onsubmit="return false;">
               <h2 class="text-danger">Create your story</h2>             
                                 
                    <div class="row">
                    {{ csrf_field() }}  
                   
                    <h4>Title</h4>
                      <div class="form-group">
                        <input type="text" class="form-control"  placeholder="*Blog Title" id="blog_title" name="blog_title">
                        <span class="help1-block hidden blog_title_error"></span>
                      </div>

                      <h4>Description</h4>
                      <div class="form-group">
                         <textarea class="form-control ckdemo" id="ckdemo" name="ckdemo" aria-labelledby="article"></textarea>
                         <span class="help1-block hidden ckdemo_error"></span>
                      </div>
                      </div>

                      <h4>Featured Image</h4>
                      <span style="color:#f44336;">Maximum file size to upload is 200KB.</span>
                      <div class="form-group">
                        <!-- <input type="file" name="featured_image"> -->
                    <input type="file" name="featured_image" id="feature-img">
                   <!--  <span class="help1-block hidden feature-img_error"></span> -->
                   @if ($errors->has('featured_image'))
                <span class="help1-block">
                    <strong>{{ $errors->first('featured_image') }}</strong>
                </span>
            @endif
                    <img src="" id="feature-img-preview" width="200px" />


                      </div>

                      <h4>SEO Content</h4>
                      <div class="form-group">
                        <input type="text" class="form-control"  placeholder="Meta Title" name="blog_meta_title" id="blog_meta_title">
                        
                      </div>

                      <div class="form-group">
                        <input type="text" class="form-control"  placeholder="Meta Keywords" name="blog_meta_keywords" id="blog_meta_keywords">
                      
                      </div>

                      <div class="form-group">
                    <textarea class="form-control"  placeholder="Meta Description" name="blog_meta_description" id="blog_meta_description"></textarea>
                   
                      </div>

                     <div class="form-group"><span>Status</span>
                        <input type="checkbox" name="status" id="status_1"value="1"  @if (!is_null(old("status")) && old("status") == 1) checked @endif> 
                       <label for="status_1" class="lbl" id="switch-box"></label>

                      </div> 

                      <input type="submit" value="Create" onclick="saveblog()">
                     </form>
                     </div>
               </div>
               </div>
               
          </div>    
</section>


<script type="text/javascript">
  var redirect_url =  "{{ route('saveBlog') }}";
</script>

@endsection