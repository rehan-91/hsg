<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>DASHBOARD</title>
  <link rel="stylesheet" href="{{ asset('frontend/css/login/bootstrap.min.css') }}">
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="{{ asset('frontend/css/login/style.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ asset('frontend/css/login/responsive.css') }}" rel="stylesheet" type="text/css">
</head>

<body STYLE="background-color:#fff;">

<div class="container">
<div class="dashboard">
<h1>
HI ! THIS IS YOUR DASHBOARD. 
</h1>
<a href="{{route('changePassword')}}">Change Your Password</a>
<hr>
<a href="{{route('logout')}}">Logout</a>

</div>
</div>
</body>
</html>