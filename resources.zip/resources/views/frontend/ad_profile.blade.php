@extends('frontend.layouts.front_layout')
    @section('content') 
   
    <section class="profile-details-block main-profile">
      <div class="container">
        <div class="row justify-content-between">
          <div class="col-md-4">
            <div class="w-100 left_container">
              <div class="cnt profile_page">
                <h2 class="float-left">{{$data['adName'] ."-". $data['metadata']['age'][0]}} Yrs</h2>

                <div class="button_section">
                  <div class="btns float-right"><span class="btn form-control"><img class="mr-2" src="frontend/images/live-green.png">LIVE</span></div>
                  
                </div>
                 <div class="City_name">Auckland</div>
                <div class="clearfix"></div>
                <div class="services_card">
                  <ul>
                    <li>Multi Shots</li>
                    <li>Blow Job</li>
                    <li>Body Slide</li>
                    <li>Breast Play</li>
                    <li>French Kissing</li>
                    <li>Deep Throat</li>
                  </ul>
                </div>
              </div>
              <div class="clearfix"></div>
              <div class="agencies_section">
                <div class="agency_logo"><img src="frontend/images/escort-bitches.png"/></div>
                <div class="agency_info">
                  <div class="agency_name">Escort Bitches</div>
                  <div class="managed_by">Managed by Escort Bitches</div>
                  <div class="short_button"><a href="#">View Profile <img class="arrow-img" src="frontend/images/right-arrow-red.png"></a></div>
                </div>
              </div>
              <div class="clearfix"></div>
              		  
			  @if (\Session::has('shortlist_status'))
              <div class="shortlist_button mt-4">
			  <a href="/" onclick="return false;" style="background-color:green;">{!! \Session::get('shortlist_status') !!}</a>
			  </div>
	         
	          @else
			  <div class="shortlist_button mt-4">
			  <a href="#">+ Shortlist</a>
			  </div>
              @endif
			  
              
			  <div class="clearfix"></div>
              <div class="contact_section">
                <div class="contact_detail">
                  <div class="icon"><img src="frontend/images/profile-phone.png"></div>
                  <div class="phone-number"><span>Phone</span><br>02102420034</div>
                </div>
                <div class="contact_detail">
                  <div class="icon"><img src="frontend/images/profile-whatsapp.png"></div>
                  <div class="phone-number"><span>Phone</span><br>02102420034</div>
                </div>
             <ul class="followus mt-5 float-left">
            
            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          </ul>

              </div>
              <div class="clearfix"></div>
              <div class="w-100 profile_cnt">
                <div class="cnt">
                  
                  <h2>Profile details</h2>
                  
                  <div class="listing">
                    
                    <div class="list"><span class="label">Age :</span>
					@foreach($age as $value )
		{{$value->meta_value}}
		@endforeach
		</div>
                    <div class="list"><span class="label">Ethnisity :</span>
								@foreach($nationality as $value )
		{{$value->meta_value}}
		@endforeach
		
					</div>
                    <div class="list"><span class="label">Orientation :</span>
					@foreach($orientation as $value )
		{{$value->meta_value}}
		@endforeach
		</div>
                    <div class="list"><span class="label">Tattoos :</span> YES</div>
                    <div class="list"><span class="label">Bust Size :</span>
					@foreach($bustsize as $value )
		{{$value->meta_value}}
		@endforeach
		</div>
                    <div class="list"><span class="label">Dress Size :</span> 8</div>
                    <div class="list"><span class="label">Height :</span>
					@foreach($height as $value )
		{{$value->meta_value}}
		@endforeach
		</div>
                    <div class="list"><span class="label">Eye color :</span> 
					@foreach($eyecolor as $value )
		{{$value->meta_value}}
		@endforeach
					</div>
                    <div class="list"><span class="label">Hair Color :</span> 
					@foreach($haircolor as $value )
		{{$value->meta_value}}
		@endforeach
					</div>
                  </div>
                  
                </div>
              </div>
              <div class="w-100 profile_cnt">
                <div class="cnt">
                  <h2>Info</h2>
                  <div class="listing">
                    <div class="list"><span class="label">Languages :</span> English</div>
                    <div class="list"><span class="label">Place of Service :</span> Incall</div>
                    <div class="list"><span class="label">Meeting with :</span> Men</div>
                  </div>
                </div>
              </div>
              <div class="w-100 profile_cnt">
                <div class="cnt">
                  <h2>About Alice</h2>
                  <p class="text-left text-white">I'm a MILF who welcomes both younger and older gentlemen
                    to visit me at my private address in Point Chevalier, Auckland.I
                    have an extroverted personality and love to chat and have fun.
                    I will absolutely have you anticipating your next session with
                    me, as you'll totally enjoy my magical touch all over your body!
                    My hobbies include dancing and dance choreography, playing
                    music, sailing, classic American cars, riding motorcycles and it's
                  noticeable I lead a health and fitness lifestyle.</p>
                  <div class="short_button"><a href="#">View Profile <img class="arrow-img" src="frontend/images/right-arrow-red.png"></a></div>
                </div>
              </div>
              <div class="w-100 profile_cnt">
                <div class="cnt">
                  <h2>Service & Charges</h2>
                  <table class="table text-white table-data">
                    <thead>
                      <tr>
                        
                        <th scope="col" width="25%">Time</th>
                        <th scope="col" width="25%">Charges</th>
                        <th scope="col" width="50%">Services</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        
                        <td>{{ $ad_time }}</td>
                        <td>{{ $ad_charges }}</td>
                        <td>{{ $ad_services }}</td>
                        
                      </tr>
                      <tr>
                        
                        <td>{{ $ad_time_2 }}</td>
                        <td>{{ $ad_charges_2 }}</td>
                        <td>{{ $ad_services_2 }}</td>
                        
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="w-100 profile_cnt">
                <div class="cnt">
                  <h2>Extra Services & Charges</h2>
                  <table class="table text-white table-data">
                    <thead>
                      <tr>
                        
                        <th scope="col" width="40%">Charges</th>
                        <th scope="col" width="60%">Extra Services</th>
                        
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        
                        
                        <td>$120</td>
                        <td>Greek, GFE, BDSM, Strap on,Rimjob</td>
                      </tr>
                      <tr>
                        
                        <td>$180</td>
                        <td>Greek, GFE, BDSM, Strap on,Rimjob</td>
                      </tr>
                      <tr>
                        
                        <td>$280</td>
                        <td>Greek, GFE, BDSM, Strap on,Rimjob</td>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="w-100 profile_cnt">
                <div class="cnt">
                  <h2>My Availibility</h2>
                  <div class="listing">
                    <div class="list"><span class="label">Monday :</span> Off</div>
                    <div class="list"><span class="label">Tuesday :</span> 12 Noon till 5pm</div>
                    <div class="list"><span class="label">Wednesday :</span> Off</div>
                    <div class="list"><span class="label">Thursday :</span> 1pm till 10pm</div>
                    <div class="list"><span class="label">Friday :</span> 6am till 10pm</div>
                    <div class="list"><span class="label">Saturday :</span> Off</div>
                    <div class="list"><span class="label">Sunday :</span> Off</div>
                    
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-8">
            <div class="right_container">
              <div class="top_bar_section text-white">
                <div class="shortlist_count"><img src="frontend/images/shorlist_heart.png"/> 89</div>
                <div class="photos_veryfied"><img src="frontend/images/green_check.png"/> Photos Verified</div>
                
              </div>
              <div class="video_section">
                <div>
                  <video width="100%" controls="controls" poster="frontend/images/video-poster.jpg" preload="true">
                    <source src="video/Wildlife.mp4" type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                </div>
              </div>
              <div class="profile_gallery">
                <div class="row">
                  <div class="col-md-6"><img src="frontend/images/profile_gallery.jpg"></div>
                  <div class="col-md-6"><img src="frontend/images/profile_gallery.jpg"></div>
                </div>
              </div>
              <div class="profile_gallery">
                <div class="row">
                  <div class="col-md-6"><img src="frontend/images/profile_gallery.jpg"></div>
                  <div class="col-md-6"><img src="frontend/images/profile_gallery.jpg"></div>
                </div>
              </div>
            </div>
            
          </div>
          <div class="clearfix"></div>
        </div>
        <div class="recommended_section">
          <h3 class="text-white text-center">Our Similar & recommended <span>Escorts</span></h3>
          <div class="row">
            <div class="col col1"><img class="img-fluid" src="frontend/images/recommended_escorts.jpg"/></div>
            <div class="col col2"><img class="img-fluid" src="frontend/images/recommended_escorts.jpg"/></div>
            <div class="col col3"><img class="img-fluid" src="frontend/images/recommended_escorts.jpg"/></div>
            <div class="col col4"><img class="img-fluid" src="frontend/images/recommended_escorts.jpg"/></div>
            <div class="col col5"><img class="img-fluid" src="frontend/images/recommended_escorts.jpg"/></div>
          </div>
        </div>
      </div>
    </section>


<script type="text/javascript">
$(document).ready(function(){
$("#wizard").steps();
});
</script>
<script type="text/javascript">
   $(function(){
  $('.startdate').datepicker({
  uiLibrary: 'bootstrap4',
})
});

</script>
<script type="text/javascript">
   $(function(){
  $('.enddate').datepicker({
  uiLibrary: 'bootstrap4',
})
   });


</script>
<script type="text/javascript">
$( document ).ready(function() {
$('a[href$="#previous"]').addClass('previous');
});
</script>
<script>
$(document).ready(function(){
$("#social1").select2();

$(".select_box").select2();
$(".service_select_box").select2();
});


</script>
<script>
$(document).ready(function(){
$(".services_rates:first .remove-rate").css('display','none');
$(".services_rates:first .add-rate").css('width','100%');



});
var current_id = 0;
function addRate(){
 /* var $div = $('[id^="services_rates"]:last');
  var num = parseInt( $div.prop("id").match(/\d+/g), 10 ) +1;
  var $klon = $div.prop('id', 'services_rates'+num );
  $div.after( $klon.text('services_rates'+num) );
  */

  if ($('.service_select_box').data('select2')) {
    $(".service_select_box").select2("destroy");
    $('.service_select_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }


var num =  $('.services_rates').length;
var clone = $(".services_rates").first().clone();
clone.insertBefore('#tool-placeholder');
clone.attr('id', 'test'+num);
clone.find("select").attr("id", "services_rates_"+num);
$(".service_select_box").select2({}); 
//id = $(".services_rates:last select").attr('id', 'services_rates_'+num);
$(".services_rates:last .remove-rate").css('display','inline-block');
$(".services_rates:last .add-rate").css('width','70%');


}
function removeRate(){
$(".services_rates:last .remove-rate").closest('.services_rates').remove();
}
</script>
<script>
$(document).ready(function(){
$(".touring_girls:first .remove-tour").css('display','none');
$(".touring_girls:first .add-tour").css('width','100%');



});
function addTour(){
  if ($('.select_box').data('select2')) {
    $(".select_box").select2("destroy");
    $('.select_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }
 
var num =  $('.touring_girls').length;
console.log(num);
var clone = $(".touring_girls").first().clone();

clone.attr('id', 'touring_girls'+num);
clone.find("select").attr("id", "touring_girls_"+num);
clone.find('.enddate').val('').removeClass('hasDatepicker');
clone.find('.startdate').val('').removeClass('hasDatepicker');
clone.find(':input.startdate').attr("id", "startdate"+num);
clone.find(':input.enddate').attr("id", "enddate"+num);
clone.find('#startdate'+num).datepicker();
clone.insertBefore('#touring-section-placeholder');


$(".enddate").datepicker({
 // uiLibrary: 'bootstrap4',
});
$(".startdate").datepicker({
 // uiLibrary: 'bootstrap4',
});

$(".select_box").select2({}); 
$(".touring_girls:last .remove-tour").css('display','inline-block');
$(".touring_girls:last .add-tour").css('width','70%');
}
function removeTour(){
$(".touring_girls:last .remove-tour").closest('.touring_girls').remove();
}
</script>
<script type="text/javascript">
$(document).ready(function() {
document.getElementById('pro-image').addEventListener('change', readImage, false);

$( ".preview-images-zone" ).sortable();

$(document).on('click', '.image-cancel', function() {
let no = $(this).data('no');
$(".preview-image.preview-show-"+no).remove();
});
});
var num = 4;
function readImage() {
if (window.File && window.FileList && window.FileReader) {
var files = event.target.files; //FileList object
var output = $(".preview-images-zone");
for (let i = 0; i < files.length; i++) {
var file = files[i];
if (!file.type.match('image')) continue;

var picReader = new FileReader();

picReader.addEventListener('load', function (event) {
var picFile = event.target;
var html =  '<div class="preview-image preview-show-' + num + '">' +
  '<div class="image-cancel" data-no="' + num + '">x</div>' +
  '<div class="image-zone"><img id="pro-img-' + num + '" src="' + picFile.result + '"></div>' +
  '<div class="radio radio-info form-check-inlinesquarebox image-zone1"> <input type="checkbox" name="available-women" id="pro-img1-' + num + '" class="css-checkbox"><label for="pro-img1-' + num + '" class="css-label">Set as main image</label></div>'
'</div>';
output.append(html);
num = num + 1;
});
picReader.readAsDataURL(file);
}
$("#pro-image").val('');
} else {
console.log('Browser not support');
}
}
</script>
		@endsection