@extends('frontend.layouts.default_layout')
@section('content')
    <div class="container">
      <div class="row">
        <!-- Latest Posts -->
        <main class="post blog-post col-lg-8"> 
          <div class="container">

            <div class="post-single">

              <div class="post-thumbnail"> 
				       @php
				        $imageurl = url('uploads/ads_image/'.$blogdata->blog_featured_img);
				       @endphp
				        <img src="{{ $imageurl }}" class="figure-img img-fluid rounded" alt="dummyaccountseeting-" width="30%">
				       
              </div>

              <div class="post-details">
                <div class="post-meta d-flex justify-content-between">
                  <div class="category">
                  	<a href="#">Business</a>
                  	<a href="#">Financial</a>
                  </div>
                </div>
                <h1>{{$blogdata->blog_title}}<a href="#"><i class="fa fa-bookmark-o"></i></a>
                </h1>
                <div class="post-footer d-flex align-items-center flex-column flex-sm-row">
                	<a href="#" class="author d-flex align-items-center flex-wrap">
                    <div class="avatar">
                    	@if(empty($blogdata->users->user_image))
                    
				 	 <img src="{{asset('frontend/images/user-profile-icon.png')}}" class="figure-img img-fluid rounded" alt="user" width="10%">
				       @else
				       @php
				        $imageurl = url('uploads/users/'.$blogdata->users->user_image);
				       @endphp
				        <img src="{{ $imageurl }}" class="figure-img img-fluid rounded" alt="dummyaccountseeting-" width="30%">
				        @endif
                    </div>

                    <div class="title">
                    	<span>{{$blogdata->users->name}}</span>
                    </div>
                	</a>
                  <div class="d-flex align-items-center flex-wrap">       
                    <div class="date">
                    	<i class="icon-clock"></i>
                    	 {{$blogdata->created_at->diffForHumans()}}
                    	</div>
                  </div> 
                </div>
                <div class="post-body">
                  <p class="lead">{{$blogdata->blog_desc}}
                  </p>
                                
                </div>
              </div>
            </div> <!---post single--->

          </div>
        </main>
 
      </div>
    </div>
    @endsection 