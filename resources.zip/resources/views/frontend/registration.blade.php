<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Sign Up</title>
  <link rel="stylesheet" href="{{ asset('frontend/css/login/bootstrap.min.css') }}">
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="{{ asset('frontend/css/login/style.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ asset('frontend/css/login/responsive.css') }}" rel="stylesheet" type="text/css">
</head>

<body id="login_bg">


  <section class="login-mainblock padding1">
    <div class="container">

      <div class="col-sm-12 col-sm-5 col-lg-5 logincenter " id="signup-container">

        <div class="loginform-top">
          <h1>Sign Up</h1>
          <div class="craft-form">
            <form action="{{ route('saveregistration') }}" name="register" id="register" method="post" onsubmit="return false;">
              {{ csrf_field() }}

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop">
                    <input type="text" class="form-control LoginInputForm" placeholder="Name" name="name" id="name">
                    <span class="help-block hidden name_error"></span>
                  </div>
                </div>
              </div>
              
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop">
                    <input type="text" class="form-control LoginInputForm" placeholder="Email" name="email" id="email">
                    <span class="help-block hidden email_error"></span>
                  </div>
                </div>
              </div>

            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop">
                    <input type="tel" class="form-control LoginInputForm" placeholder="Phone" name="phone" id="phone">
                    <span class="help-block hidden phone_error"></span>
                  </div>
                </div>
              </div>

              <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="row">
                  <label for="usertype" class="radio-uertype-label">You Are:</label>
                  <div class="form-group LoginFormGrop radiogroup-class">

                    <input type="radio" name="usertype" id="usertype" value="Employer" /> Employer
                    <input type="radio" name="usertype" id="usertype" value="Individual" /> Individual
                    <input type="radio" name="usertype" id="usertype" value="Agency" /> Agency
                    <span class="help-block hidden usertype_error"></span>
                  </div>
                </div>
              </div>
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop">
                    <input type="password" class="form-control LoginInputForm" placeholder="Password" name="password" id="password">
                    <span class="help-block hidden password_error"></span>
                  </div>
                </div>
              </div> 

                <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop has-error">
                    <span class="help-block hidden g-recaptcha-response_error"></span>
                    {!! NoCaptcha::display() !!}
                      {!! NoCaptcha::renderJs() !!}
          
                   
                  </div>
                </div>
              </div>

              <div class="buttonblock">
                <div class="row">
                  <div class="col-sm-12">
                    <button type="submit" class="login-btn" onclick="add_user_registration()">Sign Up</button></div>
                </div>
              </div>

            </form>
          </div>

        </div>

      </div>
     
    </div>
  </section>

  <script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
  <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
  <script>
    function add_user_registration() {
      jQuery(".help-block").addClass("hidden");
      jQuery(".input-box").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("register"));
      jQuery.ajax({
        type: 'POST',
        dataType: "JSON",
        url: "{!! route('saveregistration') !!}",
        data: registration_form,
        processData: false,
        contentType: false,
        success: function(data) {
          if (data.errors) {
            jQuery.each(data.errors, function(key, value) {
              jQuery("." + key + "_error").html(value);
              jQuery("." + key + "_error").removeClass("hidden");
              jQuery("#" + key).parent().addClass("has-error");
            });


            jQuery('html, body').animate({
              scrollTop: parseInt(jQuery('.has-error:visible:first').offset().top) - 10
            }, 1000);
          } else if (data.success) {
            jQuery("#signup-container").fadeOut("fast");
            jQuery("#user-verification-section").fadeIn("slow");
            var redirect_url = data.redirect_response;
            window.location.href = redirect_url;
          }
        },
      });
    }
  </script>
</body>

</html>