@extends('frontend.layouts.default_layout')

@section('header-css')
<link href="{{ asset('registrations/css/bootstrap.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/font-awesome.min.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/responsive.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_css.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_responsive.css') }}" rel="stylesheet">
@endsection

@section('content')
  <div class="container">
	@if( intval( $is_success ) == 0 )
	<div class="white-bg otp-main">
	  <div class="otp-icon">
		<img src="{{ asset('registrations/images/otp-icon.png') }}">
	  </div>
	  <h3>{!! trans('translations.frontend.otp_verify_title') !!}</h3>
	  <p>
		+91 - <input type="text" class="edit-otp" id="agent_contact_number" name="agent_contact_number" value="{{ $contact_number }}" readonly disabled>
		@if( intval( $otp_is_updatable ) == 1 )
			<a href="Javascript:void(0);" id="edit_button" data-toggle="tooltip" data-placement="top" title="Edit"><img src="{{ asset('registrations/images/edit-icon.png')}}"></a>
			<a href="Javascript:void(0);" id="update_button" style="display:none;" data-toggle="tooltip" data-placement="top" title="Update"><img src="{{ asset('registrations/images/update.png')}}"></a>
			<a href="Javascript:void(0);" id="cancel_button" style="display:none;" data-toggle="tooltip" data-placement="top" title="Cancel"><img src="{{ asset('registrations/images/cancel.png')}}"></a>
			<span class="help-block popup-text-err" style="display:none;" id="agent_contact_number_error"></span>
		@endif
	  </p>
		
		
	  <form id="agent_otp_verify" name="agent_otp_verify" action="{{ route('agentotpverify') }}" method="POST">
		{{ csrf_field() }}
		<h4>{!! trans('translations.frontend.otp_enter_code') !!}</h4>
		<div id="divOuter">
		  <div id="divInner" class="@if($errors->has('otp_code')) has-error @endif">
			<input name="otp_code" id="partitioned" type="text" maxlength="4" />
			@if($errors->has("otp_code"))
				<span class="help-block">{{ $errors->first("otp_code") }}</span>
			@endif
		  </div>
		</div>
		
		<div class="clearfix"></div>
		
		<small>{!! trans('translations.frontend.didnt_receive') !!} <a href="javascript:void(0)" onclick="ResendOtp()">{!! trans('translations.frontend.resend_code') !!}</a></small>
		<div class="clearfix"></div>
		<div id="ajax_success" class="alert alert-success" style="display:none;"></div>

		<div class="clearfix"></div>
		<button type="submit" class="orange-btn arrow-icon btn-cm text-center">{!! trans('translations.frontend.otp_verify') !!}</button>

	  </form>
	  
	</div>
	@endif
	@if( intval( $is_success ) == 1 )
	<div class="white-bg otp-main success-otp">
	  <div class="otp-icon">
		<img src="{{ asset('registrations/images/otp-icon.png') }}">
	  </div>
	  <h2>{!! trans('translations.frontend.congrate_text') !!}! </h2>
	  <p>{!! trans('translations.frontend.otp_mobile_updated') !!}</p>
	</div>
	@endif
  </div>
  <script>
	var access_token = jQuery("input[name=_token]").val();
	
	jQuery(document).ready(function(){
		jQuery('[data-toggle="tooltip"]').tooltip();
		
		jQuery("#edit_button").click( function(){
			jQuery("#agent_contact_number").prop("readonly", false);
			jQuery("#agent_contact_number").prop("disabled", false);
			jQuery("#agent_contact_number").addClass("otp-edit");
			jQuery("#agent_contact_number").removeClass("edit-otp");
			
			jQuery("#edit_button").fadeOut('fast');
			jQuery("#update_button").fadeIn('fast');
			jQuery("#cancel_button").fadeIn('fast');
		});
		
		jQuery("#cancel_button").click( function(){
			jQuery("#agent_contact_number").prop("readonly", true);
			jQuery("#agent_contact_number").prop("disabled", true);
			jQuery("#agent_contact_number").removeClass("otp-edit");
			jQuery("#agent_contact_number").addClass("edit-otp");
			
			jQuery("#update_button").fadeOut('fast');
			jQuery("#cancel_button").fadeOut('fast');
			jQuery("#edit_button").fadeIn('fast');
		});
		
		jQuery("#update_button").click( function(){
			jQuery.ajax({
				type: 'POST',
				dataType: "JSON",
				url: "{!! route('updateagentmobile') !!}",
				data: {
					"_token" : access_token,
					"agent_contact_number" : jQuery("#agent_contact_number").val(),
				},
				success: function(data){
					if( data.success ){
						jQuery("#agent_contact_number").prop("readonly", true);
						jQuery("#agent_contact_number").prop("disabled", true);
						jQuery("#agent_contact_number").removeClass("otp-edit");
						jQuery("#agent_contact_number").addClass("edit-otp");
						
						jQuery("#update_button").fadeOut('fast');
						jQuery("#cancel_button").fadeOut('fast');
						jQuery("#edit_button").fadeIn('fast');
					}
					else if( data.errors ){
						jQuery("#agent_contact_number_error").html( data.errors.agent_contact_number );
						jQuery("#agent_contact_number_error").css("display", "block");
					}
					
					setTimeout(function(){
						jQuery("#agent_contact_number_error").css("display", "none");
					},4000);
				}
			});
		});
	});
	  
	function ResendOtp(){
		jQuery.ajax({
			type: 'POST',
			dataType: "JSON",
			url: "{!! route('resendagentotp') !!}",
			data: {
				"_token" : access_token,
			},
			success: function(data){
				if( data.success ){
					jQuery("#ajax_success").html( "<p>" + data.success + "</p>" );
					jQuery("#ajax_success").show();
				}
				
				setTimeout(function(){
					jQuery("#ajax_success").hide();
				}, 4000);
			}
		});
	}
	
	var obj = document.getElementById('partitioned');
	obj.addEventListener("keydown", stopCarret); 
	obj.addEventListener("keyup", stopCarret); 

	function stopCarret() {
		if (obj.value.length > 4){
			setCaretPosition(obj, 4);
		}
	}

	function setCaretPosition(elem, caretPos) {
		if(elem != null) {
			if(elem.createTextRange) {
				var range = elem.createTextRange();
				range.move('character', caretPos);
				range.select();
			}
			else {
				if(elem.selectionStart) {
					elem.focus();
					elem.setSelectionRange(caretPos, caretPos);
				}
				else
					elem.focus();
			}
		}
	}
  </script>
  <style>
	#partitioned {
		/* padding-left: 10px; 
		letter-spacing: 45px;*/
		border: 0;
		/* background-image: linear-gradient(to left, #e5e5e5 70%, rgba(255, 255, 255, 0) 0%);
		background-position: bottom;
		background-size: 50px 1px;
		background-repeat: repeat-x;
		background-position-x: 35px; */
		letter-spacing: 10px;
		width: 130px;
		min-width: 130px;
		overflow: hidden;
		border-bottom: 2px solid #9299bd;
		text-align: center;
	}

	#divInner{
	  left: 0;
	  position: sticky;
	}

	#divOuter{
		  margin-bottom: 35px;
		overflow: hidden;
	}
.otp-edit {
    background: transparent;
    border: 0px;
    border-bottom: 1px solid #9299bd;
	width: 112px;
}
#divOuter .help-block, .popup-text-err {
    text-align: center;
}
.edit-otp{    background: transparent;
    border: 0px;
    width: 112px;}
</style>
@endsection