@extends('frontend.layouts.front_layout')
@section('content')


<section class="profile-details-block searchPageBlock">

     <div class="clearfix"></div>
     @include('frontend.layouts.partials.default.frontsearch')
     <div class="clearfix"></div>
     
     <div class="clearfix"></div>

     <div class="container">
          <div class="row">

               <div class="col-md-12">
                    <div class="row side_box">
                         <div class="col-12">
                              <h2>Search Results</h2>
                         </div>
                         <div class="clearfix"></div>
                         @foreach($result as $res)
                         <div class="col-md-2 mb-4 modelProfile">
                              <img class="img-fluid" src="{{ asset('frontend/images/1.jpg') }}">
                              <div class="live-btnpositon"> <span>live</span> </div>
                         </div>
                        @endforeach
                         <div class="col-12">
                              <h2>Search Results</h2>
                         </div>
                         <div class="clearfix"></div>


                    </div>

               </div>

          </div>
     </div>
</section>
@endsection