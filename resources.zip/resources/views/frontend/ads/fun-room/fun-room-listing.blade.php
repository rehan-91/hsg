@extends('frontend.layouts.front_layout')
@section('content')

<section class="funRooms-main padding-50">

<div class="photographer-steps">

<span class="glowing-border-blue"></span>

	  <h2><img src="images/funroom-heading.png" alt="funroom-heading"></h2>
	  <p>House of Sexy Girls have created this dynamic Fun Room features by inviting the individual property onwers who are letting their property by Hourly, Daily and Weekly basis on the resonable rates compares to the Hotels or Motels. Its like a private property having all the essentials for you and a good standard as well . so check out the below listed fun rooms.</p>	
	</div>
</section>

<div class="clearfix"></div>

<section class="funroom-listing-block padding-80">
  <div class=""><!--container div-->
     <div class="listing-contain">
	     
		 
		 <div class="img_slider_funroomlisting">
                  <div id="demo" class="carousel slide" data-ride="carousel">                                        
                    <!-- The slideshow -->
					<h2>name comes here</h2>
                    <div class="carousel-inner">
					   
					  
                      <div class="carousel-item active">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
					  <div class="funroom-motels-detail">
					      <div class="funroom-motels-location">
						   <h6>Location</h6>
						   Auckland, New Zealand
						  </div>
                          <div class="funroom-motels-location">
						    <h6>Phone</h6>
						   02102420034
						  </div>	
                             
							 <a class="motels-fulldetails-btn" href="#">view full details</a>
                             						  
					  </div>					  
                    </div>                   
                  </div>
                </div>
								
				<div class="img_slider_funroomlisting remove-afterline">
                  <div id="demo" class="carousel slide" data-ride="carousel">                                        
                    <!-- The slideshow -->
					<h2>name comes here</h2>
                    <div class="carousel-inner">
					   					  
                      <div class="carousel-item active">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
					  <div class="funroom-motels-detail">
					      <div class="funroom-motels-location">
						   <h6>Location</h6>
						   Auckland, New Zealand
						  </div>
                          <div class="funroom-motels-location">
						    <h6>Phone</h6>
						   02102420034
						  </div>	
                             
							 <a class="motels-fulldetails-btn" href="#">view full details</a>
                             						  
					  </div>					  
                    </div>                   
                  </div>
                </div>
				
				
				<div class="clearfix margin-between"></div>
				
				
				<div class="img_slider_funroomlisting">
                  <div id="demo" class="carousel slide" data-ride="carousel">                                        
                    <!-- The slideshow -->
					<h2>name comes here</h2>
                    <div class="carousel-inner">
					   					  
                      <div class="carousel-item active">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
					  <div class="funroom-motels-detail">
					      <div class="funroom-motels-location">
						   <h6>Location</h6>
						   Auckland, New Zealand
						  </div>
                          <div class="funroom-motels-location">
						    <h6>Phone</h6>
						   02102420034
						  </div>	
                             
							 <a class="motels-fulldetails-btn" href="#">view full details</a>
                             						  
					  </div>					  
                    </div>                   
                  </div>
                </div>
				
				
				<div class="img_slider_funroomlisting remove-afterline">
                  <div id="demo" class="carousel slide" data-ride="carousel">                                        
                    <!-- The slideshow -->
					<h2>name comes here</h2>
                    <div class="carousel-inner">
					   					  
                      <div class="carousel-item active">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
                      <div class="carousel-item">
                        <img class="img-fluid" src="images/funroom-listing-motels.jpg" alt="funroom-listing-motels">						
                      </div>
					  
					  <div class="funroom-motels-detail">
					      <div class="funroom-motels-location">
						   <h6>Location</h6>
						   Auckland, New Zealand
						  </div>
                          <div class="funroom-motels-location">
						    <h6>Phone</h6>
						   02102420034
						  </div>	
                             
							 <a class="motels-fulldetails-btn" href="#">view full details</a>
                             						  
					  </div>					  
                    </div>                   
                  </div>
                </div>
	 
	 </div>   
  </div>
</section>

<div class="clearfix"></div>
<section class="redbar-cta text-center">
  <div class="container-fluid">
    <div class="row">
      <div class="cta-text">
        <p>Be a proud member of <span class="chlsHseTxt">House of</span> <span class="chlsSxyTxt">Sexy Girls</span></p>
        <a class="post-addcta-btn" href="#">Post your ad now</a></div>
    </div>
  </div>
</section>
<div class="clearfix"></div>
<section class="bottom-advertiseblock padding-50">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="images/advertise-img.jpg" class="img-fluid" alt="img"></div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="images/advertise-img1.png" class="img-fluid" alt="img"></div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="images/advertise-img2.png" class="img-fluid" alt="img"></div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="images/advertise-img3.png" class="img-fluid" alt="img"></div>
      </div>
    </div>
  </div>
</section>


<script>
  jQuery(document).ready(function() {
  jQuery('.overlay').hide();
  });
  jQuery(document).ready(function() {
  jQuery('.test1').hover(function() {
  jQuery('.overlay').show();
  },
  function() {
  jQuery('.overlay').hide();
  });
  });
  </script>  
<script>
// Autoplay
            $('#box4').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 5000,
                autoplayPauseOnHover: true
            });
			
			     $('#box5').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 4000,
                autoplayPauseOnHover: true
            });
			
			     $('#box6').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 3000,
                autoplayPauseOnHover: true
            });
			
				     $('#box7').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 2000,
                autoplayPauseOnHover: true
            });
			
				     $('#box8').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 6000,
                autoplayPauseOnHover: true
            });
			
			// Buttons
            $('button.prev').click(function() {
                $(this).closest('.item').find('.box').flipbox('prev', $(this).hasClass('reverse'));
            });
            $('button.next').click(function() {
                $(this).closest('.item').find('.box').flipbox('next', $(this).hasClass('reverse'));
            });
            $('button.jump').click(function() {
                $(this).closest('.item').find('.box').flipbox('jump', $(this).data('index'), $(this).hasClass('reverse'));
            });
            $('button.config').click(function() {
                $(this).closest('.item').find('.box')
                    .flipbox({
                        animationDuration: $(this).data('duration'),
                        animationEasing: $(this).data('easing')
                    })
                    .flipbox('next');
					
					});
</script>

<script>
var vid = document.getElementById("gossVideo"); 

function playVid() { 
    vid.play(); 
} 

function pauseVid() { 
    vid.play(); 
} 
</script>


<style>

.box {width: 300px; height: 450px; margin: 0px 10px 10px 0; font-size: initial; display:inline-block; position:relative;}
            .box .side {line-height: 230px; font-size: 80px; font-weight: 700; color: #fff; text-align: center; user-select: none;}
			
          .flipSlide-btn .prev, .flipSlide-btn .next {
    border: 0;
    text-indent: 0;
    font-size: 0;
    width: 15px;
    height: 15px;
    display: inline-block;
    vertical-align: middle;
    border-radius: 100px;
    background: #f00;
	cursor:pointer;
	margin:5px;
	transition:all 0.3s linear 0s;
} 

.flipSlide-btn .prev:hover, .flipSlide-btn .next:hover{
	background:#fff;
	transition:all 0.3s linear 0s;
}

    
.flipSlide-btn {
    margin-top: 40px;
}  

.item .box .live-btnpositon {   
    line-height: normal;
}     

.item .box .live-btnpositon span:after{
	top:7px;
}
            
</style>
@endsection