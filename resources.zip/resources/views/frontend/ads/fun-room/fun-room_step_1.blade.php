<div class="content_block step_1 content">
        <form action="{{route('photographerad.savephotographerdetails')}}" method="post" onsubmit="return false;" id="form_step_1" >
            <h2 class="text-danger">Details</h2>             
              <div class="setup-content" id="step-1"> 
                <div class="profile-details-form">    
                  <div class="contact-box">
                    <h4>Contact</h4>
                    <div class="row">
                    {{ csrf_field() }} 

                      <div class="form-group col-md-4">
                        <input type="text" class="form-control"  placeholder="*Name" name="name" required="">
                      </div>

                    <div class="form-group col-md-4">
                        <input type="email" class="form-control"  placeholder="*Email Address" name="email" required="">
                      </div>
                      
                       <div class="form-group col-md-4">
                        <input type="text" class="form-control" placeholder="*Phone Number" required="" maxlength="13" minlength="10">
                      </div>

                         <div class="form-group col-md-4">
                            <select class="form-control"  name="country_name"   onchange="getCity(this.value)" id="country_name" required>
                            <option value=''>Select Location</option>
                            @foreach($countries as $country)
                                    <option value="{{ $country->id }}">{{ $country['country_name']  }}</option>
                                    @endforeach

                            </select>
                        </div>

                    <div class="form-group col-md-4">
                        <select class="form-control" name="city_name" id="city_name" placeholder="City"  required>

                            <option value=''>City</option>
                        </select>
                        </div>
                        <div class="form-group col-md-4">
                        <input type="text" class="form-control" placeholder="Suburbs" name="suburbs" required="">
                        </div>
                      
                       <div class="form-group col-md-4">
                        <input type="text" class="form-control"  placeholder="Work Experience" required="">                      
                      </div>                       
                    </div>
                  </div>
                  
                  
                  
                   <div class="profile_photos">
                
                <h4><sup class="text-danger">*</sup>Upload Banner</h4>
                <div class="preview-images-zone">
                  <fieldset class="form-group">
                    <div class="field_set">
                      <a href="javascript:void(0)" onclick="$('#pro-image').click()"><span class="pkus_icon">+</span><br/>Add Banner</a>
                      <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control" multiple required="">
                    </div>                    
                  </fieldset>
                  
                  <div class="clearfix"></div>
                 
                  
                </div>
                 <div class="form-group">
                    <textarea class="form-control custom-textarea" id="exampleFormControlTextarea1" rows="3" placeholder="Hi Ladies and Gentle Man, I am John. I have 10 years exp. in the erotic and adult photography."></textarea>
                  
                  </div>
              </div>
              
              <div class="clearfix"></div>
              
              
              <div class="profile_photos">
                
                <h4>Upload Photos</h4>
                <div class="preview-images-zone">
                  <fieldset class="form-group">
                    <div class="field_set">
                      <a href="javascript:void(0)" onclick="$('#pro-image').click()"><span class="pkus_icon">+</span><br/>Add Photos</a>
                      <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control" multiple required="">
                    </div>
                    <div class="max-photos">Max 40 High Quality Photos</div>
                  </fieldset>
                  
                  
                </div>
              </div>
              
              
              <div class="clearfix"></div>
              
              
              <div class="profile_photos">
                
                <h4>Upload Videos</h4>
                <div class="preview-images-zone">
                  <fieldset class="form-group">
                    <div class="field_set">
                      <a href="javascript:void(0)" onclick="$('#pro-image').click()"><span class="pkus_icon">+</span><br/>Add Videos</a>
                      <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control" multiple>
                    </div>
                    <div class="max-photos">Max  5 HD Video, length 3 mins each</div>
                  </fieldset>
                  
                  
                </div>
              </div>
              
                 
                  <div class="clearfix"></div>
                 
                </div>
        <div class="actions clearfix step_1">
            <ul role="menu" aria-label="Pagination">
                <li></li>
                <li aria-hidden="false" aria-disabled="false">
                
                        <input type="submit" name="next_step_1" value="Save & Next" id="next_step_1" class="NextBTN">               
                    </li>
                <li></li>
                
            </ul>
        </div>
              </div>
          </form>
      </div>
            