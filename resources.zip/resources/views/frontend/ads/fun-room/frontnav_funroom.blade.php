<div class="steps clearfix">
                <ul class="tablist" role="tablist">
                    <li role="tab" class="first current" aria-disabled="false" aria-selected="true">
                        <a id="wizard-t-0" href="#wizard-h-0" aria-controls="wizard-p-0">
                            <span class="current-info audible info">current step: </span>
                            <span class="number"><span>1</span></span> Details</a>
                    </li>
                    <li role="tab" class="second disabled" aria-disabled="true">
                        <a id="wizard-t-1" href="#wizard-h-1" aria-controls="wizard-p-1">
                            <span class="number"><span>2</span></span> Upgrade</a>
                    </li>
                    <li role="tab" class="three disabled" aria-disabled="true">
                        <a id="wizard-t-2" href="#wizard-h-2" aria-controls="wizard-p-2">
                            <span class="number"><span>3</span></span> Services</a>
                        </li> 
                        <li role="tab" class="four disabled" aria-disabled="true">
                            <a id="wizard-t-3" href="#wizard-h-3" aria-controls="wizard-p-3">
                                <span class="number"><span>4</span></span> Photos</a>
                    </li>
            
                    <li role="tab" class="disabled last" aria-disabled="true">
                        <a id="wizard-t-4" href="#wizard-h-4" aria-controls="wizard-p-4">
                            <span class="number"><span>5</span></span> Finished</a>
                    </li>
                </ul>
            </div>