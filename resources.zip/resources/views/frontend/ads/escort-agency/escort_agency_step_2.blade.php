<div class="content_block step_2" style="display:none;">
        <section class="pay-boxz">
            <div class="container">
                
                <div class="row">
                   <div class="content_block">
            
            <div class="select_escorts-block">
              <h2 class="text-danger">Select Escorts</h2>                        
             <div class="profile-details-form">             
                                   
                    <div class="row">                   
                    <div class="form-group col-md-4">
                        <input type="number" class="form-control" placeholder="Enter Number of Escorts *">
                      </div>                      
                    </div>
                                 
                </div>
                </div>
           </div> 
                </div>
            </div>

        </section>
    </div>
    <div class="actions clearfix step_2" style="display:none;">
        <ul role="menu" aria-label="Pagination">
            <li>
               <input type="button" value="Previous" class="previous PreviousBTN" name="prev_step_2" id="prev_step_2">
            </li>
            <li>
            <input type="button" value="Next" class="next NextBTN" name="next_step_2" id="next_step_2">
            </li>
            <li>
            </li>
        </ul>
    </div>

      <!-- select number of model modal pop up start -->
<div class="modal fade services-addTime" id="selected-escortsmodel" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Selected Number of Escorts - <span>04</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h2>Plan & Subscription</h2>
        <h3>Daily Rate for single Ad NZ$16.99 (24hours)</h3>
        
        <div class="clearfix"></div>
        
        <div class="escorts-total-charge">
           <h6>Choose your plan:</h6>
        
        <ul>
            <li><input type="radio" name="radiog_dark" id="radio6" class="css-checkbox" /><label for="radio6" class="css-label radGroup2">01  Day - NZ$16.99</label></li>
            
            <li><input type="radio" name="radiog_dark" id="radio7" class="css-checkbox" /><label for="radio7" class="css-label radGroup2">04 Day - NZ$67.96 x 4  = NZ$271.84</label></li>
            
            <li><input type="radio" name="radiog_dark" id="radio8" class="css-checkbox" /><label for="radio8" class="css-label radGroup2">07  Day - NZ$118.93</label></li>
            
            <li><input type="radio" name="radiog_dark" id="radio9" class="css-checkbox" /><label for="radio9" class="css-label radGroup2">14   Day - NZ$237.86</label></li>
        
        </ul>
        
        </div>    
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="button" class="servicespopupSave-btn selectescorts-proccedbtn">proceed</button>
        
        <button type="button" class="selectedescorts-backbtn">back</button>
        
      </div>
    </div>
  </div>
</div>
<!-- select number of model modal pop up End -->
