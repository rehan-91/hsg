@extends('frontend.layouts.front_layout')
@section('content')

<section class="funroom-profileSlider-block">
    <div class="demo">
  <h2>Name comes here</h2>
 <ul id="lightSlider">
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
         <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li> <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li> <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
        <li data-thumb="{{asset('frontend/images/advertise-img3.png')}}">
           <img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img">
        </li>
    </ul> 
</div>
</section>

<div class="clearfix"></div>

<section class="funroom-motels-details">
    <div class="container">
       <div class="funroom-motelDetail-top">
        <h5>{{getCityCountry($data['adLocation'])}}</h5>
      <span><img src="{{asset('frontend/images/vacancy-title-img.png')}}" alt="vacancy-title"></span>
      
             <div class="public_likesdiv funroom-likes-block">
                <div id="music" class="heartbadge-iconhover">
                <div class="heartbadge-icon">
                    <img src="{{asset('frontend/images/badge-icon5.png')}}">
                </div>
                </div>

                <div class="photos_veryfied text-white">
                  <img src="{{asset('frontend/images/photosverified-icon.png')}}"> Photos Verified</div>
                
            </div>
        
        <div class="clearfix"></div>
        
        <p>We have the best room to hire on Hourly, Daily, Weekly Basis</p>
        </div>
        
        <div class="clearfix"></div>
        
        
        <div class="funroom-details-block">
        
        <div class="contact_section">       
            <h3>Contact details</h3>        
                <div class="contact_detail">
                  <div class="icon"><img src="{{asset('frontend/images/profile-phone.png')}}"></div>
                  <div class="phone-number"><span>Text Message</span><br>{{$data['adContact']}}</div>
                </div>
                <div class="contact_detail">
                  <div class="icon"><img src="{{asset('frontend/images/profile-whatsapp.png')}}"></div>
                  <div class="phone-number"><span>whatsapp</span><br>{{$data['adContact']}}</div>
                </div>
        
                <div class="contact_detail">
                  <div class="icon"><img src="{{asset('frontend/images/profile-phone.png')}}"></div>
                  <div class="phone-number"><span>Phone</span><br>{{$data['adContact']}}</div>
                </div>
        
               <div class="clearfix"></div>
        
                <div class="contact_detail profilemail-contact">
                  <div class="icon"><img src="{{asset('frontend/images/email-dashboardicon.png')}}"></div>
                  <div class="phone-number">{{$data['adEmail']}}</div>
                </div>
        
          
          <div class="clearfix"></div>
                          
          <div class="subscribe-block">
            <a href="javascript:void;"><img src="{{asset('frontend/images/share-red-icon.png')}}"> share</a>

            <a href="#" data-toggle="modal" data-target="#subscribeProfile-popup">
              <img src="{{asset('frontend/images/subscribe-red-icon.png')}}"> subscribe</a>

            <a href="#" data-toggle="modal" data-target="#reportThisadd">
              <img src="{{asset('frontend/images/report-red-icon.png')}}"> report</a>

              <a href="#" data-toggle="modal" data-target="#testimonial-popup"><!-- <img src="{{asset('frontend/images/testimonials.png')}}"> --><i class="fa fa-quote-left"></i> testimonials</a>

          </div>                  
     </div>
           
    <div class="funroom-followme-block">
        
       <div class="followme">
          <h3>Follow me on</h3>

         <ul>

          @foreach($social_media_links as $mlinks)
           @if(!empty($data['metadata']['social_links_'.$mlinks->id]))

          <li>
            <a href="{$data['metadata']['social_links_'.$mlinks->id][0]}}" target="_blank">
              <img src="{{ url('upload/'.$mlinks->meta_icon) }}">
            </a>
          </li>

          @endif
          @endforeach
            
        </ul>
       </div>
           
           <div class="contact_detail mt-3 profilemail-contact">
            <div class="icon"><img src="{{asset('frontend/images/dashobar-web-icon.png')}}"></div>
            <div class="phone-number">{{$data['metadata']['website_url'][0]}}</div>
          </div>

    </div>
          
          
          <div class="profile-details-buttonblock">
             <div class="shortlist_button mt-4">
              <a href="#">+ Shortlist</a></div>
             @if(!empty($data['metadata']['run_specials']))
             <a class="todaysSpecial-btn" href="javascript:void;">
             special offer
             <span>{{ $data['metadata']['run_specials'][0] }}</span>
             </a>
             @endif
          </div>                  
   </div>

 </div>  

</section>
<div class="clearfix"></div>

<section class="redbar-cta text-center">
  <div class="container-fluid">
    <div class="row">
      <div class="cta-text">
        <p>Be a proud member of <span class="chlsHseTxt">House of</span> <span class="chlsSxyTxt">Sexy Girls</span></p>
        @if (!Auth::check())
        <a class="post-addcta-btn" href="{{route('login')}}">Post your ad now</a></div>
        @else
        <a href='{{route("post-ad.","/")}}'class="post-addcta-btn">Post Ad</a>
        @endif
    </div>
  </div>
</section>
<div class="clearfix"></div>
<section class="bottom-advertiseblock padding-50">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="{{asset('frontend/images/advertise-img.jpg')}}" class="img-fluid" alt="img">
        </div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="{{asset('frontend/images/advertise-img1.png')}}" class="img-fluid" alt="img"></div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="{{asset('frontend/images/advertise-img2.png')}}" class="img-fluid" alt="img"></div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
        <div class="advertise-box"><img src="{{asset('frontend/images/advertise-img3.png')}}" class="img-fluid" alt="img"></div>
      </div>
    </div>
  </div>
</section>

<!-- subscribe my profile modal pop up start -->
 
<div class="modal fade services-addTime" id="subscribeProfile-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Subscribe My Profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="signup-container">
     
        <form action="{{ route('subscribe.store') }}" method="post" name="register" id="register" onsubmit="return false;">
          {{ csrf_field() }}
            <div class="sevicesaddtime-top reportthis-form">            
          <div class="form-group">           
            <input type="text" placeholder="Name(optional)" name="subs_name" class="form-control" id="subs_name">
             <span class="help1-block hidden subs_name_error"></span>
          </div>
          
          <div class="form-group ">
            <input type="email" placeholder="*Email Address" name="subs_email" class="form-control" id="subs_email">
             <span class="help1-block hidden subs_email_error"></span>
           
          </div>
          
           <div class="form-group">
            <input type="number" placeholder="*Phone Number (optional)"  name="subs_phone" class="form-control" id="Service-type">
          </div>
            
            
            <div class="subscribe-Notify" >
             
             <h3>subscribe to Notification</h3>
              <ul>
               
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="Misleading" class="css-checkbox" value="1">
                                <label for="Misleading" class="css-label">Live Status</label>
                                    </div>
                            </li>
                                   
                         
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="FakePhoto" class="css-checkbox" value="2">
                                <label for="FakePhoto" class="css-label">Special Rates</label>
                              </div>
                            </li>
                                   
                                   <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="MoneyCheating" class="css-checkbox" value="3">
                                <label for="MoneyCheating" class="css-label">New Photos</label>
                               </div>
                            </li>
                                   
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="HumanTrafficking" class="css-checkbox" value="4">
                                <label for="HumanTrafficking" class="css-label">New Video</label>
                              </div>
                            </li>
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="BadBehaviuors" class="css-checkbox" value="5">
                                <label for="BadBehaviuors" class="css-label">New Availibility</label>
                              </div>
                            </li>
                                   
                                   <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="Violence" class="css-checkbox" value="6">
                                <label for="Violence" class="css-label">My Story</label>
                              </div>
                            </li>
                                   
                                   <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="Others" class="css-checkbox" value="7">
                                <label for="Others" class="css-label">Touring Cities & Dates</label>
                              </div>
                            </li>
                                   
                                   
                          </ul>          
            </div>            
        </div>
        <input type="hidden"  name="test_ad_id" value="{{$data[adId]}}" >
          <input type="hidden"  name="test_user_id" value="{{$data[adUserId]}}}" >
      <!-- captcha -->
               <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop has-error">
                    <span class="help-block hidden g-recaptcha-response_error"></span>
                    {!! NoCaptcha::display() !!}
                      {!! NoCaptcha::renderJs() !!}
          
                   
                  </div>
                </div>
              </div>
             
        <!-- captcha -->
        </form><!--form end-->
        

      </div>
    
     <div class="modal-footer"><br>        
        <button type="button" class="servicespopupSave-btn" onclick="add_user_registration()">Subscribe Now</button>
        
      </div>
     
    </div>
  </div>
</div>
<!-- subscribe my profile modal pop up end -->

<!-- Thank you Subscribe Notification modal pop up start -->

<div class="modal fade services-addTime thankyou-pop" id="ThankyouNotify-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <h2>Thank you!</h2>
    <p>You have successfully <span>subscribed</span> to  notification.</p>          
      </div>  

<div class="modal-footer">

</div>
    
    </div>
  </div>
</div>
<!-- Thank you Subscribe Notification modal pop up End -->




<!-- report this ad modal pop up start -->
<div class="modal fade services-addTime" id="reportThisadd" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Report this AD</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="signup">
        
        <form action="{{route('reportAD')}}" method="post" id="reportform" name="reportform" onsubmit="return false;"> 
               {{ csrf_field() }}
            <div class="sevicesaddtime-top reportthis-form">            
          <div class="form-group">           
            <input type="text" placeholder="*Name" class="form-control" name="report_name" id="report_name">
            <span class="help1-block hidden report_name_error"></span>
          </div>
          
          <div class="form-group">
            <input type="text" placeholder="*Email Address" class="form-control" id="report_email" name="report_email">
            <span class="help1-block hidden report_email_error"></span>
          </div>
          
           <div class="form-group">
            <input type="text" placeholder="*Phone Number" class="form-control" id="report_phone" name="report_phone">
          </div>
          
          <div class="form-group">
            <div class="dropdown dropdown-select">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="false">
                            Services
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -433px, 0px); top: 0px; left: 0px; will-change: transform;">
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="1" id="checkboxG155" class="css-checkbox">
                                <label for="checkboxG155" class="css-label">Misleading Info</label>
                                    </div>
                            </li>
                                   
                         
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="2" id="checkboxG156" class="css-checkbox">
                                <label for="checkboxG156" class="css-label">Fake Photo/Video</label>
                              </div>
                            </li>
                                   
                                   <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="3" id="checkboxG161" class="css-checkbox">
                                <label for="checkboxG161" class="css-label">Money Cheating</label>
                              </div>
                            </li>
                                   
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="4" id="checkboxG157" class="css-checkbox">
                                <label for="checkboxG157" class="css-label">Human Trafficking</label>
                              </div>
                            </li>
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="5" id="checkboxG158" class="css-checkbox">
                                <label for="checkboxG158" class="css-label">Bad Behaviuors</label>
                              </div>
                            </li>
                                   
                                   <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="6" id="checkboxG159" class="css-checkbox">
                                <label for="checkboxG159" class="css-label">Violence</label>
                              </div>
                            </li>
                                   
                                   <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]" value="7" id="checkboxG160" class="css-checkbox">
                                <label for="checkboxG160" class="css-label">Others</label>
                              </div>
                            </li>
                                   
                                   
                          </ul>
                        </div>
          </div>
            
            <input type="hidden" name="ad_id" value="{{$data[adId]}}">
            <div class="form-group">
            <textarea  placeholder="Write Description" name="other_report" class="form-control"></textarea>
          </div>



           <!-- captcha -->
               <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop has-error">
                    <span class="help-block hidden g-recaptcha-response_error"></span>
                    {!! NoCaptcha::display() !!}
                      {!! NoCaptcha::renderJs() !!}
          
                   
                  </div>
                </div>
              </div>
             
        <!-- captcha -->

            
        </div>
    
        </form>
        

      </div>
    
     <div class="modal-footer">        
        <button type="button" class="servicespopupSave-btn" onclick="add_user_report()">Submit</button>
      </div>
  
    </div>
  </div>
</div>
<!-- report this ad modal pop up end -->

<!-- Report Success modal pop up start -->
 
<div class="modal fade services-addTime thankyou-pop" id="report-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <h2>Thank you!</h2>
          <p>You have successfully reported <span>a executive will look</span> asap.</p>          
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>
<!--report success Notification modal pop up End -->


<!-- testimonial modal pop up start -->
<div class="modal fade services-addTime" id="testimonial-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Write A Testimonial</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h6>Note: Please provide the same email ID/Mobile number that you have had used for booking. The escorts you have had met, might check contact workbook matching your email or mobile number for the authenticity to validate your testimonial. We will not publish or sell your email/contact to anyone. Thanks!</h6>

          
        <form action="{{route('testimonial')}}" method="post" id="testimonial" name="testimonial" onsubmit="return false;">
          {{ csrf_field()}}

          <div class="sevicesaddtime-top reportthis-form" style="background: #fff;">            
          <div class="form-group">           
            <input type="text" name="name" placeholder="*Robert William" class="form-control" id="name" value="{{ Auth::user()->name}}" >
             <span class="help1-block hidden name_error"></span>
          </div>
          
          <div class="form-group">
            <input type="text"  name="email" placeholder="*Email Address" class="form-control" id="email" value="{{ Auth::user()->email}}">
             <span class="help1-block hidden email_error"></span>
          </div>
          
           <div class="form-group">
            <input type="text" name="contact" placeholder="*Phone Number" class="form-control" id="contact" >
            <span class="help1-block hidden contact_error"></span>
          </div>
          
         
            
            <div class="form-group">
               <!-- <textarea class='autoExpand'   placeholder='Auto-Expanding Textarea'></textarea> -->
          <textarea  placeholder="Write Testimonial..." class="autoExpand form-control" name="message" id="message"></textarea>
          <span class="help1-block hidden  message_error"></span>
          </div>
            
            <div class="starRating-cover"> 
            Rating   
                              <div class="star-css">
                      
                                     <input type="hidden" id="php_1_hidden" value="1">
                                     <img src="{{asset('frontend/images/star1.png')}}" width="5%" onclick="change(this.id);" id="php_1" class="php">
                                     <input type="hidden" id="php_2_hidden" value="2">
                                     <img src="{{asset('frontend/images/star1.png')}}" width="5%" onclick="change(this.id);" id="php_2" class="php">
                                     <input type="hidden" id="php_3_hidden" value="3">
                                     <img src="{{asset('frontend/images/star1.png')}}" width="5%" onclick="change(this.id);" id="php_3" class="php">
                                     <input type="hidden" id="php_4_hidden" value="4">
                                     <img src="{{asset('frontend/images/star1.png')}}"  width="5%" onclick="change(this.id);" id="php_4" class="php">
                                     <input type="hidden" id="php_5_hidden" value="5">
                                     <img src="{{asset('frontend/images/star1.png')}}"  width="5%" onclick="change(this.id);" id="php_5" class="php">
                                     <input type="hidden" name="rating_value" value="" id="rating_value">
                                     <span class="help1-block hidden rating_value_error"></span>
                      
                             </div>
                      
                              </div>   
                              
<!-- end rating -->
 
               <!-- captcha -->
               <div class="form-group LoginFormGrop has-error">
                    <span class="help-block hidden g-recaptcha-response_error"></span>
                    {!! NoCaptcha::display() !!}
                      {!! NoCaptcha::renderJs() !!}
          
                   
                  </div>
                  <!-- captcha end -->

            </div>  

           
        </div>
<input type="hidden"  name="test_ad_id" value="{{$data['adId']}}" >
<input type="hidden"  name="test_user_id" value="{{$data['adUserId']}}" >
     
               

        <div class="modal-footer">        
        <button type="button" class="servicespopupSave-btn" onclick="add_user_testimonial()">Submit</button>
      </div>     
        </form>
       

      </div>
      
    </div>
  </div>
</div>
<!-- testimonial modal pop up end -->

<!-- Thank you testimonial modal pop up start -->

<div class="modal fade services-addTime thankyou-pop" id="testimonial-Thankyou-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <h2>Thank You {{Auth::user()->name}}!</h2>
          <p>Your testimonial is under review. It will be displayed once the <span>Admin</span> accepts and you will be notified by email.</p>          
      </div>  

<div class="modal-footer"> 

</div>
       
    </div>
  </div>
</div>
<!-- Thank you testimonial modal pop up end -->
 <script type="text/javascript" >
     var image_path="{{asset('frontend/images/')}}";
     
</script>

<script>
  jQuery(document).ready(function() {
  jQuery('.overlay').hide();
  });
  jQuery(document).ready(function() {
  jQuery('.test1').hover(function() {
  jQuery('.overlay').show();
  },
  function() {
  jQuery('.overlay').hide();
  });
  });
  </script> 


 
<script>
// Autoplay
            $('#box4').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 5000,
                autoplayPauseOnHover: true
            });
      
           $('#box5').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 4000,
                autoplayPauseOnHover: true
            });
      
           $('#box6').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 3000,
                autoplayPauseOnHover: true
            });
      
             $('#box7').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 2000,
                autoplayPauseOnHover: true
            });
      
             $('#box8').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 6000,
                autoplayPauseOnHover: true
            });
      
      // Buttons
            $('button.prev').click(function() {
                $(this).closest('.item').find('.box').flipbox('prev', $(this).hasClass('reverse'));
            });
            $('button.next').click(function() {
                $(this).closest('.item').find('.box').flipbox('next', $(this).hasClass('reverse'));
            });
            $('button.jump').click(function() {
                $(this).closest('.item').find('.box').flipbox('jump', $(this).data('index'), $(this).hasClass('reverse'));
            });
            $('button.config').click(function() {
                $(this).closest('.item').find('.box')
                    .flipbox({
                        animationDuration: $(this).data('duration'),
                        animationEasing: $(this).data('easing')
                    })
                    .flipbox('next');
          
          });
</script>

<script>
var vid = document.getElementById("gossVideo"); 

function playVid() { 
    vid.play(); 
} 

function pauseVid() { 
    vid.play(); 
} 
</script>


<script>
$('#lightSlider').lightSlider({
    gallery: true,
    item: 1,    
    slideMargin: 10,
    thumbItem: 7,
  thumbMargin: 10,
  pauseOnHover: true,
  auto: true
  
});

</script>

@endsection