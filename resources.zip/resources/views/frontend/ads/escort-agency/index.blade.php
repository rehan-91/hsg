@extends('frontend.layouts.front_layout')
@section('content')
<div id="Load" class="load" style="display:none;">
    <div class="load__container">
        <div class="load__animation"></div>
        <div class="load__mask"></div>
        <span class="load__title">Loading...</span>
    </div>
</div>
<section class="profile-details-block">
    <div class="container">
        <div id="wizard" class="wizard clearfix">
        @include('frontend.ads.escort-agency.frontnav_agency')
         @include('frontend.ads.escort-agency.escort_agency_step_1')
         @include('frontend.ads.escort-agency.escort_agency_step_2')
         @include('frontend.ads.escort-agency.escort_agency_step_3')
         @include('frontend.ads.escort-agency.escort_agency_step_4')
         @include('frontend.ads.escort-agency.escort_agency_step_5')
         
         </div>
    </div>
</section>


<script type="text/javascript">
var imagePostURL = "{!! route('ajaximageupload') !!}";
var fetchcityURL = "{!! route('fetchcitiesbycountry') !!}";
</script>
<script src="{{ asset('frontend/js/ad_agency_post_script.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/jquery.imgareaselect.pack.js') }}"></script>
@endsection

