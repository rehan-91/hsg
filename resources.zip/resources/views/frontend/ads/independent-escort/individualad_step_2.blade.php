<div class="content_block step_2" style="display:none;">
        <section class="pay-boxz">
            <div class="container">
                <h2 class="text-danger mb-5 mt-3"><img src="{{ asset('frontend/images/ad-plan-heading.png') }}" alt="ad-plan-heading.png" class="img-fluid"></h2>
                <div class="row">
				
				<div class="col-12 col-sm-6 col-md-6 col-lg-6">
				   <div class="row">
				    
				@php
                    $count = 1;
                    @endphp
                    @foreach($plans as $p)
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6 price-cards ">
                        <div class="card @if($count == 1) red-border @elseif($count == 2) purple-border @elseif($count==3) magenta-border @endif" id="plan-section-div{{$p->id}}">
                            <div class="card-header text-center border-bottom-0 bg-transparent">
                                <h5>{{ strtoupper($p->plan_name) }}</h5>
                            </div>
                            <div class="card-body">
                                <h1>{{ price_format($p->plan_price_base) }}</h1>
                                <h5 class="text-center"><small>Ad duration :
                                        <span>{{ $p->plan_duration." ".$p->plan_duration_unit}}</span></small>
                                </h5>
                            </div>
                            <ul class="list-group list-group-flush" id="hide-more-features{{$p->id}}">
                                @php
                                $plans_features = explode("\n", $p->plan_features);
                                $fcount = 1;

                                @endphp
                                @foreach($plans_features as $pf)
                                @php
                                $planClass = ($fcount > 3) ? "hide-more-features" : '';
                                $style = ($fcount > 3) ? "style=display:none" :'';
                                @endphp
                                <li class="list-group-item {{ $planClass }}" {{ $style }}><i
                                        class="fa fa-check mx-2"></i><span>{{ $pf }}</span></li>
                                @php $fcount++; @endphp
                                @endforeach
                            </ul>
                            @if(count($plans_features) > 3)
                            <p class="text-left small read-more-features" onclick="readMoreFeatures({{$p->id}})"><span id="read-more-features{{$p->id}}">Read More</span><img src="{{ asset('frontend/images/next-arrow.png') }}" alt="next-arrow" class="img-fluid"></p>
                            @endif
							
							<div class="plan-adon-features">
							  <div class="plan-firstHeading">Ad-Ons Features</div>
							  
						
							 
            <div class="dropdown dropdown-select">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="false">
                            Featured Sexy Girls
                            <span class="caret"></span>							
                        </button>
						
						
                        <ul id="style-2" class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -433px, 0px); top: 0px; left: 0px; will-change: transform;">
						   <h5>Select Days</h5>
						
                            <li role="presentation">
                                <input type="radio" name="radiog_dark" id="radio6" class="css-checkbox">
								<label for="radio6" class="css-label radio2">1 Day  - $2.99</label>							
                            </li>
                            <li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio7" class="css-checkbox">
								<label for="radio7" class="css-label radio2">2 Day - $4.99</label>                              
                            </li>
                         								
							<li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio8" class="css-checkbox">
								<label for="radio8" class="css-label radio2">3 Day - $ 6.99</label>                              
                            </li>							
                        </ul>
          </div>
							  
							  
							  <div class="dropdown dropdown-select">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="false">
                            Sexy Teaser Video
                            <span class="caret"></span>							
                        </button>
						
						
                        <ul id="style-2" class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -433px, 0px); top: 0px; left: 0px; will-change: transform;">
						   <h5>Select Days</h5>
						
                            <li role="presentation">
                                <input type="radio" name="radiog_dark" id="radio6" class="css-checkbox">
								<label for="radio6" class="css-label radio2">1 Day  - $2.99</label>							
                            </li>
                            <li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio7" class="css-checkbox">
								<label for="radio7" class="css-label radio2">2 Day - $4.99</label>                              
                            </li>
                         								
							<li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio8" class="css-checkbox">
								<label for="radio8" class="css-label radio2">3 Day - $ 6.99</label>                              
                            </li>							
                        </ul>
          </div>
							  
							  
							  
							  
							  
							  
							</div>
							
                            <div class="card-footer border-top-0 upgrade-btn text-center">
                                <a href="#" class="text-uppercase">select</a>
                            </div>
                        </div>
                    </div>
                    @php
                    $count++;
                    @endphp
                    @endforeach
				
				</div>
				</div>
				
				
				<div class="col-12 col-sm-6 col-md-6 col-lg-6 price-cards ">
				   <img src="{{ asset('frontend/images/subscription-right-img.png') }}" alt="subscription-right-img" class="img-fluid">
				
				</div>
				
                    
                </div>
				
				<div class="clearfix"></div>
				
				 <div class="actions clearfix step_2" style="display:none;">
        <ul role="menu" aria-label="Pagination">
            <li>
               <input type="button" value="Previous" class="previous PreviousBTN" name="prev_step_2" id="prev_step_2">
            </li>
            <li>
            <input type="button" value="Next" class="next NextBTN" name="next_step_2" id="next_step_2">
            </li>
            <li>
            </li>
        </ul>
    </div>
				
				
            </div>
           
        </section>
    </div>
    
   
