@extends('frontend.layouts.front_layout')
@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" integrity="sha256-Tcd+6Q3CIltXsx0o/gYhPNbEkb3HJJpucOvQA7csVwI=" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.css" integrity="sha256-ke5yDzwl7GsgnYgBnCDiWSNA/x/hyU89VDHl/R535dw=" crossorigin="anonymous" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.js" integrity="sha256-kiFgik3ybDpn1VOoXqQiaSNcpp0v9HQZFIhTgw1c6i0=" crossorigin="anonymous"></script>

<section class="profile-details-block main-profile">
     <div class="container"> 
          <div class="row justify-content-between">
               <div class="col-md-4">
                    <div class="w-100 left_container">
                         <div class="cnt profile_page">
                              <h2 class="float-left">{{$data['adName']}}-{{getMaterData($data['metadata']['age'][0])}}
                                    <span class="whiteColor">Yrs</span></h2>
                              
                            <div class="live-btnpositon {{$data['login_status'] == 1 ? 'profile-livebtn':'Offliine-btnpositon'}}"> <span>{{$data['login_status'] == 1 ? 'live':'offline'}}</span> </div>
                              
                              <div class="City_name">{{getCityCountry($data['adLocation'])}}</div>
                              <div class="clearfix"></div>
                              <div class="services_card">

                                   @if(!empty($data['metadata']['services-available']) &&
                                   count($data['metadata']['services-available']) > 0 )
                                   <ul>

                                        @foreach($data['metadata']['services-available'] as $ds)
                                        <li>{{getMaterData($ds)}}</li>
                                        @endforeach
                                   </ul>
                                   @endif
                              </div>
                         </div>
                         <div class="clearfix"></div>
                         @php
                         $data['adListingTypeId'];
                         $listingtype = listingtype($data['adListingTypeId']);

                         $listingtypename = $listingtype[$data['adListingTypeId']]['title'];
                         @endphp
                         @if(strtolower($listingtypename) == 'escort agency')
                         <div class="agencies_section">
                              <div class="agency_logo"><img src="{{asset('frontend/images/escort-bitches.png')}}" />
                              </div>
                              <div class="agency_info">
                                   <div class="agency_name">Escort Bitches</div>
                                   <div class="managed_by">Managed by Escort Bitches</div>
                                   <div class="short_button"><a href="#">View Profile <img class="arrow-img"
                                                  src="{{asset('frontend/images/right-arrow-red.png')}}"></a></div>
                              </div>
                         </div>
                         @endif
                         <div class="clearfix"></div>
                         @php
                                             $wishlist_ad_ids = array();
                                             $wishlist_ad_ids = getWishlist()->pluck('short_ad_id')->toArray();
                                             $style = "style=display:none;";
                                             $style1 = "style=display:none;";
                                            
                                        if(!in_array($data['adId'], $wishlist_ad_ids)){
                                        $style = "style=display:block;'";
                                        }else{
                                        $style1 = "style=display:block;";
                                        } 
                                        @endphp
                        
                         <div  class="shortlist_button mt-4">
                              <a class="progile-shortlistbtn"  id="profile-shortlist-btn{{$data['adId']}}" {{$style}}  href="javascript:void()" onclick="addToShortlist({{$data['adId']}})"><i class="fa fa-plus"></i>  Shortlist</a>
                              <a  {{$style1}} id="profile-shortlisted-btn{{$data['adId']}}" class="progile-shortlistbtn" href="javascript:void()"><i class="fa fa-heart"> Shortlisted</i></a>
                         </div>
                         <div class="clearfix"></div>
                         <div class="contact_section">
                              <h3>Prefered Contact Method</h3>	
                              <div class="contact_detail">
                                   <div class="icon"><img src="{{asset('frontend/images/profile-phone.png')}}"></div>
                                   <div class="phone-number"><span>Phone</span><br>{{$data['adContact']}}</div>
                              </div>
                              <div class="contact_detail">
                                   <div class="icon"><img src="{{asset('frontend/images/profile-whatsapp.png')}}"></div>
                                   <div class="phone-number"><span>Phone</span><br />{{$data['adContact']}}</div>
                              </div>
                              
                              <div class="clearfix"></div>
                              
                              <div class="contact_detail profilemail-contact">
                  <div class="icon"><img src="{{asset('frontend/images/email-dashboardicon.png')}}"></div>
                  <div class="phone-number">{{$data['adEmail']}}</div>
                </div>
                @if(!empty($data['metadata']['additional_information']))
                <div class="donotAnswer">
                    <span>P.S:</span> 
                {{ $data['metadata']['additional_information'][0] }}
               </div>
               @endif
                
                <div class="clearfix"></div>
				
                              
                              <div class="followme">
			    <h3>Follow me on</h3>
				
				<ul>

                    @foreach($social_media_links as $mlinks)
                    @if(!empty($data['metadata']['social_links_'.$mlinks->id]))
                    <li><a href="{{$data['metadata']['social_links_'.$mlinks->id][0]}}" 
                    target="_blank"><img src="{{ url('upload/'.$mlinks->meta_icon) }}"></a></li>
				 @endif
                    @endforeach
				 </ul>
			 </div>
             
              <div class="contact_detail mt-3 profilemail-contact">
                      <div class="icon"><img src="{{asset('frontend/images/dashobar-web-icon.png')}}"></div>
                      <div class="phone-number">{{$data['metadata']['website_url'][0]}}</div>
                    </div>
					
					<div class="clearfix"></div>
					
					<div class="contact_detail mt-3 profilemail-contact">
                      <div class="icon"><img src="{{asset('frontend/images/dashobar-blog-icon.png')}}"></div>
                      <div class="phone-number">Read My Escorts Story</div>
                    </div>
					
					<div class="subscribe-block">

					  <a href="javascript:void;"><img src="{{asset('frontend/images/share-red-icon.png')}}"> share</a>

					  <a href="#" data-toggle="modal" data-target="#subscribeProfile-popup"><img src="{{asset('frontend/images/subscribe-red-icon.png')}}"> subscribe</a>

                           <a href="#" data-toggle="modal" data-target="#reportThisadd"><img src="{{asset('frontend/images/report-red-icon.png')}}"> report</a>

                           <a href="#" data-toggle="modal" data-target="#testimonial-popup"><!-- <img src="{{asset('frontend/images/testimonials.png')}}"> --><i class="fa fa-quote-left"></i> testimonials</a>
					
					</div>
					@if(!empty($data['metadata']['run_specials']))
					<a class="todaysSpecial-btn" href="javascript:void;">
					   
                            
					   <span>{{ $data['metadata']['run_specials'][0] }}</span>
                            
                            
					</a>
                         @endif

                         </div>
                         <div class="clearfix"></div>
                         <div class="w-100 profile_cnt">
                              <div class="cnt">

                                   <h2>My Attributes</h2>

                                   <div class="listing">
                                        @if(!empty($data['metadata']['age']))
                                        <div class="list"><span class="label">Age :</span>
                                             {{ getMaterData($data['metadata']['age'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['gender']))
                                        <div class="list"><span class="label">Gender :</span>
                                             {{ $data['metadata']['gender'][0] }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['personal']))
                                        <div class="list"><span class="label">Personal :</span>
                                             {{ getMaterData($data['metadata']['personal'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['bustsize']))
                                        <div class="list"><span class="label">Bust Size :</span>
                                             {{ getMaterData($data['metadata']['bustsize'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['nationality']))
                                        <div class="list"><span class="label">Nationality :</span>
                                             {{ getMaterData($data['metadata']['nationality'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['ethnicity']))
                                        <div class="list"><span class="label">Ethnicity :</span>
                                             {{ $data['metadata']['ethnicity'][0] }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['orientation']))
                                        <div class="list"><span class="label">Orientation :</span>
                                             {{ getMaterData($data['metadata']['orientation'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['tattoos']))
                                        <div class="list"><span class="label">Tattoos :</span>
                                             {{ $data['metadata']['tattoos'][0] }}</div>
                                        @endif

                                        @if(!empty($data['metadata']['dresssize']))
                                        <div class="list"><span class="label">Dress Size :</span>
                                             {{ getMaterData($data['metadata']['dresssize'][0]) }}</div>
                                        @endif
                                        @if(!empty($data['metadata']['shoessize']))
                                        <div class="list"><span class="label">Shoe Color :</span>
                                             {{ getMaterData($data['metadata']['shoessize'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['height']))
                                        <div class="list"><span class="label">Height :</span>
                                             {{ getMaterData($data['metadata']['height'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['eyecolor']))
                                        <div class="list"><span class="label">Eye Color :</span>
                                             {{ getMaterData($data['metadata']['eyecolor'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['haircolor']))
                                        <div class="list"><span class="label">Hair Color :</span>
                                             {{ getMaterData($data['metadata']['haircolor'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['body-type']))
                                        <div class="list"><span class="label">Body Type :</span>
                                             @php
                                             $bodytype = "";
                                             foreach( $data['metadata']['body-type'] as $b){

                                             $bodytype .= getMaterData($b).", ";
                                             }

                                             @endphp
                                             {{ trim($bodytype, ", ") }}
                                        </div>
                                        @endif
                                        
                                        @if(!empty($data['metadata']['hairlength']))
                                        <div class="list"><span class="label">Hair Length :</span>
                                             {{ getMaterData($data['metadata']['hairlength'][0]) }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['piercing']))
                                        <div class="list"><span class="label">Piercing :</span>
                                             @php
                                             $piercing = "";
                                             foreach( $data['metadata']['piercing'] as $p){

                                             $piercing .= getMaterData($p).", ";
                                             }

                                             @endphp
                                             {{ trim($piercing, ", ") }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['smoker']))
                                        <div class="list"><span class="label">Smoker :</span>
                                             {{ $data['metadata']['smoker'][0] }}
                                        </div>
                                        @endif
                                        @if(!empty($data['metadata']['drinks']))
                                        <div class="list"><span class="label">Drinks :</span>
                                             {{ $data['metadata']['drinks'][0] }}
                                        </div>
                                        @endif


                                   </div>

                              </div>
                         </div>

                         <div class="w-100 profile_cnt read-less-desc">
                              <div class="cnt">
                                   <h2>About {{$data['adName']}}</h2>
                                   <p class="text-left">
                                   {{ substr($data['aboutDescription'], 0, 200)}}
                                   </p>
                                   <div class="short_button">
                                        <a href="javascript:void(0)" onclick="readMore()">Read More 
                                         <img class="arrow-img"src="{{asset('frontend/images/right-arrow-red.png')}}"></a>
                                    </div>
                              </div>
                         </div>
                         <div class="w-100 profile_cnt read-more-desc" style="display:none;">
                              <div class="cnt">
                                   <h2>About {{$data['adName']}}</h2>
                                   <p class="text-left text-white">
                                   {{ $data['aboutDescription']}}
                                   </p>
                                   <div class="short_button"><a href="javascript:void(0)" onclick="readLess()">Read Less <img class="arrow-img"
                                                  src="{{asset('frontend/images/right-arrow-red.png')}}"></a></div>
                              </div>
                         </div>
                         <div class="w-100 profile_cnt">
                              <div class="cnt">
                                   <h2>My Fee & Services</h2>
                                   <table class="table text-white table-data">
                                        <thead>
                                             <tr>

                                                  <th scope="col" width="25%">Time</th>
                                                  <th scope="col" width="25%">In Call</th>
                                                  <th scope="col" width="25%">Out call</th>
                                                  <th scope="col" width="25%">Services Included</th>
                                             </tr>
                                        </thead>
                                        <tbody>
                                             <tr>
                                             @foreach($data['services'] as $serv)
                                             <td>{{$serv['ad_time']}}</td>
                                             <td>{{$serv['incall_charge']}}</td>
                                             <td>{{$serv['outcall_charge']}}</td>
                                             @php
                                             $services = explode(", ", $serv['services']);
                                             $service_name = "";
                                             foreach( $services as $ss){
                                                  $service_name .= getMaterData($ss).", ";    
                                             } 
                                             @endphp
                                             <td>{{trim($service_name, ", ")}}</td>
                                             @endforeach
                                             </tr>


                                        </tbody>
                                   </table>
                              </div>
                         </div>
                         <div class="w-100 profile_cnt">
                              <div class="cnt">
                                   <h2>Extra Service</h2>
                                   <table class="table text-white table-data">
                                        <thead>
                                             <tr>

                                                  <th scope="col" width="40%">Fee</th>
                                                  <th scope="col" width="60%">Service Included</th>

                                             </tr>
                                        </thead>
                                        <tbody>
                                             <tr>
                                             @foreach($data['extra_services'] as $ex)
                                             <td>{{$ex->ad_fee}}</td>
                                             @php
                                             $ex_services = explode(", ", $ex['ad_services']);
                                             $exservice_name = "";
                                             foreach( $ex_services as $ss){
                                                  $exservice_name .= getMaterData($ss).", ";    
                                             } 
                                             @endphp
                                             <td>{{$ex->ad_fee}}</td>
                                             <td>>{{trim($exservice_name, ", ")}}</td>
                                             @endforeach 
                                             </tr>

                                        </tbody>
                                   </table>
                              </div>
                         </div>
                         
                         
                          
              <div class="w-100 profile_cnt aboutprofileMember">
                <div class="cnt">
                  <h2>Additional Service Info</h2>
                  @if(!empty($data['metadata']['services_additional_information']))
                  <p class="text-left"> {{ $data['metadata']['services_additional_information'][0] }}</p>
                    @endif
                  
                </div>
              </div>
              
              
              <div class="w-100 profile_cnt aboutprofileMember">
                <div class="cnt">
                  <h2>My Hobbies & Interest</h2>
                  @if(!empty($data['metadata']['hobbies_interest']))
                  <p class="text-left">{{ $data['metadata']['hobbies_interest']['0'] }}</p>
                    @endif
                  
                </div>
              </div>
              


              <div class="w-100 profile_cnt">
                <div class="cnt">
                  <h2>My Favourites Things</h2>
                  <div class="listing">
                     @foreach($fav_things as $fav)
                    @if(!empty($data['metadata']['fav_things_'.$fav->id]))
                    <div class="list"><span class="label">{{$fav->meta_value}}:&nbsp</span>{{$data['metadata']['fav_things_'.$fav->id][0]}}
                    </div>
                     @endif
                    @endforeach                  
                  </div>
                </div>
              </div>
              
              
              <div class="w-100 profile_cnt">
                <div class="cnt">
                  <h2>My Wishlist</h2>
                  <div class="listing">
                    @foreach($wish_things as $wish)
                    @if(!empty($data['metadata']['wish_things_'.$wish->id]))
                    <div class="list"><span class="label">{{$wish->meta_value }} :</span> {{$data['metadata']['wish_things_'.$wish->id][0]}}
                     </div>
                      @endif
                    @endforeach                         
                  </div> 
                </div>
              </div>
              
              
                         <div class="w-100 profile_cnt">
                              <div class="cnt">
                                   <h2>My Availibility</h2>
                                   <div class="listing">
                                        @if($data['metadata']['dayoff_monday'])
                                         <div class="list"><span class="label">Monday :</span>  
                                             {{ $data['metadata']['dayoff_monday'][0] }}
                                        </div>
                                        @else
                                        <div class="list"><span class="label">Monday :</span>  
                                             {{ $data['metadata']['monday_from'][0] }} to {{ $data['metadata']['monday_to'][0] }}
                                        </div>
                                        @endif

                                        @if($data['metadata']['dayoff_tuesday'])
                                         <div class="list"><span class="label">Tuesday :</span>  
                                             {{ $data['metadata']['dayoff_tuesday'][0] }}
                                        </div>
                                        @else
                                        <div class="list"><span class="label">Tuesday :</span>  
                                             {{ $data['metadata']['tuesday_from'][0] }} to {{ $data['metadata']['tuesday_to'][0] }}
                                        </div>
                                        @endif

                                        @if($data['metadata']['dayoff_wednesday'])
                                         <div class="list"><span class="label">Wednesday :</span>  
                                               {{ $data['metadata']['dayoff_wednesday'][0] }}
                                        </div>
                                        @else
                                        <div class="list"><span class="label">Wednesday :</span>  
                                             {{ $data['metadata']['wednesday_from'][0] }} to {{ $data['metadata']['wednesday_to'][0] }}
                                        </div>
                                        @endif

                                         @if($data['metadata']['dayoff_thursday'])
                                         <div class="list"><span class="label">Thursday :</span>  
                                             {{ $data['metadata']['dayoff_thursday'][0] }}
                                        </div>
                                        @else
                                        <div class="list"><span class="label">Thursday :</span>  
                                             {{ $data['metadata']['thursday_from'][0] }} to {{ $data['metadata']['thursday_to'][0] }}
                                        </div>
                                        @endif

                                       @if($data['metadata']['dayoff_friday'])
                                         <div class="list"><span class="label">Friday :</span>  
                                              {{ $data['metadata']['dayoff_friday'][0] }}
                                        </div>
                                        @else
                                        <div class="list"><span class="label">Friday :</span>  
                                             {{ $data['metadata']['friday_from'][0] }} to {{ $data['metadata']['friday_to'][0] }}
                                        </div>
                                        @endif

                                         @if($data['metadata']['dayoff_staurday'])
                                         <div class="list"><span class="label">Saturday :</span>  
                                            {{ $data['metadata']['dayoff_staurday'][0] }}
                                        </div>
                                        @else
                                        <div class="list"><span class="label">Saturday :</span>  
                                             {{ $data['metadata']['staurday_from'][0] }} to {{ $data['metadata']['staurday_to'][0] }}
                                        </div>
                                        @endif

                                        @if($data['metadata']['dayoff_sunday'])
                                         <div class="list"><span class="label">Sunday :</span>  
                                             {{ $data['metadata']['dayoff_sunday'][0] }}
                                        </div>
                                        @else
                                        <div class="list"><span class="label">Sunday :</span>  
                                             {{ $data['metadata']['sunday_from'][0] }} to {{ $data['metadata']['sunday_to'][0] }}
                                        </div>
                                        @endif
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
               <div class="col-md-8">
                    <div class="right_container">
                         <div class="top_bar_section text-white">
                <div class="shortlist_count">
  <!--Emojis Click  -->
 <div class="actions-block">
     <ul id="musicinfo" class="actions-list">
          @php
          $emojiconarray = array(
          "winiking_face" => asset('frontend/images/badge-icon1.png'),
          "heart_eyes_face" => asset('frontend/images/badge-icon2.png'),
          "rose" => asset('frontend/images/badge-icon3.png'),
          "lips" => asset('frontend/images/badge-icon4.png'),
          "heart" => asset('frontend/images/badge-icon5.png'),
          );
          @endphp
         @foreach( $emojiconarray as $key=>$ema) 
      <li data-id="{{$key}}" data-ad-id="{{$data['adId']}}">
          <a href="#">
          <button type="button" class="btn btn-primary">
            <img src="{{$ema}}">
             <span class="badge badge-light">{{(int)$data['emojis']->$key}}</span>
            <span class="sr-only">unread messages</span>
          </button>
          </a>
      </li>
      @endforeach

      </ul>
      
      
    </div>
    <!-- Emojis Click end -->
    
     
  <script>
     var saveEmojiURL = '{{route('saveemoji')}}';
     $(document).ready(function(){
          $(".actions-list li").click(function(){
               var emoname = $(this).attr('data-id');
               var ad_id = $(this).attr('data-ad-id'); 
               if(emoname){
                    $.get(saveEmojiURL,{emoname:emoname, ad_id:ad_id},function(data){
                         $(this).find('.badge-light').text(data);
                    })
               }
          })
     })
  </script>


                </div>
                <div class="public_likesdiv">
                <div id="music"  class="heartbadge-iconhover">

<div class="heartbadge-icon">
                <img src="{{asset('frontend/images/badge-icon5.png')}}">
                </div>
</div>
                <div class="photos_veryfied"><img src="{{asset('frontend/images/photosverified-icon.png')}}"> Photos Verified</div>
                
                </div>
                
              </div>
                         <div class="video_section">
                              <div>
                              @foreach($data['videos'] as $v)
                                   <video width="100%" controls="controls"
                                        poster="{{asset('frontend/images/video-poster.jpg')}}" preload="true">
                                        <source src="{{getS3VideoURL($v->media_filename)}}" type="video/mp4" />
                                        Your browser does not support the video tag.
                                   </video>
                                   @endforeach
                              </div>
                         </div>
                         <div class="profile_gallery">
                               <div class="row">
                              @if(count($data['images']) == 1)
                              @foreach($data['images'] as $i)
                               <div class="col-md-6">
                               <img src="{{getS3ImageURL($i->media_filename, '508*762')}}">
                              </div>
                            @endforeach
                              @else
                          @foreach($data['images']->split($data['images']->count()/2) as $im)
                              @foreach($im as $i)
                             <div class="col-md-6">
                               <img src="{{getS3ImageURL($i->media_filename, '508*762')}}">
                            </div>
                         @endforeach
                         @endforeach
                         @endif
                         </div>   

                    </div>              
               <div class="clearfix"></div>
          </div>
     </div>
</section>


     <section class="mybookingCalendar-block padding-50">
       <div class="container">
            <h2><img src="{{asset('frontend/images/bookingCalendar-img.png')}}" alt="bookingCalendar-img"></h2>
             <div class="clearfix"></div>
             <div id="owl-demo" class="owl-carousel owl-theme">
             @foreach ($tourData as $tour)
               <div class="item">
                    <figure class="figure">
                    <img src="{{asset('frontend/images/singapore.png') }}" class="figure-img img-fluid rounded" alt="A generic square placeholder image with rounded corners in a figure.">
                    <figcaption class="figure-caption">
                         <div class="visit-imageblock"><img src="{{asset('frontend/images/calendar-airplane-icon.png')}}"></div>

                         <div class="text-caption">
                         <p>{{getCityCountry($data['adLocation'])}}</p>
                         <span><img src="{{asset('frontend/images/calendor-small-icon.png') }}"> {{Carbon\Carbon::parse($tour->from_date)->format('d')}}th 
                         {{Carbon\Carbon::parse($tour->from_date)->format('M')}},
                          {{Carbon\Carbon::parse($tour->from_date)->format('Y')}}  &nbsp;to &nbsp;{{Carbon\Carbon::parse($tour->to_date)->format('d')}}th {{Carbon\Carbon::parse($tour->to_date)->format('M')}},
                         {{Carbon\Carbon::parse($tour->to_date)->format('Y')}}  </span>
                         </div>
                         
                    </figcaption>
               </figure> 
               </div>
               @endforeach
 

               </div>
               
               <div class="clearfix"></div>
               
               
               <div class="calendar-main padding-80">
                  <div class="calendar-left-panel">
                     <div class="calendar-bookingTime-Slot">
                       <div class="bookingSlot-day">
                       <h3>09</h3>
                       <span><h6>Tuesday</h6> Aug, 2019</span>
                        
                       </div>
                       <div class="clearfix"></div>
                       
                       <div class="slotTime-block">
                          <div class="slotTime-left">
                            <h4>booking time slot</h4>
                            <div class="TimeSlot-start">
                            <h5>start time</h5>
                           <ul>
                                   <li>00:00</li>
                                   <li>00:30</li>
                                   <li>01:00</li>
                                   <li>01:30</li>
                                   <li>02:00</li>
                                   <li>02:30</li>
                                   <li>03:00</li>
                                   <li>03:30</li>
                                   <li>04:00</li>
                                   <li>04:30</li>
                                   <li>05:00</li>
                                   <li>05:30</li>
                                   <li>06:00</li>
                                   <li>06:30</li>
                                   <li>07:00</li>
                                   <li>07:30</li>
                                   
                         </ul>                               
                               <div class="timeselection-slot">
                                <span class="green-time-select"></span>
                                <span class="violet-time-select"></span>                             
                               </div>                             
                               <h5>finish time</h5>
                               </div>
                               
                           </div>
                           <div class="slotTime-right"></div>                      
                       </div>              
                  </div>
                  </div>
                  
                  
                  
                   <div class="calendar-right-panel">
                  <img class="img-responsive" src="{{asset('frontend/images/calendar-dummy.jpg')}}" alt="calendar-dummy"/>
                  
                  </div>
                  
                  <div class="clearfix"></div>
                  
                  <ul class="calendar-Indicators">
                   <li><span class="red-calenderIndicator"></span> booked</li>
                    <li><span class="red-calenderIndicator green-calenderIndicator"></span> available</li>
                    <li><span class="red-calenderIndicator violet-calenderIndicator"></span> break time</li>
                    <li><span class="touring-calenderIndicator"></span> <img src="{{asset('frontend/images/aeroplane-icon.png')}}">touring</li>
                    <li><span class="red-calenderIndicator dayoff-calenderIndicator"></span> day off</li>
                  </ul>
                  
                 <div class="calander-textarea-block">
                     <textarea class="calandar-textarea" name="additional_information"  rows="3" placeholder="Additinal infortmation"></textarea>                  
                  </div>              
               </div>         
       </div>  
     </section>
<!-- subscribe my profile modal pop up start -->
 
<div class="modal fade services-addTime" id="subscribeProfile-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Subscribe My Profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="signup-container">
     
        <form action="{{ route('subscribe.store') }}" method="post" name="register" id="register" onsubmit="return false;">
          {{ csrf_field() }}
            <div class="sevicesaddtime-top reportthis-form">            
          <div class="form-group">           
            <input type="text" placeholder="Name(optional)" name="subs_name" class="form-control" id="subs_name">
             <span class="help1-block hidden subs_name_error"></span>
          </div>
          
          <div class="form-group ">
            <input type="email" placeholder="*Email Address" name="subs_email" class="form-control" id="subs_email">
             <span class="help1-block hidden subs_email_error"></span>
           
          </div>
          
           <div class="form-group">
            <input type="number" placeholder="*Phone Number (optional)"  name="subs_phone" class="form-control" id="Service-type">
          </div>
            
            
            <div class="subscribe-Notify" >
             
             <h3>subscribe to Notification</h3>
              <ul>
               
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="Misleading" class="css-checkbox" value="1">
                                <label for="Misleading" class="css-label">Live Status</label>
                                    </div>
                            </li>
                                   
                         
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="FakePhoto" class="css-checkbox" value="2">
                                <label for="FakePhoto" class="css-label">Special Rates</label>
                              </div>
                            </li>
                                   
                                   <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="MoneyCheating" class="css-checkbox" value="3">
                                <label for="MoneyCheating" class="css-label">New Photos</label>
                              </div>
                            </li>
                                   
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="HumanTrafficking" class="css-checkbox" value="4">
                                <label for="HumanTrafficking" class="css-label">New Video</label>
                              </div>
                            </li>
                            <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="BadBehaviuors" class="css-checkbox" value="5">
                                <label for="BadBehaviuors" class="css-label">New Availibility</label>
                               </div>
                            </li>
                                   
                                   <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="Violence" class="css-checkbox" value="6">
                                <label for="Violence" class="css-label">My Story</label>
                              </div>
                            </li>
                                   
                                   <li>
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="subs_for[]" id="Others" class="css-checkbox" value="7">
                                <label for="Others" class="css-label">Touring Cities & Dates</label>
                              </div>
                            </li>
                                   
                                   
                          </ul>          
            </div>            
        </div>
        <input type="hidden"  name="test_ad_id" value="{{$data[adId]}}" >
          <input type="hidden"  name="test_user_id" value="{{$data[adUserId]}}" >

          <!-- captcha -->
               <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop has-error">
                    <span class="help-block hidden g-recaptcha-response_error"></span>
                    {!! NoCaptcha::display() !!}
                      {!! NoCaptcha::renderJs() !!}
          
                   
                  </div>
                </div>
              </div>
             
        <!-- captcha -->
        </form><!--form end-->
        

      </div>
	  
	   <div class="modal-footer">    <br>    
        <button type="button" class="servicespopupSave-btn" onclick="add_user_registration()">Subscribe Now</button>
        
      </div>
     
    </div>
  </div>
</div>
<!-- subscribe my profile modal pop up end -->

<!-- Thank you Subscribe Notification modal pop up start -->

<div class="modal fade services-addTime thankyou-pop" id="ThankyouNotify-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <h2>Thank you!</h2>
    <p>You have successfully subscribed to  notification.</p>          
      </div>  

<div class="modal-footer">

</div>
    
    </div>
  </div>
</div>
<!-- Thank you Subscribe Notification modal pop up End -->




<!-- report this ad modal pop up start -->
<div class="modal fade services-addTime" id="reportThisadd" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Report this AD</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="signup">
        
        <form action="{{route('reportAD')}}" method="post" id="reportform" name="reportform" onsubmit="return false;"> 
               {{ csrf_field() }}
            <div class="sevicesaddtime-top reportthis-form">            
          <div class="form-group">           
            <input type="text" placeholder="*Name" class="form-control" name="report_name" id="report_name">
            <span class="help1-block hidden report_name_error"></span>
          </div>
          
          <div class="form-group">
            <input type="text" placeholder="*Email Address" class="form-control" id="report_email" name="report_email">
            <span class="help1-block hidden report_email_error"></span>
          </div>
          
           <div class="form-group">
            <input type="text" placeholder="*Phone Number" class="form-control" id="report_phone" name="report_phone">
          </div>
          
          <div class="form-group">
            <div class="dropdown dropdown-select">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="false">
                            Services
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -433px, 0px); top: 0px; left: 0px; will-change: transform;">
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="1" id="checkboxG155" class="css-checkbox">
                                <label for="checkboxG155" class="css-label">Misleading Info</label>
                                    </div>
                            </li>
                                   
                         
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="2" id="checkboxG156" class="css-checkbox">
                                <label for="checkboxG156" class="css-label">Fake Photo/Video</label>
                              </div>
                            </li>
                                   
                                   <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="3" id="checkboxG161" class="css-checkbox">
                                <label for="checkboxG161" class="css-label">Money Cheating</label>
                              </div>
                            </li>
                                   
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="4" id="checkboxG157" class="css-checkbox">
                                <label for="checkboxG157" class="css-label">Human Trafficking</label>
                              </div>
                            </li>
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="5" id="checkboxG158" class="css-checkbox">
                                <label for="checkboxG158" class="css-label">Bad Behaviuors</label>
                              </div>
                            </li>
                                   
                                   <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]"  value="6" id="checkboxG159" class="css-checkbox">
                                <label for="checkboxG159" class="css-label">Violence</label>
                              </div>
                            </li>
                                   
                                   <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" name="report_for[]" value="7" id="checkboxG160" class="css-checkbox">
                                <label for="checkboxG160" class="css-label">Others</label>
                              </div>
                            </li>
                                   
                                   
                          </ul>
                        </div>
          </div>
            
            <input type="hidden" name="ad_id" value="{{$data[adId]}}">
            <div class="form-group">
            <textarea  placeholder="Write Description" name="other_report" class="form-control"></textarea>
          </div>

             
                  <div class="form-group LoginFormGrop has-error">
                    <span class="help-block hidden g-recaptcha-response_error"></span>
                    {!! NoCaptcha::display() !!}
                      {!! NoCaptcha::renderJs() !!}
          
                   
                  </div>
              
             
            
        </div>
    
        </form>
        

      </div>
	  
	   <div class="modal-footer">        
        <button type="button" class="servicespopupSave-btn" onclick="add_user_report()">Submit</button>
      </div>
  
    </div>
  </div>
</div>
<!-- report this ad modal pop up end -->

<!-- Report Success modal pop up start -->
 
<div class="modal fade services-addTime thankyou-pop" id="report-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <h2>Thank you!</h2>
          <p>You have successfully reported <span>a executive will look</span> asap.</p>          
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>
<!--report success Notification modal pop up End -->


<!-- testimonial modal pop up start -->
<div class="modal fade services-addTime" id="testimonial-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Write A Testimonial</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h6>Note: Please provide the same email ID/Mobile number that you have had used for booking. The escorts you have had met, might check contact workbook matching your email or mobile number for the authenticity to validate your testimonial. We will not publish or sell your email/contact to anyone. Thanks!</h6>

          
        <form action="{{route('testimonial')}}" method="post" id="testimonial" name="testimonial" onsubmit="return false;">
          {{ csrf_field()}}

          <div class="sevicesaddtime-top reportthis-form" style="background: #fff;">            
          <div class="form-group">           
            <input type="text" name="name" placeholder="*Robert William" class="form-control" id="name" value="{{ Auth::user()->name}}" >
             <span class="help1-block hidden name_error"></span>
          </div>
          
          <div class="form-group">
            <input type="text"  name="email" placeholder="*Email Address" class="form-control" id="email" value="{{ Auth::user()->email}}">
             <span class="help1-block hidden email_error"></span>
          </div>
          
           <div class="form-group">
            <input type="text" name="contact" placeholder="*Phone Number" class="form-control" id="contact" >
            <span class="help1-block hidden contact_error"></span>
          </div>
          
         
            
            <div class="form-group">
               <!-- <textarea class='autoExpand'   placeholder='Auto-Expanding Textarea'></textarea> -->
          <textarea  placeholder="Write Testimonial..." class="autoExpand form-control" name="message" id="message"></textarea>
          <span class="help1-block hidden  message_error"></span>
          </div>
            
            <div class="starRating-cover"> 
            Rating   
                              <div class="star-css">
                      
                                     <input type="hidden" id="php_1_hidden" value="1">
                                     <img src="{{asset('frontend/images/star1.png')}}" width="5%" onclick="change(this.id);" id="php_1" class="php">
                                     <input type="hidden" id="php_2_hidden" value="2">
                                     <img src="{{asset('frontend/images/star1.png')}}" width="5%" onclick="change(this.id);" id="php_2" class="php">
                                     <input type="hidden" id="php_3_hidden" value="3">
                                     <img src="{{asset('frontend/images/star1.png')}}" width="5%" onclick="change(this.id);" id="php_3" class="php">
                                     <input type="hidden" id="php_4_hidden" value="4">
                                     <img src="{{asset('frontend/images/star1.png')}}"  width="5%" onclick="change(this.id);" id="php_4" class="php">
                                     <input type="hidden" id="php_5_hidden" value="5">
                                     <img src="{{asset('frontend/images/star1.png')}}"  width="5%" onclick="change(this.id);" id="php_5" class="php">
                                     <input type="hidden" name="rating_value" value="" id="rating_value">
                                     <span class="help1-block hidden rating_value_error"></span>
                      
                             </div>
                      
                              </div>   
                              
<!-- end rating -->
 
               <!-- captcha -->
               <div class="form-group LoginFormGrop has-error">
                    <span class="help-block hidden g-recaptcha-response_error"></span>
                    {!! NoCaptcha::display() !!}
                      {!! NoCaptcha::renderJs() !!}
          
                   
                  </div>
                  <!-- captcha end -->

            </div>  

           
        </div>
<input type="hidden"  name="test_ad_id" value="{{$data['adId']}}" >
<input type="hidden"  name="test_user_id" value="{{$data['adUserId']}}" >
     
               

        <div class="modal-footer">        
        <button type="button" class="servicespopupSave-btn" onclick="add_user_testimonial()">Submit</button>
      </div>     
        </form>
       

      </div>
      
    </div>
  </div>
</div>
<!-- testimonial modal pop up end -->

<!-- Thank you testimonial modal pop up start -->

<div class="modal fade services-addTime thankyou-pop" id="testimonial-Thankyou-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <h2>Thank You {{Auth::user()->name}}!</h2>
          <p>Your testimonial is under review. It will be displayed once the <span>Admin</span> accepts and you will be notified by email.</p>          
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>
<!-- Thank you testimonial modal pop up end -->
<script type="text/javascript">
function readMore(){
  $('.read-more-desc').show();
  $('.read-less-desc').hide();
}
function readLess(){
  $('.read-less-desc').show();
  $('.read-more-desc').hide();
}

</script>

<script>
$(document).ready(
    function() {
        $("#music").click(function() {
            $("#musicinfo").fadeToggle();
        });
    });
  </script> 

  <script type="text/javascript" >
     var image_path="{{asset('frontend/images/')}}";
     
</script>
 <script>
   $(document).ready(function() {
 
  $("#owl-demo").owlCarousel({
 
      //autoPlay: 3000, //Set AutoPlay to 3 seconds
 
      items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
       pagination : false,
       navigation:true,
       autoWidth:false,
       margin:25,
       
 
  });
 
});
  </script>
@endsection