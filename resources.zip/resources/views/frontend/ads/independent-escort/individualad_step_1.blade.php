<div class="content_block step_1 content">


<form action="{{route('individualad.savedetails')}}" method="post" onsubmit="return false;" id="form_step_1">
    <h2 class="text-danger">details</h2>
        <div class="setup-content" id="step-1">
            <div class="profile-details-form">
			
			
			
			<section class="mybookingCalendar-block padding-50">
       <div class="container">
            <h2><img src="{{asset('frontend/images/bookingCalendar-img.png')}}" alt="bookingCalendar-img"></h2>
             <div class="clearfix"></div>
             <div id="owl-demo" class="owl-carousel owl-theme">
             @foreach ($tourData as $tour)
               <div class="item">
                    <figure class="figure">
                    <img src="{{asset('frontend/images/singapore.png') }}" class="figure-img img-fluid rounded" alt="A generic square placeholder image with rounded corners in a figure.">
                    <figcaption class="figure-caption">
                         <div class="visit-imageblock"><img src="{{asset('frontend/images/calendar-airplane-icon.png')}}"></div>

                         <div class="text-caption">
                         <p>{{getCityCountry($data['adLocation'])}}</p>
                         <span><img src="{{asset('frontend/images/calendor-small-icon.png') }}"> {{Carbon\Carbon::parse($tour->from_date)->format('d')}}th 
                         {{Carbon\Carbon::parse($tour->from_date)->format('M')}},
                          {{Carbon\Carbon::parse($tour->from_date)->format('Y')}}  &nbsp;to &nbsp;{{Carbon\Carbon::parse($tour->to_date)->format('d')}}th {{Carbon\Carbon::parse($tour->to_date)->format('M')}},
                         {{Carbon\Carbon::parse($tour->to_date)->format('Y')}}  </span>
                         </div>
                         
                    </figcaption>
               </figure> 
               </div>
               @endforeach
 

               </div>
               
               <div class="clearfix"></div>
               
               
               <div class="calendar-main padding-80">
                  <div class="calendar-left-panel">
                     <div class="calendar-bookingTime-Slot">
                       <div class="bookingSlot-day">
                       <h3>09</h3>
                       <span><h6>Tuesday</h6> Aug, 2019</span>
                        
                       </div>
                       <div class="clearfix"></div>
                       
                       <div class="slotTime-block">
                          <div class="slotTime-left">
                            <h4>booking time slot</h4>
                            <div class="TimeSlot-start">
                            <h5>start time</h5>
                           <ul>
                                   <li>00:00</li>
                                   <li>00:30</li>
                                   <li>01:00</li>
                                   <li>01:30</li>
                                   <li>02:00</li>
                                   <li>02:30</li>
                                   <li>03:00</li>
                                   <li>03:30</li>
                                   <li>04:00</li>
                                   <li>04:30</li>
                                   <li>05:00</li>
                                   <li>05:30</li>
                                   <li>06:00</li>
                                   <li>06:30</li>
                                   <li>07:00</li>
                                   <li>07:30</li>
                                   
                         </ul>                               
                               <div class="timeselection-slot">
                                <span class="green-time-select"></span>
                                <span class="violet-time-select"></span>                             
                               </div>                             
                               <h5>finish time</h5>
                               </div>
                               
                           </div>
                           <div class="slotTime-right"></div>                      
                       </div>              
                  </div>
                  </div>
                  
                  
                  
                   <div class="calendar-right-panel">
                    <!--<img class="img-responsive" src="{{asset('frontend/images/calendar-dummy.jpg')}}" alt="calendar-dummy"/>-->
				  
				  <div id="touring-calender"></div>
                  
                  </div>
                  
                  <div class="clearfix"></div>
                  
                  <ul class="calendar-Indicators">
                   <li><span class="red-calenderIndicator"></span> booked</li>
                    <li><span class="red-calenderIndicator green-calenderIndicator"></span> available</li>
                    <li><span class="red-calenderIndicator violet-calenderIndicator"></span> break time</li>
                    <li><span class="touring-calenderIndicator"></span> <img src="{{asset('frontend/images/aeroplane-icon.png')}}">touring</li>
                    <li><span class="red-calenderIndicator dayoff-calenderIndicator"></span> day off</li>
                  </ul>
                  
                 <div class="calander-textarea-block">
                     <textarea class="calandar-textarea" name="additional_information"  rows="3" placeholder="Additinal infortmation"></textarea>                  
                  </div>              
               </div>         
       </div>  
     </section>
			

			
			<div class="contact-box personal-radiobutton-box">
                    <h4>Select Gender<sup>*</sup></h4>
                    <div class="cntr_radio">
                      <label for="female" class="radio">
                        <input type="radio" name="rdo" value="female" id="female" class="hidden"  
                        {{ !empty($listdata['metaData']['rdo']) && $listdata['metaData']['rdo'] == 'female'? 'checked' : ''}}>
                        <span class="label"></span>Female
                      </label>
					  
                      <label for="male" class="radio">
                        <input type="radio" name="rdo" value="male"  id="male" class="hidden"
                        {{ !empty($listdata['metaData']['rdo']) && $listdata['metaData']['rdo'] == 'male'? 'checked' : ''}}>
                        <span class="label"></span>Male
                      </label>
					  
					  <label for="trans" class="radio">
                        <input type="radio" name="rdo" value="trans" id="trans" class="hidden"
                        {{ !empty($listdata['metaData']['rdo']) && $listdata['metaData']['rdo']== 'trans'? 'checked' : ''}}>
                        <span class="label"></span>Trans
                      </label>
                    </div>
                    
                  </div>
			
			
			
                <div class="contact-box">
                    <h4>Contact</h4>
                    <div class="row">
                    {{ csrf_field() }}
                    <input type="hidden" name="ad_listing_type_id" value="{{$ad_listing_type_id}}">
                    <input type="hidden" name="user_ad_id" value="{{!empty($user_ad_id)? $user_ad_id : ''}}">
                    <!---gdhsa-->
                        <div class="form-group col-md-4">
                            <input type="text" class="form-control" placeholder="Name" name="ad_name" 
                            value="{{!empty($listdata['adName']) ? $listdata['adName']:'' }}">
                            <!-- <sup><img src="images/red-inputstar.png" alt="red-inputstar"></sup>-->
                        </div>
                        <div class="form-group col-md-4">
                            <input type="email" class="form-control" placeholder="Email" name="ad_email" 
                            value="{{!empty($listdata['adEmail']) ? $listdata['adEmail']:'' }}">
                        </div>
                        <div class="form-group col-md-4">
                            <input type="text" class="form-control" placeholder="Phone Number" name="ad_contactno" 
                            value="{{!empty($listdata['adContact']) ? $listdata['adContact']:'' }}">
                        </div>
                        <div class="form-group col-md-4">
                        <select class="form-control" name="country_name" onchange="getCity(this.value)" id="country_name" >
                            <option value=''>Country</option>
                            @foreach($countries as $cn)
                            <option value='{{ $cn["id"] }}'>{{ $cn['country_name'] }}</option>
                            @endforeach
                        </select>
                        </div>
                        <div class="form-group col-md-4">
                        <select class="form-control" name="city_name" id="city_name" placeholder="City" >
                            <option value=''>City</option>
                        </select>
                        </div>
                        <div class="form-group col-md-4">
                        <input type="text" class="form-control" placeholder="Suburbs" name="suburbs"
                        value="{{!empty($listdata['adSuburbs']) ? $listdata['adSuburbs']:'' }}">
                        </div>
                        <div class="form-group col-md-4">
                        <input type="text" class="form-control" placeholder="Website URL" name="website_url"
                        value="{{!empty($listdata['metaData']['website_url']) ? $listdata['metaData']['website_url']:'' }}">
                        </div>
						
						<div class="clearfix"></div>
						<div class="form-group col-md-12 margin-bottom-zero">
                    <textarea class="form-control custom-textarea" name="additional_information" id="additional_information" rows="3" placeholder="Additinal infortmation e.g. I do not answer blocked / private numbers.">{{!empty($listdata['metaData']['additional_information']) ? $listdata['metaData']['additional_information']:'' }}</textarea>
                </div>
				    </div>
					</div>
					
					
					<div class="contact-box personal-radiobutton-box">
					<h4>Social Media Links (optional)</h4>
					  <div class="row">
                       @foreach($social_media_links as $mlinks)
					  <div class="form-group col-md-4">
					    <span class="socialIcons">@if(!empty($mlinks['icon']))<img src="{{ url('upload/'.$mlinks['icon']) }}">@endif</span>
                        <input type="text" class="form-control socialInput"
                         placeholder="{{$mlinks['value']}}" name="social_links_{{$mlinks['id']}}"
                         value="{{!empty($listdata['metaData']['social_links_'.$mlinks['id']]) ? $listdata['metaData']['social_links_'.$mlinks['id']]:'' }}">
                        </div>
                        @endforeach
					</div>
					</div>
					
					
					<div class="contact-box personal-radiobutton-box">
                    <h4>Write Your Tagline (optional)</h4>
                    <div class="form-group col-md-7 margin-bottom-zero">	
                        <div class="row">  					
							<input type="text" class="form-control"  value="{{!empty($listdata['metaData']['tagline']) ? $listdata['metaData']['tagline']:'' }}"
                            placeholder="Pristine glamour meets graciously elite discretion hot & sexy euro girl in sydney now " name="tagline">
							</div>
					</div>

                </div>
				
				
				<div class="contact-box personal-radiobutton-box">
                    <h4>Preferred method of booking via</h4>
                             @php
                             if(!empty($listdata['metaData']['booking_method']) ){
                                if(!is_array($listdata['metaData']['booking_method'])){
                                    $b_array = (array)$listdata['metaData']['booking_method'];
                                }else{
                                    $b_array = $listdata['metaData']['booking_method'];
                                }
                             }
                                @endphp
                    <div class="radio radio-info form-check-inlinesquarebox">
                      <input type="checkbox" name="booking_method[]" 
                      id="checkboxG15" value="text message" class="css-checkbox"
                      {{!empty($b_array) && in_array('text message', $b_array) ? 'checked': ''}}>
                      <label for="checkboxG15" class="css-label">Text Message</label>
                    </div>
                    <div class="radio radio-info form-check-inlinesquarebox">
                      <input type="checkbox" name="booking_method[]" 
                      id="checkboxG16" value="call" class="css-checkbox"
                      {{!empty($b_array) && in_array('call', $b_array) ? 'checked': ''}}>
                      <label for="checkboxG16" class="css-label">Call</label>
                    </div>
                    <div class="radio radio-info form-check-inlinesquarebox">
                      <input type="checkbox" name="booking_method[]" id="checkboxG17"  
                      value="email" class="css-checkbox" {{!empty($b_array) && in_array('email', $b_array) ? 'checked': ''}}>
                      <label for="checkboxG17" class="css-label">Email</label>
                    </div>
                    <div class="radio radio-info form-check-inlinesquarebox">
                      <input type="checkbox" name="booking_method[]" id="checkboxG18" value="watsapp" class="css-checkbox"
                      {{!empty($b_array) && in_array('watsapp', $b_array) ? 'checked': ''}}>
                      <label for="checkboxG18" class="css-label">Whatsapp</label>
                    </div>
                    
                  </div>
                

                <div class="contact-box personal-radiobutton-box personal-section">
                    <h4>Personal</h4>
                    <div class="cntr_radio">
                        @foreach($personal as $p)
                        <label for="personal{{$p['id']}}" class="radio">
                            <input type="radio" name="personal" id="personal{{$p['id']}}" value="{{$p['value']}}"
                            {{!empty($listdata['metaData']['personal']) && $listdata['metaData']['personal'] == $p['id'] ? 'checked': ''}}/>
                            <span class="label"></span>{{ $p['value'] }}
                        </label>
                        @endforeach

                    </div>
                    <div class="clearfix"></div>
                    <div id="personal-error2"></div>
                </div>
                <div class="contact-box personal-radiobutton-box">
				<h4>My Attributes</h4>
				  <div class="row">
                                        				
					<div class="col-md-3 col-sm-12 col-xs-12">
				    <div class="selectdetail-widthblock">
                        <select class="select_box" name="age" >
                            <option value=''>Age</option>
                            @foreach($age as $a)
                            <option value="{{$a['id']}}"  {{!empty($listdata['metaData']['age']) && $listdata['metaData']['age'] == $a['id'] ? 'selected':''}}
                            >{{ $a['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="bustsize" >
                            <option value=''>Bust size</option>
                            @foreach($bustsize as $bs)

                            <option value="{{$bs['id']}}" {{!empty($listdata['metaData']['bustsize']) && $listdata['metaData']['bustsize'] == $bs['id'] ? 'selected':''}}>{{ $bs['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock" >
                        <select class="select_box" name="gender">
                            <option value=''>gender</option>
                            <option value='male' {{!empty($listdata['metaData']['gender']) && $listdata['metaData']['gender'] == 'male' ? 'checked': ''}}>Male</option>
                            <option value='female' {{!empty($listdata['metaData']['gender']) && $listdata['metaData']['gender'] == 'female' ? 'selected': ''}}>Female</option>
                        </select>
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="weight" >
                            <option value=''>weight</option>
                            @foreach($weight as $w)
                            <option {{!empty($listdata['metaData']['weight']) && $listdata['metaData']['weight'] == $w['id'] ? 'selected': ''}} value="{{ $w['id'] }}">{{ $w['value'] }}</option>
                            @endforeach

                        </select>
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="nationality" >
                            <option value=''>nationality</option>
                            @foreach($nationality as $n)
                            <option value="{{$n['id']}}" {{!empty($listdata['metaData']['nationality']) && $listdata['metaData']['nationality'] == $n['id'] ? 'selected':''}}>{{ $n['value'] }}</option>
                            @endforeach
                        </select>                      
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
					    <div class="form-group">                   
                        <input type="text" id="ethnicity" class="form-control" name="ethinicity" value="{{!empty($listdata['metaData']['ethnicity']) && $listdata['metaData']['ethnicity'] == $a['id'] ? $listdata['metaData']['ethnicity']:''}}" placeholder="Ethnicity" >
						</div>
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="height" >
                            <option value=''>height</option>
                            @foreach($height as $h)
                            <option value='{{ $h["id"] }}' {{!empty($listdata['metaData']['height']) && $listdata['metaData']['height'] == $h['id'] ? 'selected': ''}}>{{ $h['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="orientation" >
                            <option value=''>orientation</option>
                            @foreach($orientation as $o)
                            <option value="{{ $o['id'] }}" {{!empty($listdata['metaData']['orientation']) && $listdata['metaData']['orientation'] == $o['id'] ? 'selected':''}}>{{ $o['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="eyecolor" >
                            <option value=''>eye color</option>
                            @foreach($eyecolor as $e)
                            <option value='{{ $e["id"] }}' {{!empty($listdata['metaData']['eyecolor']) && $listdata['metaData']['eyecolor'] == $e['id'] ? 'selected':''}}>{{ $e['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="haircolor" >
                            <option value=''>hair color</option>
                            @foreach($haircolor as $h)
                            <option value='{{ $h["id"] }}' {{!empty($listdata['metaData']['haircolor']) && $listdata['metaData']['haircolor'] == $h['id'] ? 'selected':''}}>{{ $h['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
				</div>	
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="hairlength" >
                            <option value=''>hair length</option>
                            @foreach($hairlength as $hl)
                            <option value='{{ $hl["id"] }}' {{!empty($listdata['metaData']['hairlength']) && $listdata['metaData']['hairlength'] == $hl['id'] ? 'selected':''}}>{{ $hl['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="dresssize" >
                            <option value=''>Dress Size</option>
                            @foreach($dresssize as $ds)
                            <option value='{{ $ds["id"] }}' {{!empty($listdata['metaData']['dresssize']) && $listdata['metaData']['dresssize'] == $ds['id'] ? 'selected':''}}>{{ $ds['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="shoessize" >
                            <option value=''>Shoes Size</option>
                            @foreach($shoessize as $ss)
                            <option value='{{ $ss["id"] }}' {{!empty($listdata['metaData']['shoessize']) && $listdata['metaData']['shoessize'] == $ss['id'] ? 'selected':''}}>{{ $ss['value'] }}</option>
                            @endforeach
                        </select>
                    </div>
					</div>
					
					 
					 <div class="col-md-3 col-sm-12 col-xs-12">
					<div class="selectdetail-widthblock">
					<div class="dropdown dropdown-select">
					  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                            Body Type
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                        @php
                        if(!empty($listdata['metaData']['body-type'])){
                                if(!is_array($listdata['metaData']['body-type'])){
                                    $body_array = (array)$listdata['metaData']['body-type'];
                                }else{
                                    $body_array = $listdata['metaData']['body-type'];
                                }
                        }
                        @endphp
                        @foreach($bodytype as $body)
                            <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                              
                                <input type="checkbox"  id="checkbox{{$body['id']}}" {{!empty($body_array) && in_array($body['id'], $body_array) ? 'checked':''}} name="body-type[]" value="{{ $body['id'] }}" class="css-checkbox" />
                                <label for="checkbox{{$body['id']}}" class="css-label">{{$body['value']}}</label>
                              </div>
                            </li>
                            @endforeach													
                        </ul>
				    </div>
					</div>
					</div>
					
					
					<div class="col-md-3 col-sm-12 col-xs-12">
					<div class="selectdetail-widthblock">
					<div class="radio radio-info form-check-inlinesquarebox tall-checkbox">
                          <input type="checkbox" name="is_tall" id="is_tall" class="css-checkbox" {{!empty($listdata['metaData']['is_tall']) && $listdata['metaData']['is_tall'] == 'on' ? 'checked': ''}}>
                          <label for="is_tall" class="css-label">Tall<span class="smalltext">(optional)</span></label>
                        </div>
						
						<div class="radio radio-info form-check-inlinesquarebox tall-checkbox">
                          <input type="checkbox" name="is_short" id="is_short" class="css-checkbox" {{!empty($listdata['metaData']['is_short']) && $listdata['metaData']['is_short'] == 'on' ? 'checked': ''}}>
                          <label for="is_short" class="css-label">Short<span class="smalltext">(optional)</span></label>
                        </div>
						</div>
					</div>	
						
						<div class="clearfix"></div>
						
						<div class="col-md-12">
						 <div class="form-group margin-bottom-zero">
                    <textarea class="form-control custom-textarea" name="about_description" id="description" rows="3"
                        placeholder="Describe Yourself">{{!empty($listdata['aboutDescription']) ? $listdata['aboutDescription']:''}}</textarea>
                </div>
					
                </div>
				</div>
                
              
                <div class="clearfix"></div>
				
				</div>
                
                <div class="contact-box personal-radiobutton-box">
                    <h4>Tattos (optional)</h4>
                    <div class="cntr_radio">
                        <label for="tattoos1" class="radio">
                            <input type="radio" name="tattoos" id="tattoos1" value="yes" class="hidden" 
                            {{!empty($listdata['metaData']['tattoos']) && $listdata['metaData']['tattoos'] == 'yes' ? 'checked': ''}}/>
                            <span class="label"></span>Yes
                        </label>
                        <label for="tattoos2" class="radio">
                            <input type="radio" name="tattoos" id="tattoos2" class="hidden" value="no" checked 
                            {{!empty($listdata['metaData']['tattoos']) && $listdata['metaData']['tattoos'] == 'no' ? 'checked': ''}}/>
                            <span class="label"></span>No
                        </label>
                    </div>

                </div>
                <div class="clearfix"></div>
                <div class="contact-box personal-radiobutton-box">
                    <h4>Piercing (optional)</h4>
                    @php
                    if(!empty($listdata['metaData']['piercing'])){
                        if(!is_array($listdata['metaData']['piercing'])){
                            $piercing_array = (array)$listdata['metaData']['piercing'];
                        }else{
                            $piercing_array = $listdata['metaData']['piercing'];
                        }
                    }
                    @endphp
                    @foreach($piercing as $p)
                    <div class="radio radio-info form-check-inlinesquarebox">
                        <input type="checkbox" name="piercing[]" value="{{ $p['id'] }}" id="checkboxG{{ $p['id'] }}"
                       
                            class="css-checkbox"  {{!empty($piercing_array) && in_array( $p['id'],  $piercing_array) ? 'checked':''}}/>
                        <label for="checkboxG{{ $p['id'] }}" class="css-label">{{ $p['value'] }}</label>
                    </div>
                    @endforeach
                    <div class="clearfix"></div>
                    <div id="piercing-error2"></div>
                </div>
                <div class="clearfix"></div>
                <div class="contact-box personal-radiobutton-box">
                    <h4>Smoker (optional)</h4>
                    <div class="cntr_radio">
                        <label for="smoker" class="radio">
                            <input type="radio" name="smoker" id="smoker" value="smoker" class="hidden"  
                            {{!empty($listdata['metaData']['smoker']) && $listdata['metaData']['smoker'] == 'smoker' ? 'checked':'checked'}}/>
                            <span class="label"></span>Smoker
                        </label>
                        <label for="non-smoker" class="radio">
                            <input type="radio" name="smoker" id="non-smoker" class="hidden" value="non smoker" 
                            {{!empty($listdata['metaData']['smoker']) && $listdata['metaData']['smoker'] == 'non smoker' ? 'checked': ''}} />
                            <span class="label"></span>Non Smoker
                        </label>
                        <label for="occasional-smoker" class="radio">
                            <input type="radio" name="smoker" id="occasional-smoker" class="hidden" value="occasional smoker" 
                            {{!empty($listdata['metaData']['smoker']) && $listdata['metaData']['smoker'] == 'occasional smoker' ? 'checked': ''}}/>
                            <span class="label"></span>Occasional Smoker
                        </label>
                    </div>
                    <div class="clearfix"></div>
                   
                </div>
				
				<div class="clearfix"></div>
				
				
				<div class="contact-box personal-radiobutton-box drinkbox">
                    <h4>Drinks (optional)</h4>
                    <div class="cntr_radio">
                        <label for="drink" class="radio">
                            <input type="radio" name="drink" id="regular-drink" value="regular drink" class="hidden" 
                            {{!empty($listdata['metaData']['drink']) && $listdata['metaData']['drink'] == 'regular drink' ? 'checked': ''}} />
                            <span class="label"></span>Regular Drink
                        </label>
                        <label for="non-drink" class="radio">
                            <input type="radio" name="drink" id="non-drink" class="hidden" value="non drink"  
                            {{!empty($listdata['metaData']['drink']) && $listdata['metaData']['drink'] == 'non drink' ? 'checked': ''}}/>
                            <span class="label"></span>Non Drink
                        </label>
                        <label for="occasional-drink" class="radio">
                            <input type="radio" name="drink" id="occasional-drink" class="hidden" value="occasional drink" 
                            {{!empty($listdata['metaData']['drink']) && $listdata['metaData']['drink'] == 'occasional drink' ? 'checked': ''}}/>
                            <span class="label"></span>Occasional Drink
                        </label>
                    </div>
                    <div class="clearfix"></div>
                 
					<div class="form-group margin-bottom-zero">
                    <textarea class="form-control custom-textarea" name="additional_information" id="additional_information" rows="3" placeholder="Additinal infortmation e.g. *I have tattoos that have been removed from my images for my privacy*">{{!empty($listdata['metaData']['additional_information']) ?  $listdata['metaData']['additional_information']:''}}</textarea>
                </div>
                </div>
				
				<div class="clearfix"></div>
				<div class="contact-box personal-radiobutton-box drinkbox">
                    <h4>My Hobbie & Interest</h4>
                	<div class="form-group margin-bottom-zero">
                    <textarea class="form-control custom-textarea" name="hobbies_interest" id="hobbies_interest" rows="3" 
                    placeholder="Yoga / the mind / creativity / spirituality / the arts / simplicity / business / scuba diving / hip hop / music etc...">{{!empty($listdata['metaData']['hobbies_interest']) ?  $listdata['metaData']['hobbies_interest']:''}}</textarea>
                </div>
                </div>
				
				
                <div class="clearfix"></div>
                    
                    <div class="contact-box fav-things">
                    <h4>My Favourites Things</h4>
                        <div class="row">
                        @php
                            $favcount = 1;
                            @endphp
                            @foreach($favthings as $fav)
                            
                            <div class="col-md-6 favthings">
                             
                                <div class="form-group row">
                                    <label for="inputText" class="col-sm-2 col-form-label">{{ $fav['value'] }}</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="fav_things_{{$fav['id']}}" class="form-control" id="inputText"
                                            placeholder="Place your text" value="{{!empty($listdata['metaData']['fav_things_'.$fav['id']])  ? $listdata['metaData']['fav_things_'.$fav['id']]:''}}">
                                    </div>
                                </div>
                                
                            </div>
                           
                            @endforeach
                            <div class="col-md-12 favthings_placeholder"></div>
							
							<a href="javascript:void(0)" class="add-BTN" onclick="addFavThings()">Add more<i class="fa fa-plus"></i> </a>

                        </div>
                    </div>
					
					
					<div class="contact-box fav-things wishlist-box wishlist_things">
                    <h4>My Wishlists</h4>
                        <div class="row">
                        @php
                            $wishcount = 1;
                            @endphp
                            @foreach($wishlistthings as $wt)
                            @if($wishcount%2)
                            <div class="col-md-6">
                                @endif
                                <div class="form-group row">
                                    <label for="inputText" class="col-sm-2 col-form-label">{{ $wt['value'] }}</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="wish_things_{{$wt['id']}}" class="form-control" id="inputText"
                                            placeholder="Place your text" value="{{!empty($listdata['metaData']['wish_things_'.$wt['id']])  ? $listdata['metaData']['wish_things_'.$wt['id']]:''}}">
                                    </div>
                                </div>
                                @if($wishcount%2)
                            </div>  
                            @endif
                            @endforeach
							
							<div class="col-md-12 wishlist_placeholder"></div>
							<a href="javascript:void(0)" class="add-BTN" onclick="addWishThings()">Add more<i class="fa fa-plus"></i> </a>
							
                        </div>
                        

                    </div>
                    
                </div>
				</div>
            </div>

        </div>
            <div class="actions clearfix step_1">
            <ul role="menu" aria-label="Pagination">
                <li></li>
                <li aria-hidden="false" aria-disabled="false">
                    <a href="#">
                        <input type="submit" name="next_step_1" value="Save & Next" id="next_step_1" class="NextBTN">
                    </a>
                    </li>
                <li></li>
                
            </ul>
        </div>
        </form>
</div>
<!-- services time modal pop up start -->
<div class="modal fade services-addTime" id="services-addTime" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Booking Calender</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
       
        
        <form>
            <div class="sevicesaddtime-top">
            <h4>Booking Notes</h4>
            <div class="form-group">
            <label for="recipient-name" class="col-form-label">Title</label>
            <input type="text" placeholder="Enter title" class="form-control" id="title">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Client Name</label>
            <input type="text" placeholder="Enter Client Name" class="form-control" id="client_name">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Service Type</label>
            <input type="text" placeholder="Sansual Massage, Blow Job, Full Service" class="form-control" id="Service_type">
          </div>
        </div>

        <div class="sevicesaddtime-top bookingSlot-block">
            <h4>Booking Slot</h4>
          <button type="button" class="bookslot-btns booked-btn">Booked</button>
          <button type="button" class="bookslot-btns breaktime-btn">Break Time</button>
          <button type="button" class="bookslot-btns dayoff-btn">Day OFF</button>
          <button type="button" class="bookslot-btns Available-btn">Available</button>
          
          <div class="clearfix"></div>
           <div class="row">

         
          <div class='col-md-6 form-group from-time'>
              <label for="message-text" class="col-form-label">From</label>
              <input type="text" class="form-control datepicker" name="calendar_start_date" id="calendar_start_date"/>
                <input type="text" class="form-control timepicker" name="calendar_start_time" id="calendar_start_time"/>
             
          </div>
  
          <div class='col-md-6 form-group to-time'>
              <label for="message-text" class="col-form-label">To</label>
              <input type="text" class="form-control datepicker" name="calendar_end_date" id="calendar_end_date"/>
                <input type="text" class="form-control timepicker" name="calendar_end_time" id="calendar_end_time"/>
             
          </div>
        </div>
        </div>    
        </form>
        
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="button" class="servicespopupSave-btn">Save</button>
      </div>
    </div>
  </div>
</div>
<!-- services time modal pop up end -->