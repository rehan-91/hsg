@extends('frontend.layouts.front_layout')
@section('content')
<div id="Load" class="load" style="display:none;">
    <div class="load__container">
        <div class="load__animation"></div>
        <div class="load__mask"></div>
        <span class="load__title">Loading...</span>
    </div>
</div>
<style>
.load__animation {
    border: 5px solid #272727;
    border-top-color: #e50914;
    border-top-style: groove;
    height: 100px;
    width: 100px;
    border-radius: 100%;
    position: relative;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    -webkit-animation: turn 1.5s linear infinite;
    -o-animation: turn 1.5s linear infinite;
    animation: turn 1.5s linear infinite;
}

.load {
    position: fixed;
    background-color: rgba(0, 0, 0, 0.8);
    width: 100%;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 999;
    top: 0;
}

.load__container {
    position: relative;
}

@keyframes turn {
    from {
        transform: rotate(0deg)
    }

    to {
        transform: rotate(360deg)
    }
}

.load__title {
    color: #fff;
    font-size: 2rem;
}

@keyframes loadPage {
    0% {
        opacity: 1;
    }

    50% {
        opacity: .5;
    }

    100% {
        opacity: 1;
    }

}
</style>

<section class="profile-details-block">
    <div class="container">
        <form role="form" action="" method="post" id="contact">
            <div id="wizard">
                {{ csrf_field() }}
                <h1>Details</h1>
                <div class="content_block">
                    <h2 class="text-danger">details</h2>
                    <div class="setup-content" id="step-1">
                        <div class="profile-details-form">
                            <div class="contact-box">
                                <h4>Contact</h4>
                                <div class="row">

                                    <div class="form-group col-md-4">
                                        <input type="text" class="form-control" placeholder="Name" name="name" required>
                                        <!-- <sup><img src="images/red-inputstar.png" alt="red-inputstar"></sup>-->
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="email" class="form-control" placeholder="Email" name="email"
                                            required>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" class="form-control" placeholder="Phone Number" name="phone"
                                            required>
                                    </div>
                                </div>
                            </div>

                            <div class="contact-box personal-radiobutton-box">
                                <h4>Personal</h4>
                                <div class="cntr_radio">
                                    @foreach($personal as $p)
                                    <label for="personal{{$p['id']}}" class="radio">
                                        <input type="radio" name="personal" id="personal{{$p['id']}}" />
                                        <span class="label"></span>{{ $p['value'] }}
                                    </label>
                                    @endforeach

                                </div>
                                <div class="clearfix"></div>
                                <div id="personal-error2"></div>
                            </div>
                            <div class="contact-box personal-radiobutton-box">
                                <h4>My Physical Attributes</h4>

                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="age" required>
                                        <option value=''>Age</option>
                                        @foreach($age as $a)
                                        <option value="{{$a['id']}}">{{ $a['value'] }}</option>
                                        @endforeach


                                    </select>
                                </div>
                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="bust_size" required>
                                        <option value=''>Bust size</option>
                                        @foreach($bustsize as $bs)

                                        <option value="{{$bs['id']}}">{{ $bs['value'] }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="selectdetail-widthblock" required>
                                    <select class="select_box" name="gender">
                                        <option value=''>gender</option>
                                        <option value='male'>Male</option>
                                        <option value='female'>Female</option>
                                    </select>
                                </div>
                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="weight" required>
                                        <option value=''>weight</option>
                                        @foreach($weight as $w)
                                        <option value="{{ $w['id'] }}">{{ $w['value'] }}</option>
                                        @endforeach

                                    </select>
                                </div>
                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="nationality" required>
                                        <option value=''>nationality</option>
                                        @foreach($nationality as $n)
                                        <option value="$n['id']">{{ $n['value'] }}</option>
                                        @endforeach

                                    </select>
                                </div>
                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="height" required>
                                        <option value=''>height</option>
                                        @foreach($height as $h)
                                        <option value='{{ $h["id"] }}'>{{ $h['value'] }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="orientation" required>
                                        <option value=''>orientation</option>
                                        @foreach($orientation as $o)
                                        <option value="{{ $o['id'] }}">{{ $o['value'] }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="eyecolor" required>
                                        <option value=''>eye color</option>
                                        @foreach($eyecolor as $e)
                                        <option value='{{ $e["id"] }}'>{{ $e['value'] }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="selectdetail-widthblock">
                                    <select class="select_box" name="haircolor" required>
                                        <option value=''>hair color</option>
                                        @foreach($haircolor as $h)
                                        <option value='{{ $h["id"] }}'>{{ $h['value'] }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="form-group">
                                <textarea class="form-control custom-textarea" name="description" id="description"
                                    rows="3" placeholder="Describe Yourself"></textarea>
                            </div>

                            <div class="clearfix"></div>

                            <div class="contact-box personal-radiobutton-box">
                                <h4>Body type</h4>
                                @foreach($bodytype as $body)
                                <div class="radio radio-info form-check-inlinesquarebox">
                                    <input type="checkbox" name="bodytype[]" value="{{ $body['id'] }}"
                                        id="checkbox{{$body['id']}}" class="css-checkbox" />
                                    <label for="checkbox{{$body['id']}}" class="css-label">{{$body['value']}}</label>
                                </div>
                                @endforeach
                                <div class="clearfix"></div>
                                <div id="bodytype-error2"></div>

                            </div>
                            <div class="clearfix"></div>
                            <div class="contact-box personal-radiobutton-box">
                                <h4>Tattos (optional)</h4>
                                <div class="cntr_radio">
                                    <label for="tattoos1" class="radio">
                                        <input type="radio" name="tattoos" id="tattoos1" value="yes" class="hidden" />
                                        <span class="label"></span>Yes
                                    </label>
                                    <label for="tattoos2" class="radio">
                                        <input type="radio" name="tattoos" id="tattoos2" class="hidden" value="no"
                                            checked />
                                        <span class="label"></span>No
                                    </label>
                                </div>

                            </div>
                            <div class="clearfix"></div>
                            <div class="contact-box personal-radiobutton-box">
                                <h4>Body Piercing (optional)</h4>
                                @foreach($piercing as $p)

                                <div class="radio radio-info form-check-inlinesquarebox">
                                    <input type="checkbox" name="piercing[]" value="{{ $p['id'] }}" id="checkboxG1"
                                        class="css-checkbox" />
                                    <label for="checkboxG1" class="css-label">{{ $p['value'] }}</label>
                                </div>
                                @endforeach
                                <div class="clearfix"></div>
                                <div id="piercing-error2"></div>
                            </div>
                            <div class="contact-box">
                                <h4>Social Information</h4>
                                <div class="row">

                                    <div class="form-group col-md-4">
                                        <input type="text" class="form-control" placeholder="Facebook URL"
                                            name="facebook_url">
                                        <!-- <sup><img src="images/red-inputstar.png" alt="red-inputstar"></sup>-->
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" class="form-control" placeholder="Youtube URL"
                                            name="youtube_url">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" class="form-control" placeholder="Instagram URL"
                                            name="instagram_url">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" class="form-control" placeholder="G+ URL" name="gplus_url">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" class="form-control" placeholder="Whatsapp Number"
                                            name="watsapp_number">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <h1>Upgrade</h1>


<div class="content_block">
    <section class="pay-boxz">
        <div class="container">
            <h2 class="text-danger mb-5 mt-3">Choose your Subsription</h2>
            <div class="row">
                @php
                $count = 1;
                @endphp
                @foreach($plans as $p)
                <div class="col-12 col-sm-8 col-md-6 col-lg-4 price-cards ">
                    <div
                        class="card @if($count == 1) red-border @elseif($count == 2) purple-border @elseif($count==3) magenta-border @endif">
                        <div class="card-header text-center border-bottom-0 bg-transparent pt-4">
                            <h5>{{ strtoupper($p->plan_name) }}</h5>
                        </div>
                        <div class="card-body">
                            <h1>{{ price_format($p->plan_price_base) }}</h1>
                            <h5 class="text-center"><small>Ad duration :
                                    <span>{{ $p->plan_duration." ".$p->plan_duration_unit}}</span></small>
                            </h5>
                        </div>
                        <ul class="list-group list-group-flush" id="hide-more-features{{$p->id}}">
                            @php
                            $plans_features = explode("\n", $p->plan_features);
                            $fcount = 1;

                            @endphp
                            @foreach($plans_features as $pf)
                            @php
                            $planClass = ($fcount > 3) ? "hide-more-features" : '';
                            $style = ($fcount > 3) ? "style=display:none;" :'';
                            @endphp
                            <li class="list-group-item {{ $planClass }}" {{ $style }}><i
                                    class="fa fa-check mx-2"></i><span>{{ $pf }}</span></li>
                            @php $fcount++; @endphp
                            @endforeach
                        </ul>
                        @if(count($plans_features) > 3)
                        <p class="text-left small read-more-features"
                            onclick="readMoreFeatures({{$p->id}})"> Read More </p>
                        @endif
                        <div class="card-footer border-top-0 upgrade-btn text-center">
                            <a href="#" class="text-uppercase">upgrade</a>
                        </div>
                    </div>
                </div>
                @php
                $count++;
                @endphp
                @endforeach
            </div>
        </div>
    </section>
</div>   
                <h1>Services</h1>
                <div class="content_block services-step-section">
                    <h2>Services</h2>
                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Available for</h4>
                        @foreach($serviceavailablefor as $saf)

                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="service_avail_for[]" id="service-avail-for{{$saf['id']}}"
                                class="css-checkbox" />
                            <label for="service-avail-for{{$saf['id']}}" class="css-label">{{$saf['value']}}</label>
                        </div>
                        @endforeach

                        <div class="clearfix"></div>
                        <div id="service_avail_for-error2"></div>

                    </div>
                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Service type</h4>
                        @foreach($servicetype as $st)

                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="service_type[]" id="service-type{{$st['id']}}"
                                class="css-checkbox" />
                            <label for="service-type{{$st['id']}}" class="css-label">{{$st['value']}}</label>
                        </div>

                        @endforeach
                        <div class="clearfix"></div>
                        <div id="service_type-error2"></div>



                    </div>

                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Service available</h4>

                        @foreach($servicesavailable as $sa)

                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="service_available[]" id="service-available{{$sa['id']}}"
                                class="css-checkbox" />
                            <label for="service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                        </div>

                        @endforeach
                        <div class="clearfix"></div>
                        <div id="service_available-error2"></div>
                        <div class="clearfix"></div>
                        <div class="form-group mt-4">
                            <textarea class="form-control custom-textarea bg-theme-dark-form" id="describe_service"
                                name="describe_service" rows="3" placeholder="Describe Yourself"></textarea>
                        </div>


                    </div>
                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Extra Services</h4>
                        @foreach($extraservices as $es)
                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="extraservices[]" id="extra-service{{$es['id']}}"
                                class="css-checkbox" />
                            <label for="extra-service{{$es['id']}}" class="css-label">{{ $es['value'] }}</label>
                        </div>
                        @endforeach
                        <div class="clearfix"></div>
                        <div id="extraservices-error2"></div>
                    </div>
                    <div class="contact-box personal-radiobutton-box pink-label working_hours_box">
                        <h4>Working Hours</h4>
                        <div class="working_hours">
                            <div class="col-half">
                                @for($i=1; $i <= 7; $i++) <div class="dropcol_box">
                                    <div class="label-col"><label>{{ getDay($i) }}</label></div>
                                    <div class="dropbox-col">
                                        <div class="dropdown-col">
                                            <select id="{{ getDay($i) }}_from" class="select_box"
                                                name="{{ getDay($i) }}_from">
                                                <option>From</option>
                                                @php echo get_times() @endphp
                                            </select>
                                        </div>
                                        <div class="dropdown-col">
                                            <select id="{{ getDay($i) }}_to" class="select_box"
                                                name="{{ getDay($i) }}_to">
                                                <option>To</option>
                                                @php echo get_times() @endphp
                                            </select>
                                        </div>
                                    </div>
                            </div>
                            @if($i % 4 == 0)
                        </div>
                        <div class="col-half">
                            @endif
                            @if($i === 7)
                        </div>
                        @endif
                        @endfor
                    </div>

                </div>


                <div class="services_select_box contact-box personal-radiobutton-box pink-label working_hours_box">
                    <h4>Rates</h4>
                    <div class="add-userroles services_rates" id="test">
                        <div class="rates_section">
                            <div class="drop_box services_select_box">
                                <select id="services_rates_0" class="service_select_box">
                                    @php
                                    $rates_time = get_rate_time();
                                    @endphp
                                    @foreach($rates_time as $key=>$t)
                                    <option value="{{$key}}">{{ $t }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="charges_box"><input type="text" class="form-control" placeholder="Charges">
                            </div>
                            <div class="service_box"><input type="text" class="form-control" placeholder="Services">
                            </div>
                            <div class="button_box"> <a href="javascript:void(0)" class="btn btn-danger add-rate"
                                    onclick="addRate()"><i class="fa fa-plus"></i> Add rate</a>

                                <a href="javascript:void(0)" class="btn remove-rate" onclick="removeRate()"><i
                                        class="fa fa-minus"></i></a></div>
                        </div>
                    </div>
                    <div id="tool-placeholder"></div>
                </div>

            </div>
            <h1>Photos</h1>
            <div class="content_block">
                <h2 class="text-danger">Photos & Videos</h2>
                <h4>Requirements</h4>
                <div class="listings">
                    <p><i class="fa fa-check" aria-hidden="true"></i>Upload high quality video and photos</p>
                    <p><i class="fa fa-check" aria-hidden="true"></i>Hosg accept Genuine photos and videos only</p>
                    <p><i class="fa fa-check" aria-hidden="true"></i>UploadWe will contact you for your profile
                        verification. Ant fake profile will be removed, no excelations and refund.</p>
                    <p><i class="fa fa-check" aria-hidden="true"></i>Keep it real, Keep it Fun</p>
                </div>
                <div class="profile_photos">

                    <h4>Profile Photos</h4>
                    <div class="preview-images-zone">
                        <fieldset class="form-group">
                            <div class="field_set">
                                <a href="javascript:void(0)" onclick="$('#pro-image').click()"><span
                                        class="pkus_icon">+</span><br />Add Photos</a>
                                <input type="file" id="pro-image" name="pro-image" style="display: none;"
                                    class="form-control" multiple>
                            </div>
                            <div class="max-photos">Max 10</div>
                        </fieldset>


                    </div>
                </div>
            </div>
            <h1>Touring</h1>
            <div class="content_block">
                <h2 class="text-danger">Touring</h2>
                <div class="contact-box personal-radiobutton-box pink-label working_hours_box touring_girls_box">
                    <h4>Select City and Dates</h4>
                    <div class="add-userroles touring_girls" id="touring_girls">
                        <div class="rates_section">
                            <div class="drop_box">
                                <input class="form-control startdate" id="startdate" placeholder="From Date" />

                            </div>
                            <div class="charges_box">
                                <input class="form-control enddate" id="enddate" placeholder="To Date" />
                            </div>
                            <div class="service_box">
                                <select class="select_box">
                                    <option value=''>Select City</option>
                                    <option value=''>City 1</option>
                                    <option value=''>City 2</option>
                                </select>
                            </div>
                            <div class="button_box"> <a href="javascript:void(0)" class="btn btn-danger add-tour"
                                    onclick="addTour()"><i class="fa fa-plus"></i> Add More</a>

                                <a href="javascript:void(0)" class="btn remove-tour" onclick="removeTour()"><i
                                        class="fa fa-minus"></i></a></div>
                        </div>
                        <p class="text_city text-left">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                        </p>
                    </div>
                    <div id="touring-section-placeholder"></div>
                </div>


            </div>

            <h1>Things I Love</h1>
            <div class="content_block">
                <h2 class="text-danger">Things I love</h2>
                <div class="contact-box personal-radiobutton-box working_hours_box touring_girls_box">

                    <div class="add-userroles touring_girls">
                        <div class="row">
                            @php
                            $favcount = 1;
                            @endphp
                            @foreach($favthings as $fav)
                            @if($favcount%2)
                            <div class="col-md-6">
                                @endif
                                <div class="form-group row">
                                    <label for="inputText" class="col-sm-2 col-form-label">{{ $fav['value'] }}</label>
                                    <div class="col-sm-10">
                                        <input type="text"  name="fav_things[]" class="form-control" id="inputText"
                                            placeholder="Place your text">
                                    </div>
                                </div>
                                @if($favcount%2)
                            </div>
                            @endif
                            @endforeach

                        </div>
                    </div>
                </div>

            </div>
            <h1>Finished</h1>
            <div class="content_block">
                <div class="thanks_box text-center">
                    <h2>Congratulation Alice</h2>
                    <p>Your ad is succesfully created</p>
                    <div class="clearfix"></div>
                    <a href="#" class="green_gredient_btn gr_green">View Dashoard</a>
                </div>
            </div>
    </div>
    </form>
    </div>
</section>

<!-- Creates the bootstrap modal where the image will appear -->
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
  <div class="modal-dialog" style="max-width:100%; margin:0">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">Image preview</h4>
      </div>
      <div class="modal-body">
        <img src="" id="imagepreview" style="width:100%">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">var imagePostURL = "{!! route('ajaximageupload') !!}";</script>
<script src="{{ asset('frontend/js/ad_post_script.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/jquery.imgareaselect.pack.js') }}"></script>
@endsection