
<div class="container">
<div class="content_block step_7" style="display:none;">
                <div class="thanks_box text-center">

                <!--<img src="{{ asset('frontend/images/giphy.gif') }}">-->
				<div id="finished_crackerss"></div>
				<h2>Congratulation Alice</h2>
                    <p>Your ad is succesfully created</p>
                    <div class="clearfix"></div>
					<div class="postremaing-cover">
					<a href="#" class="green_gredient_btn red_orangegradient">Post remaining AD’s</a>
					<span class="profile-smallheading">Your 1st ad out of 4 has been successfully posted. please post the remaining 3 ad NOW</span>
					</div>
                    <a href="#" class="green_gredient_btn gr_pink">View Dashoard</a>
					<a href="#" class="green_gredient_btn savedraft-btn">Save as draft & Post Ad later</a>
					
					
					

                </div>
				
				
				
			
            </div>
			</div>
			
			
			
			