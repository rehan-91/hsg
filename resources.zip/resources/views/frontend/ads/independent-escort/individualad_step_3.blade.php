
 <div class="container">

<div class="content_block services-step-section step_3" style="display:none;">

     <form method="post" action="{{ route('individualad.saveservices') }}" id="form_step_3" onsubmit="return false;">
          {{ csrf_field() }}
          <h2 class="text-danger">Services</h2>
          <div class="contact-box personal-radiobutton-box pink-label">
               <h4>Available for</h4>
               @php
                        if(!empty($listdata['metaData']['service-avail-for'])){
                                if(!is_array($listdata['metaData']['service-avail-for'])){
                                    $service_avail_array = (array)$listdata['metaData']['service-avail-for'];
                                }else{
                                    $service_avail_array = $listdata['metaData']['service-avail-for'];
                                }
                        }
                        @endphp
               @foreach($serviceavailablefor as $saf)

               <div class="radio radio-info form-check-inlinesquarebox">
                    <input type="checkbox" value="{{$saf['id']}}" 
                    {{!empty($service_avail_array) && in_array($saf['id'], $service_avail_array) ? 'checked':''}}
                    name="service-avail-for[]" id="service-avail-for{{$saf['id']}}"
                         class="css-checkbox" />
                    <label for="service-avail-for{{$saf['id']}}" class="css-label">{{$saf['value']}}</label>
               </div>
               @endforeach

               <div class="clearfix"></div>
               <div id="service-avail-for-error2"></div>

          </div>
          <div class="contact-box personal-radiobutton-box pink-label">
               <h4>Service type</h4>
               @php
                        if(!empty($listdata['metaData']['service-type'])){
                                if(!is_array($listdata['metaData']['service-type'])){
                                    $service_type_array = (array)$listdata['metaData']['service-type'];
                                }else{
                                    $service_type_array = $listdata['metaData']['service-type'];
                                }
                        }
                        @endphp
               @foreach($servicetype as $st)

               <div class="radio radio-info form-check-inlinesquarebox">
              
                    <input type="checkbox" value="{{$st['id']}}" name="service-type[]"
                    {{!empty($service_type_array) && in_array($st['id'], $service_type_array) ? 'checked':''}}
                     id="service-type{{$st['id']}}" class="css-checkbox" />
                    <label for="service-type{{$st['id']}}" class="css-label">{{$st['value']}}</label>
               </div>

               @endforeach
               <div class="clearfix"></div>
               <div id="service-type-error2"></div>



          </div>
          <div class="services_select_box contact-box personal-radiobutton-box pink-label working_hours_box">
     <h4>My Fees</h4>
        @if(count($listdata['rate']) > 0)
        @php $listcount = 0; @endphp
        @foreach($listdata['rate'] as $r)
 <div class="add-userroles services_rates" id="test">
          <div class="rates_section">
               <div class="drop_box services_select_box">
               <h6 class="labelwhite">Time<sup>*</sup></h6>
                    <select id="services_rates_{{$listcount}}" class="service_select_box service_time"
                         name="service[{{$listcount}}][service_time]">
                         @php
                         $rates_time = get_rate_time();
                         @endphp
                         @foreach($rates_time as $key=>$t)
                         <option value="{{$key}}" {{$t == $r->ad_time ? 'selected' : ''}}>{{ $t }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="charges_box">
               <h6 class="labelwhite">In Call <sup>*</sup></h6>
                    <input type="text" name="service[{{$listcount}}][service_incall_charge]"
                         class="form-control service_incall_charge" placeholder="Charges" value="{{$r->incall_charge}}">
               </div>
               <div class="charges_box">
               <h6 class="labelwhite">Out Call <sup>*</sup></h6>
                    <input type="text" name="service[{{$listcount}}][service_outcall_charge]"
                         class="form-control service_outcall_charge" placeholder="Charges"  value="{{$r->outcall_charge}}">
               </div>
               <div class="service_box" data-toggle="modal" data-target="#serviceIncluded-popup" data-backdrop="static">
                    <h6 class="labelwhite">Service Included <sup>*</sup></h6>
          @if(!empty($r->ad_services))
          @php 
          $services="";
          $servicesarraylist = explode(",", $r->ad_services);
          @endphp
          @foreach($servicesarraylist as $adsr)
          @php
          $services .= ",".getServiceName($adsr);
          @endphp
        
          @endforeach
          @endif
          <input type="text" id="service_name{{$listcount}}"
                         class="form-control service_name" placeholder="Choose Services" onclick="setId(this.id)" 
                         value="{{!empty($services) ?trim($services, ','):'' }}">

          <input type="hidden" name="service[{{$listcount}}][service_name]"
                         class="form-control service_name_hidden" id="service_name_hidden{{$listcount}}"  value="{{!empty($r->ad_services) ? $r->ad_services :'' }}">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
               </div>
               <div class="button_box"> 
                    <a href="javascript:void(0)" class="servicefee-btn-add add-rate"
                         onclick="addRate()"><i class="fa fa-plus"></i></a>
                        @if($listcount > 0)
                                   <a href="javascript:void(0)" class="servicefee-btn-remove remove-rate" onclick="removeRate()"><i
                              class="fa fa-minus"></i></a>
                       @endif
         </div>
       </div>
     </div>
        @php $listcount++; @endphp

        @endforeach
      @else
     <div class="add-userroles services_rates" id="test">
          <div class="rates_section">
               <div class="drop_box services_select_box">
               <h6 class="labelwhite">Time<sup>*</sup></h6>
                    <select id="services_rates_0" class="service_select_box service_time"
                         name="service[0][service_time]">
                         @php
                         $rates_time = get_rate_time();
                         @endphp
                         @foreach($rates_time as $key=>$t)
                         <option value="{{$key}}">{{ $t }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="charges_box">
               <h6 class="labelwhite">In Call <sup>*</sup></h6>
                    <input type="text" name="service[0][service_incall_charge]"
                         class="form-control service_incall_charge" placeholder="Charges">
               </div>
               <div class="charges_box">
               <h6 class="labelwhite">Out Call <sup>*</sup></h6>
                    <input type="text" name="service[0][service_outcall_charge]"
                         class="form-control service_outcall_charge" placeholder="Charges">
               </div>
               <div class="service_box" data-toggle="modal" data-target="#serviceIncluded-popup" data-backdrop="static">
                    <h6 class="labelwhite">Service Included <sup>*</sup></h6>
          
          <input type="text" id="service_name0"
                         class="form-control service_name" placeholder="Choose Services" onclick="setId(this.id)">

          <input type="hidden" name="service[0][service_name]"
                         class="form-control service_name_hidden" id="service_name_hidden0" >
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
               </div>
               <div class="button_box"> 
                    <a href="javascript:void(0)" class="servicefee-btn-add add-rate"
                         onclick="addRate()"><i class="fa fa-plus"></i></a>

                    <a href="javascript:void(0)" class="servicefee-btn-remove remove-rate" onclick="removeRate()"><i
                              class="fa fa-minus"></i></a></div>
          </div>
     </div>
     @endif;
     <div id="tool-placeholder"></div>
</div>
    
      
      <div class="contact-box personal-radiobutton-box pink-label">
                  <h4>Extra Service Fee</h4>
                  @if(count($listdata['extraService']) > 0)
                    @php $excount = 0; @endphp
                  @foreach($listdata['extraService'] as $lex)
                     <div class="add-userroles extraservice_fee">
                    <div class="rates_section">
                      <div class="drop_box">                        
                       <input type="text" class="form-control extraservice_price" name="extra_services[{{$excount}}][price]" placeholder="$300" value="{{$lex->ad_fee}}">
                      </div>
                      @if(!empty($lex->ad_services))
                      @php 
                      $exservices="";
                      $exservicesarraylist = explode(",", $lex->ad_services);
                      @endphp
                      @foreach($exservicesarraylist as $adsr)
                      @php
                      $exservices .= ",".getServiceName($adsr);
                      @endphp

                      @endforeach
                      @endif
                      <div class="service_box" data-toggle="modal" data-target="#extraserviceIncluded-popup" data-backdrop="static">
                         <!--<h6 class="labelwhite">Service Included <sup>*</sup></h6>-->
          
          <input type="text" id="extra_service_name{{$excount}}"
                         class="form-control extra_service_name" value="{{!empty($exservices) ?trim($exservices, ','):'' }}" placeholder="Choose Services" onclick="setExtraId(this.id)">

          <input type="hidden" name="extra_services[{{$excount}}][service_name]"
                         class="form-control extra_service_name_hidden" id="extra_service_name_hidden{{$excount}}" value="{{!empty($lex->ad_services) ? $lex->ad_services :'' }}">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
                    </div>
                    
                      <div class="button_box">
                         <a href="javascript:void(0)" class="servicefee-btn-add" onclick="addServiceFee()"><i class="fa fa-plus"></i></a>
                       @if($excount > 0)
                      <a href="javascript:void(0)" class="servicefee-btn-remove remove-service-rate" onclick="removeServiceFee()"><i class="fa fa-minus"></i></a>
                      @endif
                      </div>
                    </div>
                   
                  </div>
                    @php $excount++; @endphp
                  @endforeach
                  @else
                  <div class="add-userroles extraservice_fee">
                    <div class="rates_section">
                      <div class="drop_box">                        
                       <input type="text" class="form-control extraservice_price" name="extra_services[0][price]" placeholder="$300">
                      </div>
                          
                      <div class="service_box" data-toggle="modal" data-target="#extraserviceIncluded-popup" data-backdrop="static">
                         <!--<h6 class="labelwhite">Service Included <sup>*</sup></h6>-->
          
          <input type="text" id="extra_service_name0"
                         class="form-control extra_service_name" placeholder="Choose Services" onclick="setExtraId(this.id)">

          <input type="hidden" name="extra_services[0][service_name]"
                         class="form-control extra_service_name_hidden" id="extra_service_name_hidden0">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
                    </div>
                    
                      <div class="button_box">
                         <a href="javascript:void(0)" class="servicefee-btn-add" onclick="addServiceFee()"><i class="fa fa-plus"></i></a>
                      
                      <a href="javascript:void(0)" class="servicefee-btn-remove remove-service-rate" onclick="removeServiceFee()"><i class="fa fa-minus"></i></a></div>
                    </div>
                   
                  </div>
                  @endif
                  <div id="service-placeholder"></div>
          
          <div class="clearfix"></div>
          
           <div class="personal-radiobutton-box pink-label">
                    <div class="form-group mt-4">
                      <textarea class="form-control custom-textarea bg-theme-dark-form" name="services_additional_information"  id="exampleFormControlTextarea1" rows="3" placeholder="Addtional Information">{{$listdata['metaData']['services_additional_information']}}</textarea>
                    </div>
                    
                    
                  </div>
                
                 
                </div>
               
      <div class="clearfix"></div>
          <div class="contact-box personal-radiobutton-box pink-label working_hours_box">
               <h4>Working Hours</h4>
               <div class="working_hours">
                    <div class="col-half">
                         @for($i=1; $i <= 7; $i++) <div class="dropcol_box">
                              <div class="label-col"><label>{{ getDay($i) }}</label></div>
                              <div class="dropbox-col">
                                   <div class="dropdown-col">
                                  
                                        <select id="{{ getDay($i) }}_from" class="select_box"
                                             name="{{ strtolower(getDay($i))}}_from">
                                             <option value="">From</option>

                                             @php echo get_times($listdata['metaData'][strtolower(getDay($i)).'_from']) @endphp
                                        </select>
                                   </div>
                                   <div class="dropdown-col">
                                        <select id="{{ getDay($i) }}_to" class="select_box"
                                             name="{{ strtolower(getDay($i))}}_to">
                                             <option value="">To</option>
                                             @php echo get_times($listdata['metaData'][strtolower(getDay($i)).'_to']) @endphp
                                        </select>
                                   </div>
                   
                    <div class="working-hours-dayoff-block">
                    <div class="radio radio-info form-check-inlinesquarebox">
                      @php
                      $dayoff = $listdata['metaData']['dayoff_'.strtolower(getDay($i))];
                      @endphp
                          <input type="checkbox" name="dayoff_{{ strtolower(getDay($i))}}" id="dayoff{{$i}}" class="css-checkbox" {{  $dayoff == "on" ? 'checked':''}}>
                          <label for="dayoff{{$i}}"  class="css-label" >Day OFF</label>
                        </div> 
            </div>
            
                              </div>
                    </div>
                    @if($i % 4 == 0)
               </div>
               <div class="col-half">
                    @endif
                    @if($i === 7)
               </div>
               @endif
               @endfor
         
         <div class="form-group mt-4">
                      <textarea class="form-control custom-textarea bg-theme-dark-form" id="exampleFormControlTextarea1" rows="3" name="working_additional_information" placeholder="Additional Information">{{$listdata['metaData']['working_additional_information']}}</textarea>
                    </div>
          </div>

</div>
<div class="clearfix"></div>
<div id="touring-calenders"></div>
<div class="clearfix"></div>
<div class="contact-box personal-radiobutton-box pink-label working_hours_box touring_girls_box">
     <h4>Touring</h4>
     @if(count($listdata['touring']) > 0)
     @php
     $tcount = 0;
     @endphp
     @foreach($listdata['touring'] as $tour)
      <div class="touring_girls" id="touring_girls">
          <div class="rates_section">
               <div class="drop_box">
                    <input class="form-control startdate" id="startdate" name="tour[{{$tcount}}][startdate]" placeholder="From Date" 
                    value="{{getDateddFormat($tour->from_date)}}"/>
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>

               </div>
               <div class="charges_box">
                    <input class="form-control enddate" id="enddate" name="tour[{{$tcount}}][enddate]" placeholder="To Date" value="{{getDateddFormat($tour->to_date)}}"/>
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>
               </div>

               <div class="service_box">
                    <select class="select_country_box form-control" name="tour[{{$tcount}}][country]" id="tour_country{{$tcount}}" onchange="getTourCity(this.value, this.id)" >
                         <option value=''>Select Country</option>
                         @foreach($countries as $cn)
                            <option value='{{ $cn["id"] }}' {{$cn['id'] == $tour->country_id ?'selected':''}}>{{ $cn['country_name'] }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="service_box">
                @php
                $cities = getcities($tour->country_id);
                @endphp
                    <select class="select_city_box form-control" name="tour[{{$tcount}}][city]" id="tour_city{{$tcount}}">
                         <option value=''>Select City</option>
                        @if(count($cities) > 0)
                        @foreach($cities as $ct)
                        <option value="{{$ct->id}}" {{$ct->id == $tour->city_id ? 'selected':''}}>{{$ct->name}}</option>
                        @endforeach
                        @endif
                    </select>
               </div>
              <div class="button_box">
                         <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addTour()"><i class="fa fa-plus"></i></a>
                      
                      <a href="javascript:void(0)" class="servicefee-btn-remove remove-tour" onclick="removeTour()"><i class="fa fa-minus"></i></a></div>
            
          </div>
         
     </div>
      @php
     $tcount++;
     @endphp
     @endforeach
     @else
      <div class="touring_girls" id="touring_girls">
          <div class="rates_section">
               <div class="drop_box">
                    <input class="form-control startdate" id="startdate" name="tour[0][startdate]" placeholder="From Date" />
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>

               </div>
               <div class="charges_box">
                    <input class="form-control enddate" id="enddate" name="tour[0][enddate]" placeholder="To Date" />
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>
               </div>

               <div class="service_box">
                    <select class="select_country_box form-control" name="tour[0][country]" id="tour_country0" onchange="getTourCity(this.value, this.id)" >
                         <option value=''>Select Country</option>
                         @foreach($countries as $cn)
                            <option value='{{ $cn["id"] }}'>{{ $cn['country_name'] }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="service_box">
                    <select class="select_city_box form-control" name="tour[0][city]" id="tour_city0">
                         <option value=''>Select City</option>
                  
                    </select>
               </div>
              <div class="button_box">
                         <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addTour()"><i class="fa fa-plus"></i></a>
                      
                      <a href="javascript:void(0)" class="servicefee-btn-remove remove-tour" onclick="removeTour()"><i class="fa fa-minus"></i></a></div>
            
          </div>
         
     </div>
     @endif
    
     <div id="touring-section-placeholder"></div>
</div>

<div class="clearfix"></div>

 <div class="contact-box personal-radiobutton-box pink-label run-specialboxmain">
                      <h4>Run Special (Optional)</h4>
                      <div class="add-userroles">
                        <div class="rates_section">
                          <div class="runspecial-box">       
                          <span>today's special:</span>             
                           <input type="text" class="form-control" name="run_specials" placeholder="15mins $100 Quickies, Full Service Mutual Kissing" value="{{$listdata['metaData']['run_specials']}}">
               <p>Max. 20 words</p>
                          </div>                                                       
                        </div>
                      </div>
                      
                    </div>  



<div class="actions clearfix">
     <ul role="menu" aria-label="Pagination">
          <li class="" aria-disabled="false">
               <input type="button" name="prev_step_3" class="previous PreviousBTN" value="Previous" id="prev_step_3">
          </li>
          <li aria-hidden="false" aria-disabled="false">
               <input type="submit" name="next_step_3" class="NextBTN" value="Save & Next" id="next_step_3">
          </li>

     </ul>
</div>
</form>
</div>
</div>





<!-- service Included modal pop up start -->
<div class="modal fade services-steps-form" id="serviceIncluded-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
         <h2>Please select services</h2>    
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToTextbox()">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
              
        <div class="service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
      
                            
          @foreach($servicesavailable as $sa)    
                        <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" value="{{$sa['id']}}" name="service-available"  id="service-available{{$sa['id']}}" class="css-checkbox services_include" >
                               
                                <label for="service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                              </div>
                        </li>
                        @endforeach
                           
                      
              
              
                    </ul>
                          <input type="hidden" value="" id="service_available">    
      </div>        
          </div>
      </div>  
    </div>
  </div>
</div>
<!-- service Included modal pop up End -->
<!-- extra service Included modal pop up start -->
<div class="modal fade services-steps-form" id="extraserviceIncluded-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">   
<h2>Please select services</h2>     
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToExtraTextbox()">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
              
        <div class="extra_service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
      
                            
          @foreach($servicesavailable as $sa)    
                        <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" value="{{$sa['id']}}" name="extra-service-available"  id="extra-service-available{{$sa['id']}}" class="css-checkbox extra_services_include" >
                               
                                <label for="extra-service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                              </div>
                        </li>
                        @endforeach
                           
                      
              
              
                    </ul>
                          <input type="hidden" value="" id="extra_service_available">    
      </div>        
          </div>
      </div>  
    </div>
  </div>
</div>
<!-- services time modal pop up start -->
<div class="modal fade services-addTime" id="services-addTsime" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Booking Calender</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
       
        
        <form>
            <div class="sevicesaddtime-top">
            <h4>Booking Notes</h4>
            <div class="form-group">
            <label for="recipient-name" class="col-form-label">Title</label>
            <input type="text" placeholder="Enter title" class="form-control" id="title">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Client Name</label>
            <input type="text" placeholder="Enter Client Name" class="form-control" id="client_name">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Service Type</label>
            <input type="text" placeholder="Sansual Massage, Blow Job, Full Service" class="form-control" id="Service_type">
          </div>
        </div>

        <div class="sevicesaddtime-top bookingSlot-block">
            <h4>Booking Slot</h4>
          <button type="button" class="bookslot-btns booked-btn">Booked</button>
          <button type="button" class="bookslot-btns breaktime-btn">Break Time</button>
          <button type="button" class="bookslot-btns dayoff-btn">Day OFF</button>
          <button type="button" class="bookslot-btns Available-btn">Available</button>
          
          <div class="clearfix"></div>
           <div class="row">

         
          <div class='col-md-6 form-group from-time'>
              <label for="message-text" class="col-form-label">From</label>
              <input type="text" class="form-control datepicker" name="calendar_start_date" id="calendar_start_date"/>
                <input type="text" class="form-control timepicker" name="calendar_start_time" id="calendar_start_time"/>
             
          </div>
  
          <div class='col-md-6 form-group to-time'>
              <label for="message-text" class="col-form-label">To</label>
              <input type="text" class="form-control datepicker" name="calendar_end_date" id="calendar_end_date"/>
                <input type="text" class="form-control timepicker" name="calendar_end_time" id="calendar_end_time"/>
             
          </div>
        </div>
        </div>    
        </form>
        
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="button" class="servicespopupSave-btn">Save</button>
      </div>
    </div>
  </div>
</div>
<!-- services time modal pop up end -->