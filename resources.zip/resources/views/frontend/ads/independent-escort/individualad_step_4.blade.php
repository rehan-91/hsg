<div class="container">
 <div class="content_block step_4" style="display:none;">
     <form id="form_step_4" class="addphotoVideos" onsubmit="return false;" action="{{ route('individualad.saveimages') }}">
     {{ csrf_field() }}
         <h2 class="text-danger">Photos & Videos</h2>
		 
		   <div class="listings">
		 <h4>Requirements</h4>
             <p><i class="fa fa-check" aria-hidden="true"></i>Upload high quality photos, selfie upto 30</p>
             <p><i class="fa fa-check" aria-hidden="true"></i>Upload high quality videos, upto 3</p>
             <p><i class="fa fa-check" aria-hidden="true"></i>House of Sexy Girls accept your Genuine photos and videos only</p>
             <p><i class="fa fa-check" aria-hidden="true"></i>We will contact you for your profile verification.   <span class="fakeprofile"> (Any fake profile will be removed, no refund)</span></p>
			 <p><i class="fa fa-check" aria-hidden="true"></i>Keep it real, Keep it Fun</p>
			 <p><span class="fakeprofile text-danger"> HOUSE OF SEXY GIRLS HAS ZERO TOLARENCE FOR FAKE AND MISLEADING INFORMATION</span></p>
         </div>
         <div class="profile_photos">

             <h4><sup class="text-danger">*</sup>Profile Photos</h4>
             <div class="preview-images-zone ui-sortable">
                 <fieldset class="form-group ui-sortable-handle">
                     <div class="field_set">
                         <a href="javascript:void(0)" onclick="$('#pro-image').click()"><span
                                 class="pkus_icon">+</span><br />Add Photos</a>
                         <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"
                             multiple>
                     </div>
                     <div class="max-photos">High Quality Max. 30</div>
                 </fieldset>
        @if(!empty($listdata['adImage']))
        @foreach($listdata['adImage'] as $imm)
        <div class="preview-image preview-show-{{$imm->id}}">
        <div class="image-cancel" data-no="{{$imm->id}}">x</div>
        <div class="image-zone"><img id="pro-img-{{$imm->id}}" src="{{getS3ImageURL($imm->media_filename,'202*182')}}"></div>
        <div class="radio radio-info form-check-inlinesquarebox image-zone1">
        <input type="hidden" value="{{$imm->media_filename}}" name="imageurl[]">
        <input type="checkbox" value="1" name="img_is_default" {{ $imm->media_is_default == 1? 'checked':''}} name="available-women" id="pro-img1-{{$imm->id}}" class="css-checkbox">
        <label for="pro-img1-{{$imm->id}}'" class="css-label">Set as main image</label></div>
        </div>
        @endforeach
        @endif
             </div>
         </div>
         <div class="profile_photos">

<h4>Profile Video <span class="profile-smallheading">(Highly recommended)</span></h4>
<div class="preview-video-zone ui-sortable">
    <fieldset class="form-group ui-sortable-handle">
        <div class="field_set">
            <a href="javascript:void(0)" onclick="$('#pro-video').click()"><span
                    class="pkus_icon">+</span><br />Add Videos</a>
            <input type="file" id="pro-video" name="pro-video" style="display: none;" class="form-control"
                multiple>
        </div>
        @if(!empty($listdata['adVideo']))
        @foreach($listdata['adVideo'] as $vd)
        <div class="preview-image preview-show-{{$vd->id}}">
        <div class="image-cancel" data-no="{{$vd->id}}">x</div>
        <div class="image-zone"><video video width="250" height="200" controls>
        <source src="{{getS3VideoURL($vd->media_filename)}}"></source>
        </video>
        </div>
        <div class="radio radio-info form-check-inlinesquarebox image-zone1">
        <input type="hidden" value="{{$vd->media_filename}}" name="videourl[]">
        
        </div>
        @endforeach
        @endif
        <div class="max-videos">Max length 2 mins. HD Video</div>
    </fieldset>


</div>
</div>


 <div class="profile_photos">

<h4>Teaser Video</h4>
<div class="preview-teaservideo-zone ui-sortable">
    <fieldset class="form-group ui-sortable-handle">
        <div class="field_set">
            <a href="javascript:void(0)" onclick="$('#teaser-video').click()"><span
                    class="pkus_icon">+</span><br />Add Videos</a>
            <input type="file" id="teaser-video" name="teaser-video" style="display: none;" class="form-control"
                multiple>
        </div>
        <div class="max-videos">Max length 7 sec. HD Video</div>
    </fieldset>
    @if(!empty($listdata['adTeaser']))
        @foreach($listdata['adTeaser'] as $atd)
        <div class="preview-image preview-show-{{$atd->id}}">
        <div class="image-cancel" data-no="{{$atd->id}}">x</div>
        <div class="image-zone"><video video width="250" height="200" controls>
        <source src="{{getS3VideoURL($atd->media_filename)}}"></source>
        </video>
        </div>
        <div class="radio radio-info form-check-inlinesquarebox image-zone1">
        <input type="hidden" value="{{$atd->media_filename}}" name="teaservideourl[]">
        
        </div>
        @endforeach
        @endif

</div>
</div>
         <div class="actions clearfix">
             <ul role="menu" aria-label="Pagination">
                 <li class="" aria-disabled="false">
                     <input type="button" class="previous PreviousBTN" name="prev_step_4" id="prev_step_4" value="Previous">
                 </li>
                 <li aria-hidden="false" aria-disabled="false">
                     <input type="button" class="NextBTN" name="next_step_4" id="next_step_4" value="Save & Next">
                 </li>
             </ul>
         </div>
     </form>
 </div>
 </div>

 <div class="modal js-loading-bar">
 <div class="modal-dialog">
   <div class="modal-content">
     <div class="modal-body">
       <div class="progress progress-popup">
       
            <div class="progress-bar progress-bar-success myprogress" role="progressbar" style="width:0%">0%</div>
            <div class="show-video-screenshot">
            </div>
       </div>
     </div>
   </div>
 </div>
</div>