<div class="content_block step_3" style="display:none;">
                <div class="thanks_box text-center">
                    <h2>Congratulation</h2>
                    <p>Your ad is succesfully created</p>
                    <div class="clearfix"></div>
                    <a href="#" class="green_gredient_btn gr_pink">View Dashoard</a>
                </div>
            </div>