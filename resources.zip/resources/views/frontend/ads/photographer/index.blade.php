@extends('frontend.layouts.front_layout')
@section('content')

<div id="Load" class="load" style="display:none;">
    <div class="load__container">
        <div class="load__animation"></div>
        <div class="load__mask"></div>
        <span class="load__title">Loading...</span>
    </div>
</div>
<section class="profile-details-block photographer-detail-steps">

 <div class="photographer-steps">
      <h2 data-toggle="modal" data-target="#selected-escortsmodel">Photographer</h2>
      <p>Here on the <span>HOUSE OF SEXY GIRLS</span>, we have tried our best to bring some of the best professional photographers from around the New Zealand for you, In case if you need a professional photoshoot for your <span>HOUSE OF SEXY GIRLS AD</span> Profile. Indeed, It works wonder for your business if you are having a great quality <span>Photos and Videos in your AD Profile.</span> 
Disclaimer: We don’t represent any photographer listed here, so its solely between you and your chosen photographers only.</p>
    
    </div>
	
    <div class="container">
        <div id="wizard" class="wizard clearfix">
        @include('frontend.ads.photographer.frontnav_photographer')
         @include('frontend.ads.photographer.photographerad_step_1')
         @include('frontend.ads.photographer.photographerad_step_2')
         @include('frontend.ads.photographer.photographerad_step_3')
         </div>
    </div>
</section>
<!-- Creates the bootstrap modal where the image will appear -->
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
  <div class="modal-dialog" style="max-width:100%; margin:0; vertical-align:center;">
    <div class="modal-content">
      <div class="modal-header">
     <a href="javascript:void(0)" class="btn btn-primary crop_image" onclick="cropImage()">Crop</a>
     <a href="javascript:void(0)" class="btn btn-primary blur_image" onclick="blurImage()">Blur</a>
     <a href="javascript:void(0)" class="btn btn-primary blur_image" onclick="resetChanges()">Reset</a>
    
        <button type="button" class="close close-modal-btn" data-dismiss="modal" ><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      </div>
      <div class="modal-body">
     
      <img src="" id="imagepreview" style="max-width:100%">

       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default close-modal-btn" data-dismiss="modal" >Close</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
var imagePostURL = "{!! route('ajaximageupload') !!}";
var fetchcityURL = "{!! route('fetchcitiesbycountry') !!}";
</script>
<script src="{{ asset('frontend/js/ad_photographer_post_script.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/jquery.imgareaselect.pack.js') }}"></script>
@endsection


