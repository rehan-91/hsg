@extends('frontend.layouts.front_layout')
@section('content')
@php
$default_locale = app()->getLocale();

@endphp


     <div class="form-steps">
          <div class="container">


               <section class="profile-details-block">
                    <div class="ad_signup_form_container">


                         <h2 class="text-center">Are you a</h2>

                       

                              <div class="signup_box">

                                   <div class="row radios mt-5">
                                        @foreach($listingtype as $list)
                                        <div class="form-group col-md-4 listingtype-box" onclick="window.location.href='{{route("post-ad.",$list["slug"])}}'">
                                             <div class="gr_box">
                                                  <div class="text_container {{$list['class_name']}}">
                                                       <h4>{{$list['title']}}</h4>
                                                       <div class="service_img mt-4"><img
                                                                 src="{{url('/upload/'.$list['icon_image'])}}"></div>
                                                       <div id="showOne" class="check-mark"><i class="fa fa-check"></i>
                                                       </div>
                                                  </div>
                                                 {{-- <input type="radio" name="rGroup" value="One" id="r1"
                                                       checked="checked" />
                                                  <label class="radio" for="r1"></label>
                                                 --}}
                                             </div>

                                        </div>
                                        @endforeach


                                   </div>
                              </div>



                    </div>
               </section>
          </div>
     </div>

     @endsection