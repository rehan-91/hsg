@extends('frontend.layouts.default_layout')
@section('content')

<div class="clearfix"></div>
{{--
<div class="clearfix"></div>

{{<section class="escorts-listing-banner">}}
    {{ <img src="{{ asset('images/listing-bg.jpg') }}" class="" />}}
   {{  <div class="clearfix"></div>}}
     
</section>

<div class="clearfix"></div>
<span class="glowing-border-blue"></span>
<div class="clearfix"></div>
--}}
<section class="auckland-escorts-block">
     <div class="clearfix"></div>
     <div class="container-fluid">
          <div class="leftaucklandescrots-block">
               @if(count($list) > 0)
               <div class="aucklandtop-left-block escorts_listingnew">
                    <div class="top-bar-sec">
                         <h2 class="today-exclusive-sexy-girls">{{$title}}</h2>
                         <div class="sortby-block float-right">
                              <div class="dropdown float-left mr-3"> Sort by </div>
                              <div class="four-grid-icon float-left mr-3"> <img src="{{asset('frontend/images/4-grid-icon.png')}}"> </div>
                              <div class="six-grid-icon float-left"> <img src="{{asset('frontend/images/6-grid-icon.png')}}"> </div>
                         </div>
                    </div>
                    <ul class="aucklandtop-leftblock-box">
                         <div class="overlay"> </div>
                         @foreach($list as $l)
                         <li class="test1">
                              <img class="img-fluid" id="ad_image{{$l['adId']}}" src="{{getS3ImageURL($l['adImage'], '252*384')}}">
                              <div class="live-btnpositon {{$bp['login_status'] == 0 ? 'Offliine-btnpositon':''}}"><span>{{$l['login_status'] == 0 ? 'Offline':'Live'}}</span> </div>
                              <div class="hoverdiv">
                                   <div class="img-section"> <img class="img-fluid" 
                                             src="{{getS3ImageURL($l['adImage'], '508*762')}}"> </div>
                                   <div class="cnt_section">
                                        <div class="cnt">
                                             <h2 id="ad_name{{$l['adId']}}">{{ucwords($l['adName'])}}</h2>
                                             <div class="location">{{ getCityCountry($l['adLocation']) }}</div>
                                             <div class="private_tag">{{getListingType($l['adListingTypeId'])}}</div>
                                             <div class="listing">

                                                  <div class="list">{{getMaterData($l['metaData']['age'])}} Yrs</div>
                                                  @if(!empty($l['metaData']['bustsize']))
                                                  <div class="list"><span class="label">Size:
                                                       </span>{{getMaterData($l['metaData']['bustsize'])}}</div>
                                                  @endif
                                                  <div class="list"><span class="label">Height:
                                                       </span>{{getMaterData($l['metaData']['height'])}}</div>
                                                  @if(!empty($l['metaData']['weight']))
                                                  <div class="list"><span class="label">Weight:
                                                       </span>{{getMaterData($l['metaData']['weight'])}} KG</div>
                                                  @endif
                                                  @if(!empty($l['metaData']['eyecolor']))
                                                  <div class="list"><span class="label">Eye Color:
                                                       </span>{{getMaterData($l['metaData']['eyecolor'])}}</div>
                                                  @endif
                                                  @if(!empty($l['metaData']['haircolor']))
                                                  <div class="list"><span class="label">Hair Color:
                                                       </span>{{getMaterData($l['metaData']['haircolor'])}}</div>
                                                  @endif
                                                  @if(!empty($l['metaData']['nationality']))
                                                  <div class="list"><span class="label">Ethnicity:
                                                       </span>{{getMaterData($l['metaData']['nationality'])}}</div>
                                                  @endif

                                             </div>
                                             <div class="contact_detail mt-3">
                                                  <div class="icon"><img
                                                            src="{{asset('frontend/images/hover-phone-icon.png')}}">
                                                  </div>
                                                  <div class="phone-number"><span>Phone</span><br />
                                                       {{$l['adContact']}}
                                                  </div>
                                             </div>
                                             <div class="rate">{{ $l['rate'] }} / Hour</div>
                                             <div class="view-profile"><a href="{{route('profile.',$l['slug'])}}">View Profile <img
                                                            src="{{asset('frontend/images/long-arrow.png') }}"></a></div>
                                        </div>
                                        <div class="shortlist_button">
                                             @php
                                             $wishlist_ad_ids = array();
                                             $wishlist_ad_ids = getWishlist()->pluck('short_ad_id')->toArray();
                                             $style = "style=display:none;";
                                             $style1 = "style=display:none;";
                                            
                                        if(!in_array($l['adId'], $wishlist_ad_ids)){
                                        $style = "style=display:block;'";
                                        }else{
                                        $style1 = "style=display:block;";
                                        } 
                                        @endphp
                                        <a {{$style}} id="showshortListing{{$l['adId']}}" href="javascript:void(0)"  onclick="addToShortlist({{$l['adId']}})"><i class="fa fa-plus"></i> Shortlist</a>
                                        <a {{$style1}} class="shotlilsted-btn"  href="javascript:void(0)" id="showshortListed{{$l['adId']}}"><i class="fa fa-heart"></i> Shotlisted</a>
                                            
                                   </div>
                                   </div>
                              </div>
                         </li>
                         @endforeach
                    </ul>
               </div>
               @else

                <div class="aucklandtop-left-block escorts_listingnew">
                    <div class="top-bar-sec">
                         <h2 class="today-exclusive-sexy-girls">{{$title}}</h2>
                         <h3>No Result found.</h3>

                    </div>
               </div>
               @endif
          </div>
     </div>
</section>
<div class="clearfix"></div>
<section class="redbar-cta text-center">
     <div class="container-fluid">
          <div class="row">
               <div class="cta-text">
                    <p>Be a proud member of <span class="chlsHseTxt">House of</span> <span class="chlsSxyTxt">Sexy
                              Girls</span>
                    </p>
                    <a class="post-addcta-btn" href='{{route("post-ad.","/")}}'>Post your ad now</a>
               </div>
          </div>
     </div>
</section>
<div class="clearfix"></div>
<section class="bottom-advertiseblock padding-50">
     <div class="container-fluid">
          <div class="row">
               @foreach($other_ads as $oth)
               <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
                    <div class="advertise-box">
                         <img src="{{ get_image_data_2($oth->ad_photo,'other_ads_photos') }}" class="img-fluid"
                              alt="img">
                    </div>
               </div>
               @endforeach
          </div>
     </div>
</section>
<div class="clearfix"></div>
<script>
      $('html,body').animate({
        scrollTop: $(".escorts_listingnew").offset().top
    }, 'slow');
$(document).ready(function(){
     $( "form" ).on( "submit", function( event ) {
          event.preventDefault();
          var formdata = $( this ).serialize()+'&type=ajax';
       $.get($( this ).attr('action'),formdata, function(data){
         var  received_msg = JSON.parse(data);
         var html = "";
      if (received_msg.count > 0) {
           delete received_msg.count;
               for (var key in received_msg) {
                html += '<li class="test1">';
               var login_status_class = (received_msg[key].login_status == 0) ? 'Offliine-btnpositon':'';
               var login_status_text = (received_msg[key].login_status == 0) ? 'Offliine':'Live';
               html += '<img class="img-fluid" src="'+received_msg[key].ad_small_image+'" id="ad_image'+received_msg[key].adId+'">';
               html += '<div class="live-btnpositon '+login_status_class+'">';
               html += '<span id="user_status_'+received_msg[key].adId+'">'+login_status_text+'</span>';
               html += '</div>';

               html += '<div class="hoverdiv">';
               html += '<div class="img-section">';
               html += '<img class="img-fluid" src="'+received_msg[key].ad_large_image+'">';
               html += '</div>';
               html += '<div class="cnt_section">';
               html += '<div class="cnt">';
               html += '<h2 id="ad_name'+received_msg[key].adId+'">'+received_msg[key].adName+'</h2>';

               html += '<div class="location">'+received_msg[key].adLocation+'</div>';
               html += '<div class="private_tag">'+received_msg[key].adListingTypeId+'</div>';
               html += '<div class="listing">';

               html += '<div class="list">'+received_msg[key].age+' Yrs</div>';

               if(received_msg[key].height !=''){
               html += '<div class="list"><span class="label">Height:</span>'+received_msg[key].height+'</div>';
               }
               if(received_msg[key].bustsize !=''){
               html += '<div class="list"><span class="label">Size:</span>'+received_msg[key].bustsize+'</div>';
               }
               if(received_msg[key].weight !=''){
               html += '<div class="list"><span class="label">Weight:</span>'+received_msg[key].weight+'</div>';
               }
               if(received_msg[key].eyecolor !=''){
               html += '<div class="list"><span class="label">Eye Color:</span>'+received_msg[key].eyecolor+'</div>';
               }
               if(received_msg[key].haircolor !=''){
               html += '<div class="list"><span class="label">Hair Color:</span>'+received_msg[key].haircolor+'</div>';
               }
               if(received_msg[key].ethinicity !=''){
               html += '<div class="list"><span class="label">Ethinicity:</span>'+received_msg[key].ethinicity+'</div>';
               }
               html += '</div>';
               html += '<div class="contact_detail mt-3">';
               html += '<div class="icon"><img src="{{asset('frontend/images/hover-phone-icon.png')}}">';
               html += '</div>';
               html += '<div class="phone-number">';
               html += '<span>Phone</span><br />'+received_msg[key].adContact+' </div>';
               html += '</div>';
               html += '<div class="rate">'+received_msg[key].rate+' / Hour</div>';
               html += '<div class="view-profile"><a href="'+received_msg[key].profile_link+'">View Profile<img src="{{asset('frontend/images/long-arrow.png')}}"></a></div>';
               html += ' </div>';

               html += '<div class="shortlist_button">';
               if(received_msg[key].is_shortlist == 1){
               var style = "style=display:block;'";
               }else{
               var style1 = "style=display:block;";
               }

               <?php
               $wishlist_ad_ids = array();
               $wishlist_ad_ids = getWishlist()->pluck('short_ad_id')->toArray();
               ?>
               var style = "style=display:none;";
               var style1 = "style=display:none;";
               var wishlist_ad_ids = '<?php echo  $wishlist_ad_ids; ?>';
               if(jQuery.inArray(received_msg[key].adId, wishlist_ad_ids) !== -1){
                 style = "style=display:block;'";

               }else{
                 style1 = "style=display:block;";
               }
               html += ' <a '+style+' id="showshortListing'+received_msg[key].adId+'" href="javascript:void(0)" onclick="addToShortlist('+received_msg[key].adId+')"><i class="fa fa-plus"></i> Shortlist</a>';
               html += ' <a  '+style1+' class="shotlilsted-btn" href="javascript:void(0)" id="showshortListed'+received_msg[key].adId+'"><i class="fa fa-heart"></i> Shotlisted</a>';

               html += '</div>';
               html += '</div>';
               html += '</div>';
               html += ' </li>';
          }


          }
          
          if(html !=""){
          $(".aucklandtop-leftblock-box").html(html);

          }else{
               $('.aucklandtop-leftblock-box').html('no Records found');
          }
       } )
       //console.log( $( this ).serialize() );
     });
 
});

</script>
@endsection