@extends('frontend.layouts.front_layout')

@section('content')
@php
$default_locale = app()->getLocale();

@endphp
<section class="profile-details-block">
     <div class="container">
          <div class="row">
      @include('frontend.layouts.partials.navfordashboard')



               <div class="col-md-9">
                @if(count($query) > 0)
                    <div class="row side_box">
                         <div class="col-md-3">
                              <div class="card-boxes gr_pink">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-view-icon.png')}}"></div>
                                   <div class="text">Views<br /><span>{{ $stat_views }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_orange">
                                   <div class="dashboard_icon"><img
                                             src="{{ asset('frontend/images/dashboard-shortlisted-icon.png')}}"></div>
                                   <div class="text">Shortlisted<br /><span>80</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_purple">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-likes-icon.png')}}"></div>
                                   <div class="text">Likes<br /><span>{{ $stat_likes }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_green">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-clicks-icon.png')}}"></div>
                                   <div class="text">Clicks<br /><span>{{ $stat_clicks }}</span></div>
                              </div>
                         </div>
                    </div>
                    @endif

<div class="testimonial-listing-block mt-4"> 
			<h2>Account settings</h2>			
			<div class="clearfix"></div>
			
		<div class="account-setting-form-block" id="signup-container">
    <form method="post" action="{{route('accountUpdate', Auth::user()->id)}}" onsubmit="return false;" id="register" name="register" enctype="multipart/form-data" >
    {{csrf_field()}}	
			<div class="row">
			
			<div class="col-md-8">
				<div class="form-group col-md-12">
				<div class="row">
					<label>Name</label>
					<input type="text" class="form-control" placeholder="Alice Quinn" name="name" id="name" value="{{Auth::user()->name}}" > 
           <span class="help-block hidden name_error"></span>
					</div>
				</div>             

      <div class="form-group col-md-12">
				<div class="row">
					<label>Email Address</label>
					<input type="email" class="form-control" name="email" id="email" placeholder="annasthesia@houseofsexygirls.com" value="{{Auth::user()->email}}" >
           <span class="help-block hidden email_error"></span>
					</div>
				</div>	

       <div class="form-group col-md-12">
				  <div class="row">
					<label>Phone Number</label>
					<input type="tel" class="form-control" name="phone" id="phone" placeholder="+0987654321" value="{{Auth::user()->phone}}">
           <span class="help-block hidden phone_error"></span>
					</div>
				</div>	

       <div class="form-group col-md-12 account-sttng-btns-block">
				  <div class="row">
           <button class="post-add-btn account-setting-submitbtn" type="submit" onclick="validate_user()">submit</button> 
					<button data-toggle="modal" data-target="#reportThisadd" class="post-add-btn account-setting-submitbtn account-setting-deletebtn" type="button">delete account</button> 
					</div>
			</div>	

			</div>

			<div class="col-md-4 account-profileimg"> 
			 <figure class="figure">
        @if(empty(Auth::user()->user_image))
                    <div class="account-setting-userprofile">
 			 <img src="{{asset('frontend/images/user-profile-icon.png')}}" class="figure-img img-fluid rounded" alt="dummyaccountseeting-">
			 </div>
       @else
       @php
        $imageurl = url('uploads/users/'.Auth::user()->user_image);
       @endphp
	   <div class="account-setting-userprofile">
        <img src="{{ $imageurl }}" class="figure-img img-fluid rounded" alt="dummyaccountseeting-" width="20%">
		</div>
        @endif
               
        <input type="file" class="figure-caption" name="user_image" id="user_image" value='{{ Auth::user()->id }}'>
         <span class="help-block hidden user_image_error"></span>
			   

      <input type="hidden" name="old_user_image" value="{{ Auth::user()->user_image }}">
       <span class="max-photos account-max-photos">Max Image size:200kB</span>
	   <div class="clearfix"></div>
	   <img src="" id="user_image_preview" width="20%" />
			</figure>
			
			</div> 

       
			
			</div>	
    </form>


</div>			
           </div>	

                   
            </div>
               
          </div>
     </div>
</section>

<!-- Thank you Subscribe Notification modal pop up start -->

<div class="modal fade services-addTime thankyou-pop" id="success-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
   
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <h2>Success!</h2>
    <p class="success"> Successfully updated profile!</p>          
      </div>  

<div class="modal-footer">

</div>
    
    </div>
  </div>
</div>
<!-- Thank you Subscribe Notification modal pop up End -->
 <!-- report this ad modal pop up start --> 
<div class="modal fade services-addTime" id="reportThisadd" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Delete my account</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
       <form method="post" action="{{route('accountDestroy', Auth::user()->id)}}">
        {{ csrf_field()}}
            <div class="sevicesaddtime-top reportthis-form">                      
      <ul class="why-delete-account @if($errors->has('reason')) has-error @endif">

        <li><label><input type="radio" name="reason" class="reason" id="reason" value="Opened account in error">Opened account in error</label></li>
              <li><label><input type="radio" name="reason"   class="reason" id="reason" value="Posting Ad under different account">Posting Ad under different account.</label></li>
              <li><label><input type="radio" name="reason"   class="reason" id="reason" value="Opened another account with houseofsexygirls in another country.">Opened another account with houseofsexygirls in another country.</label></li>
                <li><label><input type="radio" name="reason"  class="reason" id="reason" value="others">Others</label></li>


                 @if($errors->has("reason"))
                       <span class="help-block">{{ $errors->first("reason") }}</span>
                    @endif
      </ul>
      
      
      
         <div class="form-group reason-others  @if($errors->has('delete_description')) has-error @endif" style="display:none;">
          <label class="control-label"><span style="color:red;">Reason For delete!</label>
            <textarea type="text" name="delete_description" placeholder="Write Description" class="form-control"></textarea>
             @if($errors->has("delete_description"))
                       <span class="help-block">{{ $errors->first("delete_description") }}</span>
                    @endif
          </div>
      
        </div> 
      <div class="modal-footer">        
        <button type="button" class="post-add-btn account-setting-submitbtn" data-dismiss="modal">Cancel</button>
    <button type="submit" class="post-add-btn account-setting-submitbtn account-setting-deletebtn">delete</button>
      </div>
    </form>
        
      
        

      </div>
 
    
    </div>
</div>
</div>
 
<script >
   function validate_user() {
      jQuery(".help1-block").addClass("hidden");
      jQuery(".input-box").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("register"));
      jQuery.ajax({
        type: 'POST',
        dataType: "JSON",
        url: $("#register").attr('action'),
        data: registration_form,
        processData: false,
        contentType: false,
     success: function(data) {
          if (data.errors) {
            jQuery.each(data.errors, function(key, value) {
              jQuery("." + key + "_error").html(value);
              jQuery("." + key + "_error").removeClass("hidden");
              jQuery("#" + key).parent().addClass("has-error");
            });


            jQuery('html, body').animate({
              scrollTop: parseInt(jQuery('.has-error:visible:first').offset().top) - 10
            }, 1000);
          } else if (data.success) {
               
          jQuery("#signup-container").fadeOut("fast");
            var redirect_url = data.redirect_response;
            window.location.href = redirect_url;
          }
        },
      });
    }

 $('body').on('change', '.reason', function() {
  
   if (this.value == 'others') {
        $(".reason-others").show();
    }
    else{
         $(".reason-others").hide();
    }
 });

</script>

@endsection