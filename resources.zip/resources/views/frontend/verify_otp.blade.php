@extends('frontend.layouts.front_login')

@section('content')
  <div class="container">
	<div class="white-bg otp-main">
	  <div class="otp-icon">
		<img src="{{ asset('registrations/images/otp-icon.png')}}">
	  </div>
	  <h3>{!! trans('translations.frontend.otp_verify_title') !!}</h3>
	  <p>
		+91 - {{ $user_data->contact_number }}
	  </p>
		
	  <form id="register_otp_verify" name="register_otp_verify" action="{{ route('registerotpverify') }}" method="POST">
		{{ csrf_field() }}
		<h4>{!! trans('translations.frontend.otp_enter_code') !!}</h4>
		<div id="divOuter">
		  <div id="divInner" class="@if($errors->has('otp_code')) has-error @endif">
			<input name="otp_code" id="partitioned" type="text" maxlength="4" />
			@if($errors->has("otp_code"))
				<span class="help-block">{{ $errors->first("otp_code") }}</span>
			@endif
		  </div>
		</div>
		
		<div class="clearfix"></div>
		
		<small>{!! trans('translations.frontend.didnt_receive') !!} <a href="javascript:void(0)" onclick="ResendOtp()">{!! trans('translations.frontend.resend_code') !!}</a></small>
		
		<div class="clearfix"></div>
		<div id="ajax_success" class="alert alert-success" style="display:none;">
		</div>
		
		<div class="clearfix"></div>
		<button type="submit" class="orange-btn arrow-icon btn-cm text-center">{!! trans('translations.frontend.otp_verify') !!}</button>

	  </form>
	  
	</div>
  </div>
  <script>
	var access_token = jQuery("input[name=_token]").val();
	function ResendOtp(){
		jQuery.ajax({
			type: 'POST',
			dataType: "JSON",
			url: "{!! route('resendregisterotp') !!}",
			data: {
				"_token" : access_token,
			},
			success: function(data){
				if( data.success ){
					jQuery("#ajax_success").html( "<p>" + data.success + "</p>" );
					jQuery("#ajax_success").show();
				}
				
				setTimeout(function(){
					jQuery("#ajax_success").hide();
				}, 4000);
			}
		});
	}
	
	var obj = document.getElementById('partitioned');
	obj.addEventListener("keydown", stopCarret); 
	obj.addEventListener("keyup", stopCarret); 

	function stopCarret() {
		if (obj.value.length > 3){
			setCaretPosition(obj, 3);
		}
	}

	function setCaretPosition(elem, caretPos) {
		if(elem != null) {
			if(elem.createTextRange) {
				var range = elem.createTextRange();
				range.move('character', caretPos);
				range.select();
			}
			else {
				if(elem.selectionStart) {
					elem.focus();
					elem.setSelectionRange(caretPos, caretPos);
				}
				else
					elem.focus();
			}
		}
	}
  </script>
  <style>
	#partitioned {
		/* padding-left: 10px; 
		letter-spacing: 45px;*/
		border: 0;
		/* background-image: linear-gradient(to left, #e5e5e5 70%, rgba(255, 255, 255, 0) 0%);
		background-position: bottom;
		background-size: 50px 1px;
		background-repeat: repeat-x;
		background-position-x: 35px; */
		letter-spacing: 10px;
		width: 130px;
		min-width: 130px;
		overflow: hidden;
		border-bottom: 2px solid #9299bd;
		text-align: center;
	}

	#divInner{
	  left: 0;
	  position: sticky;
	}

	#divOuter{
		  margin-bottom: 35px;
		overflow: hidden;
	}
	#divOuter .help-block, .popup-text-err {
		text-align: center;
	}
  </style>
@endsection