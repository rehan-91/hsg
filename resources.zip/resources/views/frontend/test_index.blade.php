@extends('frontend.layouts.default_layout')

@section('content')

 <section class="featured-sexy-girls-block padding-120">
    <h2 class="featured-sexy-girls">Featured  Sexy Girls</h2>
    <div class="container-fluid">
      <div class="myshortlist">
  <img src="{{ asset('frontend/images/shortlist_heart.png') }}"> My Shortlist <span class="badge">
	{{ count($my_total_short_list)}} 
		
  </span>
 </div> 
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
              <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
              <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
            <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
                <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
               <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
                <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
            </div>
            
          </div>
          <div class="carousel-item">
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
              <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
               <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
                <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
               <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
               <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 featured-image-align">
               <div class="featured-image">
                <img class="img-fluid" src="frontend/images/eotd.jpg">
                <div class="live-btnpositon">
                  <span>live</span>
                </div>
              </div>
              
              
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </section>
  
<div class="clearfix"></div>
  <span class="glowing-border-blue"></span>
  <div class="clearfix"></div>
  <section class="auckland-escorts-block">
    <div class="container-fluid">
      <div class="leftaucklandescrots-block">
        <div class="aucklandtop-left-block">
          <div class="top-bar-sec">
            <h2 class="today-exclusive-sexy-girls">Today Exclusive Sexy Girls</h2>
            <div class="sortby-block float-right">
              <div class="dropdown float-left mr-3">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Sorty by
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                </div>
              </div>
              <div class="four-grid-icon float-left mr-3">
                <button type="button" name="form_grid_2" id="form_grid_2" class="form_grid_2" style="background-color:rgb(0,0,0,0.5);border:none;padding:5px;">
				<img src="frontend/images/4-grid-icon.png">
              </button>
			  </div>
              <div class="six-grid-icon float-left">
                <button name="form_grid_3" id="form_grid_3" class="form_grid_3" style="background-color:rgb(0,0,0,0.5);border:none;padding:5px;">
				<img src="frontend/images/6-grid-icon.png">
              </button>
			  </div>
            </div>
            <div class="badges">
              
              <div class="blue-badge"><a href="#">Auckland Girls</a></div>
              <div class="blue-badge"><a href="#">Hamilton Girls</a></div>
              <div class="blue-badge"><a href="#">Queenstown Girl</a></div>
            </div>
          </div>
		  <script type="text/javascript">
$(document).ready(function(){
    $("#form_grid_2").click(function(){
        $("ul").removeClass();
        $("ul").addClass("aucklandtop-leftblock-box_grid_2");
    });
	$("#form_grid_3").click(function(){
        $("ul").removeClass();
        $("ul").addClass("aucklandtop-leftblock-box");
    });
});
</script>
          <ul class="aucklandtop-leftblock-box">
            <div class="overlay">
            </div>
            <li class="test1">
              <img class="img-fluid" src="frontend/images/1.jpg">
              <div class="live-btnpositon">
                <span>live</span>
              </div>
			  
              <div class="hoverdiv">
                <div class="img-section">
                  <img class="img-fluid" src="frontend/images/hover-div-img.jpg">
                </div>
                <div class="cnt_section">
                  <div class="cnt">
                    <h2>Alice</h2>
                    <div class="location"> 
					@foreach($profile_city as $value)
					
					{{ $value->name }}


					@endforeach , Newzealnd</div>
                    <div class="private_tag">Private</div>
                    <div class="listing">
                      <div class="list">@foreach($user_ad_meta_age  as $key => $mvalues){{ $mvalues->meta_value }} @endforeach Yrs</div>
                      <div class="list"><span class="label">Size: </span>@foreach($user_ad_meta_size  as $key => $mvalues){{ $mvalues->meta_value }} @endforeach</div>
                      <div class="list"><span class="label">Height: </span>@foreach($user_ad_meta_height  as $key => $mvalues){{ $mvalues->meta_value }} @endforeach</div>
                      <div class="list"><span class="label">Weight: </span>@foreach($user_ad_meta_weight  as $key => $mvalues){{ $mvalues->meta_value }} @endforeach KG</div>
                      <div class="list"><span class="label">Eye Color: </span> @foreach($user_ad_meta_eyecolor  as $key => $mvalues){{ $mvalues->meta_value }} @endforeach</div>
                      <div class="list"><span class="label">Hair Color: </span> @foreach($user_ad_meta_haircolor  as $key => $mvalues){{ $mvalues->meta_value }} @endforeach</div>
                      <div class="list"><span class="label">Ethnicity: </span> @foreach($user_ad_meta_ethnicity  as $key => $mvalues){{ $mvalues->meta_value }} @endforeach</div>
                    </div>
                    <div class="contact_detail mt-3">
                      <div class="icon"><img src="frontend/images/hover-phone-icon.png"></div>
                      <div class="phone-number"><span>Phone</span><br/>02102420034</div>
                    </div>
                    <div class="rate">180$ / Hour</div>
                    <div class="view-profile"><a href="{{route('dum_profile')}}">View Profile <img src="frontend/images/long-arrow.png"></a></div>
                  </div>
                             		  
			  @if (\Session::has('shortlist_status'))
              <div class="shortlist_button mt-4">
			  <a href="/" onclick="return false;" style="background-color:green;">{!! \Session::get('shortlist_status') !!}</a>
			  </div>
	         
	          @else
			  <div class="shortlist_button mt-4">
			  <a href="{{route('shortlist_by_guest')}}">+ Shortlist</a>
			  </div>
              @endif
              </div>
              </div>
              
              
            </li>
            
            
            <li>
              <img class="img-fluid" src="frontend/images/1.jpg">
              <div class="live-btnpositon">
                <span>live</span>
              </div>
              
              
            </li>
            <li >
              <img class="img-fluid" src="frontend/images/1.jpg">
              <div class="live-btnpositon">
                <span>live</span>
              </div>
              
              
            </li>
            <li >
              <img class="img-fluid" src="frontend/images/1.jpg">
              <div class="live-btnpositon">
                <span>live</span>
              </div>
              
              
            </li>
            <li >
              <img class="img-fluid" src="frontend/images/1.jpg">
              <div class="live-btnpositon">
                <span>live</span>
              </div>
              
              
            </li>
            <li >
              <img class="img-fluid" src="frontend/images/1.jpg">
              <div class="live-btnpositon">
                <span>live</span>
              </div>
              
              
            </li>
            @for($total_profile_display=0;$total_profile_display <= 3; $total_profile_display++)
		<li >
              <img class="img-fluid" src="frontend/images/1.jpg">
              <div class="live-btnpositon">
                <span>live</span>
              </div>
              
              
            </li>	
		@endfor
          </ul>
          
          
        </div>
        
        <div class="aucklandtop-right-block">
          <div class="top-bar-sec"> <h2 class="eotd"><img class="img-fluid" src="frontend/images/eotd1.png"></h2></div>
          
          <div id="carouselExampleIndicators2" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                
                <div><img src="frontend/images/eotd.jpg" class="img-fluid" alt="img"></div>
                
                
              </div>
              <div class="carousel-item">
                <div><img src="frontend/images/eotd.jpg" class="img-fluid" alt="img"></div>
              </div>
              
              <div class="carousel-item">
                <div><img src="frontend/images/eotd.jpg" class="img-fluid" alt="img"></div>
              </div>
              
            </div>
          </div>
          <div class="profile_home">
          <h2>Live Updates</h2>
          <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>


        </div>
        </div>
        
        
      </div>
      
      
    </div>
  </section>
  
<div class="clearfix"></div>


<section class="redbar-cta text-center">
 <div class="container-fluid">
  <div class="row">
   <div class="cta-text"><p>Be a proud member of <b>House of Sexy Girls</b></p><a class="post-addcta-btn" href="#">Post your ad now</a></div>   
   </div>   
 </div>
</section>

<div class="clearfix"></div>

<section class="bottom-advertiseblock padding-50">
 <div class="container-fluid">
  <div class="row">
    <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
     <div class="advertise-box"><img src="{{ asset('frontend/images/advertise-img.jpg') }}" class="img-fluid" alt="img"></div>
    </div>
    <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
     <div class="advertise-box"><img src="{{ asset('frontend/images/advertise-img1.png') }}" class="img-fluid" alt="img"></div>
    </div>
    <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
     <div class="advertise-box"><img src="{{ asset('frontend/images/advertise-img2.png') }}" class="img-fluid" alt="img"></div>
    </div>
    <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
     <div class="advertise-box"><img src="{{ asset('frontend/images/advertise-img3.png') }}" class="img-fluid" alt="img"></div>
    </div>
    
   
   </div>
   
 </div>
</section>
@endsection 