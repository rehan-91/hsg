@extends('frontend.layouts.front_layout')
@section('header-css')
<link href="{{ asset('registrations/css/bootstrap.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/font-awesome.min.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/responsive.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_css.css') }}" rel="stylesheet">
<link href="{{ asset('registrations/css/admin_responsive.css') }}" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
@endsection

@section('content')
@php
$default_locale = app()->getLocale();
@endphp


<section class="profile-details-block">
      <div class="container">                 
          <div class="row profile-details-form">		  
		  
		 @include('frontend.layouts.partials.navfordashboard')
		  
		  
		  <div class="col-md-9">
		 
		  <div class="row side_box">
                         <div class="col-md-3">
                              <div class="card-boxes gr_pink">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-view-icon.png')}}"></div>
                                   <div class="text">Views<br /><span>{{ $stat_views }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_orange">
                                   <div class="dashboard_icon"><img
                                             src="{{ asset('frontend/images/dashboard-shortlisted-icon.png')}}"></div>
                                   <div class="text">Shortlisted<br /><span>80</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_purple">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-likes-icon.png')}}"></div>
                                   <div class="text">Likes<br /><span>{{ $stat_likes }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_green">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-clicks-icon.png')}}"></div>
                                   <div class="text">Clicks<br /><span>{{ $stat_clicks }}</span></div>
                              </div>
                         </div>
                    </div>
					
					 <div class="testimonial-listing-block account-setting-form-block">
					 <h2>{!! trans('translations.frontend.changep_title') !!}</h2>
					<form id="change_password_form" name="change_password_form" action="{{ route('cPasswordSave') }}" method="POST">
									{{ csrf_field() }}
											  
                      <div class="form-group col-md-8 col-sm-6 col-xs-12  @if($errors->has('old_password')) has-error @endif">
					      <div class="row">
						   <label>old password</label>
                       <input type="password" name="old_password" id="old_password" placeholder="{!! trans('translations.frontend.password_field_placeholder') !!}" class="form-control verification1">
					   
					   @if($errors->has("old_password"))
										<span class="help-block">{{ $errors->first("old_password") }}</span>
										@endif
					      </div>

										
                      </div>
					  
									<div class="form-group col-md-8 col-sm-6 col-xs-12 @if($errors->has('new_password')) has-error @endif">
									<div class="row">
									     <label>new password</label>
										<input type="password" name="new_password" id="new_password" placeholder="{!! trans('translations.frontend.new_password_field_placeholder') !!}" class="form-control verification1">
										@if($errors->has("new_password"))
										<span class="help-block">{{ $errors->first("new_password") }}</span>
										@endif
										</div>
									</div>

									<div class="form-group col-md-8 col-sm-6 col-xs-12 @if($errors->has('confirm_new_password')) has-error @endif">
									      <div class="row">
										  <label>confirm new password</label>
										<input type="password" name="confirm_new_password" id="confirm_new_password" placeholder="{!! trans('translations.frontend.new_password_field_placeholder') !!}" class="form-control verification1">
										@if($errors->has("confirm_new_password"))
										<span class="help-block">{{ $errors->first("confirm_new_password") }}</span>
										@endif
										</div>
									</div>




									<div class="form-group col-md-8 col-sm-6 col-xs-12">
									    <div class="row">
										<button class="post-add-btn account-setting-submitbtn verification-btn">{!! trans('translations.frontend.form_submit') !!}</button>
									</div>
									</div>
									</form>
					</div>

								
									
								</div>	
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
                   
                    
                    </div>           
  </div>
</section>

<script>
	jQuery(document).ready(function() {
		setTimeout(function() {
			jQuery(".alert-success").fadeOut("slow");
		}, 8000);
	});
</script>
@endsection