@extends('frontend.layouts.default_layout')

@section('header-css')
	<link href="{{ asset('registrations/css/style.css') }}" rel="stylesheet">
	<link href="{{ asset('registrations/css/responsive.css') }}" rel="stylesheet">
	<link href="{{ asset('registrations/css/admin_css.css') }}" rel="stylesheet">
	<link href="{{ asset('registrations/css/admin_responsive.css') }}" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
	<link rel="stylesheet" href="{{ asset('admin-vendors/css/bootstrap-datepicker.min.css') }}">
	<link href="{{ asset('admin-vendors/css/select2.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('registrations/css/magicsuggest.css') }}" rel="stylesheet" />
@endsection

@section('header-scripts')
    <script src="{{ asset('admin-vendors/js/bootstrap-datepicker.min.js') }}"></script>
	<script src="{{ asset('admin-vendors/js/select2.min.js') }}"></script>
	<script src="{{ asset('js/magicsuggest.js') }}"></script>
@endsection

@section('content')
  <section class="grey-bg paddingComm70 registration agent-pop">
	<div class="container">
	  <h1 class="text-center">{!! trans('translations.frontend.edit_profile_title') !!}</h1>
	  
	  @if (\Session::has('message'))
		<div class="alert alert-warning">
			{!! \Session::get('message') !!}
		</div>
	  @endif
	  
	  <form id="edit_agent_profile" name="edit_agent_profile" method="POST" action="{{ route('profilesave') }}" enctype="multipart/form-data">
		{{ csrf_field() }}
		
	    <div class="white-bg">
			<h4>{!! trans('translations.frontend.registration_basic') !!}</h4>
			<p>{!! trans('translations.frontend.registration_basic_desp') !!}</p>
		
			@php
			  $first_name = old('first_name', $user_data->getUnapprovedData( $user_data->id, 'first_name', $user_profile_data->first_name ) );
			  
			  $last_name = old('last_name', $user_data->getUnapprovedData( $user_data->id, 'last_name', $user_profile_data->last_name ) );
			  $agent_email = old('agent_email', $user_data->email );
			  
			  $agent_contact_number = old('agent_contact_number', $user_data->contact_number );
			  
			  $edu_qualify = old('education_qualification', $user_data->getUnapprovedData( $user_data->id, 'education_qualification', $user_profile_data->education_qualification ) );
			  
			  $gender_sel = old('gender', $user_data->getUnapprovedData( $user_data->id, 'gender', $user_profile_data->gender ) );
			@endphp
			<div class="input-box @if($errors->has('first_name')) has-error @endif">
			  <input type="text" name="first_name" id="first_name" placeholder="{!! trans('translations.frontend.first_name_placeholder') !!}" class="bg-input" value="{{ $first_name }}">
			  @if($errors->has("first_name"))
				<span class="help-block">{{ $errors->first("first_name") }}</span>
			  @endif
			</div>
		
			<div class="input-box @if($errors->has('last_name')) has-error @endif">
			  <input type="text" name="last_name" id="last_name" placeholder="{!! trans('translations.frontend.last_name_placeholder') !!}" class="bg-input" value="{{ $last_name }}">
			  @if($errors->has("last_name"))
				<span class="help-block">{{ $errors->first("last_name") }}</span>
			  @endif
			  <p class="blue activate-txt field-not-comp">{!! trans('translations.frontend.field_not_compulsory') !!}</p>
			</div>
			
			<div class="input-box @if($errors->has('agent_email')) has-error @endif">
			  <input type="text" name="agent_email" id="agent_email" placeholder="{!! trans('translations.frontend.agent_email_placeholder') !!}" class="bg-input" value="{{ $agent_email }}">
			  @if($errors->has("agent_email"))
				<span class="help-block">{{ $errors->first("agent_email") }}</span>
			  @endif
			  <p class="blue activate-txt">{!! trans('translations.frontend.activation_message_email') !!}</p>
			</div>
			
			<div class="input-box @if($errors->has('agent_contact_number')) has-error @endif">
			  <input type="text" name="agent_contact_number" id="agent_contact_number" placeholder="{!! trans('translations.frontend.agent_contact_number_placeholder') !!}" class="bg-input" value="{{ $agent_contact_number }}">
			  @if($errors->has("agent_contact_number"))
				<span class="help-block">{{ $errors->first("agent_contact_number") }}</span>
			  @endif
			  <p class="blue activate-txt">{!! trans('translations.frontend.activation_message_contact') !!}</p>
			</div>
			
			<div class="clearfix"></div>
			
			<div class="input-box @if($errors->has('education_qualification')) has-error @endif">
				<select class="bg-input" id="education_qualification" name="education_qualification">
					<option value="">{!! trans('translations.frontend.education_qualification_placeholder') !!}</option>
				    @if( count($qualifications) > 0 )
						@foreach($qualifications as $qualification)
						  <option value="{{ $qualification->id }}" @if( intval( $edu_qualify ) == intval( $qualification->id ) ) selected @endif >{!! $qualification->name !!}</option>
						@endforeach
				    @endif
				</select>
				@if($errors->has("education_qualification"))
				  <span class="help-block">{{ $errors->first("education_qualification") }}</span>
				@endif
			</div>
			
			
			@php
			  $gender_arr = array(
							'male' => trans('translations.frontend.gender_option_male'),
							'female' => trans('translations.frontend.gender_option_female'),
							'others' => trans('translations.frontend.gender_option_other'),
							);
			@endphp
			
			<div class="input-box @if($errors->has('gender')) has-error @endif">
				<select class="bg-input" id="gender" name="gender">
					<option value="">{!! trans('translations.frontend.gender_placeholder') !!}</option>
				    @if( count($gender_arr) > 0 )
						@foreach($gender_arr as $key => $value)
						  <option value="{{ $key }}" @if( $gender_sel == $key ) selected @endif >{!! $value !!}</option>
						@endforeach
				    @endif
				</select>
				@if($errors->has("gender"))
				  <span class="help-block">{{ $errors->first("gender") }}</span>
				@endif
			</div>
			
			<div class="clearfix"></div>
			<hr>
			
			@php
			
			$profile_image_id = old('hidden_profile_id', $user_data->getUnapprovedData( $user_data->id, 'image_id', $user_data->image_id ) );
			
			$secondary_image_id = old('hidden_secondary_image_id', $user_data->getUnapprovedData( $user_data->id, 'secondary_image_id', $user_profile_data->secondary_image_id ) );
			@endphp
			
			<div style="display:none;">
			  <span id="hidden_profile_id_required">{{ trans('translations.frontend.profile_img_required') }}</span>
			  <span id="hidden_profile_id_image">{{ trans('translations.frontend.profile_store_mimes_image') }}</span>
			  <span id="hidden_profile_id_mimes">{{ trans('translations.frontend.profile_store_mimes_image') }}</span>
			  <span id="hidden_profile_id_size">{{ trans('translations.frontend.profile_sizemax') }}</span>
			  
			  <span id="hidden_secondary_image_id_required">{{ trans('translations.frontend.secondary_img_required') }}</span>
			  <span id="hidden_secondary_image_id_image">{{ trans('translations.frontend.profile_store_mimes_image') }}</span>
			  <span id="hidden_secondary_image_id_mimes">{{ trans('translations.frontend.profile_store_mimes_image') }}</span>
			  <span id="hidden_secondary_image_id_size">{{ trans('translations.frontend.store_sizemax') }}</span>
			</div>
			
			<h4>{!! trans('translations.frontend.upload_title') !!}</h4>
			<p>{!! trans('translations.frontend.upload_desp') !!}</p>
			<div class="profile-img dual-profile">
			  <div class="first-image">
				<span class="add_pic pull-right" id="agents_profile_image_master" @if( $user_data->get_image_data($profile_image_id, 'size400', 1) != "" ) style="visibility:hidden;" @endif >
					<img src="{{ asset('images/no-img.png') }}"><strong>{!! trans('translations.frontend.add_profile_img') !!}</strong>
				</span>
				<div class="form-group">
				  <div>
					<button type="button" onclick="update_edit_image_content( 'agents_profile_image_preview', 'agents_profile_image_master', 'agents_profile_image_editor', 'hidden_profile_id');"></button>
					<span class="img-profile_size">
						<img src="{{ $user_data->get_image_data($profile_image_id, 'size400', 1) }}" id="agents_profile_image_preview">
					</span>
					<input type="hidden" name="hidden_profile_id" id="hidden_profile_id" value="{{ $profile_image_id }}">
					
					<span class="help-block popup-text-err image_cont_error hidden_profile_id_error @if($errors->has('hidden_profile_id')) @else hidden @endif" >{{ $errors->first("hidden_profile_id") }}</span>
				  </div>
				</div>
				<div class="image-edits profile-edit" id="agents_profile_image_editor" @if( $user_data->get_image_data($profile_image_id, 'size400', 1) == "" ) style="display:none;"  @endif >
					<a href="javascript:void(0);" onclick="remove_user_image( 'agents_profile_image_preview', 'agents_profile_image_master', 'agents_profile_image_editor', 'hidden_profile_id' );" class="pull-left"><i class="fa fa-trash" aria-hidden="true"></i></a>
					<a href="javascript:void(0);" class="pull-right" onclick="update_edit_image_content( 'agents_profile_image_preview', 'agents_profile_image_master', 'agents_profile_image_editor', 'hidden_profile_id');" ><i class="fa fa-pencil" aria-hidden="true"></i> </a>
				</div>
			  </div>
			  
			  <div class="second-image">
				<span class="add_pic pull-right" id="agents_secondary_image_master" @if( $user_data->get_image_data($secondary_image_id, 'size400', 1) != "" ) style="visibility:hidden;" @endif>
				  <img src="{{ asset('images/no-img.png') }}"><strong>{!! trans('translations.frontend.add_store_img') !!}</strong>
				</span>
				<div class="form-group">
				  <div>
							
					<button type="button" onclick="update_edit_image_content( 'agents_secondary_image_preview', 'agents_secondary_image_master', 'agents_secondary_image_editor', 'hidden_secondary_image_id');"></button>
					<span class="img-profile_size">
						<img src="{{ $user_data->get_image_data($secondary_image_id, 'size400', 1) }}" id="agents_secondary_image_preview">
					</span>
					<input type="hidden" name="hidden_secondary_image_id" id="hidden_secondary_image_id" value="{{ $secondary_image_id }}">
					<span class="help-block popup-text-err image_cont_error hidden_secondary_image_id_error @if($errors->has('hidden_secondary_image_id')) @else hidden @endif" >{{ $errors->first("hidden_secondary_image_id") }}</span>
				  </div>
				</div>
				<div class="image-edits profile-edit" id="agents_secondary_image_editor" @if( $user_data->get_image_data( $secondary_image_id, 'size400', 1) == "" ) style="display:none;"  @endif >
					<a href="javascript:void(0);" onclick="remove_user_image( 'agents_secondary_image_preview', 'agents_secondary_image_master', 'agents_secondary_image_editor', 'hidden_secondary_image_id' );" class="pull-left"><i class="fa fa-trash" aria-hidden="true"></i></a>
					<a href="javascript:void(0);" class="pull-right" onclick="update_edit_image_content( 'agents_secondary_image_preview', 'agents_secondary_image_master', 'agents_secondary_image_editor', 'hidden_secondary_image_id');" ><i class="fa fa-pencil" aria-hidden="true"></i> </a>
				</div>
			  </div>
			</div>
			
			<div class="clearfix"></div>
			<hr>
			
			<div class="col-md-3 col-sm-12 col-xs-12 advanced">
			  <div class="row">
				<h4>{!! trans('translations.frontend.advanced_title') !!}</h4>
				<div class="input-box @if($errors->has('associated_user')) has-error @endif">
					<select class="bg-input" id="associated_user" name="associated_user" disabled>
					  <option value="">{!! trans('translations.frontend.associated_user_placeholder') !!}</option>
					  @if( count($cbc_users) > 0 )
						@foreach($cbc_users as $users)
						  <option value="{{ $users->id }}" @if( intval($user_profile_data->parent_cbc) == intval($users->id) ) selected @endif >{!! $users->name !!}</option>
						@endforeach
					  @endif
					</select>
					
					@if($errors->has("associated_user"))
					  <span class="help-block">{{ $errors->first("associated_user") }}</span>
					@endif
					<p class="blue activate-txt field-not-comp">{!! trans('translations.frontend.field_not_compulsory') !!}</p>
				</div>
			  </div>
			</div>
			
			@php
			  $sel_services = explode(",", $user_data->getUnapprovedData( $user_data->id, 'services', $user_profile_data->services ) );
			
			  if( count( $errors ) > 0 ){
				$sel_services = old('services', array() );
			  }
			@endphp
			<div class="col-md-8 col-sm-12 col-xs-12 services-reg">
				<h4>{!! trans('translations.frontend.services_placeholder') !!}</h4>
				<div class="pull-left  serviceSwitch switch-btns agent_service_container">
					@if( count($agent_services) > 0 )
					  @foreach($agent_services as $service)
						<span>
							<input type="checkbox" id="agent_service_{{ $service->id }}" name="services[]" value="{!! $service->id !!}" class="css-checkbox" @if( in_array( $service->id, $sel_services ) ) checked @endif >
							<label for="agent_service_{{ $service->id }}" class="css-label">{!! $service->name !!}</label>
						</span>
					  @endforeach
					@endif
					@if($errors->has("services"))
					  <div class="clearfix"></div>
					  <span class="help-block popup-text-err">{{ $errors->first("services") }}</span>
					@endif
				</div>
		    </div> 
			
			<div class="clearfix"></div>
			<hr>
			
			@php
			  $pan_card = old('pan_card', $user_data->getUnapprovedData( $user_data->id, 'pan_number', $user_profile_data->pan_number ) );
			  
			  $voter_id = old('voter_id', $user_data->getUnapprovedData( $user_data->id, 'voter_id_number', $user_profile_data->voter_id_number ) );
			  
			  $driving_license = old('driving_license', $user_data->getUnapprovedData( $user_data->id, 'driving_license', $user_profile_data->driving_license ) );
			  
			  $dob = old('dob', $user_data->getUnapprovedData( $user_data->id, 'dob', $user_profile_data->dob ) );
			  
			  $cibil_score = old('cibil_score', $user_data->getUnapprovedData( $user_data->id, 'cibil_score', $user_profile_data->cibil_score ) );
			@endphp
			
			<h4 class="mrbtm">{!! trans('translations.frontend.identity_title') !!}</h4>
			<div class="input-box @if($errors->has('pan_card')) has-error @endif">
			  <input type="text" id="pan_card" name="pan_card" placeholder="{!! trans('translations.frontend.pan_card_placeholder') !!}" class="bg-input" value="{{ $pan_card }}">
			  @if($errors->has("pan_card"))
				<span class="help-block">{{ $errors->first("pan_card") }}</span>
			  @endif
			</div>
			
			<div class="input-box voter-box @if($errors->has('voter_id')) has-error @endif">
			  <input type="text" id="voter_id" name="voter_id" placeholder="{!! trans('translations.frontend.voter_id_placeholder') !!}" class="bg-input" value="{{ $voter_id }}">
			  @if($errors->has("voter_id"))
				<span class="help-block">{{ $errors->first("voter_id") }}</span>
			  @endif
			</div>
			
			<div class="input-box @if($errors->has('driving_license')) has-error @endif">
			  <input type="text" id="driving_license" name="driving_license" placeholder="{!! trans('translations.frontend.driving_license_placeholder') !!}" class="bg-input" value="{{ $driving_license }}">
			  @if($errors->has("driving_license"))
				<span class="help-block">{{ $errors->first("driving_license") }}</span>
			  @endif
			</div>
			
			<div class="input-box do-box @if($errors->has('dob')) has-error @endif">
			  <input type="text" id="dob" name="dob" placeholder="{!! trans('translations.frontend.dob_placeholder') !!}" class="bg-input" value="{{ $dob }}">
			  @if($errors->has("dob"))
				<span class="help-block">{{ $errors->first("dob") }}</span>
			  @endif
			</div>
			
			<div class="input-box cibil-box @if($errors->has('cibil_score')) has-error @endif">
			  <input type="text" id="cibil_score" name="cibil_score" placeholder="{!! trans('translations.frontend.cibil_score_placeholder') !!}" class="bg-input" value="{{ intval($cibil_score) }}">
			  @if($errors->has("cibil_score"))
				<span class="help-block">{{ $errors->first("cibil_score") }}</span>
			  @endif
			  <p class="blue activate-txt field-not-comp">{!! trans('translations.frontend.field_not_compulsory') !!}</p>
			</div>
		
			<div class="clearfix"></div>
			<hr>
			
			<h4>{!! trans('translations.frontend.contact_title') !!}</h4>
			<p>{!! trans('translations.frontend.contact_desp') !!}</p>
			
			@php
			  $sel_state_val = $user_data->getUnapprovedData( $user_data->id, 'state_id', $user_profile_data->state_id );
			
			  if( count( $errors ) > 0 ){
				$sel_state_val = old('addr_state', '' );
			    if( is_array( $sel_state_val ) > 0 ){
				  $sel_state_val = $sel_state_val[0];
			    }
			  }
			  
			  $sel_district_val = $user_data->getUnapprovedData( $user_data->id, 'district_id', $user_profile_data->district_id );
			
			  if( count( $errors ) > 0 ){
				$sel_district_val = old('addr_district', '' );
			    if( is_array( $sel_district_val ) > 0 ){
				  $sel_district_val = $sel_district_val[0];
			    }
			  }
			  
			  $sel_subdistrict_val = $user_data->getUnapprovedData( $user_data->id, 'sub_district_id', $user_profile_data->sub_district_id );
			
			  if( count( $errors ) > 0 ){
				$sel_subdistrict_val = old('addr_sub_district', '' );
			    if( is_array( $sel_subdistrict_val ) > 0 ){
				  $sel_subdistrict_val = $sel_subdistrict_val[0];
			    }
			  }
			  
			  $sel_block_val = $user_data->getUnapprovedData( $user_data->id, 'block_id', $user_profile_data->block_id );
			
			  if( count( $errors ) > 0 ){
				$sel_block_val = old('addr_block', '' );
			    if( is_array( $sel_block_val ) > 0 ){
				  $sel_block_val = $sel_block_val[0];
			    }
			  }
			@endphp
			
			<div class="input-box @if($errors->has('addr_state')) has-error @endif">
			  <select class="bg-input" id="addr_state" name="addr_state[]">
				@if($states)
					@foreach( $states as $state_data )
						<option value="{{ $state_data['id'] }}"> {{ $state_data["name"] }} </option>
					@endforeach
				@endif
			  </select>
			  @if($errors->has("addr_state"))
				<span class="help-block">{{ $errors->first("addr_state") }}</span>
			  @endif
			</div>
			
			<div class="input-box @if($errors->has('addr_district')) has-error @endif">
			  <select class="bg-input" id="addr_district" name="addr_district" >
				<?php
				/* <option value="">{!! trans('translations.frontend.district_placeholder') !!}</option>
				@if($district)
					@foreach( $district as $district_data )
						<option value="{{ $district_data['id'] }}"> {{ $district_data["name"] }} </option>
					@endforeach
				@endif */
				?>
			  </select>
			  @if($errors->has("addr_district"))
				<span class="help-block">{{ $errors->first("addr_district") }}</span>
			  @endif
			</div>
			
			<div class="input-box @if($errors->has('addr_sub_district')) has-error @endif">
			  <select class="bg-input" id="addr_sub_district" name="addr_sub_district" onchange="update_subdistrict_based_listings(this.value, '');">
				<?php
				/* <option value="">{!! trans('translations.frontend.sub_district_placeholder') !!}</option>
				@if($sub_district)
					@foreach( $sub_district as $sub_district_data )
						<option value="{{ $sub_district_data['id'] }}"> {{ $sub_district_data["name"] }} </option>
					@endforeach
				@endif */
				?>
			  </select>
			  @if($errors->has("addr_sub_district"))
				<span class="help-block">{{ $errors->first("addr_sub_district") }}</span>
			  @endif
			</div>
			
			<div class="input-box @if($errors->has('addr_block')) has-error @endif">
			  <select class="bg-input" id="addr_block" name="addr_block">
				<?php
				/* <option value="">{!! trans('translations.frontend.block_placeholder') !!}</option>
				@if($blocks)
					@foreach( $blocks as $blocks_data )
						<option value="{{ $blocks_data['id'] }}"> {{ $blocks_data["name"] }} </option>
					@endforeach
				@endif */
				?>
			  </select>
			  @if($errors->has("addr_block"))
				<span class="help-block">{{ $errors->first("addr_block") }}</span>
			  @endif
			</div>
			
			<div class="clearfix"></div>
			@php			
			$street_name = old('street_name', $user_data->getUnapprovedData( $user_data->id, 'address_street', $user_profile_data->address_street ) );
			
			$addr_pincode = old('addr_pincode', $user_data->getUnapprovedData( $user_data->id, 'pin_code', $user_profile_data->pin_code ) );
			
			/* $latitude_longitude = explode( ",", $user_data->getUnapprovedData( $user_data->id, 'address_latlong', $user_profile_data->address_latlong ) );
			
			$addr_latitude = is_null( old('addr_latitude') ) ? ( isset($latitude_longitude[0]) ? $latitude_longitude[0] : '' ) : old('addr_latitude');
			
			$addr_longitude = is_null( old('addr_longitude') ) ? ( isset($latitude_longitude[1]) ? $latitude_longitude[1] : '' ) : old('addr_longitude'); */
			@endphp
			
			<div class="input-box @if($errors->has('street_name')) has-error @endif">
				<input type="text" id="street_name" name="street_name" placeholder="{!! trans('translations.frontend.street_name_placeholder') !!}" class="bg-input " value="{{ $street_name }}">
				@if($errors->has("street_name"))
					<span class="help-block">{{ $errors->first("street_name") }}</span>
				@endif
			</div>
			<div class="input-box @if($errors->has('addr_pincode')) has-error @endif">
				<input type="text" id="addr_pincode" name="addr_pincode" placeholder="{!! trans('translations.frontend.pincode_placeholder') !!}" class="bg-input " value="{{ $addr_pincode }}">
				@if($errors->has("addr_pincode"))
					<span class="help-block">{{ $errors->first("addr_pincode") }}</span>
				@endif
			</div>
			<?php
			/* <div class="input-box @if($errors->has('addr_latitude')) has-error @endif">
				<input type="text" id="addr_latitude" name="addr_latitude" placeholder="{!! trans('translations.frontend.latitude_placeholder') !!}" class="bg-input " value="{{ $addr_latitude }}">
				@if($errors->has("addr_latitude"))
					<span class="help-block">{{ $errors->first("addr_latitude") }}</span>
				@endif
			</div>
			<div class="input-box @if($errors->has('addr_longitude')) has-error @endif">
				<input type="text" id="addr_longitude" name="addr_longitude" placeholder="{!! trans('translations.frontend.longitude_placeholder') !!}" class="bg-input " value="{{ $addr_longitude }}">
				@if($errors->has("addr_longitude"))
					<span class="help-block">{{ $errors->first("addr_longitude") }}</span>
				@endif
			</div> */
			?>
			
			<div class="clearfix"></div>
			<hr>
			
			<div class="clearfix"></div>
			<button type="submit" class="orange-btn arrow-icon btn-cm text-center" value="Submit">{!! trans('translations.frontend.submit_btn') !!}</button>
		</div>
	  </form>
	  
	  <div style="display:none;">
		<form id="hidden_img_uploader" name="hidden_img_uploader" method="POST" enctype="multipart/form-data">
			{{ csrf_field() }}
			
			<input type="file" name="img_file" id="img_file">
			<input type="hidden" name="img_file_src" id="img_file_src">
			<input type="hidden" name="img_file_name" id="img_file_name">
		</form>
	  </div>
	</div>
  </section>
  
  <div id="register_loader_container" class="register-loader" style="display:none;">
	<img src="{{ asset('images/register_loader.gif') }}">
  </div>
	
  <script>
	var MAX_WIDTH = 800;
	var MAX_HEIGHT = 800;
	
	var sel_state = "{{ $sel_state_val }}";
	var sel_district = "{{ $sel_district_val }}";
	var sel_sub_district = "{{ $sel_subdistrict_val }}";
	var sel_block = "{{ $sel_block_val }}";
  
	var state_route = "{!! route('fajax.stateList') !!}";
	var district_route = "{!! route('fajax.districtList') !!}";
	var subdistrict_route = "{!! route('fajax.subDistrictList') !!}";
	
	var access_token = jQuery('input[name=_token]').val();
  
	var state_combo, district_combo, subdistrict_combo, block_combo;
	
	var image_preview, default_preview, edit_container, field_id;
	
	var run_change_ajax = 0;
	
	/* Valid Image file formats */
	var ValidImageTypes = ["image/jpeg", "image/png"];
  
	jQuery(document).ready(function(){
		
		setTimeout(function(){
			jQuery(".alert-warning").fadeOut("slow");
		}, 8000);
		
		jQuery("#dob").datepicker({ 
			format: 'dd/mm/yyyy',
			autoclose: true,
			endDate: '-18y',
			weekStart : 1
		});
		
		state_combo = jQuery("#addr_state").magicSuggest({
			cls: 'select-magic',
			data: "{!! route('fajax.stateData') !!}",
			allowFreeEntries: false,
			maxSelection: 1,
			name: 'addr_state',
			placeholder: "{!! trans('translations.frontend.state_placeholder') !!}",
		});
		
		district_combo = jQuery("#addr_district").magicSuggest({
			cls: 'select-magic',
			/* data: "{!! route('fajax.districtData') !!}", */
			allowFreeEntries: false,
			disabled:true,
			maxSelection: 1,
			name: 'addr_district',
			placeholder: "{!! trans('translations.frontend.district_placeholder') !!}",
		});
		
		subdistrict_combo = jQuery("#addr_sub_district").magicSuggest({
			cls: 'select-magic',
			/* data: "{!! route('fajax.subdistrictData') !!}", */
			allowFreeEntries: true,
			disabled:true,
			maxSelection: 1,
			name: 'addr_sub_district',
			placeholder: "{!! trans('translations.frontend.sub_district_placeholder') !!}",
		});
		
		block_combo = jQuery("#addr_block").magicSuggest({
			cls: 'select-magic',
			/* data: "{!! route('fajax.blockData') !!}", */
			allowFreeEntries: true,
			disabled:true,
			maxSelection: 1,
			name: 'addr_block',
			placeholder: "{!! trans('translations.frontend.block_placeholder') !!}",
		});
		
		jQuery(state_combo).on('selectionchange', function(e, m){
			if( parseInt( run_change_ajax ) == 1 ){
				run_change_ajax = 0;
				update_state_based_listings(this.getValue()[0]);
			}
		});
		
		jQuery(district_combo).on('selectionchange', function(e, m){
			if( parseInt( run_change_ajax ) == 1 ){
				run_change_ajax = 0;
				update_district_based_listings(this.getValue()[0]);
			}
		});
		
		jQuery(subdistrict_combo).on('selectionchange', function(e, m){
			if( parseInt( run_change_ajax ) == 1 ){
				run_change_ajax = 0;
				update_subdistrict_based_listings(this.getValue()[0]);
			}
		});
		
		set_agent_address_onload(sel_state, sel_district, sel_sub_district, sel_block);
		
		jQuery("#img_file").change(function(){
			jQuery("#img_file_src").val('');
			jQuery("#img_file_name").val('');
			jQuery("."+field_id+"_error").html("");
			jQuery("."+field_id+"_error").addClass("hidden");
			
			if ( this .files && this .files[0] ) {
				
				if( parseInt( this .files[0].size ) >= 5242880 ){
					jQuery('#'+image_preview).attr('src', '');
					var txt_error = jQuery("#"+field_id+"_size").text();
					
					jQuery("#"+default_preview).css("visibility", "visible");
					jQuery("."+field_id+"_error").html(txt_error);
					jQuery("."+field_id+"_error").removeClass("hidden");
					
					jQuery("#register_loader_container").fadeOut();
				}
				else{
					if( jQuery.inArray(this .files[0].type, ValidImageTypes) < 0 ){
						jQuery('#'+image_preview).attr('src', '');
						var txt_error = jQuery("#"+field_id+"_image").text();
						
						jQuery("#"+default_preview).css("visibility", "visible");
						jQuery("."+field_id+"_error").html(txt_error);
						jQuery("."+field_id+"_error").removeClass("hidden");
						
						jQuery("#register_loader_container").fadeOut();
					}
					else{
						var reader = new FileReader();
						
						reader.onload = function (e) {
							jQuery("#img_file_src").val(e.target.result);
							jQuery("#img_file_name").val( jQuery('#img_file')[0].files[0].name );
							
						}
						reader.readAsDataURL( this .files[0] );
						
						resize_upload();
						
						
					}
				}
			}
		});
	});
	
	function resize_upload(){
		if (window.File && window.FileReader && window.FileList && window.Blob) {
			var filesToUploads = document.getElementById( "img_file" ).files;
			var file = filesToUploads[0];
			if (file) {

				var reader = new FileReader();
				// Set the image once loaded into file reader
				reader.onload = function(e) {
					var img = new Image();
					img.src = e.target.result;
					img.onload = function() {
						var canvas = document.createElement("canvas");
						var ctx = canvas.getContext("2d");
						ctx.drawImage(img, 0, 0);

						var width = img.width;
						var height = img.height;

						if (width > height) {
							if (width > MAX_WIDTH) {
								height *= MAX_WIDTH / width;
								width = MAX_WIDTH;
							}
						} else {
							if (height > MAX_HEIGHT) {
								width *= MAX_HEIGHT / height;
								height = MAX_HEIGHT;
							}
						}
						
						canvas.width = width;
						canvas.height = height;
						var ctx = canvas.getContext("2d");
						ctx.drawImage(img, 0, 0, width, height);
						
						ImageURL = canvas.toDataURL(file.type);
						
						var block = ImageURL.split(";");
						var contentType = file.type;
						var realData = block[1].split(",")[1];
						
						var img_blob = b64toBlob(realData, contentType);
						var img_name = jQuery("#img_file_name").val();
						
						jQuery("#img_file").val(null);
						jQuery("#img_file_src").val( "" );
						
						var form = document.getElementById( "hidden_img_uploader" );
						var image_uploader = new FormData(form);
						image_uploader.append("img_uploader", img_blob, img_name);
						
						jQuery.ajax({
							type: 'POST',
							dataType: "JSON",
							url: "{!! route('profileupload') !!}",
							data: image_uploader,
							processData: false,
							contentType: false,
							success: function(data) {
								if( data.error ){
									console.log( data.error );
									jQuery('#'+image_preview).attr('src', '');
									var txt_error = jQuery("#"+field_id+"_"+data.error).text();
									
									jQuery("#"+default_preview).css("visibility", "visible");
									jQuery("."+field_id+"_error").html(txt_error);
									jQuery("."+field_id+"_error").removeClass("hidden");
									
									jQuery("#register_loader_container").fadeOut();
								}
								if( data.success ){
									jQuery("#"+field_id).val( data.image_id );
									jQuery("#"+image_preview).attr("src", data.image_size_400);
									jQuery("#"+default_preview).css("visibility", "hidden");
									jQuery("#"+edit_container).css("display", "block");
									
									
									jQuery("#register_loader_container").fadeOut();
								}
							},
						});
						
					};
				}
				reader.readAsDataURL(file);
			}
			else{
				jQuery("#register_loader_container").fadeOut();
			}
		}
	}
	
	function b64toBlob(b64Data, contentType, sliceSize) {
		contentType = contentType || '';
		sliceSize = sliceSize || 512;

		var byteCharacters = atob(b64Data);
		var byteArrays = [];

		for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
			var slice = byteCharacters.slice(offset, offset + sliceSize);

			var byteNumbers = new Array(slice.length);
			for (var i = 0; i < slice.length; i++) {
				byteNumbers[i] = slice.charCodeAt(i);
			}

			var byteArray = new Uint8Array(byteNumbers);

			byteArrays.push(byteArray);
		}

	  var blob = new Blob(byteArrays, {type: contentType});
	  return blob;
	}
	
	
	function set_agent_address_onload( state_sel, district_sel, sub_district_sel, block_sel ){
		if( state_sel != "" ){
			state_combo.setValue( [ state_sel ] ); 
		}
		
		if( parseInt( state_sel ) > 0 ){
			jQuery.ajax({
				type: 'POST',
				dataType: "JSON",
				url: state_route,
				data: {
					'_token': access_token,
					'id': state_sel,
					'district_id': district_sel,
					'sub_district_id': sub_district_sel,
					'block_id': block_sel,
				},
				success: function(data) {
					
					if( parseInt(data.district_data.length) > 0 ){
						district_combo.setData(data.district_data);
					}
					
					if( district_sel != "" ){
						district_combo.enable();
						district_combo.setValue( [ district_sel ] );
						jQuery.ajax({
							type: 'POST',
							dataType: "JSON",
							url: district_route,
							data: {
								'_token': access_token,
								'id': district_sel,
								'sub_district_id': sub_district_sel,
								'block_id': block_sel,
							},
							success: function(data) {
								
								if( parseInt(data.sub_district_data.length) > 0 ){
									subdistrict_combo.setData(data.sub_district_data);
								}
								
								if( sub_district_sel != "" ){
									subdistrict_combo.enable();
									subdistrict_combo.setValue( [ sub_district_sel ] );
								
									jQuery.ajax({
										type: 'POST',
										dataType: "JSON",
										url: subdistrict_route,
										data: {
											'_token': access_token,
											'id': sub_district_sel,
											'block_id': block_sel,
										},
										success: function(data) {
											
											if( parseInt(data.blocks_data.length) > 0 ){
												block_combo.setData(data.blocks_data);
											}
											
											if( block_sel != "" ){
												block_combo.enable();
												block_combo.setValue( [ block_sel ] );
											}
											
											run_change_ajax = 1;
										},
									});
								}
								else{
									run_change_ajax = 1;
								}
							},
						});
					}
					else{
						run_change_ajax = 1;
					}
				},
			});
		}
	}
	
	/* Change city and district based on state */
	function update_state_based_listings(state_id, district_id){
		if( state_id == undefined ){
			state_id = 0;
		}
		
		district_combo.clear();
		subdistrict_combo.clear();
		block_combo.clear();
		
		district_combo.collapse();
		subdistrict_combo.collapse();
		block_combo.collapse();
		
		district_combo.setData( [] );
		subdistrict_combo.setData( [] );
		block_combo.setData( [] );
		
		subdistrict_combo.disable();
		block_combo.disable();
		
		if( parseInt( state_id ) == 0 ){
			run_change_ajax = 1;
			district_combo.disable();
			return false;
		}
		jQuery.ajax({
			type: 'POST',
			dataType: "JSON",
			url: state_route,
			data: {
				'_token': access_token,
				'id': state_id
			},
			success: function(data) {
				district_combo.enable();
				if( parseInt(data.district_data.length) > 0 ){
					district_combo.setData(data.district_data);
				}
				run_change_ajax = 1;
			},
		});
	}

	function update_district_based_listings(district_id, sub_district_id){
		if( district_id == undefined ){
			district_id = 0;
		}
		
		subdistrict_combo.clear();
		block_combo.clear();
		
		subdistrict_combo.setData( [] );
		block_combo.setData( [] );
		
		subdistrict_combo.collapse();
		block_combo.collapse();
		
		block_combo.disable();
		
		if( parseInt( district_id ) == 0 ){
			run_change_ajax = 1;
			subdistrict_combo.disable();
			return false;
		}
		jQuery.ajax({
			type: 'POST',
			dataType: "JSON",
			url: district_route,
			data: {
				'_token': access_token,
				'id': district_id
			},
			success: function(data) {
				subdistrict_combo.enable();
				if( parseInt(data.sub_district_data.length) > 0 ){
					subdistrict_combo.setData(data.sub_district_data);
				}
				run_change_ajax = 1;
			},
		});
	}

	function update_subdistrict_based_listings(sub_district_id, block_id){
		block_combo.clear();
		block_combo.setData( [] );
		
		if( sub_district_id == undefined ){
			sub_district_id = 0;
			
			block_combo.disable();
			run_change_ajax = 1;
			return false;
		}
		
		if( parseInt( sub_district_id ) > 0 ){
			jQuery.ajax({
				type: 'POST',
				dataType: "JSON",
				url: subdistrict_route,
				data: {
					'_token': access_token,
					'id': sub_district_id
				},
				success: function(data) {
					block_combo.enable();
					if( parseInt(data.blocks_data.length) > 0 ){
						block_combo.setData(data.blocks_data);
					}
					run_change_ajax = 1;
				},
			});
		}
		else{
			block_combo.enable();
			run_change_ajax = 1;
		}
	}
	
	function update_edit_image_content( preview_selector, default_preview_selector, edit_delete_selector, hidden_id ){
		jQuery("#img_file").val(null);
		jQuery("#register_loader_container").fadeIn();
		
		image_preview = preview_selector;
		default_preview = default_preview_selector;
		edit_container = edit_delete_selector;
		field_id = hidden_id;
		
		jQuery("#img_file").trigger("click");
	}
	
	function remove_user_image(preview_selector, default_preview_selector, edit_delete_selector, hidden_id){
		jQuery("#"+hidden_id).val( "" );
		jQuery("#"+preview_selector).attr("src", "");
		jQuery("#"+default_preview_selector).css("visibility", "visible");
		jQuery("#"+edit_delete_selector).css("display", "none");
	}
  </script>
	<style>
.registration .white-bg {
   display: inline-block;
    width: 100%;
    padding: 40px 53px 40px 65px;
}
.registration .input-box {
        margin-right: 12px;
    width: 23.5%;
    margin-bottom: 20px;
}
.registration .first-image span.add_pic, .registration .first-image {
    margin-left: 0;
}
.registration .dual-profile .add_pic {
    min-width: 290px !important;
    padding: 72px 43px;
    height: 257px;
}
.registration .profile-img.dual-profile .form-group button {
    width: 290px;
    height: 257px;
}
.advanced .input-box {
    width: 100%;
}

.services-reg
{
	margin-left: 4%;
    border-left: 1px solid #e5e8ec;
    padding-left: 4% !important;
}
.services-reg .switch-btns span {
    margin-right: 29px;
	    margin-bottom: 25px !important;
}
.margTp {
    margin-top: 20px;
}
.registration h1 {
    font-size: 30px;
    color: #000;
	    margin-bottom: 50px;
}
.registration h4 {
    color: #000 !important;
    font-size: 24px !important;
    margin-bottom: 5px !important;
}
.registration p {
    font-size: 14px;
    color: #8487a9;
    margin-bottom: 30px;
}
.advanced h4, .services-reg h4, body .mrbtm {
    margin-bottom: 25px !important;
}
.registration hr {
    margin: 28px 0 48px;
}
.services-reg {
    margin-bottom: 20px;
}
.registration a.orange-btn:hover, .registration a.orange-btn:focus, .registration a.orange-btn:active {
    background: #00a959;
}
.registration a.orange-btn {
    display: block;
    width: 144px;
    margin: 0 auto;
}

@media only screen and (max-width:991px)
{
	.registration .input-box {
    width: 48%;
   }
   .services-reg {
        margin-left: 0;
    border-left: 0;
    padding-left: 0 !important;
    border-top: 1px solid #f2f2f2;
    margin-top: 30px;
    padding-top: 50px;
    margin-bottom: 0 !important;
}
.serviceSwitch.switch-btns {
    margin-bottom: 0;
}

}
@media only screen and (max-width:767px)
{
.registration .input-box {
    width: 100%;
    margin-right: 0;
}
.services-reg .switch-btns span {
    margin-right: 0;
    width: 50% !important;
}
}
@media only screen and (max-width:480px)
{
.registration .white-bg {
    padding: 40px 25px;
}
.services-reg .switch-btns span {
    width: 100% !important;
}
}
</style>
@endsection


