<div class="content_block step_7" style="display:none;">
                <div class="thanks_box text-center">
                    <h2>Congratulation Alice</h2>
                    <p>Your ad is succesfully created</p>
                    <div class="clearfix"></div>
                    <a href="{{route('dashboard')}}" class="green_gredient_btn gr_green">View Dashoard</a>
                </div>
            </div>