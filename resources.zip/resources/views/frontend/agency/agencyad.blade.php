@extends('frontend.layouts.front_layout')
@section('content')
<div id="Load" class="load" style="display:none;">
    <div class="load__container">
        <div class="load__animation"></div>
        <div class="load__mask"></div>
        <span class="load__title">Loading...</span>
    </div>
</div>
<section class="profile-details-block">
    <div class="container">
        <div id="wizard" class="wizard clearfix">
        @include('frontend.layouts.partials.frontnav_photographer')
         @include('frontend.agency.agencyad_step_1')
         @include('frontend.agency.agencyad_step_2')
         @include('frontend.agency.agencyad_step_3')
         @include('frontend.agency.agencyad_step_4')
         @include('frontend.agency.agencyad_step_7')
         </div>
    </div>
</section>
<!-- Creates the bootstrap modal where the image will appear -->
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
  <div class="modal-dialog" style="max-width:100%; margin:0; vertical-align:center;">
    <div class="modal-content">
      <div class="modal-header">
     <a href="javascript:void(0)" class="btn primary crop_image" onclick="cropImage()">Crop</a>
     <a href="javascript:void(0)" class="btn btn-primary blur_image" onclick="blurImage()">Blur</a>
    <a href="javascript:void(0)" class="btn btn-primary" onclick="saveImage()">Save</a>
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      </div>
      <div class="modal-body">
        <img src="" id="imagepreview">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">var imagePostURL = "{!! route('ajaximageupload') !!}";</script>
<script src="{{ asset('frontend/js/ad_agency_post_script.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/jquery.imgareaselect.pack.js') }}"></script>
@endsection