 <div class="content_block step_4" style="display:none;">
     <form id="form_step_4" onsubmit="return false;">
     {{ csrf_field() }}
         <h2 class="text-danger">Photos & Videos</h2>
         <h4>Requirements</h4>
         <div class="listings">
             <p><i class="fa fa-check" aria-hidden="true"></i>Upload high quality video and photos</p>
             <p><i class="fa fa-check" aria-hidden="true"></i>Hosg accept Genuine photos and videos only</p>
             <p><i class="fa fa-check" aria-hidden="true"></i>UploadWe will contact you for your profile
                 verification. Ant fake profile will be removed, no excelations and refund.</p>
             <p><i class="fa fa-check" aria-hidden="true"></i>Keep it real, Keep it Fun</p>
         </div>
         <div class="profile_photos">

             <h4>Profile Photos</h4>
             <div class="preview-images-zone">
                 <fieldset class="form-group">
                     <div class="field_set">
                         <a href="javascript:void(0)" onclick="$('#pro-image').click()"><span
                                 class="pkus_icon">+</span><br />Add Photos</a>
                         <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"
                             multiple>
                     </div>
                     <div class="max-photos">Max 10</div>
                 </fieldset>


             </div>
         </div>
         <div class="actions clearfix">
		  <div class="clearfix"></div>
				
		 <div class="profile_photos">
             <h4>Videos</h4>
             <div class="preview-images-zone">
                 <fieldset class="form-group">
                     <div class="field_set">
                         <a href="javascript:void(0)" onclick="$('#pro-video').click()"><span
                                 class="pkus_icon">+</span><br />Videos</a>
                         <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"
                             multiple>
                     </div>
					</fieldset>


             </div>
         </div>
				<div class="clearfix"></div>
				
             <ul role="menu" aria-label="Pagination">
                 <li class="" aria-disabled="false">
                     <input type="button" class="previous PreviousBTN" name="prev_step_4" id="prev_step_4" value="Previous">
                 </li>
                 <li aria-hidden="false" aria-disabled="false">
                     <input type="button" class="NextBTN" name="next_step_4" id="next_step_4" value="Save & Next">
                 </li>
             </ul>
         </div>
     </form>
 </div>