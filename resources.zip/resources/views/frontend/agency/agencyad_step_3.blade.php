
                <div class="content_block services-step-section step_3" style="display:none;">
                <form method="post" action="{{ route('photographerad.savephotographerservices') }}" id="form_step_3" onsubmit="return false;">
                {{ csrf_field() }}    
                <h2>Services</h2>
                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Available for</h4>
                        @foreach($serviceavailablefor as $saf)

                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="service_avail_for[]" id="service-avail-for{{$saf['id']}}"
                                class="css-checkbox" />
                            <label for="service-avail-for{{$saf['id']}}" class="css-label">{{$saf['value']}}</label>
                        </div>
                        @endforeach

                        <div class="clearfix"></div>
                        <div id="service_avail_for-error2"></div>

                    </div>
                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Service type</h4>
                        @foreach($servicetype as $st)

                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="service_type[]" id="service-type{{$st['id']}}"
                                class="css-checkbox" />
                            <label for="service-type{{$st['id']}}" class="css-label">{{$st['value']}}</label>
                        </div>

                        @endforeach
                        <div class="clearfix"></div>
                        <div id="service_type-error2"></div>



                    </div>

                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Service available</h4>

                        @foreach($servicesavailable as $sa)

                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="service_available[]" id="service-available{{$sa['id']}}"
                                class="css-checkbox" />
                            <label for="service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                        </div>

                        @endforeach
                        <div class="clearfix"></div>
                        <div id="service_available-error2"></div>
                        <div class="clearfix"></div>
                        <div class="form-group mt-4">
                            <textarea class="form-control custom-textarea bg-theme-dark-form" id="describe_service"
                                name="describe_service" rows="3" placeholder="Describe Yourself"></textarea>
                        </div>


                    </div>
                    <div class="contact-box personal-radiobutton-box pink-label">
                        <h4>Extra Services</h4>
                        @foreach($extraservices as $es)
                        <div class="radio radio-info form-check-inlinesquarebox">
                            <input type="checkbox" name="extraservices[]" id="extra-service{{$es['id']}}"
                                class="css-checkbox" />
                            <label for="extra-service{{$es['id']}}" class="css-label">{{ $es['value'] }}</label>
                        </div>
                        @endforeach
                        <div class="clearfix"></div>
                        <div id="extraservices-error2"></div>
                    </div>
                    <div class="contact-box personal-radiobutton-box pink-label working_hours_box">
                        <h4>Working Hours</h4>
                        <div class="working_hours">
                            <div class="col-half">
                                @for($i=1; $i <= 7; $i++) <div class="dropcol_box">
                                    <div class="label-col"><label>{{ getDay($i) }}</label></div>
                                    <div class="dropbox-col">
                                        <div class="dropdown-col">
                                            <select id="{{ getDay($i) }}_from" class="select_box"
                                                name="{{ getDay($i) }}_from">
                                                <option>From</option>
                                                @php echo get_times() @endphp
                                            </select>
                                        </div>
                                        <div class="dropdown-col">
                                            <select id="{{ getDay($i) }}_to" class="select_box"
                                                name="{{ getDay($i) }}_to">
                                                <option>To</option>
                                                @php echo get_times() @endphp
                                            </select>
                                        </div>
                                    </div>
                            </div>
                            @if($i % 4 == 0)
                        </div>
                        <div class="col-half">
                            @endif
                            @if($i === 7)
                        </div>
                        @endif
                        @endfor
                    </div>

                </div>


                <div class="services_select_box contact-box personal-radiobutton-box pink-label working_hours_box">
                    <h4>Rates</h4>
                    <div class="add-userroles services_rates" id="test">
                        <div class="rates_section">
                            <div class="drop_box services_select_box">
                                <select id="services_rates_0" class="service_select_box">
                                    @php
                                    $rates_time = get_rate_time();
                                    @endphp
                                    @foreach($rates_time as $key=>$t)
                                    <option value="{{$key}}">{{ $t }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="charges_box"><input type="text" class="form-control" placeholder="Charges">
                            </div>
                            <div class="service_box"><input type="text" class="form-control" placeholder="Services">
                            </div>
                            <div class="button_box"> <a href="javascript:void(0)" class="btn btn-danger add-rate"
                                    onclick="addRate()"><i class="fa fa-plus"></i> Add rate</a>

                                <a href="javascript:void(0)" class="btn remove-rate" onclick="removeRate()"><i
                                        class="fa fa-minus"></i></a></div>
                        </div>
                    </div>
                    <div id="tool-placeholder"></div>
                </div>
                <div class="actions clearfix">
                    <ul role="menu" aria-label="Pagination">
                        <li class="" aria-disabled="false">
                        <input type="button" name="prev_step_3" class="previous PreviousBTN" value="Previous" id="prev_step_3">
                        </li>
                        <li aria-hidden="false" aria-disabled="false">
                        <input type="submit" name="next_step_3" class="NextBTN" value="Save & Next" id="next_step_3">
                        </li>
                    
                    </ul>
                </div>
                </form>
            </div>
  
