<div class="content_block step_2" style="display:none;">
        <section class="pay-boxz">
            <div class="container">
                <h2 class="text-danger mb-5 mt-3">Choose your Subsription</h2>
                <div class="row">
                    @php
                    $count = 1;
                    @endphp
                    @foreach($plans as $p)
                    <div class="col-12 col-sm-8 col-md-6 col-lg-4 price-cards ">
                        <div
                            class="card @if($count == 1) red-border @elseif($count == 2) purple-border @elseif($count==3) magenta-border @endif">
                            <div class="card-header text-center border-bottom-0 bg-transparent pt-4">
                                <h5>{{ strtoupper($p->plan_name) }}</h5>
                            </div>
                            <div class="card-body">
                                <h1>{{ price_format($p->plan_price_base) }}</h1>
                                <h5 class="text-center"><small>Ad duration :
                                        <span>{{ $p->plan_duration." ".$p->plan_duration_unit}}</span></small>
                                </h5>
                            </div>
                            <ul class="list-group list-group-flush" id="hide-more-features{{$p->id}}">
                                @php
                                $plans_features = explode("\n", $p->plan_features);
                                $fcount = 1;

                                @endphp
                                @foreach($plans_features as $pf)
                                @php
                                $planClass = ($fcount > 3) ? "hide-more-features" : '';
                                $style = ($fcount > 3) ? "style=display:none;" :'';
                                @endphp
                                <li class="list-group-item {{ $planClass }}" {{ $style }}><i
                                        class="fa fa-check mx-2"></i><span>{{ $pf }}</span></li>
                                @php $fcount++; @endphp
                                @endforeach
                            </ul>
                            @if(count($plans_features) > 3)
                            <p class="text-left small read-more-features" onclick="readMoreFeatures({{$p->id}})"> Read
                                More </p>
                            @endif
                            <div class="card-footer border-top-0 upgrade-btn text-center">
                                <a href="#" class="text-uppercase">upgrade</a>
                            </div>
                        </div>
                    </div>
                    @php
                    $count++;
                    @endphp
                    @endforeach
                </div>
            </div>

        </section>
    </div>
    <div class="actions clearfix step_2" style="display:none;">
        <ul role="menu" aria-label="Pagination">
            <li>
               <input type="button" value="Previous" class="previous PreviousBTN" name="prev_step_2" id="prev_step_2">
            </li>
            <li>
            <input type="button" value="Next" class="next NextBTN" name="next_step_2" id="next_step_2">
            </li>
            <li>
            </li>
        </ul>
    </div>
