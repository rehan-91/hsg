<div class="content_block step_1 content">
<form action="{{route('photographerad.savephotographerdetails')}}" method="post" onsubmit="return false;" id="form_step_1">
    <h2 class="text-danger">details</h2>
        <div class="setup-content" id="step-1">
            <div class="profile-details-form">
                <div class="contact-box">
                    <h4>Contact</h4>
                    <div class="row">
                    {{ csrf_field() }}
                        <div class="form-group col-md-4">
                            <input type="text" class="form-control" placeholder="Name" name="name" required>
                            <!-- <sup><img src="images/red-inputstar.png" alt="red-inputstar"></sup>-->
                        </div>
                        <div class="form-group col-md-4">
                            <input type="email" class="form-control" placeholder="Email" name="email" required>
                        </div>
                        <div class="form-group col-md-4">
                            <input type="text" class="form-control" placeholder="Phone Number" name="phone" required>
                        </div>
						<div class="form-group col-md-4">
                            <select class="form-control" placeholder="Fees & Charges" name="fees&charges" required>
							<option value=''>Select Location</option>
							@foreach($cities as $c)
                                    <option value="{{ $c->id }}" @if( $c->id == old('location')) selected  @endif >{{ $c->name }}</option>
                                    @endforeach

							</select>
                        </div>
                    </div>
                </div>
				
				<div class="clearfix"></div>
               
			   <div class="profile_photos">

             <h4>Upload Logo</h4>
             <div class="preview-images-zone">
                 <fieldset class="form-group">
                     <div class="field_set">
                         <a href="javascript:void(0)" onclick="$('#pro-image').click()"><span
                                 class="pkus_icon">+</span><br />Add Photos</a>
                         <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"
                             multiple>
                     </div>
                 </fieldset>


             </div>
         </div>
				<div class="clearfix"></div>
				<!--
				<div class="contact-box personal-radiobutton-box">
                    <h4>Status</h4>

                    <div class="selectdetail-widthblock">
                        <select class="select_box" name="age" required>
                            <option value=''>Select Status</option>
							       <option value="">ON</option>
								   <option value="">OFF</option>
								   
                            
                        </select>
                    </div>
				</div>
				
				
				
				<div class="clearfix"></div>
				-->
				<div class="form-group">
                    <textarea class="form-control custom-textarea" name="description" id="description" rows="3"
                        placeholder="Describe Yourself"></textarea>
                </div>

               
               
            </div>

        </div>
            <div class="actions clearfix step_1">
            <ul role="menu" aria-label="Pagination">
                <li></li>
                <li aria-hidden="false" aria-disabled="false">
                    <a href="#">
                        <input type="submit" name="next_step_1" value="Save & Next" id="next_step_1" class="NextBTN">
                    </a>
                    </li>
                <li></li>
                
            </ul>
        </div>
        </form>
</div>

