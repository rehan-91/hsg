@extends('frontend.layouts.default_layout')
@section('content')
<div class="card-deck"> 

	@foreach($blogdata as $blog)
  <div class="card">
  	@if(!empty($blog->blog_featured_img))
    @php
    $imageurl = url('uploads/ads_image/'.$blog->blog_featured_img);
    @endphp
    <img class="card-img-top" src="{{$imageurl}}" alt="Card image cap" width="180" height="180" class="image-resposive">
    @endif
    <div class="card-body">
      <h5 class="card-title">{{$blog->blog_title}}</h5>
      <p class="card-text">{{ str_limit($blog->blog_desc, 100) }}</p>
      <a href="{{route('read-front-blog',$blog->blog_slug)}}" class="btn btn-primary">Read More....</a>
   
    </div>
    <div class="card-footer">
       Posted By:&nbsp;<small class="text-muted">{{$blog->users->name}}</small> 
       
    </div>
  </div> 
  
  @endforeach
</div>
@endsection 
