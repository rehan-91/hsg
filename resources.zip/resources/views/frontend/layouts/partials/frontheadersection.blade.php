@if (!Auth::check())
<header class="header-inner">
     <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
	 <div class="container">
	 
  <a class="navbar-brand inner-navbar" href="{{url('/')}}"><img src="{{ get_images($generalsettings['website_logo']) }}"></a>
 
  <div class="collapse navbar-collapse" id="navbarCollapse">
   
    <div class="form-inline mt-2 mt-md-0 ml-auto">
      <div class="dropdown dropdown-user">
<a class="login-btn" href="{{route('login')}}">Login</a></div>
     
          <a class="post-add-btn" href='{{route("login")}}'>Post Ad</a>
     
         <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="{{url('/')}}">Home</a>
  @php
  $listingtype = listingtype();
  @endphp
  @foreach($listingtype as $list)
  <a href='{{route("posts.",$list["slug"])}}'>{{$list['title']}}</a>
  @endforeach
</div>

<!-- Use any element to open the sidenav -->
<span style="font-size:30px;color:#fff;cursor:pointer;position:absolute;right:0;" onclick="openNav()">&#9776;</span>

<!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page -->
<div id="main">
  ...
</div> 
    </div>
  </div>
</nav>


    </header>
    @else
   
    <header class="header-inner">
     <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
     <div class="container">
  <a class="navbar-brand inner-navbar" href="{{url('/')}}"><img src="{{ get_images($generalsettings['website_logo']) }}"></a>
 
  <div class="collapse navbar-collapse" id="navbarCollapse">

    <div class="form-inline mt-2 mt-md-0 ml-auto">
      <div class="dropdown dropdown-user">
	  
  <button class="btn btn-link dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
     @if(empty(Auth::user()->user_image))                   
		 <div class="user-profile-cover"> 
       <img src="{{asset('frontend/images/user-profile-icon.png')}}" class="figure-img img-fluid rounded" alt="dummyaccountseeting-">
	   </div>
       @else
       @php
        $imageurl = url('uploads/users/'.Auth::user()->user_image);
       @endphp
	   <div class="user-profile-cover"> 
        <img src="{{ $imageurl }}"  alt="dummyaccountseeting-" class="image-rounded">
		</div>
        @endif {{Auth::User()->name}} <i class="fa fa-angle-down"></i>
  </button>
  
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="{{route('dashboard')}}">Dashboard</a>
   <a class="dropdown-item" href="{{$editLink}}">Edit Account</a>
    @if(Auth::user()->usertype == 'agency')
    <a class="dropdown-item" href="#">My Ads</a>
    @endif
    <a class="dropdown-item" href="{{route('changePassword')}}">Change Password</a>
    <a class="dropdown-item" href="{{route('logout')}}">Signout</a>
  </div>
</div>
     
          <a class="post-add-btn" href='{{route("post-ad.","/")}}'>Post Ad</a>
     
         <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
  <a href="{{url('/')}}">Home</a>
  @php
  $listingtype = listingtype();
  @endphp
  @foreach($listingtype as $list)
  <a href='{{route("posts.",$list["slug"])}}'>{{$list['title']}}</a>
  @endforeach
</div>

<!-- Use any element to open the sidenav -->
<span style="font-size:30px;color:#fff;cursor:pointer;position:absolute;right:0;" onclick="openNav()">☰</span>

<!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page -->
<div id="main">
  ...
</div> 
    </div>
  </div>
  </div>
</nav>


    </header>
    @endif