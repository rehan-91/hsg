<nav class="navbar navbar-default test">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      
	  <button type="button" class="navbar-toggle toggle-menu menu-right push-body pull-right" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	  
	  <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar top-bar"></span>
          <span class="icon-bar middle-bar"></span>
          <span class="icon-bar bottom-bar"></span>
		  
      </button>
      <a class="navbar-brand" href="#"><img src="/images/logo.png" class="pull-left" alt="logo"> <small>Training, Testing,<br> Certification & Registry</small></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
  
	<div class="collapse navbar-collapse cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Dashboard    <span class="sr-only">(current)</span></a></li>
        <li><a href="training.html">Training </a></li>
		<li><a href="{{'test' }}">Tests</a></li>
		<li><a href="#"> Certificates </a></li>
			<li><a href="help.html"> Help </a></li>
        </ul>
     
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
