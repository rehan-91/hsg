	<nav class="navbar navbar-default test">
	  <div class="container">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle toggle-menu menu-right push-body pull-right" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar top-bar"></span>
			<span class="icon-bar middle-bar"></span>
			<span class="icon-bar bottom-bar"></span>
		  </button>
		  <a class="navbar-brand" href="{{ route('index') }}">
			<img src="{{ asset('images/logo.png') }}" class="pull-left" alt="logo">
			<small>{!! trans('translations.frontend.logo_side_heading') !!}</small>
		  </a>
		</div>
		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right" id="bs-example-navbar-collapse-1">
		</div>
	  </div>
	</nav>