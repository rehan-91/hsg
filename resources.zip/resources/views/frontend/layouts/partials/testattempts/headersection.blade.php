  <header class="inner-header">
	<div class="container">
	  <ul>
		<li>
		  <a class="navbar-brand" href="Javascript:void(0)">
			<!--<img src="{{ asset('images/logo.png') }}" class="pull-left" alt="logo">-->
			<img src="{{ asset('images/logo-icon.png') }}" class="pull-left" alt="logo">
		  </a>
	    </li>
		<li class="pull-right inves-apear">
		  <span>
			{!! trans('translations.frontend.invigilator_as') !!} {{ $invigilator_data->name }}
			<a href="javascript:void(0)" class="round-auth"><img src="{{ $invigilator_data->get_image_data( $invigilator_data->image_id, 'size50' ) }}"></a>
		  </span>
		  <span>
		   {!! trans('translations.frontend.appearing_as') !!} {{ Auth::User()->name }} 
		   <a href="javascript:void(0)" class="round-auth"><img src="{{ Auth::user()->get_image_data(Auth::user()->image_id, 'size50'  ) }}"></a>
		  </span>
		</li>
		<li class="pull-left detail">
		  <span class="info">
			<strong class="testnameHead">{{ $test_info->name }}</strong><br>
			<small>{!! trans('translations.frontend.current_test') !!}</small>
		  </span>
		  <span class="border min-border">
			<img src="{{ asset('images/clock-black.png') }}" alt="clock"> 
			<div class="hours hidden" > <span class=""> 0 </span> <span class=""> 5 </span> : </div>
			<div class="minute"> <span class=""> 0 </span> <span class=""> 5 </span> : </div>
			<div class="seconds"> <span class=""> 0 </span> <span class="" > 0 </span> </div>
			<small> {!! trans('translations.frontend.min_rem') !!} </small>
		  </span>
		  <span class="border sec-border">
			<strong><span id="currentQuestion"> {{ $testattempt_data->total_q_attempts }}</span></strong>/<strong>{{ $testattempt_data->total_questions }} </strong>
			<small> {!! trans('translations.frontend.question_attempted') !!} </small>
		  </span>
		</li>
	  </ul>
	</div>
	<script>
		var current_test_time = "";
		var duration_timer = "{{ $testattempt_data->timer_duration }}";
	
		function start_timer(){
			var timer = new Timer();
			
		    var totalSeconds = parseInt( duration_timer );
			
			timer.start({countdown: true, startValues: {seconds: totalSeconds}});
			var current_time = timer.getTimeValues().toString().split(":");
			
			current_test_time = timer.getTimeValues().toString();
			
			var hours = current_time[0][0] + current_time[0][1];
			if( parseInt(hours) > 0 ){
				jQuery(".hours").removeClass("hidden");
				jQuery(".hours span:nth-child(1)").html(current_time[0][0]);
				jQuery(".hours span:nth-child(2)").html(current_time[0][1]);
				jQuery(".hours").parent().addClass("hours-minwidth");
			}
			else{
				jQuery(".hours").addClass("hidden");
				jQuery(".hours").parent().removeClass("hours-minwidth");
			}
			
			jQuery(".minute span:nth-child(1)").html(current_time[1][0]);
			jQuery(".minute span:nth-child(2)").html(current_time[1][1]);
			jQuery(".seconds span:nth-child(1)").html(current_time[2][0]);
			jQuery(".seconds span:nth-child(2)").html(current_time[2][1]);
			
			timer.addEventListener('secondsUpdated', function (e) {
				
				var current_time = timer.getTimeValues().toString().split(":");
				current_test_time = timer.getTimeValues().toString();
				
				var hours = current_time[0][0] + current_time[0][1];
				
				if( parseInt(hours) > 0 ){
					jQuery(".hours").removeClass("hidden");
					jQuery(".hours span:nth-child(1)").html(current_time[0][0]);
					jQuery(".hours span:nth-child(2)").html(current_time[0][1]);
					jQuery(".hours").parent().addClass("hours-minwidth");
				}
				else{
					jQuery(".hours").addClass("hidden");
					jQuery(".hours").parent().removeClass("hours-minwidth");
				}
				jQuery(".minute span:nth-child(1)").html(current_time[1][0]);
				jQuery(".minute span:nth-child(2)").html(current_time[1][1]);
				jQuery(".seconds span:nth-child(1)").html(current_time[2][0]);
				jQuery(".seconds span:nth-child(2)").html(current_time[2][1]);
			});

			timer.addEventListener('targetAchieved', function (e) {
				jQuery(".review_container").css("display", "none");
				jQuery("#test_submit_popup").modal("show");
			});
		}
		
		jQuery(function() {
			start_timer();
		});
	</script>
  </header>