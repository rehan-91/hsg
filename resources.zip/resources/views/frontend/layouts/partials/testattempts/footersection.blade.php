<div class="clearfix"></div>

<!--************ footer ***********-->
<footer class="">
  <div class="container">
	<div class="">
		<span class="footer_logos"><img src="{{ asset( 'images/world-bank-group-logo.png' ) }}"></span>
		<span class="footer_logos"><img src="{{ asset( 'images/bcfi-footer-logo.png' ) }}"></span> 
		<span class="footer_logos"><img src="{{ asset( 'images/microsave-footer-logo.png' ) }}"></span>
		
		<p class="copy-right">{!! trans('translations.frontend.rights_reserved') !!}
			<span>{!! trans('translations.frontend.developed_with_by') !!}
				<a href="https://www.vocso.com/" rel="nofollow" target="_blank">VOCSO</a>
			</span>
		</p>
	</div>
  </div>
  
  <a href="Javascript:void(0);" class="scrollToTop" style="display: none;"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>
</footer>
</body>
</html>