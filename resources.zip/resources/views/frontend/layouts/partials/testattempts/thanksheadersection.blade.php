  <header>
	@include('frontend.layouts.partials.testattempts.thanksfrontnav')
	<div class="container right-menutop">
	  <ul class="nav navbar-nav navbar-right">
		<li class="dropdown profile-btn">
			<a href="javscript:void(0)" class="profile-pic dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
				<img src="{{ Auth::user()->get_image_data(Auth::user()->image_id, 'size50'  ) }}">
			</a>
		  <ul class="dropdown-menu logout">
			<li class="blue-bg">
				<span class="media-left">
				  <img src="{{ Auth::user()->get_image_data(Auth::user()->image_id, 'size50'  ) }}">
				</span>
				<span class="media-body">
					{{ Auth::user()->name }} <a href="{{ route('changePassword') }}">{!! trans('translations.frontend.menu.change_password') !!}</a>
				</span>
			</li>
            <li><a href="{{ route('editprofile') }}"><i class="fa fa-square" aria-hidden="true"></i> {!! trans('translations.frontend.menu.edit_profile') !!}</a></li>
             <li><a href="{{ route('logout') }}"> <i class="fa fa-square" aria-hidden="true"></i> {!! trans('translations.frontend.menu.logout') !!}</a></li>
          </ul>
		</li>
      </ul>
	</div>
  </header>