<div class="home-banner-form">
      <form id="fsearch" action="{{route('fsearchData')}}" method="post">
      {{ csrf_field() }}
        <div class="form-group">
        <input type="text" class="form-control" placeholder="name" name="name">
        </div>
        
        <div class="form-group">
      
         <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Gender<span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
              <li><label class="checkbox" title="Female"><input type="checkbox" name="gender[]" value="female">Female</label></li>
              <li><label class="checkbox" title="Male"><input type="checkbox" name="gender[]" value="male">Male</label></li>
              <li><label class="checkbox" title="Trans"><input type="checkbox" name="gender[]" value="trans">Trans</label></li>
              <li><label class="checkbox" title="Others"><input type="checkbox" name="gender[]" value="others">Others</label></li>
    </ul>
</li>
          
          
          
        </div>
        <div class="form-group ageSelectBox">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Age <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
        @foreach($master_age as $value )
              <li>hello<label class="checkbox" title="{{$value->meta_value}}"><input type="checkbox" name="age[]" value="{{$value->id}}"> {{$value->meta_value}}</label></li>
        @endforeach
    </ul>
</li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Location<span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
    @foreach($cities_list as $value )
    <li><label class="checkbox" title="{{$value->name}}"><input type="checkbox" name="location[]" value="{{$value->id}}">{{$value->name}}</label></li>
    @endforeach
  </ul>
</li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Attributes <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
    @foreach($master_body_type as $value )
              <li><label class="checkbox" title="{{$value->meta_value}}"><input type="checkbox" name="bodytype[]" value="{{$value->id}}">{{$value->meta_value}}</label></li>
    @endforeach
    </ul>
    </li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Ethnicity <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
    @foreach($master_nationality as $value )
              <li><label class="checkbox" title="{{$value->meta_value}}"><input type="checkbox" name="ethnicity[]" value="{{$value->id}}">{{$value->meta_value}}</label></li>
              @endforeach	
    </ul>
</li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Services <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
    @foreach($master_service_type as $value )
              <li><label class="checkbox" title="{{$value->meta_value}}"><input type="checkbox" value="{{$value->id}}" name="services[]">{{$value->meta_value}}</label></li>
    @endforeach
    </ul>
</li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Price <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
              <li><label class="checkbox" title="$10"><input type="checkbox" name="price[]" value="10">$10</label></li>
              <li><label class="checkbox" title="$100"><input type="checkbox" name="price[]" value="100">$100</label></li>
    </ul>
</li>
         
        </div>
        <button type="submit" class="btn find-me-btn"></button>
      </form>
    </div> 