<nav class="navbar navbar-expand-lg main-navs">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
     <ul class="navbar-nav mr-auto mt-2 mt-lg-0 mx-auto main-nav">
		
          <li class="nav-item escorts"> <a class="nav-link " href="{{url('posts/indepedendent-escort')}}" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="{{ asset('frontend/images/excorts-icon.png') }}"> <span>Escorts <i class="fas fa-angle-down"></i></span></a>
            <div class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdown"> <a class="dropdown-item" href="{{url('posts/indepedendent-escort?gender=female')}}">Female Escorts</a> <a class="dropdown-item" href="{{url('posts/indepedendent-escort?gender=trans')}}">Trans Escorts</a> <a class="dropdown-item" href="{{url('posts/indepedendent-escort?gender=male')}}">Male Escorts</a> </div>
          </li>
		  
		  
		  
          <li class="nav-item  home"> <a class="nav-link " href="javascript:void(0)" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		  <img src="{{ asset('frontend/images/photographer-icon.png') }}">
		  <span>Massage<i class="fas fa-angle-down"></i></span></a>
            <div class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdown"> <a class="dropdown-item" href="#">Female Massage</a> <a class="dropdown-item" href="#">Trans Massage</a> <a class="dropdown-item" href="#">Male Massage</a> </div>
          </li>
		  
		  
		  
        <li class="nav-item agencies yellow-grad">
           <a class="nav-link" href="{{url('posts/escort-agency')}}">
            <img src="{{ asset('frontend/images/agencies-icon.png') }}">
             <span>Agencies</span>
          </a> 
          </li>
          <li class="nav-item escort-tips white-grad">
           <a class="nav-link" href="{{url('posts/clubs')}}">
            <img src="{{ asset('frontend/images/agencies-icon.png') }}">
             <span>Clubs</span>
          </a> 
        </li>
          <li class="nav-item adult-jobs dropdown"> 
            <a class="nav-link" href="{{url('posts/adult-jobs')}}"><img src="{{ asset('frontend/images/adult-jobs.png') }}"> 
              <span>Adult Jobs</span>
            </a> 
          </li>
          <li class="nav-item photographer home"> 
            <a class="nav-link" href="{{url('posts/photographer')}}">
              <img src="{{ asset('frontend/images/photographer-icon.png') }}"> 
              <span>Photographer</span>
            </a>
             </li>
          {{{--<li class="nav-item adult-shop adult-jobs">
           <a class="nav-link" href="{{url('posts/adult-shop')}}">
            <img src="{{ asset('frontend/images/adult-shop.png') }}"> 
            <span>Adult Shop</span>
          </a> 
          </li>
          <li class="nav-item dun-rooms purple-grad"> 
            <a class="nav-link" href="{{url('posts/fun-room')}}">
              <img src="{{ asset('frontend/images/fun-rooms-icon.png') }}"> 
              <span>Fun Rooms</span>
            </a>
             </li>--}}
          <li class="nav-item agencies yellow-grad">
           <a class="nav-link" href="#">
            <img src="{{ asset('frontend/images/agencies-icon.png') }} ">
             <span>Touring Girls</span>
           </a>
            </li>
          <li class="nav-item escorts"> 
            <a class="nav-link" href="#"> 
              <img src="{{ asset('frontend/images/excorts-icon.png') }}">
               <span>Specials</span>
             </a> 
           </li>
          <li class="nav-item agencies yellow-grad">
           <a class="nav-link" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="{{ asset('frontend/images/agencies-icon.png') }}"> 
            <span>Info Center <i class="fa fa-angle-down"></i></span>
          </a>
            <div class="dropdown-menu dropdown-menu-dark other-nav" aria-labelledby="navbarDropdown1"> 
              <a class="dropdown-item" href="#">Subscription & Prices</a>
               <a class="dropdown-item" href="#">FAQ</a> 
               <a class="dropdown-item" href="{{route('front-blog-list')}}">Blogs</a> 
               <a class="dropdown-item" href="#">Escorts Tips</a> 
               <a class="dropdown-item" href="#">Others</a>
             </div>
          </li>
        </ul>		    
  </div>
</nav>