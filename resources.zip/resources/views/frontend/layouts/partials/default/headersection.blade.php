<header>
<div class="container-fluid">

  @if(session()->has('message'))
    <div class="text-center alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
    <nav class="navigation">
      <a href="{{ url('/') }}" class="navbar-logo"><img class="img-fluid" src="{{ get_images($generalsettings['website_logo'])}}"></a>
      <div class="navbar-right">
      
      
  
        @if(Auth::Check())
      <div class="dropdown dropdown-user">
  <button class="btn btn-link dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

  @if(empty(Auth::user()->user_image))   
 <div class="user-profile-cover">	  
 <img src="{{asset('frontend/images/user-profile-icon.png')}}" class="figure-img img-fluid rounded" alt="dummyaccountseeting-">
 </div>
 @else
 @php
  $imageurl = url('uploads/users/'.Auth::user()->user_image);
 @endphp
 <div class="user-profile-cover">	  
  <img src="{{ $imageurl }}" class="figure-img img-fluid rounded" alt="dummyaccountseeting-">
  </div>
  @endif
  
    {{Auth::User()->name}} <i class="fa fa-angle-down"></i>
  </button>
  <div class="dropdown-menu home-topuserlogin-dropdown" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="{{route('dashboard')}}">Dashboard</a>
    @if(Auth::user()->usertype == 'agency')
    <a class="dropdown-item" href="#">My Ads</a>
    @endif
    <a class="dropdown-item" href="{{route('changePassword')}}">Change Password</a>
    <a class="dropdown-item" href="{{route('logout')}}">Signout</a>
  </div>
</div>
<a class="post-add-btn" href='{{route("post-ad.","/")}}'>Post Ad</a>
        @else
        <a class="login-btn" href="{{ route('login') }}">Login</a>
        <a class="post-add-btn" href="{{ route('login') }}">Post Ad</a>
        @endif
        
        
       
      </div>
    </nav>
<div class="typewriter" id="toggle">
    <h1 class="text-center heading">Welcome to the House of Sexy Girls!</h1>
</div>

<div class="video-container">
      <video autoplay loop muted id="video-bg">

	  @if(!empty($generalsettings['home_page_video']))		
		<source src="{{getS3VideoURL($generalsettings['home_page_video'])}}">
		@endif
		

      </video>
    </div>
</div>
</header>

  <header>

  <div class="header">
 
 
<div class="clearfix"></div>

@include('frontend.layouts.partials.default.frontnav')

<div class="clearfix"></div>

@include('frontend.layouts.partials.default.frontsearch')
<div class="clearfix"></div>



<div class="banner-bottom-secondary-links">
   <ul>
     <li><a href="#">Trans</a></li>
     <li><a href="#">BDSM</a></li>
     <li><a href="#">Tantra</a></li>
     <li><a href="#">Massage</a></li>
     <li><a href="#">Fetish</a></li>
     <li><a href="#">Dancers</a></li>
   </ul>

</div>

    
</div>