<div class="home-banner-form">
      <form id="fsearch" action="{{route('fsearchData')}}" method="get">
     
        <div class="form-group">
        <input type="text" class="form-control" placeholder="name" name="name" value="{{$inputdata['name']}}">
        </div>
       
        <div class="form-group"> 
     
         <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Gender<span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
	
	      <li>
			 <div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" name="gender[]" id="checkboxG170" {{in_array('female',$inputdata['gender'])? 'checked':'' }} value="female" class="css-checkbox">
				<label for="checkboxG170" title="female" class="css-label">Female</label>
			  </div>
		 </li>
		 
		  <li>
			 <div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" name="gender[]" {{in_array('male',$inputdata['gender'])? 'checked':'' }} id="checkboxG171" value="male" class="css-checkbox">
				<label for="checkboxG171" title="male" class="css-label">Male</label>
			  </div>
		 </li>
		 
		  <li>
			 <div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" {{in_array('trans',$inputdata['gender'])? 'checked':'' }} name="gender[]" id="checkboxG172" value="trans" class="css-checkbox">
				<label for="checkboxG172" title="Trans" class="css-label">Trans</label>
			  </div>
		 </li>
		
                          
    </ul>
</li>
          
          
          
        </div>
        <div class="form-group ageSelectBox">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Age <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
	
		@foreach($master_age as $value )
		<li>
		<div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" name="age[]"  value="{{$value->id}}" 
				{{ in_array($value->id,$inputdata['age'])? 'checked':'' }}  id="checkbox{{$value->id}}"  class="css-checkbox">
				<label for="checkbox{{$value->id}}" title="{{$value->meta_value}}" class="css-label">{{$value->meta_value}}</label>
			  </div>
		</li>
		 @endforeach
		
    </ul>
</li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Location<span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
	
   <!-- @foreach($cities_list as $value )
    <li>
	<label class="checkbox" title="{{$value->name}}">
	<input type="checkbox" name="location[]" value="{{$value->id}}">{{$value->name}}</label></li>
    @endforeach-->
	
	@foreach($cities_list as $value )
		<li>
		<div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" name="location[]"  id="checkbox{{$value->id}}" 
				value="{{$value->id}}" class="css-checkbox" {{ in_array($value->id,$inputdata['location'])? 'checked':'' }} >
				<label for="checkbox{{$value->id}}"" title="{{$value->name}}" class="css-label">{{$value->name}}</label>
			  </div>
		</li>
		 @endforeach
	
	
  </ul>
</li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Attributes <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">

	 @foreach($master_body_type as $value )
		<li>
		<div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" name="bodytype[]" {{ in_array($value->id,$inputdata['bodytype'])? 'checked':'' }} 
				 value="{{$value->id}}" id="checkbox{{$value->id}}" class="css-checkbox">
				<label for="checkbox{{$value->id}}" title="{{$value->meta_value}}" class="css-label">{{$value->meta_value}}</label>
			  </div>
		</li>
		 @endforeach
	
    </ul>
    </li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Ethnicity <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
 @foreach($master_nationality as $value )
		<li>
		<div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" name="ethnicity[]" id="checkbox{{$value->id}}" 
				value="{{$value->id}}" class="css-checkbox" {{ in_array($value->id,$inputdata['ethnicity'])? 'checked':'' }} >
				<label for="checkbox{{$value->id}}" title="{{$value->meta_value}}" class="css-label">{{$value->meta_value}}</label>
			  </div>
		</li>
		 @endforeach
			  
    </ul>
</li>
         
        </div>
        <div class="form-group">
          <li class="dropdown">
   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Services <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">

	@foreach($master_service_type as $value )
		<li>
		<div class="radio radio-info form-check-inlinesquarebox">
				<input type="checkbox" name="services[]" id="checkbox{{$value->id}}"
				{{ in_array($value->id,$inputdata['services'])? 'checked':'' }} 
				 value="{{$value->id}}" class="css-checkbox">
				<label for="checkbox{{$value->id}}" title="{{$value->meta_value}}" class="css-label">{{$value->meta_value}}</label>
			  </div>
		</li>
		 @endforeach
	
	
	
    </ul>
</li>
         
        </div>
        <div class="form-group">
        	@php
			  $pricerange = array(
			  "0-1000" => 'Under $1,000',
			   "1000-5000" => '$1000 - $5,000',
			   "5000-10000" => '$5000 - $10,000',
			    "10000-over" => 'Over $10,000',
			  );

			  @endphp
			
			  
        	<select name="price">
        			@foreach($pricerange as $key=>$p)
        			<option value="{{$key}}">{{$p}}</option>
        			@endforeach
        	</select>
 
        </div>
        <button type="submit" class="btn find-me-btn"></button>
      </form>
    </div>