<div class="clearfix"></div>

<footer class="padding-50">
 <div class="container-fluid">
   <div class="row">
    <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3 footer-logo-box trustedLogo-box">
    <a href="#"><img src="{{ asset('frontend/images/logo.png') }}" alt="logo"></a>
    <p>Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl uekt aliquip ex ea commodo consequat duis</p>
    </div>
    <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 trustedLogo-box">
    <h3>security</h3>
    <a href="#"><img src="{{ asset('frontend/images/footer-dmca-logo.png') }}" alt="dmca logo" class="img-fluid"></a>
    <a href="#"><img src="{{ asset('frontend/images/secure-payment-logo.png') }}" alt="dmca logo" class="img-fluid"></a>
    </div>
    <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 trustedLogo-box">
       <h3>quick links</h3>
       <ul>
        
            <li><a href="#"><img src="{{ asset('frontend/images/escorts-red-icon.png') }}" alt="escorts-red-icon">Escorts</a></li>
            <li><a href="#"><img src="{{ asset('frontend/images/adult-red-icon.png') }}" alt="adult-red-icon">Adult Jobs</a></li>            
            <li><a href="#"><img src="{{ asset('frontend/images/photographer-red-icon.png') }}" alt="photographer-red-icon">Photographer</a></li>            
            <li><a href="#"><img src="{{ asset('frontend/images/agencies-red-icon.png') }}" alt="agencies-red-icon">Agencies</a></li>            
            <li><a href="#"><img src="{{ asset('frontend/images/escortstips-red-icon.png') }}" alt="escortstips-red-icon">Escort Tips</a></li>
       </ul>
    
    </div>
    <div class="col-md-2 col-sm-3 col-xs-12 col-lg-2 trustedLogo-box useful-links-box">
    <h3>useful links</h3>
       <ul>
        
            <li><a href="#">Terms & Conditions</a></li>
            <li><a href="#">Privacy Policy</a></li>            
            <li><a href="#">Report</a></li>            
            <li><a href="#">Feedback</a></li>            
            <li><a href="#">Contact Us</a></li>                    

       </ul>
    
    </div>
    <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3 trustedLogo-box">
     <h3>follow us</h3>
    <ul class="followus">
        
            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>            
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>            
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>                                        
       </ul>
       <div class="clearfix"></div>
       
       
       <div class="footer-newleeterform">
       <h3>join our newsletter</h3>
       <form action="" method="post" role="form">
                    <div class="form-group">                      
                      <input class="form-control" type="text" id="" name="" placeholder="Email Address">
                      <button type="submit" class="btn btn-primary"><img src="{{ asset('frontend/images/location-arrow-white.png') }}" alt="location-arrow-white"></button>
                    </div>
              </form>
    </div>
        
    </div>  
 </div>
 </div>
</footer>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  
  
  
  <script>
  jQuery(document).ready(function() {
  jQuery('.overlay').hide();
  });
 
  </script>
 