<?php use App\Http\Controllers\Frontend\LanguageController; ?>
<header>
	@include('layouts.partials.frontnav')
<div class="container">
 <ul>
 <li><a class="navbar-brand" href="#"><img src="images/logo.png" class="pull-left" alt="logo"> <small>Training, Testing,<br> Certification & Registry</small></a></li>
 <li class="pull-right inves-apear">
 <span>invigilator as<br> Ajay Verma <a href="#" class="round-auth"><img src="images/profile-pic.png"></a></span>
 <span>Appearing As<br> Rakesh Sharma <a href="#" class="round-auth"><img src="images/profile-pic.png"></a></span>
 
 </li>
 <li class="pull-left detail">
 
 <span class="info"><strong>Basic Test</strong><br> <small>Current Test</small></span>
  <span class="border"><img src="images/clock-black.png" alt="clock"> <strong>27:06</strong> <small>Minutes<br> Remaining</small></span>
  <span class="border"><strong>23/30</strong> <small>Questions<br> Attempted</small></span>
 </li>
 </ul>
</div>
</header>
