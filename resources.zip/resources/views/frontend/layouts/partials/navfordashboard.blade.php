 <div class="col-md-3">
                    <div class="nav-side-menu">
                         <div class="profile-image text-center">
                              @if(empty(Auth::user()->user_image))
                    
                             <img src="{{asset('frontend/images/user-profile-icon.png')}}" class="figure-img img-fluid" alt="dummyaccountseeting-">
                             @else
                             @php
                              $imageurl = url('uploads/users/'.Auth::user()->user_image);
                             @endphp
                              <img src="{{ $imageurl }}" class="figure-img img-fluid" alt="dummyaccountseeting-" width="30%">
                              @endif
                         </div>
                         <div class="brand">
                              {{ Auth::user()->name  }}
                         </div>
                         <div class="private-badge text-center"> <span>{{Auth::user()->usertype}}</span> </div>
                         <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

                         <div class="menu-list">

                             <ul id="menu-content" class="menu-content collapse out">
                                   <li class="dashboard ">
                                        <a href="{{route('dashboard')}}">
                                             Dashboard
                                        </a>
                                   </li>
                                   @if(Auth::user()->usertype == 'agency') 
                                   <li class="my-ads">
                                        <a href="{{ route('ads_profile')}}">
                                             My Ads
                                        </a>
                                   </li>
                                   @endif 

                                    <li class="viewtestimonials">
                                        <a href="{{route('viewtestimonial')}}">
                                              View Testimonials
                                        </a>
                                   </li>


                                   <li class="addOnfeatures">
                                        <a href="#">
                                             Ad-On Features
                                        </a>
                                   </li>

                                   <li class="updatelivestatus">
                                        <a href="#">
                                              Update Live Status
                                        </a>
                                   </li>

                                   <li class="readmyescorstsStory">
                                        <a href="{{route('blogIndex')}}">
                                         Read my Escorts Story
                                        </a>
                                   </li>

                                   <li class="drafts">
                                        <a href="#">
                                             Drafts
                                        </a>
                                   </li>
                                   <li class="change-password">
                                        <a href="{{route('changePassword')}}">
                                             Change Password
                                        </a>
                                   </li>
                                   <li class="edit-account  ">
                                        <a href="{{route('accountSetting')}}">
                                         Account Setting
                                        </a>
                                      </li>


                                   <li class="edit-account">
                                        <a data-toggle="modal" data-target="#reportThisadd" >
                                              Delete Account
                                        </a>
                                   </li>

                                   <li class="signout">
                                        <a href="{{route('logout')}}">
                                              Signout
                                        </a>
                                   </li>
                              </ul>
                         </div>
                    </div>
               </div>

 <!-- delete account  ad modal pop up start --> 
<div class="modal fade services-addTime" id="reportThisadd" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Delete my account</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
       <form method="post" action="{{route('accountDestroy', Auth::user()->id)}}">
        {{ csrf_field()}}
            <div class="sevicesaddtime-top reportthis-form">                      
      <ul class="why-delete-account">
        <li>To permanently delete your account.</li>
              <li>Your photos, posts and videos won't be deleted. Your photos, posts and videos won't be deleted.</li>
              <li>To permanently delete your account.</li>
      </ul>      
         <div class="form-group">
          <label class="control-label"><span style="color:red;">Reason For delete!</label>
            <textarea type="text" name="delete_description" placeholder="Write Description" class="form-control"></textarea>
          </div>
      
        </div> 
      <div class="modal-footer">        
        <button type="button" class="post-add-btn account-setting-submitbtn" data-dismiss="modal">Cancel</button>
    <button type="submit" class="post-add-btn account-setting-submitbtn account-setting-deletebtn">delete</button>
      </div>
    </form>
      </div>   
    </div>
</div>
</div>
<!-- delete modal end -->