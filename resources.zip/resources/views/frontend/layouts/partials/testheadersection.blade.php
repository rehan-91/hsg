<header class="test-header">
  <nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="/images/logo.png" class="pull-left" alt="logo"> <small>Training, Testing,<br> Certification & Registry</small></a>
	 <ul class="nav navbar-nav">

<li class="pull-left inves-apear">
 <span>{!! trans('translations.frontend.invigilator_as') !!} {{ Session::get('invigilator_email') }} <a href="javascript:void(0)" class="round-auth"><img src="/images/profile-pic.png"></a></span>
 </li>
 <li class="pull-right inves-apear">
 <span>{!! trans('translations.frontend.appearing_as') !!} {{ Auth::User()->name }} <a href="#" class="round-auth"><img src="/images/profile-pic.png"></a></span>
 </li>
 </ul>
</div>
</div>
</nav>
</header>


