<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> Dashboard</title>

    <!-- Bootstrap -->
    <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">
	<link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
	<link href="{{ asset('css/responsive.css') }}" rel="stylesheet">
	<link href="{{ asset('css/style.css') }}" rel="stylesheet">
	
	<script src="{{ asset('js/jquery.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('js/front-custom.js') }}" type="text/javascript"></script>
	<script src="{{ asset('js/bootstrap.min.js') }}" type="text/javascript"></script>
	
	
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
	<!--[if lt IE 9]>
     <script src="js/html5shiv.min.js"></script>
     <script src="js/respond.min.js"></script>
    <![endif]-->
	@yield('header-css')
	
	@yield('header-scripts')
	<script src="{{ asset('js/custom.js') }}"></script>
  </head>
  <body>
	@include('frontend.layouts.partials.testattempts.thanksheadersection')
	
	@yield('header')
	@yield('content')
	
	@include('frontend.layouts.partials.default.footersection')

	@yield('footer-css')
	@yield('footer-scripts')
	<script>
	  jQuery(document).ready(function(){
		jQuery('[data-toggle="tooltip"]').tooltip(); 
	  });
	  jQuery('ul.nav li.dropdown').hover(function() {
		jQuery(this).find('.dropdown-menu').stop(true, true).delay(150).fadeIn(300);
		}, 
		function() {
		jQuery(this).find('.dropdown-menu').stop(true, true).delay(150).fadeOut(300);
		}
	  );
	</script>
  </body>
</html>