<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Login</title>
  <link rel="stylesheet" href="{{ asset('frontend/css/login/bootstrap.min.css') }}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="{{ asset('frontend/css/login/style.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ asset('frontend/css/login/responsive.css') }}" rel="stylesheet" type="text/css">
</head>

<body id="login_bg">

  <section class="login-mainblock padding1">
    <div class="container">

      <div class="col-sm-12 col-sm-5 col-lg-5 logincenter">

        <div class="loginform-top">
          <img src="{{ asset('frontend/images/login-image.png') }}" alt="">

          <div class="craft-form">
            <form action="{{ route('SubmitLogin')}}" method="POST" id="register" name="register">
              {{ csrf_field() }}
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop @if($errors->has('email')) has-error @endif">

                    <input type="text" name="email" id="email" class="form-control LoginInputForm" placeholder="Email">
                    @if($errors->has("email"))
                    <span class="help-block">{{ $errors->first("email") }}</span>
                    @endif
                  </div>
                </div>
              </div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop @if($errors->has('password')) has-error @endif">
                    <input type="password" name="password" id="password" class="form-control LoginInputForm" placeholder="Password">
                    @if($errors->has("password"))
                    <span class="help-block">{{ $errors->first("password") }}</span>
                    @endif
                  </div>
                </div>
              </div>

<!-- otp field -->
                
                <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="row otp">
                                <div class="form-group LoginFormGrop @if($errors->has('otp')) has-error @endif">


                                    <input id="otp" type="number" class="form-control LoginInputForm" name="otp" placeholder="Enter OTP" >
                                    @if($errors->has("otp"))
                                     <span class="help-block">{{ $errors->first("otp") }}</span>
                                   @endif
                                </div>
                            </div>
                          </div>

                            
                                   

                     <div class="col-sm-6">
                    <button type="submit" class="login-btn" onclick="sendOtp()">Login</button>
                  </div>

                               
<!-- end otp field -->


   <div class="buttonblock">
                <div class="row">
                

                    <div class="forgotpassword">
                      <a href="{{route('forgotpassword')}}">Forgot Password?</a>
                      <br/>
                      <a href="{{route('register')}}">Not a member?</a>
                    </div>
                  </div>
                </div>
              </div>

            </form>
          </div>

        </div>

      </div>
    </div>
  </section>
   <script>
  
  $(document).ready(function(){
    $('.otp').hide();
        function sendOtp() {
           
          var registration_form = new FormData(document.getElementById("register"));  
            $.ajax( {
                url:"{!! route('verifyotp') !!}",
                type:'post',
                 dataType: "JSON",
                data: registration_form,
                 processData: false,
                 contentType: false,
                success:function(data) {
                    // alert(data);
                    if(data != 0){
                        $('.otp').show();
                        
                    }else{
                        alert('Mobile or Email  Not found');
                    }

                },
                error:function () {
                    console.log('error');
                }
            });
        }
      });
    </script>


  <script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
  <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>

</body>
</html>

