<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" type="image/png" href="{{ get_images($generalsettings['website_favicon'])}}"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('frontend/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/css/styles.css') }}">    
     <link rel="stylesheet" href="{{ asset('frontend/css/all.css') }}">
     <link rel="stylesheet" href="{{ asset('frontend/css/animate.css') }}">
	 <link rel="stylesheet" href="{{ asset('frontend/css/jquery.flipbox.css') }}">
     <link rel="stylesheet" href="{{ asset('frontend/css/responsive.css') }}">
	 <link rel="stylesheet" href="{{ asset('frontend/css/jquery.bxslider.css') }}"> 
	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/css/gijgo.min.css">
	 

     
     <!--Fonts css-->
     <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	 
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
    <script src="{{ asset('frontend/js/popper.min.js') }}"></script>
    <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('frontend/js/jquery.flipbox.js') }}"></script>
	<script src="{{ asset('frontend/js/jquery.bxslider.min.js') }}"></script>
    <script src="//cdn.jsdelivr.net/npm/gijgo@1.9.6/js/gijgo.min.js"></script>
    <script src="{{asset('frontend/js/common.js')}}"></script>
    <title>HOSG</title>
  </head>
  <body>
	@include('frontend.layouts.partials.default.headersection')
	
	@yield('header')
	@yield('content')
	
	@include('frontend.layouts.partials.default.footersection')

	@php $wishlist = getWishlist(); 
  @endphp
  @if(count($wishlist) > 0)
  @php $vnstyle="style=display:block; " @endphp
  @else
  @php $vnstyle="style=display:none; " @endphp
  @endif
  <div {{$vnstyle}} class="myshortlist" id="vn-click"> 
  <div class="shortlisttext">My Shortlist<p>Select 10 profile</p></span></div>

  <div class="shortlistbadge">
    <img src="{{ asset('frontend/images/compareshortlist-whitehearticon.png') }}"> 
    <span class="badge badge-light shortlistcount">{{ count($wishlist) }}</span>  
</div>

</div>
 


  <div id="vn-info">

<div class="shorlist_div show-shortlist-div">
  <div class="text-right close-shortlist-div" >
  <i class="fas fa-times close-shortlist-icon"></i>
  </div>
    <div class="container-fluid">
       <div class="myshortlist-compare">
         <h3>My shortlist</h3>
         <p>You can select upto 10 for comparision</p>
        </div>
               
               
               <div class="escorts-imagesblock">
                <ul class="escorts_list escort_shortlist_list">
                 @if(count($wishlist) > 0)
                 @foreach($wishlist as $ws)
                    <li id="ad_shorlist{{$ws['short_ad_id']}}">
                        <figure><img class="figure-img img-fluid" src="{{getS3ImageURL(getAdImage($ws['short_ad_id']), '252*384')}}" alt="">
                        <span class="imagehover-black"><i class="fas fa-times" onclick="removeFromShortlist({{$ws['short_ad_id']}})"></i></span></figure>
                        <figcaption class="figure-caption">{{getAdName($ws['short_ad_id'])}}</figcaption>                    
                    </li>
                 @endforeach
                 @endif
                </ul>
                </div>
                
                <a class="compare-btn" href="{{route('compare')}}">compare</a>
                
                </div>
                </div>
</div>
           
<!--shortlist-div end-->
                

<script>
var addWishlistURL =  '{!! route('addtowishlist') !!}';
var removeWishlistURL =  '{!! route('removefromwishlist') !!}';
var token = '{{csrf_token()}}';
</script>
  </body>
</html>