<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Forgot Password</title>
  <link rel="stylesheet" href="{{ asset('frontend/css/login/bootstrap.min.css') }}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="{{ asset('frontend/css/login/style.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ asset('frontend/css/login/responsive.css') }}" rel="stylesheet" type="text/css">
</head>

<body id="login_bg">


  <section class="login-mainblock padding1">
    <div class="container">

      <div class="col-sm-12 col-sm-5 col-lg-5 logincenter">

        <div class="loginform-top">
          <!--       
	   <img src="{{ asset('frontend/images/login-image.png') }}" alt="">
   -->
          <h4 class="text-center" style="color:#fff;font-size:20px;font-weight:bold;">Forgot Password</h4>
          <div class="craft-form">
            <form action="{{route('forgotpassprocess')}}" method="POST">
              {{ csrf_field() }}
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group LoginFormGrop @if($errors->has('forgot_email')) has-error @endif">

                    <input type="email" name="forgot_email" id="forgot_email" class="form-control LoginInputForm" placeholder="Email">
                    @if($errors->has("email"))
                    <span class="help-block">{{ $errors->first("email") }}</span>
                    @endif

                    @if($errors->has("forgot_email"))
                    <span class="help-block">{{ $errors->first("forgot_email") }}</span>
                    @endif

                    <br>
                    <div class="flash-message" style="padding:2px;">
                      @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                      @if(Session::has('alert-' . $msg))

                      <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }} <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                      @endif
                      @endforeach
                    </div>

                  </div>
                </div>
              </div>


              <div class="buttonblock">
                <div class="row">
                  <div class="col-sm-6">
                    <button type="submit" class="login-btn">Send</button></div>
                  <div class="col-sm-6">
                    <div class="forgotpassword">
                      <a href="{{route('login')}}">Back To Login?</a>
                    </div>
                  </div>
                </div>
              </div>

            </form>
          </div>

        </div>

      </div>
    </div>
  </section>

  <script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
  <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
</body>

</html>