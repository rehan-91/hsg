<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" type="image/png" href="{{ get_images($generalsettings['website_favicon'])}}"/>
  
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 
	
  <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('frontend/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/css/styles.css') }}">     
    <link rel="stylesheet" href="{{ asset('frontend/css/bootstrap-select.min.css') }}">   
     <link rel="stylesheet" href="{{ asset('frontend/css/animate.css') }}">
     <link rel="stylesheet" href="{{ asset('frontend/css/responsive.css') }}">
     <link rel="stylesheet" href="{{ asset('frontend/css/jquery-steps.css') }}">
     <link rel="stylesheet" href="{{ asset('frontend/css/all.css') }}">
     <link rel="stylesheet" href="{{ asset('frontend/css/select2.css') }}">
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  
    <link rel="stylesheet" href="{{ asset('css/imgareaselect-deprecated.css') }}">
   
	     <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script src="{{ asset('frontend/js/popper.min.js') }}"></script>
        <!-- <script src="{{asset('frontend/js/moment.js')}}"></script>-->
        <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
        <script src="{{ asset('frontend/js/bootstrap-select.min.js') }}"></script>
        <script src="{{ asset('frontend/js/jquery.steps.js') }}"></script>
        <script src="{{ asset('frontend/js/select2.min.js') }}"></script>
        <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.js"></script>
        <script src="//cdn.ckeditor.com/4.12.1/full/ckeditor.js"></script>
        <script src="{{asset('frontend/js/common.js')}}"></script> 
        <script src="{{asset('frontend/js/verify-identity.js')}}"></script>    
   
      <!-- Fun room css & js -->
        <link rel="stylesheet" href="{{ asset('frontend/css/lightslider.css') }}">       
        <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.rawgit.com/krebszattila/jquery-flipbox/master/src/jquery.flipbox.css">     
        <script src="https://cdn.rawgit.com/krebszattila/jquery-flipbox/master/src/jquery.flipbox.js"></script>
      <!-- Fun room css $ js end -->
<!--
<script src="{{ asset('frontend/js/packages/core/main.js')}}"></script>
 
<script src="{{asset('frontend/js/packages/interaction/main.js')}}"></script>
<script src="{{asset('frontend/js/packages/daygrid/main.js')}}"></script>
<script src="{{asset('frontend/js/packages/timegrid/main.js')}}"></script>
<script src="{{asset('frontend/js/packages-premium/resource-common/main.js')}}"></script>
<script src="{{asset('frontend/js/packages-premium/resource-daygrid/main.js')}}"></script>
<script src="{{asset('frontend/js/packages-premium/resource-timegrid/main.js')}}"></script>
--->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>

    <title>HOSG</title>
  </head>
  <body>
	@include('frontend.layouts.partials.frontheadersection')
	
	@yield('header')
	@yield('content')
	
  @include('frontend.layouts.partials.frontfootersection')
  @php $wishlist = getWishlist(); @endphp
  @if(count($wishlist) > 0)
  @php $vnstyle="style=display:block; " @endphp
  @else
  @php $vnstyle="style=display:none; " @endphp
  @endif 
  <div {{$vnstyle}} class="myshortlist" id="vn-click"> 
  <div class="shortlisttext">My Shortlist<p>Select 10 profile</p></span></div>

  <div class="shortlistbadge">
    <img src="{{asset('frontend/images/compareshortlist-whitehearticon.png')}}"> 
    <span class="badge badge-light shortlistcount">{{ count($wishlist) }}</span>  
</div>

</div>
 
  <div id="vn-info">

<div class="shorlist_div show-shortlist-div">
  <div class="text-right close-shortlist-div" >
  <i class="fas fa-times close-shortlist-icon"></i>
  </div>
    <div class="container-fluid">
       <div class="myshortlist-compare">
         <h3>My shortlist</h3>
         <p>You can select upto 10 for comparision</p>
        </div>
               
               
               <div class="escorts-imagesblock">
                <ul class="escorts_list escort_shortlist_list">
                 @if(count($wishlist) > 0)
                 @foreach($wishlist as $ws)
                    <li id="ad_shorlist{{$ws['short_ad_id']}}">
                        <figure><img class="figure-img img-fluid" src="{{getS3ImageURL(getAdImage($ws['short_ad_id']), '252*384')}}" alt=""><span class="imagehover-black"><i class="fas fa-times"  onclick="removeFromShortlist({{$ws['short_ad_id']}})"></i></span></figure>
                        <figcaption class="figure-caption">{{getAdName($ws['short_ad_id'])}}</figcaption>                    
                    </li>
                 @endforeach
                 @endif
                </ul>
                </div>
                
                <a class="compare-btn" href="{{route('compare')}}">compare</a>
                
                </div>
                </div>
</div>
           
<!--shortlist-div end-->
                


<script>
var addWishlistURL =  '{!! route('addtowishlist') !!}';
var removeWishlistURL =  '{!! route('removefromwishlist') !!}';
var token = '{{csrf_token()}}';
</script>
  </body>
</html>