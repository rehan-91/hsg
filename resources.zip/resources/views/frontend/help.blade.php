@extends('frontend.layouts.'.$included_header)

@section('content')
  <div class="clearfix"></div>
  <section class="help-banner">
	<div class="blue-bg paddingComm70">
	  <div class="container">
		<div class="row">
		  <div class="col-md-8 col-sm-12 col-xs-12">
			<h1>{!! $general_settings["master_agency_name"] !!}</h1>
			<h5>{!! $general_settings["master_agency_address"] !!}</h5>
			<a href="tel:{{ $general_settings['master_agency_contact_number'] }}"> +{!! $general_settings["master_agency_contact_number"] !!}</a><br>
			<a href="mailto:{{ $general_settings['master_agency_email'] }}">{!! $general_settings["master_agency_email"] !!}</a>
			
			@if( $cbc_info && intval($cbc_info->id) > 0 )
				<h2>{!! trans('translations.frontend.cbc_contact') !!} </h2>
				<h5>{{ $cbc_info->xprofile->company_name }}, {{ $cbc_info->address_data }}</h5>
				<a href="tel:{{ $cbc_info->contact_number }}"> {{ $cbc_info->contact_number }}</a><br>
				<a href="mailto:{{ $cbc_info->email }}">{{ $cbc_info->email }}</a>
			@endif			
		  </div>
		</div>
	  </div>
	</div>
	
	<div class="col-md-6 col-sm-12 col-xs-12 form-postion pull-right">
	  <div class="white-bg">
		<h3 class="blue">{!! trans('translations.frontend.form_heading') !!}</h3>
		<p>{!! trans('translations.frontend.form_sub_heading') !!}</p>
		
		@if(session()->has('message'))
			<div class="alert alert-success">
				{{ session()->get('message') }}
			</div>
		@endif
		
		<form id="help-form" name="help-form" action="{{ route('helpForm') }}" method="POST">
		  {{ csrf_field() }}
		  
		  <div class="field">
		  @if($errors->has("agentname"))
			  <span class="help-block popup-text-err">{{ $errors->first("agentname") }}</span>
			@endif
			<input type="text" name="agentname" id="agentname" placeholder="{!! trans('translations.frontend.form_name_placeholder') !!}" value="{{ old('agentname', ( isset( $user_info['name'] ) ? $user_info['name'] : ''  ) ) }}" >
			<label for="agentname">{!! trans('translations.frontend.form_name_title') !!} *</label>
			</div>
		  
		  <div class="field">
		  @if($errors->has("agentemail"))
			  <span class="help-block popup-text-err">{{ $errors->first("agentemail") }}</span>
			@endif
			<input type="text" name="agentemail" id="agentemail" placeholder="{!! trans('translations.frontend.form_email_placeholder') !!}" value="{{ old('agentemail', ( isset( $user_info['email'] ) ? $user_info['email'] : ''  ) ) }}">
			<label for="agentemail">{!! trans('translations.frontend.form_email_title') !!} *</label>
		  </div>
		  
		  <div class="field">
		  @if($errors->has("helpmessage"))
			  <span class="help-block popup-text-err">{{ $errors->first("helpmessage") }}</span>
			@endif
			<textarea name="helpmessage" id="helpmessage" placeholder="{!! trans('translations.frontend.form_message_placeholder') !!}">{{ is_null(old('helpmessage')) ? '' : old('helpmessage') }}</textarea>
			<label for="helpmessage">{!! trans('translations.frontend.form_message_title') !!} *</label>
			
		  </div>
		  
		  @php
			if( $cbc_info && intval($cbc_info->id) > 0 ){
				$checked_receivers = array( 'cbc' );
			}
			else{
				$checked_receivers = array( 'bcfi' );
			}
			
			if( old('agentemail') && !old('receivers') ){
				$checked_receivers = array();
			}
			else if( old('receivers') ){
				$checked_receivers = old('receivers');
			}
			
		  @endphp
		  
		  <div class="field">
		  @if($errors->has("receivers"))
			  <span class="help-block popup-text-err check-box-err">{{ $errors->first("receivers") }}</span>
			@endif
			<ul>
			  <li>
				<input type="checkbox" name="receivers[]" id="send_bcfi" class="css-checkbox" value="bcfi" @if( in_array( 'bcfi', $checked_receivers) ) checked @endif />
				<label for="send_bcfi" class="css-label radGroup1">Send to BCFI</label>
			  </li>
			  @if( $cbc_info && intval($cbc_info->id) > 0 )
				<li>
				  <input type="checkbox" name="receivers[]" id="send_cbc" class="css-checkbox" value="cbc" @if( in_array( 'cbc', $checked_receivers) ) checked @endif />
				  <label for="send_cbc" class="css-label radGroup1" >Send to CBC</label>
				</li>
			  @endif
			</ul>
		  </div>
		  
		  <button type="submit" name="help_form_submit" id="help_form_submit" class="green-btn arrow-icon btn-cm" value="{!! trans('translations.frontend.form_submit') !!}">Submit</button>
		</form>
	  </div>
	</div>
  </section>

  
  @php
	$faq_content_title = trans('translations.frontend.faq_content_title');
	$faq_content_answers = trans('translations.frontend.faq_content_answers');
  @endphp
  <section class="grey-bg paddingComm70 faq">
	<div class="container">
    <div class="col-md-7 col-sm-12 col-xs-12">
		<h3 class="blue">{!! trans('translations.frontend.faq_title') !!}</h3>
		<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
		  
		  @if( count($faq_content_title) > 0 )
			@php
			  $counter = 0;
			@endphp
			
			@foreach($faq_content_title as $title )
			  <div class="panel panel-default">
				<div class="panel-heading" role="tab" id="heading{{ $counter }}">
				  <h4 class="panel-title">
					<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse{{ $counter }}" aria-expanded="true" aria-controls="collapse{{ $counter }}" @if( intval($counter) > 0 ) class="collapsed" @endif >
						{!! $title !!}
					</a>
				  </h4>
				</div>
				<div id="collapse{{ $counter }}" class="panel-collapse collapse @if( intval($counter) == 0 ) in @endif " role="tabpanel" aria-labelledby="heading{{ $counter }}">
				  <div class="panel-body">
					<p>{!! $faq_content_answers[$counter] !!}</p>
				  </div>
				</div>
			  </div>
			  @php
			    $counter++;
			  @endphp
			@endforeach
		  @endif
		  
		</div>
    </div>    
	</div>
  </section>
  <div class="clearfix"></div>
  
  <script>
	jQuery(document).ready(function(){
		setTimeout(function(){
			jQuery(".alert-success").fadeOut("slow");
		}, 5000);
	});
  </script>
@endsection 
