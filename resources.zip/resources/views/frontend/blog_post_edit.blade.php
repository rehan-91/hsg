@extends('frontend.layouts.front_layout')

@section('content')
@php
$default_locale = app()->getLocale();

@endphp

<section class="profile-details-block">
     <div class="container">
          <div class="row"> 
               @include('frontend.layouts.partials.navfordashboard')
               <div class="col-md-9"  id="signup-container">
               <div class="testimonial-listing-block account-setting-form-block blog-post-edit-block">
               <form action="{{ route('updateblog',[$blog->blog_slug]) }}" method="post" name="form_blog_create" id="form_blog_create" enctype="multipart/form-data" onsubmit="return false;">
               <h2 class="blog-titile-margin">Create your story</h2>             
                                
                    <div class="row">
                    {{ csrf_field() }} 
                   
                    
                      <div class="form-group col-md-6">
					    <label>Title</label>
                        <input type="text" class="form-control"  placeholder="*Blog Title" id="blog_title" name="blog_title" value="{{$blog->blog_title}}">
                        <span class="help-block hidden blog_title_error"></span>
                      </div>

                     
					  <div class="form-group col-md-12">
                      <label>Featured Image</label>
					  <div class="clearfix"></div>
                    
					<fieldset class="form-group ui-sortable-handle">                     					  
                       <input type="file" name="featured_image" id="feature-img"  value='{{ $blog->blog_title }}' class="blog-edit-chooseImg field_set">					   
					  
					  <div class="max-videos">
					  <span>Maximum file size to upload is 200KB.</span>
					</div>
					</fieldset>
					
                    <!-- <span class="help-block hidden feature-img_error"></span> -->
					
					
					<div class="blog-image-preview">
                    @if ($errors->has('featured_image'))
                <span class="help1-block">
                    <strong>{{ $errors->first('featured_image') }}</strong>
                </span>
            @endif
                    <img src="" id="feature-img-preview" width="200px" />
                    @if(!empty($blog->blog_featured_img))
                    @php
                    $imageurl = url('uploads/ads_image/'.$blog->blog_featured_img);
                    @endphp
                     <img src="{{ $imageurl }}" width="20%"> 
                    @endif
                  <input type="hidden" name="old_blog_featured_img" value="{{ $blog->blog_featured_img }}">
				  </div>

                      </div>
					  
					  
					  
					   <div class="form-group col-md-12">
					     <label>Description</label>
                         <textarea class="ckdemo form-control" id="ckdemo" name="ckdemo" aria-labelledby="article">{{$blog->blog_desc}}</textarea>
                         <span class="help-block hidden ckdemo_error"></span>
                      </div>
					  
					  
					  </div>
					  
					  
					  <div class="form-group">
					    <label>SEO Content</label>
                        <input type="text" class="form-control"  placeholder="Meta Title" name="blog_meta_title" id="blog_meta_title" value="{{ $blog->blog_meta_title }}">
                      
                      </div>
					  
					  <div class="form-group">
                        <input type="text" class="form-control"  placeholder="Meta Keywords" name="blog_meta_keywords" id="blog_meta_keywords" value="{{ $blog->blog_meta_keywords }}">

                      </div>
					  
					  <div class="form-group">
                        <textarea class="form-control ckdemo"  placeholder="Meta Description" name="blog_meta_description" id="blog_meta_description">{{ $blog->blog_meta_description }}</textarea>
                        
                      </div>
					  
					  <div class="form-group">
					   <label>Status</label>
                        <input type="checkbox" name="status" id="status_1"value="1" @if ($blog->blog_status == 1) checked @endif>
                       <label for="status_1" class="lbl" id="switch-box"></label>

                      </div> 
					  
					  
					   <input type="hidden" id="blog_id" name="blog_id" value="{{$blog->id}}">
                      <input type="submit" value="Update" onclick="saveblog()" class="post-add-btn">
					  
                      </div><!--row-->
 
                     </form>
                     </div>
               </div>
               </div>
               
          </div>    
</section>


<script type="text/javascript">
  var redirect_url =  "{{ route('updateblog') }}";
</script>

@endsection