@extends('frontend.layouts.default_layout')

@section('content')

 <section class="featured-sexy-girls-block padding-120">
    <h2 class="featured-sexy-girls"><img src="{{ asset('frontend/images/featured-sgirl-title.png') }}" alt="featured-sgirl-title" class="img-fluid"></h2>
    <div class="container-fluid">
	
      <div class="myshortlist">
  <img src="{{ asset('frontend/images/shortlist_heart.png') }}"><span class="badge">
	{{ count($my_total_short_list)}}</span> My Shortlist
 </div> 
 
    
    <div style="margin:0 auto; text-align:center; display:inline-block; width:100%;">   
    
      
                <div class="item"> 
                    <div class="box" id="box4">        
                      <div style="background:url({{ asset('frontend/images/e1.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon Offliine-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e2.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e3.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e4.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e5.jpg') }}) no-repeat center center;width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e6.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e7.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e8.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                            
                                          
                  </div>
                 
                    <div class="box" id="box5">        
                       <div style="background:url({{ asset('frontend/images/e1.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon Offliine-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e2.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e3.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e4.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e5.jpg') }}) no-repeat center center;width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e6.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e7.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e8.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
                 
                
                <div class="live-btnpositon"> <span>live</span> </div>            
                </div>
                
                     <div class="box" id="box6">        
                        <div style="background:url({{ asset('frontend/images/e1.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon Offliine-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e2.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e3.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e4.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e5.jpg') }}) no-repeat center center;width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e6.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e7.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e8.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
                    
                
                <div class="live-btnpositon"> <span>live</span> </div>         
                </div>
                
                     <div class="box" id="box7">        
                        <div style="background:url({{ asset('frontend/images/e1.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon Offliine-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e2.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e3.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e4.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e5.jpg') }}) no-repeat center center;width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side1"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e6.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side2"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e7.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side3"><div class="live-btnpositon"> <span>live</span> </div></div>
                            
                      <div style="background:url({{ asset('frontend/images/e8.jpg') }}) no-repeat center center; width:100%; height:100%; display:inline-block; background-size:cover;border-radius: 10px;" class="side side4"><div class="live-btnpositon"> <span>live</span> </div></div>
              
                
                <div class="live-btnpositon"> <span>live</span> </div>              
                </div>
                    <div class="clearfix"></div>
                    
                 <div class="flipSlide-btn">   
                     <button class="prev"></button>
                     <button class="next reverse"></button>
                 </div>
                 
                </div>
                
                
               
  </div>
 
 
         </div>        
    </div>
  </section>
  
<div class="clearfix"></div>
  <span class="glowing-border-blue"></span>
  <div class="clearfix"></div>
  <section class="auckland-escorts-block">
    <div class="container-fluid">
      <div class="leftaucklandescrots-block">
        <div class="aucklandtop-left-block">
          <div class="top-bar-sec">
            <h2 class="today-exclusive-sexy-girls"><img src="{{ asset('frontend/images/todayExlusivesexy-girl-title.png') }}" alt="todayExlusivesexy-girl-title" class="img-fluid"></h2>
            <div class="sortby-block float-right">
              <div class="four-grid-icon float-left mr-3">
                <button type="button" name="form_grid_2" id="form_grid_2" class="form_grid_2" style="background-color:rgb(0,0,0,0.5);border:none;padding:5px;">
				<img src="frontend/images/4-grid-icon.png">
              </button>
			  </div>
              <div class="six-grid-icon float-left">
                <button name="form_grid_3" id="form_grid_3" class="form_grid_3" style="background-color:rgb(0,0,0,0.5);border:none;padding:5px;">
				<img src="frontend/images/6-grid-icon.png">
              </button>
			  </div>
            </div>
            <div class="badges">
              
              <div class="blue-badge"><a href="#">Auckland Girls</a></div>
              <div class="blue-badge"><a href="#">Hamilton Girls</a></div>
              <div class="blue-badge"><a href="#">Queenstown Girl</a></div>
            </div>
          </div>

          <ul class="aucklandtop-leftblock-box">
            <div class="overlay">
            </div>
          
            @foreach($featured_profile_list as $featurelist)
            <li class="test1">
			
              <img class="img-fluid" src="frontend/images/1.jpg" id="ad_image{{$featurelist['adId']}}">
			  
              <div class="live-btnpositon">
                <span id="user_status_{{$featurelist['adId']}}"></span>
              </div>
			  
              <div class="hoverdiv">
                <div class="img-section">
                  <img class="img-fluid" src="frontend/images/hover-div-img.jpg">
                </div>
                <div class="cnt_section">
                  <div class="cnt">
                    <h2 id="ad_name{{$featurelist['adId']}}">{{ucwords($featurelist['adName'])}}</h2>
                    <div class="location"> {{ getCityCountry($featurelist['adLocation']) }}</div>
                    <div class="private_tag">{{getListingType($featurelist['adListingTypeId'])}}</div>
                    <div class="listing">
          
                  
                      <div class="list">{{$featurelist['metaData']['age']}} Yrs</div>
                      @if(!empty($featurelist['metaData']['bustsize']))
                      <div class="list"><span class="label">Size: </span>{{$featurelist['metaData']['bustsize']}}</div>
                      @endif
                      <div class="list"><span class="label">Height: </span>{{$featurelist['metaData']['height']}}</div>
                      @if(!empty($featurelist['metaData']['weight']))
                      <div class="list"><span class="label">Weight: </span>{{$featurelist['metaData']['weight']}} KG</div>
                      @endif
                      @if(!empty($featurelist['metaData']['eyecolor']))
                      <div class="list"><span class="label">Eye Color: </span>{{$featurelist['metaData']['eyecolor']}}</div>
                      @endif
                      @if(!empty($featurelist['metaData']['haircolor']))
                      <div class="list"><span class="label">Hair Color: </span>{{$featurelist['metaData']['haircolor']}}</div>
                      @endif
                      @if(!empty($featurelist['metaData']['nationality']))
                      <div class="list"><span class="label">Ethnicity: </span>{{$featurelist['metaData']['nationality']}}</div>
                      @endif
                   
                    </div>
                    <div class="contact_detail mt-3">
                      <div class="icon"><img src="frontend/images/hover-phone-icon.png"></div>
                      <div class="phone-number"><span>Phone</span><br/>{{$featurelist['adContact']}}</div>
                    </div>
                    <div class="rate">{{ $featurelist['rate'] }} / Hour</div>
                    <div class="view-profile"><a href="{{route('profile.',$featurelist['slug'])}}">View Profile <img src="frontend/images/long-arrow.png"></a></div>
                  </div>
                             		  
                  <div class="shortlist_button">
                                             @php
                                             $wishlist_ad_ids = array();
                                             $wishlist_ad_ids = getWishlist()->pluck('short_ad_id')->toArray();
                                             $style = "style=display:none;";
                                             $style1 = "style=display:none;";
                                             if(!in_array($featurelist['adId'], $wishlist_ad_ids)){
                                        $style = "style=display:block;'";
                                        }else{
                                        $style1 = "style=display:block;";
                                        }
                                        @endphp
                                        <a {{$style}} id="showshortListing{{$featurelist['adId']}}" href="javascript:void(0)"  onclick="addToShortlist({{$featurelist['adId']}})"><i class="fa fa-plus"></i> Shortlist</a>
                                       
                                   
                                        <a {{$style1}} class="shotlilsted-btn"  href="javascript:void(0)" id="showshortListed{{$featurelist['adId']}}"><i class="fa fa-heart"></i> Shotlisted</a>
                                            
                                   </div>
              </div>
              </div>
              
              
            </li>
            @endforeach
          
          </ul>
          
          
        </div>
        
        <div class="aucklandtop-right-block">
          <div class="top-bar-sec"> <h2 class="eotd"><img class="img-fluid" src="frontend/images/eotd1.png"></h2></div>
          
          <div id="carouselExampleIndicators2" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                
                <div><img src="frontend/images/eotd.jpg" class="img-fluid" alt="img"></div>
                
                
              </div>
              <div class="carousel-item">
                <div><img src="frontend/images/eotd.jpg" class="img-fluid" alt="img"></div>
              </div>
              
              <div class="carousel-item">
                <div><img src="frontend/images/eotd.jpg" class="img-fluid" alt="img"></div>
              </div>
              
            </div>
          </div>
          <div class="profile_home">
          <h2><img src="{{ asset('frontend/images/liveUpdate-title.png') }}" class="img-fluid" alt="img"></h2>
          <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>
           <div class="block1">
            <div class="image"><img src="frontend/images/alice.png"></div>
            <div class="content">
              <h3>Alice</h3>
              <p>Alice has changed the status</p>
            </div>
          </div>


        </div>
        </div>
        
        
      </div>
      
      
    </div>
  </section>
  
<div class="clearfix"></div>


<section class="redbar-cta text-center">
 <div class="container-fluid">
  <div class="row">
   <div class="cta-text"><p>Be a proud member of <b>House of Sexy Girls</b></p><a class="post-addcta-btn" href="#">Post your ad now</a></div>   
   </div>   
 </div>
</section>

<div class="clearfix"></div>

<section class="bottom-advertiseblock padding-50">
 <div class="container-fluid">
  <div class="row">
  @foreach($other_ads as $oth)
    <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3">
     <div class="advertise-box">
	 <img src="{{ get_image_data_2($oth->ad_photo,'other_ads_photos') }}" class="img-fluid" alt="img"> 
	</div>
    </div>
    @endforeach
   </div>
   
 </div>
</section>


<script>
// Autoplay
            $('#box4').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 5000,
                autoplayPauseOnHover: true
            });
			
			     $('#box5').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 4000,
                autoplayPauseOnHover: true
            });
			
			     $('#box6').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 3000,
                autoplayPauseOnHover: true
            });
			
				     $('#box7').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 2000,
                autoplayPauseOnHover: true
            });
			
				     $('#box8').flipbox({
                vertical: true,
                autoplay: true,
                autoplayReverse: true,
                autoplayWaitDuration: 6000,
                autoplayPauseOnHover: true
            });
			
			// Buttons
            $('button.prev').click(function() {
                $(this).closest('.item').find('.box').flipbox('prev', $(this).hasClass('reverse'));
            });
            $('button.next').click(function() {
                $(this).closest('.item').find('.box').flipbox('next', $(this).hasClass('reverse'));
            });
            $('button.jump').click(function() {
                $(this).closest('.item').find('.box').flipbox('jump', $(this).data('index'), $(this).hasClass('reverse'));
            });
            $('button.config').click(function() {
                $(this).closest('.item').find('.box')
                    .flipbox({
                        animationDuration: $(this).data('duration'),
                        animationEasing: $(this).data('easing')
                    })
                    .flipbox('next');
					
					});
</script>

<script type="text/javascript">
$(document).ready(function(){
    $("#form_grid_2").click(function(){
        $("ul").removeClass();
        $("ul").addClass("aucklandtop-leftblock-box_grid_2");
    });
	$("#form_grid_3").click(function(){
        $("ul").removeClass();
        $("ul").addClass("aucklandtop-leftblock-box");
    });
});
</script>
@endsection 