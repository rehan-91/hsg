@extends('frontend.layouts.default_layout')
@section('content')
<section class="compare-listing-block">
    <div class="container-fluid">
        <div class="row">
          <h3>compare list</h3>
            @if(count($list) > 0)
            @foreach($list as $l)
              <div class="col-md-6" id="comaprediv{{$l['adId']}}">
                  
               <div class="comparediv-main">
			     <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="removeFromShortlist({{$l['adId']}}, true)">×</button> 
                @if(count($l['adImage']) > 0)
                 <div class="bxslider-escortslisting">
                @foreach($l['adImage'] as $img)
                 
                    <div>
                <div class="img-section"> <img class="img-fluid" src="{{getS3ImageURL($img->media_filename,'508*762')}}">
                            </div>
                </div>
             
              @endforeach
               </div>
              @endif
              <div class="cnt_section compare-text">
                  <div class="cnt">
                    <h2>{{ucwords($l['adName'])}}</h2>
                    <div class="location">{{ getCityCountry($l['adLocation']) }}</div>
                    <div class="private_tag">{{getListingType($l['adListingTypeId'])}}</div>
                    <div class="listing">
                      <div class="list">{{getMaterData($l['metaData']['age'])}} Yrs</div>
                      <div class="list"><span class="label">Size:</span> {{getMaterData($l['metaData']['bustsize'])}}</div>
                      <div class="list"><span class="label">Height:</span> {{getMaterData($l['metaData']['height'])}}</div>
                      <div class="list"><span class="label">Weight:</span> {{getMaterData($l['metaData']['weight'])}} KG</div>
                      <div class="list"><span class="label">Eye Color:</span> {{getMaterData($l['metaData']['eyecolor'])}}</div>
                      <div class="list"><span class="label">Hair Color:</span> {{getMaterData($l['metaData']['haircolor'])}}</div>
                      <div class="list"><span class="label">Ethnicity:</span> {{$l['metaData']['ethnicity']}}</div>
                    </div>
                    
                    <div class="rate"></div>
                    <div class="view-profile"><a href="{{$l['profile_link']}}">View Profile <img src="{{asset('frontend/images/long-arrow.png')}}"></a></div>
                  </div>
                                               
                </div>
             </div>
        </div>
        @endforeach
        @else
         <div class="col-md-12  padding-120">
               <div class="comparediv-main">
			   <h3>compare list</h3>
                <p style="color:#fff;">Shortlist atleast 2 profile to compare.</p>
               </div>
             </div>
        @endif

   </div>

    </div>
</section>
<script>
  $(document).ready(function(){
    $('.bxslider-escortslisting').bxSlider({
  auto: true,
  infiniteLoop:false,
  stopAutoOnClick: true,
  minSlides:1,
  maxSlides:1,
  pager: false,
  slideWidth:400
  
  
});
  })

</script>
 

@endsection