@extends('admin.layouts.default_layout')
@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Escorts Agency</h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Ads" href="#">Back</a>
		</div>
    </div>
@endsection
@section('content')
<div id="detail-section" class="step_1">
    
    <form  action="" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
        {{ csrf_field() }}
        <section class="lime-bg paddingComm70">
            <div class="container">
                <h2 id="ad-heading">Ad Posting</h2>


                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Contact</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <div class="input-box @if($errors->has('name')) has-error @endif">
                                <label class="select-label" for="name">Name</label><br>
                                <input type="text" id="name" name="name" class="bg-input" placeholder="Please Enter Name" value='{{ old("name")}}' />
                                @if($errors->has("name"))
                                <span class="help-block">{{ $errors->first("name") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('email')) has-error @endif">
                                <label class="select-label" for="email">Email</label><br>
                                <input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email" value='{{ old("email")}}' />
                                @if($errors->has("email"))
                                <span class="help-block">{{ $errors->first("email") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('phone')) has-error @endif">
                                <label class="select-label" for="phone">Phone</label><br>
                                <input type="text" id="email" name="phone" class="bg-input" placeholder="Please Enter Phone" value='{{ old("phone")}}' />
                                @if($errors->has("phone"))
                                <span class="help-block">{{ $errors->first("phone") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('location')) has-error @endif">
                                <label class="select-label" for="location">Location</label><br>
                                <input type="text" id="email" name="location" class="bg-input" placeholder="Please Enter Location" value='{{ old("location")}}' />
                                @if($errors->has("location"))
                                <span class="help-block">{{ $errors->first("location") }}</span>
                                @endif
                            </div>
                            
                             <div class="textarea-box margR0 @if($errors->has('description')) has-error @endif">
                                <label class="select-label" for="description">Description</label><br>
                                <textarea id="job_description" name="description" class="bg-input" placeholder="Please Enter Description">{{ old("description")}}</textarea>
                                @if($errors->has("description"))
                                <span class="help-block">{{ $errors->first("description") }}</span>
                                @endif
                            </div>
                             <div class="clearfix"></div>
                              <div class="input-box">
                                <label class="select-label" for="logo">Logo / Banner</label><br>
                                <input type="file" name="logo">
                              </div>
                             
                            
                             
                        </div>
                        
                        
                        
                    </div>
                </div>
                
            </div>
             <div class="container">
             <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Photos & Videos</h2>
                   <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                           <label class="select-label" for="name">Photos</label><br>
                                    <div class="form-group">
                                        <input type="file" name="ad_photos" multiple>
                                    </div>
                                 <br>
                                <label class="select-label" for="name">Videos</label><br>
                                    <div class="form-group">
                                        <input type="file" name="ad_videos" multiple>
                                    </div>
                        </div>
                    </div>
             </div>
             </div>
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <input name="save" value="Save" type="button" class="admin-add btn-admin" id="step_1">

                        </div>
                    </div>


                </div>



            </div>
        </section>

    </form>
</div>

</div>

@endsection

@section('footer-scripts')
@endsection