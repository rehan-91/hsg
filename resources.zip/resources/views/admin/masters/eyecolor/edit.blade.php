@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Eye color  / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Eye color" href="{{ route('admin.masters.eyecolor') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
<section class="lime-bg paddingComm70">
<div class="container">
    <div class="basic-configuration-inner select-box admin-create-update">
        <h2>Edit Age</h2>
        <!--row of age -->
        <hr>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <form  action="{{ route('admin.masters.eyecolorupdate', [$eyecolor->id]) }}" method="POST">	<!--class="form-inline"	age value insert form -->
                    {{ csrf_field() }}
                    <div class="input-box @if($errors->has('eyecolor_value')) has-error @endif">
                        <label class="select-label" for="age">Eye color</label><br>
                        <input type="text" id="eyecolor_value" name="eyecolor_value" class="bg-input" placeholder="Enter Eye color Value" value='{{$eyecolor->meta_value}}'>
                    @if($errors->has("eyecolor_value"))
                            <span class="help-block">{{ $errors->first("eyecolor_value") }}</span>
                    @endif
                    </div>
                    <div class="clearfix"></div>
                    <input name="submit" value="Save" type="submit" class="admin-add btn-admin">
                </form>


            </div><!--end of age col-sm-4-->

        </div><!--end of age row-->




    </div><!--end of basic-configuration-inner-->

    <div class="clearfix"></div>
</div><!--end of container age-container -->
</section>

@endsection