@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Social Media Links  / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Shoes Size" href="{{ route('admin.masters.social-media-links') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
<section class="lime-bg paddingComm70">
<div class="container">
    <div class="basic-configuration-inner select-box admin-create-update">
        <h2>Edit Social Media Links</h2>
        <!--row of shoes size -->
        <hr>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <form  enctype="multipart/form-data" action="{{ route('admin.masters.social-media-links-update', [$social_media_links->id]) }}" method="POST">	<!--class="form-inline"	age value insert form -->
                    {{ csrf_field() }}
                    <div class="input-box @if($errors->has('social_media_links_value')) has-error @endif">
                        <label class="select-label" for="social_media_links_value">Social Media Links Placeholder</label><br>
                        <input type="text" id="social_media_links_value" name="social_media_links_value"  class="bg-input" placeholder="Enter Value" value='{{$social_media_links->meta_value}}'>
                    @if($errors->has("social_media_links_value"))
                            <span class="help-block">{{ $errors->first("social_media_links_value") }}</span>
                    @endif
                    <input type="file" name="social_media_icon">
                    @if(!empty($social_media_links->meta_icon))
                    <img src="{{url('upload/'.$social_media_links->meta_icon)}}">
                    <input type="hidden" value="{{$social_media_links->meta_icon}}" name="old_social_media_icon">
                    @endif
                    </div>
                    <div class="clearfix"></div>
                    <input name="submit" value="Save" type="submit" class="admin-add btn-admin">
                </form>


            </div><!--end of age col-sm-4-->

        </div><!--end of age row-->




    </div><!--end of basic-configuration-inner-->

    <div class="clearfix"></div>
</div><!--end of container age-container -->
</section>

@endsection