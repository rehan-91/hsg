@extends('admin.layouts.default_layout')
@section('header-css')
<link href="{{ asset('admin-vendors/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
@endsection
@section('header-scripts')
    <script src="{{ asset('admin-vendors/js/jquery.dataTables.js') }}"></script>
@endsection

@section('header')
	@section('header')
	<section class="manage-training admin-title paddingComm45">
	  <div class="container">
		<div class="row">
		  <div class="col-md-6 col-sm-6 col-xs-8 borderWdth">
			<h1 class="blue">Height</h1>
			<h2>Create/Update Height</h2>
		  </div>
		
		  <div class="col-md-6 col-sm-6 col-xs-4 borderWdth">
			<a class="adminBorder-btn plus-icon" title="Add Height" href="{{ route('admin.masters.heightcreate') }}">Add Height</a>
		  </div>
		</div>
	  </div>
	</section>
@endsection

@endsection
{{ csrf_field() }}
@section('content')
  @if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
  @endif
  
  <section class="manage-quetion lime-bg table-width paddingComm45">
	<div class="container">
	  <div class="table-responsive search-gapTop paddR0 admin-table table-line-hgt">
		<table class="table" id="plans-table">
			<thead>
				<tr>
					<th>Height Value</th>
					<th>Added On</th>
					<th>&nbsp;</th>
				</tr>
			</thead>
		</table>
	  </div>
	</div>
  </section>
@endsection

@section('footer-scripts')
<script>
	var dTable;
	jQuery(function() {
		dTable = jQuery('#plans-table').DataTable({
			"autoWidth": false,
                        stateSave: true,
			language: {
				searchPlaceholder: "Search through Plan title",
				"paginate": {
					"first": "&verbar ;&lt;",
					"last": "&gt; &verbar;",
					"next": "&gt;",
					"previous": "&lt;"
				},
				"lengthMenu": " _MENU_ ",
				"info": "_START_ - _END_ of _TOTAL_ items",
				"infoEmpty": "0 - 0 of 0 items",
				"search": "search",
                                
                              
			},
			order: [],
			"dom": 'ftilrp',
			processing: true,
			serverSide: true,
                        
			ajax: '{!! route('admin.masters.heightdata') !!}',
			columns: [
				{ data: 'title', name: 'title' },
				
				{ data: 'created_at', name: 'created_at' },
				
				{ data: 'action', name: 'action' }
			],
			"columnDefs": [
				{ "orderable": false, "targets": [2] }
		    ]
		});
	});
</script>
@endsection