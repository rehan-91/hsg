@extends('admin.layouts.default_layout')
@section('content')
  <section class="configuration-links admin-title">
	<div class="container">
	  <h1 class="black">General</h1>
	  <ul>
		<li class="{{ $active_tab == 'general'? 'active':'' }}"><a href="{{ route('admin.settings.general') }}">General</a></li>
		<li class="{{ $active_tab == 'configuration'? 'active':'' }}"><a href="{{ route('admin.settings.configuration') }}">Configurations</a></li>
		<li class="{{ $active_tab == 'video'? 'active':'' }}"><a href="{{ route('admin.settings.video') }}">Video</a></li>
	  </ul>
	</div>
  </section>

  <div class="clearfix"></div>
  <section class="lime-bg paddingComm70">
	<div class="container">
	  
	  <form class="form-inline" action="{{ route('admin.settings.updategeneralsettings') }}" method="POST" enctype="multipart/form-data">
	    {{ csrf_field() }}
	    <div class="basic-configuration-inner select-box">
			<h2>Agency Address</h2>
		
			<div class="form-group form-grouping @if($errors->has('master_agency_name')) has-error @endif">
			  <label class="select-label" for="master_agency_name">Name</label><br>
			  <input type="text" class="bg-input" id="master_agency_name" placeholder="Name" name="master_agency_name" value='{{ is_null(old("master_agency_name")) ? $generalsettings["master_agency_name"] : old("master_agency_name") }}' />
			  @if($errors->has("master_agency_name"))
				<span class="help-block">{{ $errors->first("master_agency_name") }}</span>
			  @endif
			</div>
			
			<div class="form-group form-grouping @if($errors->has('master_agency_email')) has-error @endif">
			  <label class="select-label" for="master_agency_email">Email</label><br>
			  <input type="text" class="bg-input" id="master_agency_email" placeholder="Email" name="master_agency_email" value='{{ is_null(old("master_agency_email")) ? $generalsettings["master_agency_email"] : old("master_agency_email") }}' />
			  @if($errors->has("master_agency_email"))
				<span class="help-block">{{ $errors->first("master_agency_email") }}</span>
			  @endif
			</div>
			
			<div class="form-group form-grouping @if($errors->has('master_agency_contact_number')) has-error @endif">
			  <label class="select-label" for="master_agency_contact_number">Contact Number</label><br>
			  <input type="text" class="bg-input" id="master_agency_contact_number" placeholder="Contact Number" name="master_agency_contact_number" value='{{ is_null(old("master_agency_contact_number")) ? $generalsettings["master_agency_contact_number"] : old("master_agency_contact_number") }}' />
			  @if($errors->has("master_agency_contact_number"))
				<span class="help-block">{{ $errors->first("master_agency_contact_number") }}</span>
			  @endif
			</div>
			
			<div class="clearfix"></div>
			<div class="form-group form-grouping @if($errors->has('master_agency_contact_number')) has-error @endif">
			  <label class="select-label" for="master_agency_address">Address</label><br>
			  <textarea class="bg-input" id="master_agency_address" placeholder="Address" name="master_agency_address" >{{ is_null(old("master_agency_address")) ? $generalsettings["master_agency_address"] : old("master_agency_address") }}</textarea>
			  @if($errors->has("master_agency_address"))
				<span class="help-block">{{ $errors->first("master_agency_address") }}</span>
			  @endif
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="basic-configuration-inner select-box">
			<h2>Logo/ Favicon / Watermark Image</h2>
                <div class="form-group form-grouping @if($errors->has('website_logo')) has-error @endif">
			  <label class="select-label" for="website_logo">Website Logo<span style="color:red;"> (Min Size : 480X281 required)</span></label>
			  <input type="file" id="website_logo" name="website_logo" />
			  <input type="hidden" name="old_website_logo" value="{{ $generalsettings['website_logo']}}">
			  @if($errors->has("website_logo"))
				<span class="help-block">{{ $errors->first("website_logo") }}</span>
			  @endif
			  <br/>
			  @if(!empty($generalsettings['website_logo']))
			<img src="{{ $models::get_image_data($generalsettings['website_logo'])}}" width="50%">
			@endif
			</div>
			<div class="clearfix"></div>
			<div class="form-group form-grouping @if($errors->has('website_favicon')) has-error @endif">
			  <label class="select-label" for="website_favicon">Favicon <span style="color:red;"> (Max Size : 16X16 required)</label><br>
			  <input type="file" id="website_favicon" name="website_favicon" />
			  <input type="hidden" name="old_website_favicon" value="{{ $generalsettings['website_favicon']}}">
			   @if($errors->has("website_favicon"))
				<span class="help-block">{{ $errors->first("website_favicon") }}</span>
			  @endif
			  <br/>
				@if(!empty($generalsettings['website_favicon']))
				<img src="{{ $models::get_image_data($generalsettings['website_favicon'])}}" >
				@endif
			</div>
			<div class="clearfix"></div>
			<div class="form-group form-grouping @if($errors->has('watermark_image')) has-error @endif">
			  <label class="select-label" for="watermark_image">Watermark Image</label><br>
			  <input type="file" id="watermark_image" name="watermark_image" />
			    <input type="hidden" name="old_watermark_image" value="{{ $generalsettings['watermark_image']}}">
			    @if($errors->has("watermark_image"))
				<span class="help-block">{{ $errors->first("watermark_image") }}</span>
			  @endif
			  @if(!empty($generalsettings['watermark_image']))
			 <img src="{{ $models::get_image_data($generalsettings['watermark_image'])}}" width="50%">
		 @endif
			</div>
            <div class="clearfix"></div>
			<div class="form-group form-grouping @if($errors->has('watermark_image_position')) has-error @endif">
			  <label class="select-label" for="watermark_image_position">Watermark Image Position</label><br>
			  <select class="bg-input" id="watermark_image_position" name="watermark_image_position">
					<option value="">Please Select Image Position</option>
                    @if (!empty($watermark_image_position_arr) && count($watermark_image_position_arr) > 0)
					@foreach( $watermark_image_position_arr as $key => $value )
						<option @if( !empty($generalsettings["watermark_image_position"]) && $generalsettings["watermark_image_position"] == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
					@endforeach
                    @endif
					</select>
			    <input type="hidden" name="old_watermark_image_position" value="{{ $generalsettings['watermark_image_position']}}">
				  @if($errors->has("watermark_image_position"))
				<span class="help-block">{{ $errors->first("watermark_image_position") }}</span>
			  @endif
			</div>
                 			  
		</div>
		<div class="clearfix"></div>
				<div class="basic-configuration-inner select-box">
			<h2>UPLOAD HOME PAGE VIDEO</h2>
                <div class="form-group form-grouping @if($errors->has('home_page_video')) has-error @endif">
			  <label class="select-label" for="home_page_video">UPLOAD VIDEO</label>
			  <input type="file" id="home_page_video" name="home_page_video" />
			  <input type="hidden" name="old_home_page_video" value="{{ $generalsettings['home_page_video']}}">
			  @if($errors->has("home_page_video"))
				<span class="help-block">{{ $errors->first("home_page_video") }}</span>
			  @endif
			  <br/>
			  @if(!empty($generalsettings['home_page_video']))
				  <video width="320" height="240" controls><source src="{{ $models::get_image_data($generalsettings['home_page_video'])}}"></video>
			@endif
			</div>
			
                        
		</div>
		<div class="clearfix"></div>
		<div class="basic-configuration-inner select-box">
			<h2>SEO Meta</h2>
                        <div class="form-group form-grouping">
			  <label class="select-label" for="meta_keywords">Meta Title</label><br>
			  <input type="text" class="bg-input" id="meta_title" placeholder="Meta title" name="meta_title" value='{{ !is_null(old("meta_title")) ? old("meta_title") : empty($generalsettings["meta_title"])?'':$generalsettings["meta_title"] }}' />
			 
			</div>
			<div class="form-group form-grouping">
			  <label class="select-label" for="meta_keywords">Meta Keywords</label><br>
			  <input type="text" class="bg-input" id="meta_keywords" placeholder="Meta keywords" name="meta_keywords" value='{{ !is_null(old("meta_keywords")) ? old("meta_keywords") : empty($generalsettings["meta_keywords"]) ? '' : $generalsettings["meta_keywords"] }}' />
			 
			</div>
                        <div class="clearfix"></div>
			<div class="form-group form-grouping">
			  <label class="select-label" for="meta_description">Meta Description</label><br>
			  <textarea class="bg-input" id="meta_description" placeholder="Meta Description" name="meta_description" >{{ !is_null(old("meta_description")) ? old("meta_description") : empty($generalsettings["meta_description"]) ? '' : $generalsettings["meta_description"] }}</textarea>
			</div>
			  
                        <div class="form-group form-grouping">
			  <label class="select-label" for="google_tag_manager">Google Tag Manager</label><br>
			  <textarea class="bg-input" id="google_tag_manager" placeholder="Google Tag Manager" name="google_tag_manager" >{{ !is_null(old("google_tag_manager")) ? old("google_tag_manager") : empty($generalsettings["google_tag_manager"]) ? '' : $generalsettings["google_tag_manager"] }}</textarea>
			  
			</div>
                        <div class="form-group form-grouping">
			  <label class="select-label" for="meta_description">Google Analytics</label><br>
			  <textarea class="bg-input" id="google_analytics" placeholder="Google Analytics" name="google_analytics" >{{ !is_null(old("google_analytics")) ? old("google_analytics") : empty($generalsettings["google_analytics"]) ? '' : $generalsettings["google_analytics"] }}</textarea>
			  
			</div>
		</div>
                    
                        @php
			$sel_date = is_null(old("date_format")) ? $generalsettings["date_format"] : old("date_format");
			$sel_time = is_null(old("time_format")) ? $generalsettings["time_format"] : old("time_format");
			@endphp
			<div class="clearfix"></div>
			<div class="basic-configuration-inner select-box">
				<h2>Date And Time</h2>
				<div class="form-group form-grouping @if($errors->has('date_format')) has-error @endif">
				  <label class="select-label" for="date_format">Date Format</label><br>
				  <select class="bg-input" id="date_format" name="date_format">
					<option value="">Please Select Date Format</option>
                                        @if (!empty($date_format_arr) && count($date_format_arr) > 0)
					@foreach( $date_format_arr as $key => $value )
						<option @if( $sel_date == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
					@endforeach
                                        @endif
				  </select>
				  @if($errors->has("date_format"))
					<span class="help-block">{{ $errors->first("date_format") }}</span>
				  @endif
				</div>
				
				<div class="form-group form-grouping @if($errors->has('time_format')) has-error @endif">
				  <label class="select-label" for="time_format">Time Format</label><br>
				  <select class="bg-input" id="time_format" name="time_format">
					<option value="">Please Select Time Format</option>
                                        @if (!empty($time_format_arr) && count($date_format_arr) > 0)
					@foreach( $time_format_arr as $key => $value )
						<option @if( $sel_time == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
					@endforeach
                                        @endif
				  </select>
				  @if($errors->has("time_format"))
					<span class="help-block">{{ $errors->first("time_format") }}</span>
				  @endif
				</div>
			</div>
                        <div class="clearfix"></div>
						
                    @php
			$sel_currency = is_null(old("selected_currency")) ? $generalsettings["selected_currency"] : old("selected_currency");
			@endphp
			<div class="basic-configuration-inner select-box">
				<h2>Currency</h2>
				<div class="form-group form-grouping">
				  <label class="select-label" for="selected_currency">Currency</label><br>
				  <select class="bg-input" id="date_format" name="selected_currency">
					<option value="">Please Select Currency</option>
                    @if (!empty($currency_arr) && count($currency_arr) > 0)
					@foreach( $currency_arr as $key => $value )
						<option @if( !empty($generalsettings["selected_currency"]) && $generalsettings["selected_currency"] == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
					@endforeach
                    @endif
				  </select>
				  @if($errors->has("date_format"))
					<span class="help-block">{{ $errors->first("date_format") }}</span>
				  @endif
				</div>

			</div> 
                        
		
		<button type="submit" class="btn btn-default save-btn gen-btn">SAVE</button>
	  </form>
	
	</div>
  </section>
  
@endsection

@section('footer-scripts')
  @if(session()->has('message'))
	<script>
	  var success = '{{ session()->get("message") }}';
	  show_success_container(success);
	</script>
  @endif
@endsection