@extends('admin.layouts.default_layout')
@section('content')
  <section class="configuration-links admin-title">
	<div class="container">
	  <h1 class="black">Video</h1>
	  <ul>
		<li class="{{ $active_tab == 'active'? 'active':'' }}"><a href="{{ route('admin.settings.general') }}">General</a></li>
		<li class="{{ $active_tab == 'configuration'? 'active':'' }}"><a href="{{ route('admin.settings.configuration') }}" >Configurations</a></li>
		<li class="{{ $active_tab == 'video'? 'active':'' }}"><a href="{{ route('admin.settings.video') }}">Video</a></li>
	  </ul>
         
	</div>
  </section>

  <div class="clearfix"></div>
  <section class="lime-bg paddingComm70">
	<div class="container">
	  
	  <form class="form-inline" action="{{ route('admin.settings.updatevideosetting') }}" method="POST">
	    {{ csrf_field() }}
	    <div class="basic-configuration-inner select-box">
			<h2>Video Setting</h2>
		
			<div class="form-group form-grouping">
			  <label class="select-label" for="video_resolution">Resolution</label><br>
			  <select class="bg-input" id="video_resolution" name="video_resolution">
                            <option value="">Please Select</option>
                            @if (!empty($resolutionarr) && count($resolutionarr) > 0)
                            @foreach( $resolutionarr as $value )
                                    <option value="{{ $value }}" @if (!empty($generalsettings['video_resolution']) && $generalsettings['video_resolution']==$value) selected @endif >{{ $value }}</option>
                            @endforeach
                            @endif
                        </select>
			</div>
			
			<div class="form-group form-grouping">
			  <label class="select-label" for="video_resolution">Compression</label><br>
			  <select class="bg-input" id="video_compression" name="video_compression">
                            <option value="">Please Select</option>
                            @if (!empty($compressionrr) && count($compressionrr) > 0)
                            @foreach( $compressionrr as $value )
                                    <option value="{{ $value }}"  @if (!empty($generalsettings['video_compression']) && $generalsettings['video_compression']==$value) selected @endif >{{ $value }}</option>
                            @endforeach
                            @endif
                        </select>
			</div>
                        
                        <div class="form-group form-grouping">
                            <label class="select-label" for="video_size">Size</label><br>
			  <input type="text" class="bg-input" id="video_size" placeholder="Video Size" name="video_size" value='{{ !empty($generalsettings["video_size"]) ? $generalsettings["video_size"]:(is_null(old("video_size")) ? old("video_size") :'')   }}' />
			
			</div>
			
			
		</div>
		
		<div class="clearfix"></div>
	
                        
		
		<button type="submit" class="btn btn-default save-btn gen-btn">SAVE</button>
	  </form>
	
	</div>
  </section>
  
@endsection

@section('footer-scripts')
  @if(session()->has('message'))
	<script>
	  var success = '{{ session()->get("message") }}';
	  show_success_container(success);
          
         
	</script>
  @endif
  
@endsection