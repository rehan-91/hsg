@extends('admin.layouts.default_layout')
@section('content')
  <section class="configuration-links admin-title">
	<div class="container">
	  <h1 class="black">Configurations</h1>
	  <ul>
		<li class="{{ $active_tab == 'active'? 'active':'' }} black"><a href="{{ route('admin.settings.general') }}">General</a></li>
		<li class="{{ $active_tab == 'configuration'? 'active':'' }} black"><a href="{{ route('admin.settings.configuration') }}" >Configurations</a></li>
		<li class="{{ $active_tab == 'video'? 'active':'' }} black"><a href="{{ route('admin.settings.video') }}">Video</a></li>
	  </ul>
	</div>
  </section>

  <div class="clearfix"></div>
  <section class="lime-bg paddingComm70">
	<div class="container">
	  
	  <form class="form-inline" action="{{ route('admin.settings.updateconfigsetting') }}" method="POST">
	    {{ csrf_field() }}
	    <div class="basic-configuration-inner select-box">
			<h2>Ad Image Setting</h2>
		
			<div class="form-group form-grouping @if($errors->has('ad_image_thumb_width')) has-error @endif">
			  <label class="select-label" for="ad_image_thumb_width">Ad Image Thumb Width</label><br>
			  <input type="text" class="bg-input" id="ad_image_thumb_width" placeholder="Ad Image Thumb Width" name="ad_image_thumb_width" value='{{  !empty($generalsettings["ad_image_thumb_width"]) ? $generalsettings["ad_image_thumb_width"]:(is_null(old("ad_image_thumb_width")) ? old("ad_image_thumb_width"):'') }}' />
			  @if($errors->has("master_agency_name"))
				<span class="help-block">{{ $errors->first("ad_image_thumb_width") }}</span>
			  @endif
			</div>
			
			<div class="form-group form-grouping @if($errors->has('ad_image_thumb_height')) has-error @endif">
			  <label class="select-label" for="ad_image_thumb_height">Ad Image Thumb Height</label><br>
			  <input type="text" class="bg-input" id="ad_image_thumb_height" placeholder="Ad Image Thumb Height" name="ad_image_thumb_height" value='{{ !empty($generalsettings["ad_image_thumb_height"]) ? $generalsettings["ad_image_thumb_height"]:(is_null(old("ad_image_thumb_height")) ? old("ad_image_thumb_height"):'')  }}' />
			  @if($errors->has("master_agency_email"))
				<span class="help-block">{{ $errors->first("ad_image_thumb_height") }}</span>
			  @endif
			</div>
                        
                        <div class="form-group form-grouping @if($errors->has('ad_image_quality')) has-error @endif">
			  <label class="select-label" for="ad_image_quality">Ad Image Thumb Quality</label><br>
			  <input type="text" class="bg-input" id="ad_image_thumb_height" placeholder="Ad Image Quality" name="ad_image_quality" value='{{  !empty($generalsettings["ad_image_quality"]) ? $generalsettings["ad_image_quality"]:(is_null(old("ad_image_quality")) ? old("ad_image_quality"):'')  }}' />
			  @if($errors->has("master_agency_email"))
				<span class="help-block">{{ $errors->first("ad_image_quality") }}</span>
			  @endif
			</div>
                        
                        <div class="form-group form-grouping @if($errors->has('ad_large_image_width')) has-error @endif">
			  <label class="select-label" for="ad_large_image_width">Ad Large Image Width</label><br>
			  <input type="text" class="bg-input" id="ad_large_image_width" placeholder="Ad  Large Image Width" name="ad_large_image_width" value='{{  !empty($generalsettings["ad_large_image_width"]) ? $generalsettings["ad_large_image_width"]:(is_null(old("ad_large_image_width")) ? old("ad_large_image_width"):'')  }}' />
			  @if($errors->has("master_agency_email"))
				<span class="help-block">{{ $errors->first("ad_large_image_width") }}</span>
			  @endif
			</div>
			                <div class="form-group form-grouping @if($errors->has('ad_large_image_height')) has-error @endif">
			  <label class="select-label" for="ad_large_image_height">Ad Large Image Height</label><br>
			  <input type="text" class="bg-input" id="ad_large_image_height" placeholder="Ad Large Image Height" name="ad_large_image_height" value='{{  !empty($generalsettings["ad_large_image_height"]) ? $generalsettings["ad_large_image_height"]:(is_null(old("ad_large_image_height")) ? old("ad_large_image_height"):'')  }}' />
			  @if($errors->has("master_agency_email"))
				<span class="help-block">{{ $errors->first("ad_large_image_height") }}</span>
			  @endif
			</div>
                        <div class="form-group form-grouping @if($errors->has('ad_large_image_quality')) has-error @endif">
			  <label class="select-label" for="ad_large_image_quality">Ad Large Image Quality</label><br>
			  <input type="text" class="bg-input" id="ad_large_image_quality" placeholder="Ad Large Image Quality" name="ad_large_image_quality" value='{{  !empty($generalsettings["ad_large_image_quality"]) ? $generalsettings["ad_large_image_quality"]:(is_null(old("ad_large_image_quality")) ? old("ad_large_image_quality"):'')  }}' />
			  @if($errors->has("master_agency_email"))
				<span class="help-block">{{ $errors->first("ad_large_image_quality") }}</span>
			  @endif
			</div>
        
                        
			
			
		</div>
		
		
		
		<div class="clearfix"></div>
		<div class="basic-configuration-inner select-box">
			<h2>Email Notification Setting</h2>
                        <div class="form-group form-grouping">
			 <label class="select-label" for="from">Mail Protocol</label><br>
			 <select class="bg-input" id="mail_protocol" name="mail_protocol" onchange="dispalyConfig(this.value)">
                            <option value="mail" @if( !empty($generalsettings["mail_protocol"]) && $generalsettings["mail_protocol"] =='mail' ) selected  @endif >Mail</option>
                            <option value="smtp"@if( !empty($generalsettings["mail_protocol"]) && $generalsettings["mail_protocol"] =='smtp' ) selected  @endif >SMTP</option>
                         </select>
			</div>
                        
                         <div id="smtp_config">
                            
                          <div class="form-group form-grouping" > 
			  <label class="select-label" for="">From Email</label><br>
			  <input type="text" class="bg-input" id="from_email" placeholder="From Email" name="from_email" value='{{ !empty($generalsettings["from_email"]) ? $generalsettings["from_email"]:(!is_null(old("from_email")) ? old("from_email"):'') }}' />
			 
			</div>
                         <div class="form-group form-grouping">
			  <label class="select-label" for="">From Name</label><br>
			  <input type="text" class="bg-input" id="from_name" placeholder="From Name" name="from_name" value='{{  !empty($generalsettings["from_name"]) ? $generalsettings["from_name"]:(!is_null(old("from_name")) ? old("from_name") :'') }}' />
			 
			</div>   
			<div class="form-group form-grouping">
			  <label class="select-label" for="">SMTP Host</label><br>
			  <input type="text" class="bg-input" id="smtp_host" placeholder="SMTP Host" name="smtp_host" value='{{ !empty($generalsettings["smtp_host"]) ?$generalsettings["smtp_host"]:(!is_null(old("smtp_host")) ? old("smtp_host") : '') }}' />
			 
			</div>
                            <div class="form-group form-grouping">
			  <label class="select-label" for="">SMTP Username</label><br>
			  <input type="text" class="bg-input" id="smtp_host" placeholder="SMTP Username" name="smtp_username" value='{{!empty($generalsettings["smtp_username"]) ? $generalsettings["smtp_username"]: (!is_null(old("smtp_username")) ? old("smtp_username") : '') }}' />
			 
                            </div>
                        
                          <div class="form-group form-grouping">
			  <label class="select-label" for="">SMTP Password</label><br>
			  <input type="text" class="bg-input" id="smtp_password" placeholder="SMTP Password" name="smtp_password" value='{{ !empty($generalsettings["smtp_password"]) ?$generalsettings["smtp_password"]:(!is_null(old("smtp_password")) ? old("smtp_password") : '') }}' />
			 
			</div>
                             <div class="form-group form-grouping">
			  <label class="select-label" for="">SMTP Port</label><br>
			  <input type="text" class="bg-input" id="smtp_port" placeholder="SMTP Port" name="smtp_port" value='{{ !empty($generalsettings["smtp_port"]) ? $generalsettings["smtp_port"]:(!is_null(old("smtp_port")) ? old("smtp_port") : '') }}' />
			 
			</div>
                        </div>
                        <div id="mail_config">
                        <div class="form-group form-grouping">
			  <label class="select-label" for="">From Email</label><br>
			  <input type="text" class="bg-input" id="from_email" placeholder="From Email" name="from_email" value='{{ !empty($generalsettings["from_email"]) ? $generalsettings["from_email"]:(!is_null(old("from_email")) ? old("from_email") : '') }}' />
			 
			</div>
                         <div class="form-group form-grouping">
			  <label class="select-label" for="">From Name</label><br>
			  <input type="text" class="bg-input" id="from_name" placeholder="From Name" name="from_name" value='{{ !empty($generalsettings["from_name"]) ? $generalsettings["from_name"]:(!is_null(old("from_name")) ? old("from_name") : '') }}' />
			 
			</div>
                        </div>
		</div>
                
                        <div class="clearfix"></div>
			<div class="basic-configuration-inner select-box">
				<h2>Payment Gateway</h2>
				<div class="form-group form-grouping">
				  
				</div>

			</div> 
                        
		
		<button type="submit" class="btn btn-default save-btn gen-btn">SAVE</button>
	  </form>
	
	</div>
  </section>
  
@endsection

@section('footer-scripts')
  @if(session()->has('message'))
	<script>
	  var success = '{{ session()->get("message") }}';
	  show_success_container(success);
          
         
	</script>
  @endif
  <script>
       function dispalyConfig(value){
              if(value == 'mail'){
                  $("#smtp_config").css('display', 'none');
                  $("#mail_config").css('display', 'block');
              }else{
                  $("#smtp_config").css('display', 'block');
                  $("#mail_config").css('display', 'none');
              }
          }
          
          $(document).ready(function(){
              var mail_protocol= '{{ $generalsettings["mail_protocol"] }}';
             
              if(mail_protocol.trim() == 'mail'){
             
                   $("#smtp_config").css('display', 'none');
                  $("#mail_config").css('display', 'block');
              }else{
                   
                  $("#smtp_config").css('display', 'block');
                  $("#mail_config").css('display', 'none');
              }
          })
   </script>
@endsection