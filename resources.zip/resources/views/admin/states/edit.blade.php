@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">State  / Edit </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To States" href="{{ route('admin.states.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.states.update', [$data->id])}}" method="POST">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<h2>Country Details</h2>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('state_name')) has-error @endif">
					<label class="select-label" for="state_name">State Name</label><br>
                    <input type="text" id="name" name="state_name" class="bg-input" placeholder="Please Enter State Name" value='{{ $data->name }}' />
					@if($errors->has("state_name"))
						<span class="help-block">{{ $errors->first("state_name") }}</span>
					@endif
				</div>
				
				<div class="input-box @if($errors->has('country_id')) has-error @endif">
                                    <label class="select-label" for="country_id">Country</label><br>
                                    <select name="country_id"  class="bg-input">
                                    @foreach($countries as $c)
                                    <option value="{{ $c->id }}" @if( $c->id == $data->country_id ) selected  @endif >{{ $c->country_name }}</option>
                                    @endforeach
                                    </select>
                                      @if($errors->has("country_id"))
                                            <span class="help-block">{{ $errors->first("country_id") }}</span>
                                      @endif
				</div>
                            <div class="input-box">
                                    <label class="select-label" for="">Notice</label><br>
                                      <textarea name="notice" id="notice" class="bg-input">{{ $data->notice }}</textarea>
                                 </div>
                                <div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if($data->status == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
                             
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.states.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
@endsection