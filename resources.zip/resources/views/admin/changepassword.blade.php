@extends('admin.layouts.default_layout')

@section('content')
  @php
	$default_locale = app()->getLocale();
  @endphp
  <section class="grey-bg paddingComm70 text-center">
	  <div class="container">
		<div class="login-account">
			
			<h3>Change Password</h3>
			
			@if (\Session::has('message'))
			  <div class="alert alert-success">
				{!! \Session::get('message') !!}
			  </div>
			@endif
			
			<form id="change_password_form" name="change_password_form" action="{{ route('admin.cPasswordSave') }}" method="POST">
			  {{ csrf_field() }}
			  
			  <div class="input-box @if($errors->has('old_password')) has-error @endif">
				<input type="password" name="old_password" id="old_password" placeholder="{!! trans('translations.frontend.password_field_placeholder') !!}" class="bg-input" >
				@if($errors->has("old_password"))
				  <span class="help-block">{{ $errors->first("old_password") }}</span>
				@endif
			  </div>
			  <div class="input-box @if($errors->has('new_password')) has-error @endif">
				<input type="password" name="new_password" id="new_password" placeholder="{!! trans('translations.frontend.new_password_field_placeholder') !!}" class="bg-input" >
				@if($errors->has("new_password"))
				  <span class="help-block">{{ $errors->first("new_password") }}</span>
				@endif
			  </div>
			  <div class="input-box @if($errors->has('confirm_new_password')) has-error @endif">
				<input type="password" name="confirm_new_password" id="confirm_new_password" placeholder="{!! trans('translations.frontend.confirm_password_field_placeholder') !!}" class="bg-input">
				@if($errors->has("confirm_new_password"))
					<span class="help-block">{{ $errors->first("confirm_new_password") }}</span>
				@endif
			  </div>
			  <div class="clearfix"></div>
              
			  <button type="submit" class="Loginblue-btn">{!! trans('translations.frontend.form_submit') !!}</button>
			</form>
		</div>
	  </div>
	</section>
@endsection
