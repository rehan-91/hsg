@extends('admin.layouts.default_layout')
@section('header-css')
<link href="{{ asset('admin-vendors/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
@endsection
@section('header-scripts')
    <script src="{{ asset('admin-vendors/js/jquery.dataTables.js') }}"></script>
@endsection

@section('header')
	@section('header')
	<section class="manage-training admin-title paddingComm45">
	  <div class="container">
		<div class="row">
		  <div class="col-md-6 col-sm-6 col-xs-8 borderWdth">
			<h1 class="blue">Blogs</h1>
			<h2>Create/Update Blogs</h2>
		  </div>
		
		  <div class="col-md-6 col-sm-6 col-xs-4 borderWdth">
			<a class="adminBorder-btn plus-icon" title="Add blog" href="{{ route('admin.blog.create') }}">Add Blog</a>
		  </div>
		</div>
	  </div>
	</section>
@endsection

@endsection

@section('content')
  @if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
  @endif
  
  <section class="manage-quetion lime-bg table-width paddingComm45">
	<div class="container">
	  <div class="table-responsive search-gapTop paddR0 admin-table table-line-hgt">
		<table class="table" id="content-table">
			<thead>
				<tr>
					<th>Title</th>
					<th>URL Slug</th>
					<th>Category</th>
					<th>Tags</th>
					<th>Added On</th>
                    <th>Status</th>
					<th>&nbsp;</th>
				</tr>
			</thead>
		</table>
	  </div>
	</div>
  </section>
@endsection

@section('footer-scripts')
<script>
	jQuery(function() {
		jQuery('#content-table').DataTable({
			"autoWidth": false,
                        stateSave: true,
			language: {
				searchPlaceholder: "Search through Plan title",
				"paginate": {
					"first": "&verbar ;&lt;",
					"last": "&gt; &verbar;",
					"next": "&gt;",
					"previous": "&lt;"
				},
				"lengthMenu": " _MENU_ ",
				"info": "_START_ - _END_ of _TOTAL_ items",
				"infoEmpty": "0 - 0 of 0 items",
				"search": "search",
                                
                              
			},
			order: [],
			"dom": 'ftilrp',
			processing: true,
			serverSide: true,
                        
			ajax: '{!! route('admin.blog.data') !!}',
			columns: [
				{ data: 'title', name: 'title' },
				{ data: 'page_slug', name: 'page_slug' },
				{ data: 'blog_category', name: 'blog_category' },
				{ data: 'blog_tags', name: 'blog_tags' },
				{ data: 'created_at', name: 'created_at' },
				{ data: 'blog_status', name: 'blog_status' },
				{ data: 'action', name: 'action' }
			],
			"columnDefs": [
				{ "orderable": false, "targets": [5,6] }
		    ]
		});
	});
</script>
@endsection