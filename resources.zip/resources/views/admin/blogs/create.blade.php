@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Blog / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Blogs" href="{{ route('admin.blog.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.blog.store')}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('blog_title')) has-error @endif">
					<label class="select-label" for="name">Title</label><br>
                    <input type="text" id="name" name="blog_title" class="bg-input" placeholder="Please Enter Title" value='{{ is_null(old("blog_title")) ? '' : old("blog_title") }}' />
					@if($errors->has("blog_title"))
						<span class="help-block">{{ $errors->first("blog_title") }}</span>
					@endif
				</div>
				
                    <div class="input-box">
					<label class="select-label" for="name">Ctegoory</label><br>
                    <input type="text" id="name" name="blog_category" class="bg-input" placeholder="Please Enter Blog Category" value='{{ is_null(old("blog_category")) ? '' : old("blog_category") }}' />
					
				</div>            
				<div class="input-box margR0">
					<label class="select-label" for="name">Tags</label><br>
                    <input type="text" id="name" name="blog_tags" class="bg-input" placeholder="Please Enter Blog Tags" value='{{ is_null(old("blog_category")) ? '' : old("blog_category") }}' />
					
				</div>
                              <div  class="textarea-box">
					<label class="select-label" for="contact" >Description</label>
                                        <textarea name='blog_desc' class="bg-input long_description">{{ !is_null(old("blog_desc")) ?old("blog_desc") :''}}</textarea>
				@if($errors->has("blog_desc"))
						<span class="help-block" style="color:red;">{{ $errors->first("blog_desc") }}</span>
					@endif
				</div>
                                
				<div class="input-box ">
					<label class="select-label" for="contact" >Meta Title</label>
                                        <input type="text" name='blog_meta_title'  class="bg-input" value='{{ !is_null(old("blog_meta_title")) ?old("blog_meta_title") :""}}'>
				</div>
                                <div class="input-box margR0">
					<label class="select-label" for="contact">Meta Keywords</label>
                                        <input type="text" name='blog_meta_keywords'class="bg-input"  value="{{ !is_null(old('blog_meta_keywords')) ?old('blog_meta_keywords') :''}}">
				</div>
                            
                              <div class="textarea-box">
                                            <label class="select-label" for="contact">Meta Description</label>
                                        <textarea name='blog_meta_description' class="bg-input">{{ !is_null(old('blog_meta_description')) ?old('blog_meta_description') :''}}</textarea>
				</div>
				
				
				    <div class="input-box @if($errors->has('user_id')) has-error @endif">
                                    <label class="select-label" for="from">Posted By</label><br>
                                    <select class="bg-input form-control" id="user_id" name="user_id">
                                        <option value="">Select</option>
                                        @foreach($users as $u)
                                        <option value="{{$u['id']}}" @if( $u['id'] ==  old('user_id')) selected  @endif >{{$u['email']}}</option>
                                       @endforeach
                                    </select>
                                    @if($errors->has("user_id"))
                                <span class="help-block">{{ $errors->first("user_id") }}</span>
                                @endif
                            </div>    
				  
				  
				  
                                <div class="input-box margR0">
					<label class="select-label" for="contact">Sort Order</label>
                                        <input type="number" min="0" name='sort_order'class="bg-input"  value="{{ !is_null(old('sort_order')) ?old('sort_order') :''}}">
				</div>
                                          
			<div class="input-box">
					<label class="select-label" for="contact">Featured Image</label>
                                        <input type="file" name="blog_featured_image">
				</div>	    
                                
                            <div class="clearfix"></div>
                                <div class="input-box permissionTable">
                                    <label class="select-label margR0" for="status">Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if (!is_null(old("status")) && old("status") == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
				
                              
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.blog.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
<script>
jQuery(function() {
$('#user_id').select2();
           jQuery('.long_description').summernote({

             height:300,

           });

       });
</script>
@endsection