@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Country  / Edit </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Countries" href="{{ route('admin.countries.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.countries.update', [$data->id])}}" method="POST">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<h2>Country Details</h2>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('country_name')) has-error @endif">
					<label class="select-label" for="country_name">Country Name</label><br>
                    <input type="text" id="name" name="country_name" class="bg-input" placeholder="Please Enter Country Name" value='{{ $data->country_name }}' />
					@if($errors->has("country_name"))
						<span class="help-block">{{ $errors->first("country_name") }}</span>
					@endif
				</div>
				
				<div class="input-box margR0 @if($errors->has('country_sort_name')) has-error @endif">
					<label class="select-label" for="country_sort_name">Country Sort Name</label>
                    <input type="text" id="base_price" name="country_sort_name" class="bg-input" placeholder="Please Enter Country Sort Name" value='{{ $data->country_sort_name }}' />
					@if($errors->has("country_sort_name"))
						<span class="help-block">{{ $errors->first("country_sort_name") }}</span>
					@endif
				</div>
				
				
				<div class="input-box">
					<label class="select-label" for="contact">Country Phone Code</label>
                                        <input type="text" id="country_phone_code" name="country_phone_code" class="bg-input" placeholder="Please Enter Country Phone Code" value='{{ $data->country_phone_code }}' />
					
				</div>
                            
                                <div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden"  @if($data->status == 1) checked @endif > 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
                             
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.countries.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
@endsection