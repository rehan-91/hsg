@extends('admin.layouts.default_layout')
@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Individual Ad  / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Ads" href="#">Back</a>
		</div>
    </div>
@endsection
@section('content')
<div id="detail-section" class="step_1">
    
    <form  action="" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
        {{ csrf_field() }}
        <section class="lime-bg paddingComm70">
            <div class="container">
                <h2 id="ad-heading">Details</h2>


                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Contact</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <div class="input-box @if($errors->has('name')) has-error @endif">
                                <label class="select-label" for="name">Title</label><br>
                                <input type="text" id="name" name="name" class="bg-input" placeholder="Please Enter Name" value='{{ old("name")}}' />
                                @if($errors->has("name"))
                                <span class="help-block">{{ $errors->first("name") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('email')) has-error @endif">
                                <label class="select-label" for="email">Email</label><br>
                                <input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email" value='{{ old("email")}}' />
                                @if($errors->has("name"))
                                <span class="help-block">{{ $errors->first("email") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('phone')) has-error @endif">
                                <label class="select-label" for="phone">Email</label><br>
                                <input type="text" id="email" name="phone" class="bg-input" placeholder="Please Enter Phone" value='{{ old("phone")}}' />
                                @if($errors->has("name"))
                                <span class="help-block">{{ $errors->first("phone") }}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Personal</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                                <tbody>

                                    <tr class="text_display">
                                        <td>
                                            <input type="radio" name="personal" value="natural">
                                            <label for="check_m_perm_2">Natural</label>

                                        </td>

                                        <td>
                                            <input type="radio" name="personal" value="Trim">
                                            <label for="check_m_perm_3">Trim</label>

                                        </td>

                                        <td>
                                            <input type="radio" name="personal" value="Fully Waxed">
                                            <label for="check_m_perm_4">Fully Waxed</label>

                                        </td>

                                        <td>
                                            <input type="radio" name="personal" value="Landing strip">
                                            <label for="check_m_perm_5"> Landing strip</label>

                                        </td>
                                        <td>
                                            <input type="radio" name="personal" value="Fully Shaved">
                                            <label for="check_m_perm_5"> Fully Shaved</label>

                                        </td>
                                        <td>
                                            <input type="radio" name="personal" value="IPL/Laser">
                                            <label for="" >IPL/Laser</label>

                                        </td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Physical Attribute</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="input-box @if($errors->has('age')) has-error @endif">
                                <label class="select-label" for="age">Age</label><br>

                                <select class="bg-input" id="user_type_id" name="age">
                                    <option>25</option>
                                    <option>30</option>
                                    <option>32</option>
                                    <option>34</option>
                                </select>
                                @if($errors->has("age"))
                                <span class="help-block">{{ $errors->first("age") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('bust_size')) has-error @endif">
                                <label class="select-label" for="bust_size">Bust size</label><br>
                                <select class="bg-input" id="user_type_id" name="bust_size">
                                    <option>30</option>
                                    <option>32</option>
                                    <option>34</option>
                                    <option>36</option>
                                </select>
                                @if($errors->has("age"))
                                <span class="help-block">{{ $errors->first("bust_size") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('gender')) has-error @endif">
                                <label class="select-label" for="gender">Gender</label><br>
                                <select class="bg-input" id="user_type_id" name="gender">
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                                @if($errors->has("age"))
                                <span class="help-block">{{ $errors->first("gender") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('weight')) has-error @endif">
                                <label class="select-label" for="weight">Weight</label><br>

                                <select class="bg-input" id="weight" name="weight">
                                    <option>40</option>
                                    <option>45</option>
                                </select>
                                @if($errors->has("weight"))
                                <span class="help-block">{{ $errors->first("weight") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('height')) has-error @endif">
                                <label class="select-label" for="height">Height</label><br>
                                <select class="bg-input" id="height" name="height">
                                    <option>4 feet</option>
                                    <option>5 feet</option>
                                </select>
                                @if($errors->has("height"))
                                <span class="help-block">{{ $errors->first("height") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('nationality')) has-error @endif">
                                <label class="select-label" for="nationality">Nationality</label><br>
                                <select class="bg-input" id="nationality" name="nationality">
                                    <option>Indian</option>
                                    <option>Pakistani</option>
                                    <option>African</option>
                                </select>
                                @if($errors->has("nationality"))
                                <span class="help-block">{{ $errors->first("nationality") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('Orientation')) has-error @endif">
                                <label class="select-label" for="orientation">Orientation</label><br>
                                <select class="bg-input" id="orientation" name="orientation">
                                    <option>12</option>
                                    <option>22</option>
                                    <option>25</option>
                                </select>
                                @if($errors->has("orientation"))
                                <span class="help-block">{{ $errors->first("orientation") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('eye_color')) has-error @endif">
                                <label class="select-label" for="eye_color">Eye Color</label><br>
                                <select class="bg-input" id="eye_color" name="eye_color">
                                    <option>Red</option>
                                    <option>Green</option>
                                    <option>Yellow</option>
                                </select>
                                @if($errors->has("eye_color"))
                                <span class="help-block">{{ $errors->first("eye_color") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('aukland_newmarket')) has-error @endif">
                                <label class="select-label" for="aukland_newmarket">Aukland Newmarket</label><br>
                                <select class="bg-input" id="aukland_newmarket" name="aukland_newmarket">
                                    <option>Red</option>
                                    <option>Green</option>
                                    <option>Yellow</option>
                                </select>
                                @if($errors->has("aukland_newmarket"))
                                <span class="help-block">{{ $errors->first("aukland_newmarket") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('hair_color')) has-error @endif">
                                <label class="select-label" for="hair_color">Hair Color</label><br>
                                <select class="bg-input" id="hair_color" name="hair_color">
                                    <option>Red</option>
                                    <option>Green</option>
                                    <option>Yellow</option>
                                </select>
                                @if($errors->has("hair_color"))
                                <span class="help-block">{{ $errors->first("hair_color") }}</span>
                                @endif
                            </div>
                            <div class="clearfix"></div>
                            <div class="input-box @if($errors->has('about')) has-error @endif">
                                <label class="select-label" for="about">About Yourself</label><br>
                                <textarea id="about_yourself" name="about_yourself" class="bg-input"></textarea>
                                @if($errors->has("about"))
                                <span class="help-block">{{ $errors->first("about") }}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Body Type</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                                <tbody>

                                    <tr class="text_display">
                                        <td>
                                            <input type="checkbox" name="body_type" value="Slim">
                                            <label for="check_m_perm_2">Slim</label>

                                        </td>

                                        <td>
                                            <input type="checkbox" name="body_type" value="Curvy">
                                            <label for="check_m_perm_3">Curvy</label>

                                        </td>

                                        <td>
                                            <input type="checkbox" name="body_type" value="Athlete">
                                            <label for="check_m_perm_4">Athlete</label>

                                        </td>

                                        <td>
                                            <input type="checkbox" name="body_type" value="BBW">
                                            <label for="check_m_perm_5">BBW</label>

                                        </td>


                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Tattoos(Optional)</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                                <tbody>

                                    <tr class="text_display">
                                        <td>
                                            <input type="radio" name="tattoos" value="Yes">
                                            <label for="check_m_perm_2">Yes</label>

                                        </td>

                                        <td>
                                            <input type="radio" name="tattoos" value="No">
                                            <label for="check_m_perm_3">No</label>

                                        </td>




                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Piercing(Optional)</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                                <tbody>

                                    <tr class="text_display">
                                        <td>
                                            <input type="checkbox" name="piercing[]" value="None">
                                            <label for="check_m_perm_2">None</label>

                                        </td>

                                        <td>
                                            <input type="checkbox" name="piercing[]" value="Ears">
                                            <label for="check_m_perm_3">Ears</label>

                                        </td>
                                        <td>
                                            <input type="checkbox" name="piercing[]" value="Nipples">
                                            <label for="check_m_perm_3">Nipples</label>

                                        </td>
                                        <td>
                                            <input type="checkbox" name="piercing[]" value="Genitals">
                                            <label for="check_m_perm_3">Genitals</label>

                                        </td>
                                        <td>
                                            <input type="checkbox" name="piercing[]" value="Navel">
                                            <label for="check_m_perm_3">Navel</label>

                                        </td>
                                        <td>
                                            <input type="checkbox" name="piercing[]" value="Tongue">
                                            <label for="check_m_perm_3">Tongue</label>

                                        </td>



                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <input name="next" value="Next" type="button" class="admin-add btn-admin" id="step_1">

                        </div>
                    </div>


                </div>



            </div>
        </section>

    </form>
</div>
<div class="step_2" style="display:none;">
    <section class="lime-bg paddingComm70">
        <div class="container">
             <h2 id="ad-heading">Services</h2>
            <div class="basic-configuration-inner select-box admin-create-update">
                <h2>Available For</h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                            <tbody>

                                <tr class="text_display">
                                    <td>
                                        <input type="checkbox" name="available_for[]" value="Women">
                                        <label for="check_m_perm_2">Women</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="available_for[]" value="Men">
                                        <label for="check_m_perm_3">Men</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="available_for[]" value="Couples">
                                        <label for="check_m_perm_4">Couples</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="available_for[]" value="Clients with Disabilities">
                                        <label for="check_m_perm_5">Clients with Disabilities</label>

                                    </td>

                                </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="basic-configuration-inner select-box admin-create-update">
                <h2>Service Type </h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                            <tbody>

                                <tr class="text_display">
                                    <td>
                                        <input type="checkbox" name="service_type[]" value="In-Call">
                                        <label for="check_m_perm_2">In-Call</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="service_type[]" value="Out-Call">
                                        <label for="check_m_perm_3">Out-Call</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="service_type[]" value="Overnight">
                                        <label for="check_m_perm_4">Overnight</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="service_type[]" value="Dinner Date">
                                        <label for="check_m_perm_5">Dinner Date</label>

                                    </td>
                                    <td>
                                        <input type="checkbox" name="service_type[]" value="Available For Travel">
                                        <label for="check_m_perm_5">Available For Travel</label>

                                    </td>

                                </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="basic-configuration-inner select-box admin-create-update">
                <h2>Service Available </h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                            <tbody>

                                <tr class="text_display">
                                    <td>
                                        <input type="checkbox" name="service_available[]" value="Escort(Full Service)">
                                        <label for="check_m_perm_2">Escort(Full Service)</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="service_available[]" value="Sensual Massage">
                                        <label for="check_m_perm_3">Sensual Massage</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="service_available[]" value="BDSM/Fetish">
                                        <label for="check_m_perm_4">BDSM/Fetish</label>

                                    </td>

                                    <td>
                                        <input type="checkbox" name="service_available[]" value="Striper">
                                        <label for="check_m_perm_5">Striper</label>

                                    </td>
                                    <td>
                                        <input type="checkbox" name="service_type[]" value="Tantaric Massage">
                                        <label for="check_m_perm_5">Tantaric Massage</label>

                                    </td>

                                </tr>

                            </tbody>
                        </table>
                        <br><br><br>
                        <div class="textarea-box">
                            <label class="select-label" for="service_description">Descripe Your Service</label>
                            <textarea id="service_description" name="service_description" class="bg-input" placeholder="Please Enter Phone" /></textarea>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="basic-configuration-inner admin-create-update">
                <h2>Working Hours</h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <table class="text_display permissionTableCmm add-roletable permissionTable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                            <tbody>

                                <tr class="add-userroles" colspan="1">
                                    <td>
                                        Monday
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_monday_from" class="form-control" name="wh_perm_monday_from">
                                            <option id="#" value="0">From</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_monday_to" class="form-control" name="wh_perm_monday_to">
                                            <option id="#" value="0">To</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr class="add-userroles" colspan="1">
                                    <td>
                                        Tuesday
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_tuesday_from" class="form-control" name="wh_perm_tuesday_from">
                                            <option id="#" value="0">From</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_tuesday_to" class="form-control" name="wh_perm_tuesday_to">
                                            <option id="#" value="0">To</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr class="add-userroles" colspan="1">
                                    <td>
                                        Wednesday
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_wednesday_from" class="form-control" name="wh_perm_wednesday_from">
                                            <option id="#" value="0">From</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_wednesday_to" class="form-control" name="wh_perm_wedneaday_to">
                                            <option id="#" value="0">To</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr class="add-userroles" colspan="1">
                                    <td>
                                        Thursday
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_thrusday_from" class="form-control" name="wh_perm_thrusday_from">
                                            <option id="#" value="0">From</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_thrusday_to" class="form-control" name="wh_perm_thrusday_to">
                                            <option id="#" value="0">To</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr class="add-userroles" colspan="1">
                                    <td>
                                        Friday
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_friday_from" class="form-control" name="wh_perm_friday_from">
                                            <option id="#" value="0">From</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_friday_to" class="form-control" name="wh_perm_friday_to">
                                            <option id="#" value="0">To</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr class="add-userroles" colspan="1">
                                    <td>
                                        Saturday
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_saturday_from" class="form-control" name="wh_perm_saturday_from">
                                            <option id="#" value="0">From</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_saturday_to" class="form-control" name="wh_perm_saturday_to">
                                            <option id="#" value="0">To</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr class="add-userroles" colspan="1">
                                    <td>
                                        Sunday
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_sunday_from" class="form-control" name="wh_perm_sunday_from">
                                            <option id="#" value="0">From</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<select id="wh_perm_sunday_to" class="form-control" name="wh_perm_sunday_to">
                                            <option id="#" value="0">To</option>
                                        </select>
                                    </td>
                                </tr>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="basic-configuration-inner admin-create-update">
                <h2>Rates</h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <table class="text_display permissionTableCmm add-roletable permissionTable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                            <tbody>

                                <tr class="add-userroles services_rates" colspan="1">

                                    <td>
                                        &nbsp;<select id="rate_perm_20min" class="form-control" name="rate_perm_20min">
                                            <option id="#" value="0">20 Minutes</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;<input type="text" id="rate_perm_charges_20min" class="form-control" name="rate_perm_charges_20min" placeholder="Charges" >
                                    </td>
                                    <td>
                                        &nbsp;<input type="text" id="rate_perm_service_20min" class="form-control" name="rate_perm_service_20min" placeholder="Services" >
                                    </td>

                                    <td>
                                        <a href="javascript:void(0)" id="add-rate"  class="btn btn-success" onclick="addRate()"><i class="fa fa-plus"></i></a>

                                        <a href="javascript:void(0)" id="remove-rate"  class="btn btn-danger" onclick="removeRate()"><i class="fa fa-minus"></i></a>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="container">
            <div class="basic-configuration-inner select-box admin-create-update">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">

                        <input name="next" value="Previous" type="button" class="btn-danger btn-admin" id="prev_step_2">
                        <input name="next" value="Next" type="button" class="admin-add btn-admin" id="next_step_2">
                    </div>
                </div>

            </div> 
        </div>

    </section>
</div>

<div class="step_3" style="display:none;">
    <section class="lime-bg paddingComm70">

        <div class="container">
          <h2 id="ad-heading">Photos & videos</h2>


            <div class="basic-configuration-inner select-box admin-create-update">
                <h2>Photos & Videos</h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                       <label class="select-label" for="name">Photos</label><br>
				<div class="form-group">
                                    <input type="file" name="ad_photos" multiple>
				</div>
                       <br>
                          <label class="select-label" for="name">Videos</label><br>
				<div class="form-group">
                                    <input type="file" name="ad_videos" multiple>
				</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="basic-configuration-inner select-box admin-create-update">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">

                        <input name="next" value="Previous" type="button" class="btn-danger btn-admin" id="prev_step_3">
                        <input name="next" value="Next" type="button" class="admin-add btn-admin" id="next_step_3">
                    </div>
                </div>

            </div> 
        </div>



    </section>
</div>

<div class="step_4" style="display:none;">
    <section class="lime-bg paddingComm70">

        <div class="container">
          <h2 id="ad-heading">Touring</h2>


            <div class="basic-configuration-inner select-box admin-create-update">
                <h2>Touring</h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                       <label class="select-label" for="name">City</label><br>
				<div class="form-group">
                                  <select name="city">
								  <option value="">--Select City --</option>
								  <option value="">Faridabad</option>
								  </select>
				</div>
                     
                          <label class="select-label" for="name">Date</label><br>
				<div class="form-group">
                                    <input type="date" name="from_date">
				</div>
				 <label class="select-label" for="name">To Date</label><br>
				<div class="form-group">
					<input type="date" name="to_date">
				</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="basic-configuration-inner select-box admin-create-update">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">

                        <input name="next" value="Previous" type="button" class="btn-danger btn-admin" id="prev_step_4">
                        <input name="next" value="Next" type="button" class="admin-add btn-admin" id="next_step_4">
                    </div>
                </div>

            </div> 
        </div>



    </section>
</div>
<div class="step_5" style="display:none;">
    <section class="lime-bg paddingComm70">
    <div class="container">
       

        <h2 id="ad-heading">Plans</h2>
            <div class="basic-configuration-inner select-box admin-create-update">
                <h2>Contact</h2>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="input-box">
                         <label class="select-label" for="plan">Choose Plan</label><br>
                          
                        <select class="bg-input" id="plan" name="plan">
                                <option>4 Hours</option>
                                <option>5 Hours</option>
                                <option>7 Hours</option>
                            </select>
                        </div>
                        <div class="input-box margR0">
                            <label class="select-label" for="plan">Choose Time</label><br>
                         <select class="bg-input" id="plan" name="from" style="width:33%;">
                                <option>4 PM</option>
                             
                            </select>
                         <select class="bg-input" id="plan" name="to"  style="width:33%;">
                                <option>8 PM</option>
                             
                            </select>
                        </div>
                          <div class="input-box">
                        <label class="select-label" for="plan">Profile Boost</label><br>
                         <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                        <tbody>
                             
                             <tr class="text_display">
                                        <td>
                                            <input type="radio" name="tattoos" value="Slim">
                                              <label for="check_m_perm_2">Yes</label>
                                              
                                        </td>

                                         <td>
                                              <input type="radio" name="tattoos" value="Curvy">
                                              <label for="check_m_perm_3">No</label>
                                              
                                        </td>


                                      
                                        
                                        </tr>

                        </tbody>
                        </table>
                          </div>
                          <div class="input-box">
                           <label class="select-label" for="plan">Featured Profile</label><br>
                         <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                        <tbody>
                             
                             <tr class="text_display">
                                        <td>
                                            <input type="radio" name="tattoos" value="Slim">
                                              <label for="check_m_perm_2">Yes</label>
                                              
                                        </td>

                                         <td>
                                              <input type="radio" name="tattoos" value="Curvy">
                                              <label for="check_m_perm_3">No</label>
                                              
                                        </td>


                                      
                                        
                                        </tr>

                        </tbody>
                        </table>
                       
                    </div>
                </div>
            </div>
    </div>
    </div>
      <div class="container">
               <div class="basic-configuration-inner select-box admin-create-update">
         
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                         <input name="next" value="Previous" type="button" class="btn-danger btn-admin" id="prev_step_5">    
                        <input name="Submit" value="Finish" type="submit" class="admin-add btn-admin">
                        
                    </div>
                </div>


            </div>



    </div>
   
   
</section>
</div>
<script>
    $(document).ready(function () {
        $(".services_rates:first #remove-rate").css('display', 'none');
        $("#step_1").click(function () {
            $(".step_2").show();
            $(".step_1").hide();
              $(".step_3").hide();
               $(".step_4").hide();
               $(".step_5").hide();
              
        });


        $("#next_step_2").click(function () {
            $(".step_1").hide();
            $(".step_2").hide();
            $(".step_3").show();
              $(".step_4").hide();
              $(".step_5").hide();
            
        });
        $("#next_step_3").click(function () {
          
            $(".step_1").hide();
            $(".step_2").hide();
            $(".step_3").hide();
            $(".step_4").show();
            $(".step_5").hide();
            
        });
		 $("#next_step_4").click(function () {
          
            $(".step_1").hide();
            $(".step_2").hide();
            $(".step_3").hide();
            $(".step_4").hide();
			 $(".step_5").show();
            
        });

        $("#prev_step_2").click(function () {
            $(".step_1").show();
            $(".step_2").hide();
            $(".step_3").hide();
             $(".step_4").hide();
			 $(".step_5").hide();
              
        });
        $("#prev_step_3").click(function () {
            $(".step_2").show();
            $(".step_1").hide();
            $(".step_3").hide();
             $(".step_4").hide();
			 $(".step_5").hide();
           
        });
         $("#prev_step_4").click(function () {
            $(".step_2").hide();
            $(".step_1").hide();
            $(".step_3").show();
             $(".step_4").hide();
			 $(".step_5").hide();
             
        });
		 $("#prev_step_5").click(function () {
            $(".step_2").hide();
            $(".step_1").hide();
            $(".step_3").hide();
             $(".step_4").show();
			 $(".step_5").hide();
             
        });
    });
    function addRate() {

        $(".services_rates:first").clone().insertAfter('.services_rates:last');
        $(".services_rates:last #remove-rate").css('display', 'inline-block');
    }
    function removeRate() {
        $(".services_rates:last #remove-rate").closest('.services_rates').remove();
    }
</script>
@endsection

@section('footer-scripts')
@endsection
