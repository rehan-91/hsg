@extends('admin.layouts.default_layout')

@section('header-css')
	<link href="{{ asset('admin-vendors/css/select2.min.css') }}" rel="stylesheet" />
@endsection

@section('header-scripts')
	<script src="{{ asset('admin-vendors/js/select2.min.js') }}"></script>
	<script>
		var state_id = district_id = sub_district_id = block_id = 0;
	</script>
@endsection

@section('header')
	<div class="bulk-top admin-title">
		<div class="container">
			<h1 class="blue pull-left">Edit Your Profile </h1>
			<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back to CBC" href="{{ route('admin.index') }}">Back</a>
		</div>
    </div>
@endsection

@section('content')
	<section class="lime-bg paddingComm70">
	  <div class="container">
		<form action="{{ route('admin.editprofilesave') }}" method="POST" enctype="multipart/form-data">
		  {{ csrf_field() }}
		  
		  @if( intval( $set_design_limiter ) == 0 )
			<div class="basic-configuration-inner select-box admin-create-update">
				<h2>Profile Details</h2>
				<div class="col-md-8 col-sm-12 col-xs-12">
				  <div class="row">
					<div class="input-box @if($errors->has('name')) has-error @endif">
						<label class="select-label" for="name">Name</label><br>
						<input type="text" id="name" name="name" class="bg-input" placeholder="Please Enter Name" value="{{ is_null(old("name")) ? $user_data->name : old("name") }}" />
						@if($errors->has("name"))
						  <span class="help-block">{{ $errors->first("name") }}</span>
						@endif
					</div>
				
					
					<div class="input-box margR0 @if($errors->has('email')) has-error @endif">
						<label class="select-label" for="email">Email</label>
						<input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email Address" value='{{ is_null(old("email")) ? $user_data->email : old("email") }}' />
						@if($errors->has("email"))
							<span class="help-block">{{ $errors->first("email") }}</span>
						@endif
					</div>
					
					<div class="clearfix"></div>
					<div class="input-box margR0 @if($errors->has('contact')) has-error @endif">
						<label class="select-label" for="contact">Contact Number</label>
						<input type="text" id="contact" name="contact" class="bg-input" placeholder="Please Enter Contact No." value='{{ is_null(old("contact")) ? $user_data->contact_number : old("contact") }}' />
						@if($errors->has("contact"))
							<span class="help-block">{{ $errors->first("contact") }}</span>
						@endif
					</div>
				  </div>
				</div>
					
				<div class="col-md-4 col-sm-4 col-xs-12 profile-img">
					<label class="select-label imgHeadLabelProfile" for="profile_img">Profile Image</label>
					<span class="add_pic pull-right" id="admin_profile_image_master" @if( $user_data->get_image_data($user_data->image_id, 'size400', 1) != "" ) style="visibility:hidden;"  @endif >
						<img src="{{ asset('admin-vendors/images/no-img.png') }}"><strong>Profile Image</strong>
					</span>
					<div class="form-group">
						<div>
							<div style="display:none;">
								<input type="file" id="profile_img" name="profile_img" />
							</div>
							
							<button type="button" onclick="fire_image_selector('profile_img', 'admin_profile_image_preview', 'admin_image_editor', 'admin_profile_image_master');"></button>
							<span class="img-profile_size">
								<img src="{{ $user_data->get_image_data($user_data->image_id, 'size400', 1) }}" id="admin_profile_image_preview" >
							</span>
							<input type="hidden" name="hidden_image_id" id="hidden_image_id" value="{{ $user_data->image_id }}">
						</div>
					</div>
					<div class="image-edits" id="admin_image_editor" @if( $user_data->get_image_data($user_data->image_id, 'size400', 1) == "" ) style="display:none;"  @endif >
						<a href="javascript:void(0);" onclick="remove_user_image( 'admin_profile_image_preview', 'hidden_image_id', 'admin_image_editor', 'admin_profile_image_master' );" class="pull-left"><i class="fa fa-trash" aria-hidden="true"></i></a>
						<a href="javascript:void(0);" class="pull-right" onclick="fire_image_selector('profile_img', 'admin_profile_image_preview', 'admin_image_editor', 'admin_profile_image_master');" ><i class="fa fa-pencil" aria-hidden="true"></i> </a>
					</div>
				</div>
				
				
				<div class="clearfix"></div>
				<br>
				
				<input name="Submit" value="Update" type="submit" class="admin-add btn-admin">
				<input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.index') }}'" value="Cancel">
			</div>
		  @else
			<div class="basic-configuration-inner select-box"> <!--admin-create-update class name remove-->
				<h2>Profile Details</h2>
				<div class="col-md-8 col-sm-12 col-xs-12">
				  <div class="row">
					<div class="input-box @if($errors->has('first_name')) has-error @endif">
						<label class="select-label" for="first_name">First Name</label>
						<input type="text" id="first_name" name="first_name" class="bg-input" placeholder="Please Enter First Name" value='{{ is_null(old("first_name")) ? $user_xprofile_data->first_name : old("first_name") }}' />
						@if($errors->has("first_name"))
							<span class="help-block">{{ $errors->first("first_name") }}</span>
						@endif
					</div>
					
					<div class="input-box margR0 @if($errors->has('last_name')) has-error @endif">
						<label class="select-label" for="last_name">Last Name</label>
						<input type="text" id="last_name" name="last_name" class="bg-input" placeholder="Please Enter Last Name" value='{{ is_null(old("last_name")) ? $user_xprofile_data->last_name : old("last_name") }}' />
						@if($errors->has("last_name"))
							<span class="help-block">{{ $errors->first("last_name") }}</span>
						@endif
					</div>
					
					<div class="clearfix"></div>
					
					<div class="input-box @if($errors->has('email')) has-error @endif">
						<label class="select-label" for="email">Email</label>
						<input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email" value='{{ is_null(old("email")) ? $user_data->email : old("email") }}' />
						@if($errors->has("email"))
							<span class="help-block">{{ $errors->first("email") }}</span>
						@endif
					</div>
					
					<div class="input-box margR0 @if($errors->has('contact')) has-error @endif">
						<label class="select-label" for="contact">Contact Number</label>
						<input type="text" id="contact" name="contact" class="bg-input" placeholder="Please Enter Contact No." value='{{ is_null(old("contact")) ? $user_data->contact_number : old("contact") }}' />
						@if($errors->has("contact"))
							<span class="help-block">{{ $errors->first("contact") }}</span>
						@endif
					</div>
				  </div>
				</div>
				
				<div class="col-md-4 col-sm-4 col-xs-12 profile-img">
					<label class="select-label imgHeadLabelProfile" for="profile_img">Profile Image</label>
					<span class="add_pic pull-right" id="nodal_profile_image_master" @if( $user_data->get_image_data($user_data->image_id, 'size400', 1) != "" ) style="visibility:hidden;"  @endif >
						<img src="{{ asset('admin-vendors/images/no-img.png') }}"><strong>Profile Image</strong>
					</span>
					<div class="form-group">
						<div>
							<div style="display:none;">
								<input type="file" id="profile_img" name="profile_img" />
							</div>
							
							<button type="button" onclick="fire_image_selector('profile_img', 'nodal_profile_image_preview', 'nodals_image_editor', 'nodal_profile_image_master');"></button>
							<span class="img-profile_size"><img src="{{ $user_data->get_image_data($user_data->image_id, 'size400', 1) }}" id="nodal_profile_image_preview"></span>
							
							<input type="hidden" name="hidden_image_id" id="hidden_image_id" value="{{ $user_data->image_id }}">
						</div>
					</div>
					<div class="image-edits" id="nodals_image_editor" @if( $user_data->get_image_data($user_data->image_id, 'size400', 1) == "" ) style="display:none;"  @endif >
						<a href="javascript:void(0);" onclick="remove_user_image( 'nodal_profile_image_preview', 'hidden_image_id', 'nodals_image_editor', 'nodal_profile_image_master' );" class="pull-left"><i class="fa fa-trash" aria-hidden="true"></i></a>
						<a href="javascript:void(0);" class="pull-right" onclick="fire_image_selector('profile_img', 'nodal_profile_image_preview', 'nodals_image_editor', 'nodal_profile_image_master');" ><i class="fa fa-pencil" aria-hidden="true"></i> </a>
					</div>
				</div>
			</div>
			
			
			
			<div class="basic-configuration-inner select-box admin-create-update company-configuration-inner">
				<h2>Company Details</h2>
				<div class="col-md-8 col-sm-12 col-xs-12">
				  <div class="row">
					<div class="input-box @if($errors->has('company_name')) has-error @endif">
						<label class="select-label" for="company_name">Company Name</label>
						<input type="text" id="company_name" name="company_name" class="bg-input" placeholder="Please Enter Company Name" value='{{ is_null(old("company_name")) ? $user_xprofile_data->company_name : old("company_name") }}' />
						@if($errors->has("company_name"))
							<span class="help-block">{{ $errors->first("company_name") }}</span>
						@endif
					</div>
					
					
					@php
						$state_id = old('addr_state', $user_xprofile_data->state_id);
						
						$district_id = old('addr_district', $user_xprofile_data->district_id);
						
						$sub_district_id = old('addr_sub_district', $user_xprofile_data->sub_district_id);
						
						$block_id = old('addr_block', $user_xprofile_data->block_id);
					@endphp
					
					<script>
						var state_id = "{{ $state_id }}";
						var district_id = "{{ $district_id }}";
						var sub_district_id = "{{ $sub_district_id }}";
						var block_id = "{{ $block_id }}";
					</script>
					
					<div class="input-box margR0 @if($errors->has('addr_state')) has-error @endif">
						<label class="select-label" for="addr_state">State</label>
						<select class="js-example-basic-single bg-input" id="addr_state" name="addr_state" class="bg-input" onchange="update_state_based_listings(this.value, '');" >
							<option value="">Select State</option>
							@if($states)
								@foreach( $states as $state_data )
									<option @if( $state_id && $state_id == $state_data['id'] ) selected @endif value="{{ $state_data['id'] }}"> {{ $state_data["name"] }} </option>
								@endforeach
							@endif
						</select>
						@if($errors->has("addr_state"))
							<span class="help-block">{{ $errors->first("addr_state") }}</span>
						@endif
					</div>
					
					<div class="clearfix"></div>
					
					<div class="input-box select-Newbox @if($errors->has('addr_district')) has-error @endif">
						<label class="select-label" for="addr_district">District</label>
						<select class="js-example-basic-single bg-input" id="addr_district" name="addr_district" class="bg-input" onchange="update_district_based_listings(this.value, '');">
						</select>
						@if($errors->has("addr_district"))
							<span class="help-block">{{ $errors->first("addr_district") }}</span>
						@endif
					</div>
					
					<div class="input-box margR0 @if($errors->has('addr_sub_district')) has-error @endif">
						<label class="select-label" for="addr_sub_district">Sub District</label>
						<select class="js-example-basic-single bg-input" id="addr_sub_district" name="addr_sub_district" class="bg-input" onchange="update_subdistrict_based_listings(this.value, '');">
						</select>
						@if($errors->has("addr_sub_district"))
							<span class="help-block">{{ $errors->first("addr_sub_district") }}</span>
						@endif
					</div>
					
					<div class="clearfix"></div>
					
					<div class="input-box select-Newbox @if($errors->has('addr_block')) has-error @endif">
						<label class="select-label" for="addr_block">Block</label>
						<select class="js-example-basic-single bg-input" id="addr_block" name="addr_block" class="bg-input">
						</select>
						@if($errors->has("addr_block"))
							<span class="help-block">{{ $errors->first("addr_block") }}</span>
						@endif
					</div>
					
					<div class="input-box margR0 @if($errors->has('addr_street')) has-error @endif">
						<label class="select-label" for="addr_street">Street Name</label>
						<input type="text" id="addr_street" name="addr_street" class="bg-input" placeholder="Please Enter Street Name" class="form-control" value='{{ is_null(old("addr_street")) ? $user_xprofile_data->address_street : old("addr_street") }}' />
						@if($errors->has("addr_street"))
							<span class="help-block">{{ $errors->first("addr_street") }}</span>
						@endif
					</div>
					
					<div class="clearfix"></div>
					
					<div class="input-box @if($errors->has('addr_pin_code')) has-error @endif">
						<label class="select-label" for="addr_pin_code">Pin Code</label>
						<input type="text" id="addr_pin_code" name="addr_pin_code" class="bg-input" placeholder="Please Enter Pin Code" class="form-control" value='{{ is_null(old("addr_pin_code")) ? $user_xprofile_data->pin_code : old("addr_pin_code") }}' />
						@if($errors->has("addr_pin_code"))
							<span class="help-block">{{ $errors->first("addr_pin_code") }}</span>
						@endif
					</div>
					
				  </div>
				</div>
				
				<div class="col-md-4 col-sm-4 col-xs-12 profile-img">
					<label class="select-label imgHeadLabel" for="logo_img">Company Logo</label>
					<span class="add_pic pull-right" id="nodal_logo_image_master" @if( $user_data->get_image_data($user_xprofile_data->secondary_image_id, 'size400', 1) != "" ) style="visibility:hidden;"  @endif >
						<img src="{{ asset('admin-vendors/images/no-img.png') }}"><strong>Company Logo</strong>
					</span>
					<div class="form-group">
						<div>
							<div style="display:none;">
								<input type="file" id="logo_img" name="logo_img" />
							</div>
							
							<button type="button" onclick="fire_image_selector('logo_img', 'nodal_logo_image_preview', 'nodals_sec_image_editor', 'nodal_logo_image_master');"></button>
							
							<span class="img-profile_size"><img src="{{ $user_data->get_image_data($user_xprofile_data->secondary_image_id, 'size400', 1) }}" id="nodal_logo_image_preview"></span>
							<input type="hidden" name="hidden_logo_id" id="hidden_logo_id" value="{{ $user_xprofile_data->secondary_image_id }}">
							
							@if($errors->has("logo_img"))
								<span class="help-block popup-text-err">{{ $errors->first("logo_img") }}</span>
							@endif
						</div>
					</div>
					
					<div class="image-edits" id="nodals_sec_image_editor" @if( $user_data->get_image_data($user_xprofile_data->secondary_image_id, 'size400', 1) == "" ) style="display:none;"  @endif >
						<a href="javascript:void(0);" onclick="remove_user_image( 'nodal_logo_image_preview', 'hidden_logo_id', 'nodals_sec_image_editor', 'nodal_logo_image_master' );" class="pull-left"><i class="fa fa-trash" aria-hidden="true"></i></a>
						<a href="javascript:void(0);" class="pull-right" onclick="fire_image_selector('logo_img', 'nodal_logo_image_preview', 'nodals_sec_image_editor', 'nodal_logo_image_master' );" ><i class="fa fa-pencil" aria-hidden="true"></i> </a>
					</div>
				</div>
			  
				<div class="clearfix"></div>
				<br>
				
				<input name="Submit" value="Update" type="submit" class="admin-add btn-admin">
				<input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.index') }}'" value="Cancel">
				
			</div>
		  @endif
		</form>
	  </div>
	</section>
	
@endsection


@section('footer-scripts')
@if(session()->has('message'))
  <script>
	var success = '{{ session()->get("message") }}';
	show_success_container(success);
  </script>
@endif
<script>
	
	var state_route = "{!! route('admin.ajax.stateList') !!}";
	var district_route = "{!! route('admin.ajax.districtList') !!}";
	var subdistrict_route = "{!! route('admin.ajax.subDistrictList') !!}";
	
	var access_token = jQuery('input[name=_token]').val();
	jQuery(document).ready( function(){
		
		update_address_data( state_id, district_id, sub_district_id, block_id );
		
		jQuery('#addr_state').select2();
		jQuery('#addr_district').select2();
		jQuery('#addr_sub_district').select2({
		  tags: true
		});
		jQuery('#addr_block').select2({
		  tags: true
		});
	});
</script>
@endsection