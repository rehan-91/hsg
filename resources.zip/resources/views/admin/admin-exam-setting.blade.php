@extends('admin.layouts.default_layout')
@section('content')
@include('admin.error')
<section class="configuration-links admin-title">
 <div class="container">
   <h1 class="white">Configurations</h1>
    <ul>
     <li><a href="#">General</a></li>
      <li><a href="#">Services</a></li>
       <li class="active"><a href="#">Test Settings</a></li>
        <li><a href="#">Certificates</a></li>
        </ul>
  
 </div>
</section>
<div class="clearfix"></div>
<section class="lime-bg paddingComm70">
 <div class="container">
 @if(session('successnew'))
	<div class="alert alert-success" id="id">
	{{session('successnew')}}
	</div>
@endif
@if(count($testList) > 0)
	@foreach($testList as $test)
   <div class="basic-configuration-inner select-box">
    <h2>{{$test[0]['test']['name']}}</h2>
    <form class="form-inline" action="{{ route('admin.test_setting') }}" method="POST">
	{{ csrf_field() }}
    <div class="form-group form-grouping">
      <label class="select-label" for="sel1">Test Duration :</label><br>
      <select class="form-control basic-form" id="test_duration" name="test_duration">
	  <?php $testDurrArr = array('00:30:00', '00:35:00','00:40:00','00:45:00', '00:50:00');
       for($i=0; $i < count($testDurrArr); $i++ ){	  
	  ?>
      <option value="<?= $testDurrArr[$i]?>" <?php if($testDurrArr[$i]==$test[0]['duration']){echo 'selected';} ?>><?= $testDurrArr[$i]?></option> 
	   <?php } ?>
  </select>
    </div>
    <div class="form-group form-grouping">
    <label class="select-label" for="sel1">Objective Questions :</label><br>
	 <input type="hidden" class="form-control basic-form" id="test_id"  name="test_id" value="{{$test[0]['test_id']}}">
      <input type="text" class="form-control basic-form" id="obj_que" placeholder="30" name="obj_que" value="{{$test[0]['questions']}}">
	  @if($errors->has("obj_que"))
	   <span class="help-block">{{ $errors->first("obj_que") }}</span>
	  @endif
    </div>
     <div class="form-group form-grouping">
      <label class="select-label" for="sel1">Passing Percentage :</label><br>
      <input type="text" class="form-control basic-form" id="pass_percentage" placeholder="50%" name="pass_percentage" value="{{$test[0]['passing_percentage']}}">
	  @if($errors->has("pass_percentage"))
	   <span class="help-block">{{ $errors->first("pass_percentage") }}</span>
	  @endif
    </div>
    
    <div class="clearfix"></div>
         
         <div class="col-md-4 col-xs-6 col-sm-6 check-boxes">
          <span class="title status-txt pull-left">Randomise Questions</span>
						<input type="checkbox" id="ftf_schools_is_active{{$test[0]['test_id']}}" name="random_que" value="1" class="cbx hidden" <?php if($test[0]['randomize_questions']==1){echo 'checked';} ?>>
						<label for="ftf_schools_is_active{{$test[0]['test_id']}}" class="lbl"></label>
         </div>
         
           <div class="col-md-4 col-xs-6 col-sm-6 check-boxes">
           <span class="title status-txt pull-left">Randomise Options</span>
						<input type="checkbox" id="ftf_schools_is_active_a{{$test[0]['test_id']}}" name="random_opt" value="1" class="cbx hidden" <?php if($test[0]['randomize_options']==1){echo 'checked';} ?>>
						<label for="ftf_schools_is_active_a{{$test[0]['test_id']}}" class="lbl"></label>
           
           </div>
            <div class="col-md-4 col-xs-6 col-sm-6 check-boxes"></div>
            <div class="clearfix"></div>
            
             <button type="submit" class="btn btn-default save-btn">SAVE</button>
  </form>       
 </div>
@endforeach
@endif
 </div>
</section>
@endsection
