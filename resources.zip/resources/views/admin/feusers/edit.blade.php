@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Fe-User  / Update </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Fe-Users" href="{{ route('admin.fe-users.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.fe-users.update', [$users->id]) }}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('name')) has-error @endif">
					<label class="select-label" for="name">Name</label><br>
                    <input type="text" id="name" name="name" class="bg-input" placeholder="Please Enter Name" value='{{ $users->name }}' />
					@if($errors->has("name"))
						<span class="help-block">{{ $errors->first("name") }}</span>
					@endif
				</div>
				
				<div class="input-box margR0 @if($errors->has('email')) has-error @endif">
					<label class="select-label" for="email">Email</label>
                    <input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email Address" value='{{ $users->email }}' />
					@if($errors->has("email"))
						<span class="help-block">{{ $errors->first("email") }}</span>
					@endif
				</div>
				
				<div class="clearfix"></div>
				<div class="input-box margR0 ">
					<label class="select-label" for="contact">Password - (if password entered, password  will be updated)</label>
                    <input type="password" id="password" name="password" class="bg-input" placeholder="" value='' />
					</div>
				<div class="clearfix"></div>
				 <div class="input-box permissionTable">
						<label>Status</label>
						<input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if($users->status == 1) checked @endif> 
						<label for="status_1" class="lbl" id="switch-box"></label>
				</div>
										
			  </div>
		  </div>
			<div class="clearfix"></div>
			<input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
						<input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.fe-users.index') }}'" value="Cancel">
			
			</div>
			</form>
			</div>
			</section>
@endsection