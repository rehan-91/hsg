@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">City  / Edit </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Cities" href="{{ route('admin.cities.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.cities.update', [$data->id])}}" method="POST">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<h2>Country Details</h2>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('city_name')) has-error @endif">
					<label class="select-label" for="city_name">State Name</label><br>
                    <input type="text" id="name" name="city_name" class="bg-input" placeholder="Please Enter City Name" value='{{ $data->name }}' />
					@if($errors->has("city_name"))
						<span class="help-block">{{ $errors->first("city_name") }}</span>
					@endif
				</div>
				
				<div class="input-box @if($errors->has('country_id')) has-error @endif">
                                    <label class="select-label" for="country_id">Country</label><br>
                                    <select name="country_id"  class="bg-input" onchange="getStates(this.value)">
                                    <option vlaue="">Select Country</option>
                                    @foreach($countries as $c)
                                    <option value="{{ $c->id }}" @if( $c->id == $data->country_id ) selected  @endif >{{ $c->country_name }}</option>
                                    @endforeach
                                    </select>
                                      @if($errors->has("country_id"))
                                            <span class="help-block">{{ $errors->first("country_id") }}</span>
                                      @endif
				</div>
                            
                                 <div class="input-box @if($errors->has('state_id')) has-error @endif">
                                    <label class="select-label" for="state_id">State</label><br>
                                    <select name="state_id"  class="bg-input" id="state_id">
                                    <option vlaue="">Select State</option>
                                    @foreach($states as $s)
                                     <option value="{{ $s->id }}" @if( $s->id == $data->state_id ) selected  @endif >{{ $s->name }}</option>
                                    @endforeach
                                    </select>
                                      @if($errors->has("state_id"))
                                            <span class="help-block">{{ $errors->first("state_id") }}</span>
                                      @endif
								</div>
								 <div class="input-box @if($errors->has('longitude')) has-error @endif">
                                    <label class="select-label" for="">Longitude</label><br>
                                      <input type="text" id="longitude" name="longitude" class="bg-input" placeholder="Please Enter Longitude" value='{{ $data->longitude }}' />
                                      @if($errors->has("longitude"))
                                            <span class="help-block">{{ $errors->first("longitude") }}</span>
                                      @endif
                                 </div>
								 <div class="input-box @if($errors->has('longitude')) has-error @endif">
                                    <label class="select-label" for="">Lattitude</label><br>
                                      <input type="text" id="lattitude" name="lattitude" class="bg-input" placeholder="Please Enter Lattitude" value='{{ $data->lattitude }}' />
                                      @if($errors->has("lattitude"))
                                            <span class="help-block">{{ $errors->first("lattitude") }}</span>
                                      @endif
                                 </div>
								  <div class="input-box">
                                    <label class="select-label" for="">Notice</label><br>
                                      <textarea name="notice" id="notice" class="bg-input">{{ $s->notice }}</textarea>
                                 </div>
                                <div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if($data->status == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
                             
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.cities.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
<script>
    function getStates(id){
        if(id !== ""){
        $.ajax({
             headers: {
                'X-CSRF-TOKEN': $('input[name="_token"]').val()
              },
           type:"post",
           url:"{!! route('admin.cities.fetchstate') !!}",
           data:{id:id},
           success: function(data){
              $("#state_id").html(data);
           }
        });
        }
    }
</script>
@endsection