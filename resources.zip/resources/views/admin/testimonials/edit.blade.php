@extends('admin.layouts.default_layout')
@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')

    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Testimonials Edit</h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Ads" href="{{route('admin.testimonials.index')}}">Back</a>
		</div>
    </div>
@endsection
@section('content')
<div id="detail-section" class="step_1">
      
    <form  action="{{route('admin.testimonials.update', [$data->id])}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
        {{ csrf_field() }}
        <section class="lime-bg paddingComm70">
          
           
            <div class="container">
              

                   
                <div class="basic-configuration-inner select-box admin-create-update">
                  
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="input-box @if($errors->has('user_id')) has-error @endif">
                                    <label class="select-label" for="from">User</label><br>
                                    <select class="bg-input form-control" id="user_id" name="user_id">
                                        <option value="">Select User</option>
                                        @foreach($users as $u)
                                        <option value="{{$u['id']}}" >{{$u['email']}}</option>
                                       @endforeach
                                    </select>
                                    @if($errors->has("name"))
                                <span class="help-block">{{ $errors->first("user_id") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('test_user_name')) has-error @endif">
                                <label class="select-label" for="name">Name</label><br>
                                <input type="text" id="name" name="test_user_name" class="bg-input" placeholder="Please Enter Name" value='{{  $data->test_user_name }}' />
                                @if($errors->has("test_user_name"))
                                <span class="help-block">{{ $errors->first("test_user_name") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('test_user_email')) has-error @endif">
                                <label class="select-label" for="email">Email</label><br>
                                <input type="text" id="email" name="test_user_email" class="bg-input" placeholder="Please Enter Email" value='{{  $data->test_user_email }}' />
                                @if($errors->has("test_user_email"))
                                <span class="help-block">{{ $errors->first("test_user_email") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('test_user_contactno')) has-error @endif">
                                <label class="select-label" for="phone">Phone</label><br>
                                <input type="text" id="phone" name="test_user_contactno" class="bg-input" placeholder="Please Enter Phone" value='{{  $data->test_user_contactno }}' />
                               
                                @if($errors->has("test_user_contactno"))
                                <span class="help-block">{{ $errors->first("test_user_contactno") }}</span>
                                @endif
                            </div>
                           <div class="input-box  margR0 @if($errors->has('test_user_location')) has-error @endif">
                                    <label class="select-label" for="location">Location</label><br>
										<input type="text" class="bg-input" name="test_user_location" placeholder="Enter Location" value="{{ $data->test_user_location }}">
                                      @if($errors->has("test_user_location"))
                                            <span class="help-block">{{ $errors->first("test_user_location") }}</span>
                                      @endif
							</div>
                             
                           <div class="clearfix"></div>
                              <div class="input-box">
                                <label class="select-label" for="logo"> Image</label><br>
                                <input type="file" name="test_user_img">
                              </div>
                  
                             <div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden"  @if($data->status == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
                                 <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
							<input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.testimonials.index') }}'" value="Cancel">
                             
                        </div>
                        
                        
                        
                    </div>
                </div>
                
            </div>
            
        </section>

    </form>
</div>

</div>

@endsection

@section('footer-scripts')
<script>
      $(document).ready(function() {
$('#user_id').select2();
   });
</script>
@endsection