@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Plans  / Edit </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Plans" href="{{ route('admin.plans.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.plans.update', [$plans->id])}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<h2>Plan Details</h2>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('title')) has-error @endif">
					<label class="select-label" for="name">Title</label><br>
                    <input type="text" id="name" name="title" class="bg-input" placeholder="Please Enter Title" value='{{ is_null(old("title")) ? $plans->plan_name : old("title") }}' />
					@if($errors->has("title"))
						<span class="help-block">{{ $errors->first("title") }}</span>
					@endif
				</div>
				
				<div class="input-box margR0 @if($errors->has('base_price')) has-error @endif">
					<label class="select-label" for="email">Base Price</label>
                    <input type="text" id="base_price" name="base_price" class="bg-input" placeholder="Please Enter Base Price" value='{{ is_null(old("base_price")) ? $plans->plan_price_base : old("base_price") }}' />
					@if($errors->has("base_price"))
						<span class="help-block">{{ $errors->first("base_price") }}</span>
					@endif
				</div>
				
				
				<div class="input-box  @if($errors->has('boost_price')) has-error @endif">
					<label class="select-label" for="contact">Boost Price</label>
                                        <input type="text" id="contact" name="boost_price" class="bg-input" placeholder="Please Enter Boost Price" value='{{is_null(old("boost_price")) ? $plans->plan_price_boost : old("boost_price") }}' />
					@if($errors->has("boost_price"))
						<span class="help-block">{{ $errors->first("boost_price") }}</span>
					@endif
				</div>
                                <div class="input-box margR0 @if($errors->has('featured_price')) has-error @endif">
					<label class="select-label" for="contact">Featured Price</label>
                                        <input type="text" id="contact" name="featured_price" class="bg-input" placeholder="Please Enter Boost Price" value='{{ is_null(old("featured_price")) ? $plans->plan_price_featured : old("featured_price") }}' />
					@if($errors->has("featured_price"))
						<span class="help-block">{{ $errors->first("featured_price") }}</span>
					@endif
				</div>
                              <div class="input-box  @if($errors->has('allowed_photos')) has-error @endif">
					<label class="select-label" for="contact">Allowed photos</label>
                                        <input type="number" id="contact" name="allowed_photos" class="bg-input" placeholder="Please Enter Allowed Photos" value='{{ is_null(old("allowed_photos")) ? $plans->plan_allowed_photos : old("allowed_photos") }}' />
					@if($errors->has("boost_price"))
						<span class="help-block">{{ $errors->first("allowed_photos") }}</span>
					@endif
				</div>
                                <div class="input-box margR0 @if($errors->has('allowed_videos')) has-error @endif">
					<label class="select-label" for="contact">Allowed videos</label>
                                        <input type="number" id="contact" name="allowed_videos" class="bg-input" placeholder="Please Enter Allowed Videos" value='{{ is_null(old("allowed_videos")) ? $plans->plan_allowed_videos : old("allowed_videos") }}' />
					@if($errors->has("featured_price"))
						<span class="help-block">{{ $errors->first("allowed_videos") }}</span>
					@endif
				</div>
                              <div class="input-box">
                                    <label class="select-label" for="from">Listing Type</label><br>
                                    <select class="bg-input" id="user_type_id" name="user_type_id">
                                        @foreach($usertype as $utype)
                                        <option value="{{$utype['id']}}" @if( $utype['id'] ==  $plans->user_type_id ) selected  @endif >{{$utype['title']}}</option>
                                       @endforeach
                                    </select>
                                   </div>
                              
                             
                                 <div class="input-box margR0 @if($errors->has('duration')) has-error @endif">
					<label class="select-label" for="duration">Duration</label>
                                        <div class="clearfix"></div>
                                        <input type="number" id="plan_duration" style="width: 80%;display: inline-block;" name="duration" class="bg-input pull-left"  placeholder="Please Enter Duration" value='{{ $plans->plan_duration}}' />
                                        <select name="plan_duration_unit"  class="bg-input pull-right" style="width:20%">
                                            <option value="hours" @if($plans->plan_duration_unit == 'hours') 'selected' @endif >Hours</option>
                                            <option value="day" @if($plans->plan_duration_unit == 'day') 'selected' @endif >Day</option>
                                        </select>
                                        @if($errors->has("duration"))
						<span class="help-block">{{ $errors->first("duration") }}</span>
					@endif
				</div>
				 <div class="textarea-box">
                                    <label class="select-label" for="from">Features(One fetaure per line)</label><br>
                                    <textarea name="plan_features" class="bg-input">{{  $plans->plan_features }}</textarea>
                                   </div>
              
                               <div class="clearfix"></div>
                                <div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if($plans->plan_status == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
                              <div class="input-box permissionTable">
                                    <label>Recommended</label>
                                    <input type="checkbox" id="recommended" name="recommended" value="1"  class="cbx hidden" @if($plans->plan_is_recommended == 1)checked @endif> 
                                    <label for="recommended" class="lbl" id="switch-box"></label>
				</div>
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.plans.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
@endsection