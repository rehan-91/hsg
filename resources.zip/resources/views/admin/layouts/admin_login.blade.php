<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>HOSG</title>

    <link rel="icon" href="../../favicon.ico">

    <!-- Bootstrap core CSS -->
	<link href="{{ asset('admin-vendors/css/bootstrap.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/font-awesome.min.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/style.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/responsive.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/admin_css.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/admin_responsive.css') }}" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="{{ asset('admin-vendors/css/ie10-viewport-bug-workaround.css') }}">

    <!-- Custom styles for this template -->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/admin-dashboard.css') }}">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<script src="{{ asset('admin-vendors/js/jquery.min.js') }}"></script>
	<script src="{{ asset('admin-vendors/js/bootstrap.min.js') }}"></script>
  </head>
  
  <body class="black-bg">
	<header class="borderBlack admin-header login-header">
	  <nav class="navbar navbar-dark">
		<div class="container">
		  <!-- Brand and toggle get grouped for better mobile display -->
		  <div class="navbar-header">
			<!--<button type="button" class="navbar-toggle toggle-menu menu-right push-body pull-right" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar top-bar"></span>
				<span class="icon-bar middle-bar"></span>
				<span class="icon-bar bottom-bar"></span>
			</button>-->
			<a class="navbar-brand" href="{{ route('admin.index') }}">
				<img src="{{ asset('admin-vendors/images/logo.png') }}" class="pull-left mobile-HideOnly" alt="logo"> 
				<img src="{{ asset('images/logo-icon.png') }}" class="pull-left mobile-showOnly" alt="logo">
				
			</a>
		  </div>
		  <!-- Collect the nav links, forms, and other content for toggling -->
		</div><!-- /.container-fluid -->
	  </nav>

	 
	</header>
	
	@yield('content')
	
	@include('admin.layouts.partials.footersection')
	<script>
	  jQuery(document).ready(function(){
		jQuery('[data-toggle="tooltip"]').tooltip(); 
	  });
	  
	  
	 jQuery('ul.nav li.dropdown').hover(function() {
  jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
	</script>
	<style>
	
	
	</style>
	
  </body>
</html>