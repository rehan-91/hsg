<header class="borderBlack admin-header">

	@include('admin.layouts.partials.nav')
	
	<div class="container right-menutop">
	  <ul class="nav navbar-nav navbar-right">
		<li class="dropdown profile-btn">
		  <a href="javascript:void(0);" class="profile-pic dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="{{ Auth::user()->get_image_data(Auth::user()->image_id, 'size50'  ) }}"></a>
		
		  <ul class="dropdown-menu logout">
			<li class="blue-bg">
				<span class="media-left"><img src="{{ Auth::user()->get_image_data(Auth::user()->image_id, 'size50'  ) }}"></span><span class="media-body">{{ Auth::user()->name }} <a href="{{ route('admin.changePassword') }}">Change Password</a></span>
			</li>
			<!--<li class="black-bg"> <a href="{{ route('admin.editprofile') }}"> <i class="fa fa-square" aria-hidden="true"></i> Edit Profile</a> </li>-->
			@hasanyrole( ''.App\Models\Role::ROLE_SUPERADMIN.'|'.App\Models\Role::ROLE_SUBADMIN.'' )
				<li  class="black-bg"> <a href="{{ route('admin.settings.general') }}"> <i class="fa fa-cog" aria-hidden="true"></i> General</a> </li>
				<li  class="black-bg"><a href="{{ route('admin.email-templates.index') }}"> <i class="fa fa-envelope" aria-hidden="true"></i> Email Templates</a></li>
				<li  class="black-bg"><a href="{{ route('admin.content.index') }}"> <i class="fa fa-edit" aria-hidden="true"></i> Content Management</a></li>
				<li  class="black-bg"><a href="{{ route('admin.blog.index') }}"> <i class="fa fa-edit" aria-hidden="true"></i> Blogs</a></li>
				<li  class="black-bg"><a href="{{ route('admin.testimonials.index') }}"> <i class="fa fa-users" aria-hidden="true"></i> Testimonials</a></li>
			@endif
            <li  class="black-bg"><a href="{{ route('admin.logout') }}"> <i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
          </ul>
		</li>
      </ul>
	</div>
</header>