<nav class="navbar navbar-dark">
     <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->

          <div class="navbar-header">

               <button type="button" class="navbar-toggle toggle-menu menu-right push-body pull-right"
                    data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar top-bar"></span>
                    <span class="icon-bar middle-bar"></span>
                    <span class="icon-bar bottom-bar"></span>
               </button>
               <a class="navbar-brand" href="{{ route('admin.index') }}">
                    <img src="{{ asset('admin-vendors/images/logo.png') }}" class="pull-left mobile-HideOnly"
                         alt="logo">
                    <img src="{{ asset('admin-vendors/images/logo-icon.png') }}" class="pull-left mobile-showOnly"
                         alt="logo">

               </a>
          </div>


          <!-- Collect the nav links, forms, and other content for toggling -->

          <div class="collapse navbar-collapse cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right"
               id="bs-example-navbar-collapse-1">
               <ul class="nav navbar-nav nav-admin">

                    <li @if(\Request::is('admin/dashboard')) class="active" @endif><a href="{{ route('admin.index') }}"
                              class="white"> Dashboard </a></li>
                    <li @if( \Request::is('admin/plans') || \Request::is('admin/plans/*') ) class="active" @endif><a
                              href="{{ route('admin.plans.index') }}">Plans <span class="sr-only">(current)</span></a>
                    </li>
                  

                    <li
                         class="dropdown mR16 @if( \Request::is('admin/masters') || \Request::is('admin/masters/*')) active @endif">
                         <a href="javascript:void(0);" class="dropdown-toggle nav-submenu" data-toggle="dropdown">
                              Masters <span>&nbsp;<img
                                        src="{{ asset('admin-vendors/images/caret-image.png') }}"></span></a>
                         <ul class="dropdown-menu logout menu-drop">
                              <li><a href="{{ route('admin.masters.age') }}">Age</a></li>
                              <li><a href="{{ route('admin.masters.height') }}">Height</a></li>
                              <li><a href="{{ route('admin.masters.weight') }}">Weight</a></li>
                              <li><a href="{{ route('admin.masters.nationality') }}">Nationality</a></li>
                              <li><a href="{{ route('admin.masters.orientation') }}">Orientation</a></li>
                              <li><a href="{{ route('admin.masters.haircolor') }}">Hair color</a></li>
                              <li><a href="{{ route('admin.masters.hairlength') }}">Hair length</a></li>
                              <li><a href="{{ route('admin.masters.eyecolor') }}">Eye color</a></li>
                              <li><a href="{{ route('admin.masters.bustsize') }}">Bust Size</a></li>
                              <li><a href="{{ route('admin.masters.dresssize') }}">Dress Size</a></li>
                              <li><a href="{{ route('admin.masters.shoessize') }}">Shoes Size</a></li>
                              <li><a href="{{ route('admin.masters.personal') }}">Personal</a></li>
                              <li><a href="{{ route('admin.masters.piercing') }}">Piercing</a></li>
                              <li><a href="{{ route('admin.masters.favourite-things') }}">Favourite Things</a></li>
                              <li><a href="{{ route('admin.masters.wishlist') }}">Wishlist</a></li>
                              <li><a href="{{ route('admin.masters.service-type') }}">Service Type</a></li>
                              <li><a href="{{ route('admin.masters.services-available') }}">Services Available</a></li>
                              <li><a href="{{ route('admin.masters.service-available-for') }}">Services Available
                                        For</a></li>

                         </ul>
                    </li>

                    <li
                         class="dropdown mR16 @if( \Request::is('admin/countries') || \Request::is('admin/countries/*') || \Request::is('admin/states/*')
                              || \Request::is('admin/states/*') || \Request::is('admin/cities/*') || \Request::is('admin/cities/*')) active @endif">
                         <a href="javascript:void(0);" class="dropdown-toggle nav-submenu" data-toggle="dropdown">
                              Location Management <span>&nbsp;<img
                                        src="{{ asset('admin-vendors/images/caret-image.png') }}"></span></a>
                         <ul class="dropdown-menu logout menu-drop">
                              <li><a href="{{ route('admin.countries.index') }}">Countries</a></li>
                              <li><a href="{{ route('admin.states.index') }}">States</a></li>
                              <li><a href="{{ route('admin.cities.index') }}">Cities</a></li>

                         </ul>
                    </li>
<!--

                    <li
                         class="dropdown mR16 @if( \Request::is('admin/individualad') || \Request::is('admin/individualad/*') 
                            || \Request::is('admin/photographers/*') || \Request::is('admin/photographers') || \Request::is('admin/escorts-agency')
                            || \Request::is('admin/escorts-agency/*') || \Request::is('admin/adult-job-employer') || \Request::is('admin/adult-job-employer/*')
                            || \Request::is('admin/adult-job-jobsekker') || \Request::is('admin/adult-job-jobseeker') || \Request::is('admin/funroom') || \Request::is('admin/funroom/*')) active @endif">
                         <a href="javascript:void(0);" class="dropdown-toggle nav-submenu" data-toggle="dropdown"> Ads
                              <span>&nbsp;<img src="{{ asset('admin-vendors/images/caret-image.png') }}"></span></a>
                         <ul class="dropdown-menu logout menu-drop">
                              @php
                              $listingtype = listingtype();
                              @endphp
                              @if(count($listingtype) > 0)
                              @foreach($listingtype as $key=>$list)

                              <li><a
                                        href="{{-- route('admin.'.$list['slug'].'.index', [$key]) --}}">{{$list['title']}}</a>
                              </li>
                              @endforeach
                              @endif
                         </ul>
                    </li>
-->
                    <li><a href="{{ route('admin.OtherAds') }}">Other Ads</a></li>


                    <li @if( \Request::is('admin/adminusers') || \Request::is('admin/adminusers/*') ) class="active"
                         @endif><a href="{{ route('admin.admins.index') }}">Admin Users</a></li>


          </div><!-- /.navbar-collapse -->

     </div><!-- /.container-fluid -->
</nav>