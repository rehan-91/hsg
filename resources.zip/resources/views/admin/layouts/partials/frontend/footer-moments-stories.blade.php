<footer class="topftr story-ftr">
	<div class="container">
		<ul class="ftrScllinksbotm text-center">
			<li><a href="{{ $translation['footer']['term_of_use']['url'] }}" target="_blank">{{ $translation['footer']['term_of_use']['name'] }}</a> |
			@if ($translation['language'] !== 'ru' && $translation['language'] !== 'ch')</li>
				<li><a href="{{ $translation['footer']['imprint']['url'] }}" target="_blank">{{ $translation['footer']['imprint']['name'] }} </a> |
			@endif</li>
			<li><a  href="{{ $translation['footer']['privacy']['url'] }}" target="_blank">{{ $translation['footer']['privacy']['name'] }}</a></li>
			<span id=teconsent><script type="text/javascript" src="//consent.truste.com/notice?domain=marriott.com&c=teconsent&text=true&js=0_v3"></script></span>
		</ul>

		<ul class="ftrScllinks text-center" style="width:100%;">
			<li><a target="_blank" href="https://www.facebook.com/marriottrewards/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
			<li><a target="_blank" href="https://twitter.com/marriotteurope?lang=en"><i class="fa fa-twitter"></i></a></li>
			<li><a target="_blank" href="https://www.instagram.com/marriotteurope/?hl=en"><i class="fa fa-instagram"></i></a></li>
		</ul>
	</div>
</footer>