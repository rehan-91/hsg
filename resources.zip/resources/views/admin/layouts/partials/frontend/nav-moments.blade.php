<!--Header Start-->
	<header>
	  <div class="lightblue floatleft">
		<div class="floatright"> 
			<a target="_blank" href="{{ $translation['website']['url'] }}"><img src="{{ asset('images/marriott_moments/logo@2x.png') }}" alt="Marriott Rewards Moments" ></a> 
		</div>
	  </div>
	  <div class="darkblue floatright">
		<div class="floatleft">
		  <h1>{{ $translation['copy']['header_text'] }}</h1>
		</div>
	  </div>
	</header>
<!--Header End-->

<div class="clearfix"></div>