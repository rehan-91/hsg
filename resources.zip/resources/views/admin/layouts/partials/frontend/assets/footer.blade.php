
<!-- Bootstrap core JavaScript
================================================== -->
<script src="{{ asset('vendors/bootstrap/js/jquery.min.js') }}"></script>
<script src="{{ asset('vendors/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/owl.carousel.js') }}"></script>
<script type='text/javascript'>
	jQuery('.owl-carousel').owlCarousel({
		loop:true,
		margin:10,
		autoplay: true,
		autoplayTimeout: 3000,
		autoplayHoverPause: true,
		nav:true,
		responsive:{
			0:{
				items:1
			},
			600:{
				items:2
			},
			1000:{
				items:3
			}
		}
	});
</script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="{{ asset('vendors/bootstrap/js/bootstrap.min.js') }}"></script> -->
<script src="{{ asset('vendors/bootstrap/assets/js/vendor/holder.min.js') }}"></script>
<script src="{{ asset('js/fittext.js') }}"></script>
<script src="{{ asset('js/frontend.js') }}"></script>

<script>try{Typekit.load({ async: true });}catch(e){}</script>

<?php //include_once($gaCode) ?>
<script src="{{ asset('js/gaInteractions.js') }}"></script>
