	
<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700,900' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700" rel="stylesheet">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('vendors/bootstrap/css/bootstrap.css') }}">
<link rel="stylesheet" href={{ asset('vendors/custom/class.css') }}>
<link rel="stylesheet" href={{ asset('vendors/font-awesome/css/font-awesome.css') }}>
<link rel="stylesheet" href={{ asset('vendors/custom/responsive.css') }}>
<link rel="stylesheet" href={{ asset('vendors/custom/default-common.css') }}> 
<link rel="stylesheet" href={{ asset('vendors/custom/owl.carousel.min.css') }}> 

<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]>
<script src="{{ asset('vendors/bootstrap/assets/js/ie8-responsive-file-warning.js') }}"></script><![endif]-->
<script src="{{ asset('vendors/bootstrap/assets/js/ie-emulation-modes-warning.js') }}"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

@if(intval($campaign) == 5)
	<link rel="stylesheet" href="https://use.typekit.net/jgc0jqq.css">
@endif
