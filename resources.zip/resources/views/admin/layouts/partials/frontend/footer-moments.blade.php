<footer>
  <div class="topftr">
    <div class="container">
      <div class="col-md-12 col-sm-12 col-xs-12 topftrblock">
        <div class="topfooter"><a target="_blank" href="{{ $translation['copy']['terms_conditions_link'] }}"><i class="fa fa-plus" aria-hidden="true"></i> *{{ $translation['copy']['terms_conditions'] }}</a></div>
        <ul class="ftrScllinks pull-right">
			<li><a target="_blank" href="https://www.facebook.com/marriottrewards/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
			<li><a target="_blank" href="https://twitter.com/marriotteurope?lang=en"><i class="fa fa-twitter"></i></a></li>
			<li><a target="_blank" href="https://www.instagram.com/marriotteurope/?hl=en"><i class="fa fa-instagram"></i></a></li>
        </ul>
        <!-- <div id="tc-container">
          <ul>
           {!! $translation['terms_and_conditions'] !!}
          </ul>
        </div> -->
      </div>
    </div>
  </div>
  <div class="clearfix"></div>
  <div class="loweftr">
    <div class="bottomftr">
      <ul class="ftrScllinksbotm">
		<li><a href="{{ $translation['footer']['term_of_use']['url'] }}" target="_blank">{{ $translation['footer']['term_of_use']['name'] }}</a> |
		@if ($translation['language'] !== 'ru' && $translation['language'] !== 'ch')</li>
			<li><a href="{{ $translation['footer']['imprint']['url'] }}" target="_blank">{{ $translation['footer']['imprint']['name'] }} </a> |
		@endif</li>
		<li><a  href="{{ $translation['footer']['privacy']['url'] }}" target="_blank">{{ $translation['footer']['privacy']['name'] }}</a></li>
		<span id=teconsent><script type="text/javascript" src="//consent.truste.com/notice?domain=marriott.com&c=teconsent&text=true&js=0_v3"></script></span>
      </ul>
      <p>{{ $translation['copy']['rights'] }}</p>
    </div>
  </div>
</footer>