
  <!-- JS included -->
  <script type="text/javascript" src="{{ asset('vendors/marriott-moments/js/jquery.min.js') }}"></script> 
  <script type="text/javascript" src="{{ asset('vendors/marriott-moments/js/bootstrap.js') }}"></script> 
  <script type="text/javascript" src="{{ asset('vendors/marriott-moments/js/jquery.bxslider.js') }}"></script> 
  <!-- JS included -->
  <script>
	jQuery(document).ready(function(){
		jQuery('.bxslider').bxSlider({
			mode: 'horizontal',
			moveSlides: 1,
			//slideMargin: 40,
			infiniteLoop: true,
			//slideWidth: 660,
			//minSlides: 1,
			//maxSlides: 15,
			speed: 1000,
			pager:true,
			auto:true,
			controls:true,
			clone:false,
			onSlideBefore:function($slideElement, oldIndex, newIndex){
				
				jQuery(".banner_text_"+oldIndex).fadeOut('slow', function() {
					jQuery(".banner_head").css("display", "none");
					jQuery(".banner_text_"+newIndex).parent().parent().css("display", "block");
					jQuery(".banner_text_"+newIndex).fadeIn('slow');
				});
		    },
		});
		
		jQuery('.exploreslider').bxSlider({
			mode: 'fade',
			moveSlides: 1,
			//slideMargin: 40,
			infiniteLoop: true,
			//slideWidth: 660,
			//minSlides: 1,
			//maxSlides: 15,
			speed: 1000,
			pager:false,
			auto:true,
			controls:false
		});	
	});
		
	function toggleTC() {
		jQuery('#tc-container').toggle(0, function () {
			pushFooter(jQuery('#terms-and-conditions'));
		});
	}	

	function pushFooter(id)
	{
		var pushValue = jQuery('body > .footer').height() - 10;

		jQuery('body > .container').animate({ marginBottom: pushValue + 'px'}, 0, function () {

			if (id) {
				jQuery('html, body').animate({
					scrollTop: id.offset().top - jQuery('.navbar-fixed-top').height()
				}, 0);
			}
		});
	}
  </script>
  <script src="{{ asset('js/fittext.js') }}"></script>
  <script src="{{ asset('js/frontend.js') }}"></script>

  <script>try{Typekit.load({ async: true });}catch(e){}</script>

  <script src="{{ asset('js/gaInteractions.js') }}"></script>