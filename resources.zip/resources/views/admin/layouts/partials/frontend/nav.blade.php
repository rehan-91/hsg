<style>
.lang-drops{
	margin: 0;
    padding: 0;
    width: 100%;
    border: 0;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, .3);
	z-index: 1000000;
}

.lang-drops li{
	border-bottom: 1px solid #e1e1e1;
    padding: 3px 0;
    background: #ededed;
    color: #000;
}
.lang-drops img, .button-lang-drop img{
	width: 29px;
    height: 18px;
    margin-right: 14px;
}
.button-lang-drop {
    border: 1px solid #ccc;
    background: transparent;
    width: 160px !important;
    padding-left: 0;
    box-shadow: none !important;
    border-radius: 4px;
    height: 40px;
}
</style>
<!-- Fixed navbar -->
<nav class="navbar navbar-default topNav">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header"> <a class="navbar-brand" href="{{ $translation['website']['url'] }}"><img src="{{ asset('images/common/marriott-logo.png') }}" alt="marriott"></a> </div>
    
	@if(intval($campaign) == 5)
		<!-- 	Language Dropdown Eu Promotion	-->
		<div class="pull-right">
			<div class="dropdown">
			  <button class="form-control button-lang-drop" type="button" data-toggle="dropdown"><img src="images/languages/{{ $campaignDescription->language->slug }}.png"><span>{{ $campaignDescription->language->translated_name }}</span>
			  <span class="caret"></span></button>
			  <ul class="dropdown-menu lang-drops">
				@foreach($campaign_language as $language)
					<li><a href="javascript:void(0);" onclick="change_language_translations('{{ $language->id }}');"><img src="images/languages/{{ $language->slug }}.png"><span>{{ $language->translated_name }}</span></a></li>
				@endforeach
			  </ul>
			</div>
		</div>
		<!-- 	Language Dropdown Eu Promotion	-->
	@endif
	
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        @if(intval($campaign) == 3)
			<ul class="nav navbar-nav navbar-right visalogo sixtvisalogo">
				<li class="visible-sm visible-md visible-lg"><img src="{{ asset('images/common/marriott-sixt.png') }}" alt="marriott-sixt" ></li>
			</ul>
		@else
			@if(intval($campaign) != 5)
				<ul class="nav navbar-nav navbar-right visalogo">
					<li class="visible-sm visible-md visible-lg"><img src="{{ asset('images/common/visaimg.png') }}" alt="visa" ></li>
				</ul>
			@endif
		@endif
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<div class="clearfix"></div>