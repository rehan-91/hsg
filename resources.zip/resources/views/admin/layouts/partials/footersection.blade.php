<div class="clearfix"></div>

<!--************ footer ***********-->
<footer class="black-bg">
  <div class="container">
	<div class="">
		
		<p class="copy-right">&copy; <b>{{ date('Y') }}</b>. All rights reserved.<span>Developed by <a href="https://www.vocso.com/" rel="nofollow" target="_blank" >VOCSO</a></span></p>
	</div>
  </div>
  
  <a href="#" class="scrollToTop" style="display: none;"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>
</footer>
<script>
    function deleteAction(model_id, id){
		if( confirm("Are you sure?") ){
			jQuery.ajax({
                                    headers: {
                                    'X-CSRF-TOKEN': $('input[name="_token"]').val()
                             },
				type: 'POST',
				dataType: "JSON",
                                data : {model_id:model_id, id:id},
				url: "{!! route('admin.ajax.destroy') !!}",
				success: function(data) {
					if( data.access_error_msg ){
						show_error_container( data.access_error_msg );
					}
					else if( data.error ){
						show_error_container( data.error );
					}
					else if( data.success ){
						dTable.ajax.reload();
						show_success_container( data.success );
					}
				},
			});
		}
	}
</script>