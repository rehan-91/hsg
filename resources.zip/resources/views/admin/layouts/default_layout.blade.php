<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Dashboard</title>

	<link href="{{ asset('admin-vendors/css/bootstrap.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/font-awesome.min.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/style.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/responsive.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/admin_css.css') }}" rel="stylesheet">
	<link href="{{ asset('admin-vendors/css/admin_responsive.css') }}" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css" rel="stylesheet" />
	<!--<link href="{{ asset('admin-vendors/css/animate.css') }}" rel="stylesheet"> -->
	
	
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
  <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="{{ asset('admin-vendors/css/ie10-viewport-bug-workaround.css') }}">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<script src="{{ asset('admin-vendors/js/jquery.min.js') }}"></script>
	<script src="{{ asset('admin-vendors/js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('admin-vendors/js/custom.js') }}"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote.js"></script>
	<!--<script src="{{ asset('admin-vendors/js/bootstrap-dropdownhover.js') }}"></script>--> 
	
	
	@yield('header-css')
	
	@yield('header-scripts')
  </head>
  
  <body>
  
	@include('admin.layouts.partials.headersection')

	@yield('header')
	@yield('content')
	
	@include('admin.layouts.partials.footersection')
	
	<div class="successMsg" style="display:none;" >
		<h3><i class="fa fa-check-circle" aria-hidden="true"></i> Success!</h3>
		<p></p>
	</div>
	<div class="errorMsg" style="display:none;">
		<h3><i class="fa fa-times-circle" aria-hidden="true"></i> Error!</h3>
		<p></p>
	</div>
	
	<script src="{{ asset('admin-vendors/js/admin-custom.js') }}"></script>
	@if(session()->has('access_error_msg'))
	<script>
	  var error = '{{ session()->get("access_error_msg") }}';
	  show_error_container(error);
	</script>
	@endif
	@yield('footer-css')
	@yield('footer-scripts')
	<script>
	  jQuery(document).ready(function(){
		jQuery('[data-toggle="tooltip"]').tooltip(); 
	  });
	  
	  jQuery('ul.nav li.dropdown').hover(function() {
		jQuery(this).find('.dropdown-menu').stop(true, true).delay(150).fadeIn(300);
	  }, function() {
		jQuery(this).find('.dropdown-menu').stop(true, true).delay(150).fadeOut(300);
	  });
	</script>
  </body>
</html>