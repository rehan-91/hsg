@extends('admin.layouts.admin_login')

@section('content')
	@php
	$shown_container = is_null( old('shown_container') ) ? 0 : old('shown_container');
	@endphp
	<section class="black-bg paddingComm70 text-center master_section"  id="login_section" @if( intval( $shown_container ) != 0 ) style="display:none;" @endif >
	  <div class="container">
		<div class="login-account">
			
			<!--  <h1>Welcome to Agent Portal!</h1>
			<h2>This is your one stop access to training, examination and certification.</h2>  -->
			<h3>Login to your account</h3>
			<img src="{{ asset('admin-vendors/images/login-lock.png') }}" alt="lock">
			
			@php	$logout_done = 0;	@endphp
			@if (\Session::has('logout_message'))
			  @php	$logout_done = 1;	@endphp
			  <div class="alert alert-success" style="margin-top:15px;">
				{!! \Session::get('logout_message') !!}
			  </div>
			@endif
			<form action="{{ route('admin.login') }}" method="POST">
			  {{ csrf_field() }}
			  <div class="input-box @if($errors->has('email')) has-error @endif">
				<input type="text" id="email" name="email" placeholder="Username" value="{{ old('email') }}" class="bg-input">
				@if($errors->has("email"))
					<span class="help-block">{{ $errors->first("email") }}</span>
				@endif
			  </div>
			  <div class="input-box @if($errors->has('password')) has-error @endif">
				<input type="password" id="password" name="password" placeholder="Password" class="bg-input">
				@if($errors->has("password"))
					<span class="help-block">{{ $errors->first("password") }}</span>
				@endif
			  </div>
			  <div class="clearfix"></div>
              
			  <span class="pull-left">
				<input type="checkbox" name="checkboxG5" id="checkboxG5" class="css-checkbox"><label for="checkboxG5" class="css-label radGroup1"> Remember Me</label>
			  </span>
          
			  <div class="clearfix"></div>
			  <button type="submit" class="Loginblue-btn">Log in</button>
			</form>
			
			<div class="clearfix"></div>
			<a href="Javascript:void(0);" class="pull-left frgt" onclick="show_section('forgot_section');">Forgot Password</a>
		</div>
	  </div>
	</section>
	
	
	<section class="black-bg paddingComm70 text-center master_section" id="forgot_section" @if( intval( $shown_container ) == 2 ) @else style="display:none" @endif>
	  <div class="container">
		<div class="login-account">
			<h3>Forgot Password</h3>
			
			@if (\Session::has('forgot_message'))
			  <div class="alert alert-success">
				{!! \Session::get('forgot_message') !!}
			  </div>
			@endif
			
			<form action="{{ route('admin.forgotpassword') }}" method="POST">
			  {{ csrf_field() }}
			  <input type="hidden" name="shown_container" value="2">
			  <div class="input-box @if($errors->has('forgot_email')) has-error @endif">
				<input type="text" id="forgot_email" name="forgot_email" placeholder="Email Address" value="{{ old('forgot_email') }}" class="bg-input">
				@if($errors->has("forgot_email"))
					<span class="help-block">{{ $errors->first("forgot_email") }}</span>
				@endif
			  </div>
			  
			  <div class="clearfix"></div>
			  <button type="submit" class="Loginblue-btn">Reset Password</button>
			</form>
			
			<div class="clearfix"></div>
			<a href="Javascript:void(0);" class="pull-left frgt" onclick="show_section('login_section');">Back to Login</a>
		</div>
	  </div>
	</section>
	
	<script>
	  var logout_done = "{{ $logout_done }}";
	  jQuery(document).ready(function(){
		 if( parseInt( logout_done ) == 1 ){
			history.pushState(null, null, location.href);
			window.onpopstate = function () {
				history.go(1);
			};
		 }
	  });
	  
	  function show_section( section_name ){
		  jQuery(".master_section").fadeOut('fast');
		  jQuery("#"+section_name).fadeIn('fast');
	  }
	</script>
@endsection