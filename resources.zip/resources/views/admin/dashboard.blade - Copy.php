@extends('admin.layouts.default_layout')

@section('content')

    <div class="clearfix"></div>
	<section class="paddingComm70 lime-bg">
	  <div class="container">
		<h3 class="blue">Master Admin Dashboard</h3>
		<div class="dashboard-left">
		  <div class="white-box">
			<img src="{{ asset('admin-vendors/images/dash-graph.jpg') }}" class="img-responsive center-block">
		  </div>
		  <div class="clearfix"></div>
		
		  <ul class="thumbnails">
			<li>
				<img src="{{ asset('admin-vendors/images/zero.png') }}" class="center-block">
				<h4>Zero Microfinance and savings support Private Limited</h4>
				<small>#245</small>
				<hr>
				<span class="media-left">
					<img src="{{ asset('admin-vendors/images/zero-grap.jpg') }}">
				</span>
				<span class="media-body"><h5>821</h5><p>certified agents</p></span>
			</li>
			<li>
				<img src="{{ asset('admin-vendors/images/sub-k.png') }}" class="center-block">
				<h4>Basix Sub-K Itransactions Limited (Basix)</h4>
				<small>#245</small>
				<hr>
				<span class="media-left">
					<img src="{{ asset('admin-vendors/images/zero-grap.jpg') }}">
				</span>
				<span class="media-body"><h5>821</h5><p>certified agents</p></span>
			</li>
			<li>
				<img src="{{ asset('admin-vendors/images/oxygen.png') }}" class="center-block">
				<h4>Oxigen Services India Private Lmiited (Oxigen)</h4>
				<small>#130</small>
				<hr>
				<span class="media-left">
					<img src="{{ asset('admin-vendors/images/zero-grap.jpg') }}">
				</span>
				<span class="media-body"><h5>821</h5><p>certified agents</p></span>
			</li>
		  </ul>
		
		  <div class="clearfix"></div>
		  <h3 class="blue">Recent Certified Agent</h3>
		  <small class="sm-txt">Check the agent list who certified recently.</small>

		  <div class="table-responsive admin-table">          
			<table class="table">
			  <thead>
				<tr>
				  <th>#ID</th>
				  <th>Agent Name</th>
				  <th>CBC Name</th>
				  <th>Certification Level</th>
				  <th>Score </th>
				  <th colspan="2">Date Certified  </th>
				</tr>
			  </thead>
			  <tbody>
				<tr>
				  <td>124534 </td>
				  <td><span class="table-auth"><img src="{{ asset('admin-vendors/images/table-auth.png') }}" alt="image"></span> Roshan Guru</td>
				  <td>Sub-K</td>
				  <td>Basic</td>
				  <td>20/30</td>
				  <td>10-05-2018</td>
				  <td><a href="#"><img src="{{ asset('admin-vendors/images/small-eye.png') }}"></a> <a href="#"><img src="{{ asset('admin-vendors/images/donwload.png') }}"></a></td>
				</tr>
				<tr>
				  <td>124534 </td>
				  <td> <span class="table-auth"><img src="{{ asset('admin-vendors/images/table-auth.png') }}" alt="image"></span> Roshan Guru</td>
				  <td>Sub-K</td>
				  <td>Basic</td>
				  <td>20/30</td>
				  <td>10-05-2018</td>
				  <td><a href="#"><img src="{{ asset('admin-vendors/images/small-eye.png') }}"></a> <a href="#"><img src="{{ asset('admin-vendors/images/donwload.png') }}"></a></td>
				</tr>
				<tr>
				  <td>124534 </td>
				  <td> <span class="table-auth"><img src="{{ asset('admin-vendors/images/table-auth.png') }}" alt="image"></span> Roshan Guru</td>
				  <td>Sub-K</td>
				  <td>Basic</td>
				  <td>20/30</td>
				  <td>10-05-2018</td>
				  <td><a href="#"><img src="{{ asset('admin-vendors/images/small-eye.png') }}"></a> <a href="#"><img src="{{ asset('admin-vendors/images/donwload.png') }}"></a></td>
				</tr>
				<tr>
				  <td>124534 </td>
				  <td><span class="table-auth"><img src="{{ asset('admin-vendors/images/table-auth.png') }}" alt="image"></span> Roshan Guru</td>
				  <td>Sub-K</td>
				  <td>Basic</td>
				  <td>20/30</td>
				  <td>10-05-2018</td>
				  <td><a href="#"><img src="{{ asset('admin-vendors/images/small-eye.png') }}"></a> <a href="#"><img src="{{ asset('admin-vendors/images/donwload.png') }}"></a></td>
				</tr>
				<tr>
				  <td>124534 </td>
				  <td><span class="table-auth"><img src="{{ asset('admin-vendors/images/table-auth.png') }}" alt="image"></span> Roshan Guru</td>
				  <td>Sub-K</td>
				  <td>Basic</td>
				  <td>20/30</td>
				  <td>10-05-2018</td>
				  <td><a href="#"><img src="{{ asset('admin-vendors/images/small-eye.png') }}"></a> <a href="#"><img src="{{ asset('admin-vendors/images/donwload.png') }}"></a></td>
				</tr>
				<tr>
				  <td>124534 </td>
				  <td><span class="table-auth"><img src="{{ asset('admin-vendors/images/table-auth.png') }}" alt="image"></span> Roshan Guru</td>
				  <td>Sub-K</td>
				  <td>Basic</td>
				  <td>20/30</td>
				  <td>10-05-2018</td>
				  <td><a href="#"><img src="{{ asset('admin-vendors/images/small-eye.png') }}"></a> <a href="#"><img src="{{ asset('admin-vendors/images/donwload.png') }}"></a></td>
				</tr>
			  </tbody>
			</table>
	  
			<a href="#" class="pull-left export-btn">
				<i class="fa fa-arrow-circle-o-up" aria-hidden="true"></i> EXPORT LIST
			</a>
			
			<nav aria-label="" class="pull-right">
			  <ul class="pagination">
				<li><a href="#" aria-label="Previous"><span aria-hidden="true">«</span></a></li>
				<li><a href="#">1</a></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#">4</a></li>
				<li><a href="#">5</a></li>
				<li><a href="#" aria-label="Next"><span aria-hidden="true">»</span></a></li>
			  </ul>
			</nav>
		  </div>
		</div>
		
		
		<div class="dashboard-right">
		  <div class="white-box">
			<h5>Overview</h5>
			<span class="orange-btn">365<small>CBC</small></span> 
			<span class="blue-btn">23365 <small>ABC</small></span>
			
			<div class="clearfix"></div>
			<div class="basic progs">Average content view time (Basic)</div>
			<div class="advance progs">Average content view time (Advance)</div>
			<div class="training progs">Training content view</div>
		  </div>

		  <a href="#" class="approval-btn">Approvals Pending</a>
		  <div class="clearfix"></div>
		  <div class="white-box activity">
			<h5>Activity Feed</h5>
			<p>Friday , May11th 2018</p>
			<ul>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  <li>
				<span class="media-left"><img src="{{ asset('admin-vendors/images/address-pic.png') }}"></span>
				<span class="media-body">New Agent <strong>Rakesh Sharma</strong> #3891 registered under CBC X & Y</span>
			  </li>
			  </li>
			</ul>
		  </div>
		</div>
	  </div>
	</section>

@endsection
