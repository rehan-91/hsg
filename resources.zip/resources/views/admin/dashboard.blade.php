@extends('admin.layouts.default_layout')

@section('header-css')
	<link href="{{ asset('admin-vendors/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
	<link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet" />
@endsection

@section('header-scripts')
	<script src="{{ asset('admin-vendors/js/jquery.dataTables.js') }}"></script>
	<script src="{{ asset('admin-vendors/js/Chart.bundle.js') }}"></script>
	<script src="{{ asset('js/moment.js') }}"></script>
	<script src="{{ asset('js/daterangepicker.js') }}"></script>
@endsection

@section('content')

	hi
@endsection
