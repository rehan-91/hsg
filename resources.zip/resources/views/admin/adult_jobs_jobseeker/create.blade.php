@extends('admin.layouts.default_layout')
@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Adult Job Seeker</h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Ads" href="#">Back</a>
		</div>
    </div>
@endsection
@section('content')
<div id="detail-section" class="step_1">
    
    <form  action="" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
        {{ csrf_field() }}
        <section class="lime-bg paddingComm70">
            <div class="container">
                <h2 id="ad-heading">Ad Posting</h2>


                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Contact</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <div class="input-box @if($errors->has('name')) has-error @endif">
                                <label class="select-label" for="name">Name</label><br>
                                <input type="text" id="name" name="name" class="bg-input" placeholder="Please Enter Name" value='{{ old("name")}}' />
                                @if($errors->has("name"))
                                <span class="help-block">{{ $errors->first("name") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('email')) has-error @endif">
                                <label class="select-label" for="email">Email</label><br>
                                <input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email" value='{{ old("email")}}' />
                                @if($errors->has("email"))
                                <span class="help-block">{{ $errors->first("email") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('phone')) has-error @endif">
                                <label class="select-label" for="phone">Email</label><br>
                                <input type="text" id="email" name="phone" class="bg-input" placeholder="Please Enter Phone" value='{{ old("phone")}}' />
                                @if($errors->has("phone"))
                                <span class="help-block">{{ $errors->first("phone") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('location')) has-error @endif">
                                <label class="select-label" for="location">Location</label><br>
                                <input type="text" id="email" name="location" class="bg-input" placeholder="Please Enter Location" value='{{ old("location")}}' />
                                @if($errors->has("location"))
                                <span class="help-block">{{ $errors->first("location") }}</span>
                                @endif
                            </div>
                             <div class="textarea-box margR0 @if($errors->has('description')) has-error @endif">
                                <label class="select-label" for="description">Description</label><br>
                                <textarea id="job_description" name="description" class="bg-input" placeholder="Please Enter Job Description">{{ old("description")}}</textarea>
                                @if($errors->has("description"))
                                <span class="help-block">{{ $errors->first("description") }}</span>
                                @endif
                            </div>
                             <div class="clearfix"></div>
                                <label class="select-label" for="job_type">Job Type</label><br>
                                  <table class="text_display add-roletable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
                                <tbody>

                                    <tr class="text_display">
                                        <td>
                                            <input type="radio" name="personal" value="natural">
                                            <label for="check_m_perm_2">Sensual Message</label>

                                        </td>

                                        <td>
                                            <input type="radio" name="personal" value="Trim">
                                            <label for="check_m_perm_3">Strip Tease</label>

                                        </td>

                                        <td>
                                            <input type="radio" name="personal" value="Fully Waxed">
                                            <label for="check_m_perm_4">Full Service</label>

                                        </td>

                                        <td>
                                            <input type="radio" name="personal" value="Landing strip">
                                            <label for="check_m_perm_5"> Landing strip</label>

                                        </td>
                                        
                                    </tr>

                                </tbody>
                            </table>
                           
                        </div>
                    </div>
                </div>
            </div>
             
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <input name="next" value="Save" type="button" class="admin-add btn-admin" id="">

                        </div>
                    </div>


                </div>



            </div>
        </section>

    </form>
</div>

</div>

@endsection

@section('footer-scripts')
@endsection
