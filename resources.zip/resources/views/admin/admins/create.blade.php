@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Admin Users / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Admins" href="{{ route('admin.admins.index') }}">Back</a>
		</div>
    </div>
@endsection

@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.admins.store') }}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<h2>Admin Details</h2>
			<div class="col-md-8 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('name')) has-error @endif">
					<label class="select-label" for="name">Name</label><br>
                    <input type="text" id="name" name="name" class="bg-input" placeholder="Please Enter Name" value='{{ old("name") }}' />
					@if($errors->has("name"))
						<span class="help-block">{{ $errors->first("name") }}</span>
					@endif
				</div>
				
				<div class="input-box margR0 @if($errors->has('email')) has-error @endif">
					<label class="select-label" for="email">Email</label>
                    <input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email Address" value='{{ old("email") }}' />
					@if($errors->has("email"))
						<span class="help-block">{{ $errors->first("email") }}</span>
					@endif
				</div>
				
				<div class="clearfix"></div>
				<div class="input-box margR0 @if($errors->has('contact')) has-error @endif">
					<label class="select-label" for="contact">Contact Number</label>
                    <input type="text" id="contact" name="contact" class="bg-input" placeholder="Please Enter Contact No." value='{{ old("contact") }}' />
					@if($errors->has("contact"))
						<span class="help-block">{{ $errors->first("contact") }}</span>
					@endif
				</div>
			  </div>
			</div>
				
			<div class="col-md-4 col-sm-4 col-xs-12 profile-img">
				<label class="select-label imgHeadLabel" for="profile_img">Profile Image</label>
				<span class="add_pic pull-right" id="admin_profile_image_master">
					<img src="{{ asset('admin-vendors/images/no-img.png') }}"><strong>Profile Image</strong>
				</span>
				<div class="form-group">
					<div > <!--class="prof-img-container"	-->
						<div style="display:none;">
							<input type="file" id="profile_img" name="profile_img" />
						</div>
						
						<button type="button" onclick="fire_image_selector('profile_img', 'admin_profile_image_preview', 'admin_image_editor', 'admin_profile_image_master');"></button>
						<span class="img-profile_size"><img src="" id="admin_profile_image_preview"></span>
					</div>
				</div>
				<div class="image-edits" id="admin_image_editor" style="display:none;" >
					<a href="javascript:void(0);" onclick="remove_user_image( 'admin_profile_image_preview', 'hidden_image_id', 'admin_image_editor', 'admin_profile_image_master' );" class="pull-left"><i class="fa fa-trash" aria-hidden="true"></i></a>
					<a href="javascript:void(0);" class="pull-right" onclick="fire_image_selector('profile_img', 'admin_profile_image_preview', 'admin_image_editor', 'admin_profile_image_master');" ><i class="fa fa-pencil" aria-hidden="true"></i> </a>
				</div>
			</div>
		  </div>
			<div class="clearfix"></div>
			
			<div class="white-box">
			  <div class="permission-bg">
				<h2>Permission Details</h2>
				
				<table width="100%">
				  <tbody>
					@if( count( $permission_groups) > 0)
					<tr id="permission_box">
					  <td colspan="2">
					    <table width="100%">
						  <tbody>
							<tr>
							  <td class="user-permTxt">
								<label>Permissions</label>
								<input type="checkbox" id="check_all_perms" class="cbx hidden" onclick="submit_perms_all();" value="1">
								<label for="check_all_perms" class="lbl" style="margin-right: 12px;"> </label>
								Select All
							  </td>
							</tr>
						
							@foreach($permission_groups as $perm_group)
							  @if( isset($perm_group["sub_groups"]) )
								<tr>
									<td width="100%" height="25" valign="top" id="permissions">
									  <fieldset style="border:0;">
										<table class="text_display permissionTableCmm add-roletable permissionTable" width="100%" height="100%" border="0" align="left" cellpadding="0" cellspacing="1">
										  <tbody>
											<tr class="text_display subHead add-userroles permissionTable">
											  <td colspan="5" class="tableHead"> {{ $perm_group["label_name"] }} </td>
											</tr>
											@if( count( $perm_group["sub_groups"]) > 0 )
										      @foreach($perm_group["sub_groups"] as $perm_sub_group)
												<tr class="text_display add-userroles permissionTable" colspan="1">
												  <td>
													<input type="checkbox" class="cbx hidden perm_master_{{ $perm_sub_group['sub_label_id'] }}" id="check_m_perm_{{ $perm_sub_group['sub_label_id'] }}" onclick="check_perm_sub_group( '{{ $perm_sub_group['sub_label_id'] }}' );">
													<label for="check_m_perm_{{ $perm_sub_group['sub_label_id'] }}" class="lbl"></label>
													{{ $perm_sub_group['sub_label_name'] }}
												  </td>
												  @if( count( $perm_sub_group["sub_group_permissions"]) > 0 )
													
													@php
														$counter = 0;
														$row_count = ceil( count($perm_sub_group["sub_group_permissions"]) / 3 );
													@endphp
													@foreach($perm_sub_group["sub_group_permissions"] as $permissions)
														<td>
														  <input type="checkbox" value="{{ $permissions['name'] }}" class="cbx hidden gub_group_{{ $permissions['id'] }} perm_child_{{ $perm_sub_group['sub_label_id'] }}" name="permissions[]" id="check_perm_{{ $permissions['id'] }}" onclick="check_perm_master_group( '{{ $perm_sub_group['sub_label_id'] }}', '{{ $permissions['id'] }}' );">
														  <label for="check_perm_{{ $permissions['id'] }}" class="lbl"></label>
														  {{ $permissions['name'] }}
														</td>
														@if($counter == 2 && $row_count > 1)
															</tr>	
															<tr class='text_display add-userroles permissionTable'>
																<td>&nbsp;</td>
															@php
															  $counter = 0
															@endphp
														@else
															@php
															  $counter++
															@endphp
														@endif
													@endforeach
												  @endif
												</tr>
											  @endforeach
											@endif
											
											<tr>
											  <td style="width:100%;"><hr></td>
											</tr>
										  </tbody>
										</table>
									  </fieldset>
									</td>
								</tr>
							  @endif
							@endforeach
						  </tbody>
						</table>
					  </td>
					</tr>
					@endif
				    
					<tr class="text_sty123 status-text">
					  <td height="31" class="text_sty12 text-6">
						<span class="pull-left status-txt">Status</span>
						<input type="checkbox" name="status" id="status" class="cbx hidden pull-right" value="1">
						<label for="status" class="lbl"></label>
					  </td>
					</tr>
				  
					<tr>
					  <td height="10" colspan="3"></td>
					</tr>
					
					<tr height="40">
					  <td align="left" colspan="2">
						<input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
						<input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.admins.index') }}'" value="Cancel">
					  </td>
					</tr>
				  </tbody>
				</table>
			  </div>
			</div>
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
@endsection
