@extends('admin.layouts.default_layout')

@section('header-css')
	<link href="{{ asset('admin-vendors/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
@endsection

@section('header-scripts')
    <script src="{{ asset('admin-vendors/js/jquery.dataTables.js') }}"></script>
@endsection

@section('header')
	<section class="manage-training admin-title paddingComm45">
	  <div class="container">
		<div class="row">
		  <div class="col-md-6 col-sm-6 col-xs-8 borderWdth">
			<h1 class="blue">Admin Users</h1>
			<h2>Create/Update Admins</h2>
		  </div>
		
		  <div class="col-md-6 col-sm-6 col-xs-4 borderWdth">
			<a class="adminBorder-btn plus-icon" title="Add Admins" href="{{ route('admin.admins.create') }}">Add Admins</a>
		  </div>
		</div>
	  </div>
	</section>
@endsection

@section('content')

	

  
  <section class="manage-quetion lime-bg paddingComm45">
	<div class="container">
	  <div class="table-responsive search-gapTop admin-table">
		<table class="table" id="users-table">
			<thead>
				<tr>
					<th>Name</th>
					<th>E-mail Id</th>
					<th>Added On</th>
					<th>Status</th>
					<th>&nbsp;</th>
				</tr>
			</thead>
		</table>
	  </div>
	</div>
  </section>
@endsection

@section('footer-scripts')
  @if(session()->has('message'))
	<script>
	  var success = '{{ session()->get("message") }}';
	  show_success_container(success);
	</script>
  @endif
<script>
	var dTable;
	jQuery(function() {
		dTable = jQuery('#users-table').DataTable({
			"autoWidth": false,
			language: {
				searchPlaceholder: "Search through Admins",
				"paginate": {
					"first": "&verbar ;&lt;",
					"last": "&gt; &verbar;",
					"next": "&gt;",
					"previous": "&lt;"
				},
				"lengthMenu": " _MENU_ ",
				"info": "_START_ - _END_ of _TOTAL_ items",
				"infoEmpty": "0 - 0 of 0 items",
				"search": "search",
			},
			"dom": 'ftilrp',
			processing: true,
			serverSide: true,
			ajax: '{!! route('admin.admins.data') !!}',
			columns: [
				{ data: 'name_data', name: 'name_data' },
				{ data: 'email', name: 'email' },
				{ data: 'created_at', name: 'created_at' },
				{ data: 'status', name: 'status' },
				{ data: 'action', name: 'action' }
			],
			"columnDefs": [
				{ "orderable": false, "targets": [3, 4] }
		    ]
		});
	});
	
	function delete_admins(deletion_url){
		if( confirm("Are you sure?") ){
			jQuery.ajax({
				type: 'GET',
				dataType: "JSON",
				url: deletion_url,
				success: function(data) {
					if( data.access_error_msg ){
						show_error_container( data.access_error_msg );
					}
					else if( data.error ){
						show_error_container( data.error );
					}
					else if( data.success ){
						dTable.ajax.reload();
						show_success_container( data.success );
					}
				},
			});
		}
	}
</script>


@endsection