@extends('admin.layouts.default_layout')
@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Adult Jobs Employer</h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Ads" href="#">Back</a>
		</div>
    </div>
@endsection
@section('content')
<div id="detail-section" class="step_1">
    
    <form  action="{{ route('admin.individual.store')}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
        {{ csrf_field() }}
        <section class="lime-bg paddingComm70">
            <div class="container">
                <h2 id="ad-heading">Ad Posting</h2>


                <div class="basic-configuration-inner select-box admin-create-update">
                    <h2>Contact</h2>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <div class="input-box @if($errors->has('name')) has-error @endif">
                                <label class="select-label" for="name">Employer Name</label><br>
                                <input type="text" id="name" name="name" class="bg-input" placeholder="Please Enter Name" value='{{ old("name")}}' />
                                @if($errors->has("name"))
                                <span class="help-block">{{ $errors->first("name") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('email')) has-error @endif">
                                <label class="select-label" for="email">Email</label><br>
                                <input type="text" id="email" name="email" class="bg-input" placeholder="Please Enter Email" value='{{ old("email")}}' />
                                @if($errors->has("email"))
                                <span class="help-block">{{ $errors->first("email") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('phone')) has-error @endif">
                                <label class="select-label" for="phone">Email</label><br>
                                <input type="text" id="email" name="phone" class="bg-input" placeholder="Please Enter Phone" value='{{ old("phone")}}' />
                                @if($errors->has("phone"))
                                <span class="help-block">{{ $errors->first("phone") }}</span>
                                @endif
                            </div>
                            <div class="input-box margR0 @if($errors->has('location')) has-error @endif">
                                <label class="select-label" for="location">Location</label><br>
                                <input type="text" id="email" name="location" class="bg-input" placeholder="Please Enter Location" value='{{ old("location")}}' />
                                @if($errors->has("location"))
                                <span class="help-block">{{ $errors->first("location") }}</span>
                                @endif
                            </div>
                            <div class="input-box @if($errors->has('job_title')) has-error @endif">
                                <label class="select-label" for="job_title">Job Title</label><br>
                                <input type="text" id="email" name="job_title" class="bg-input" placeholder="Please Enter Job Title" value='{{ old("job_title")}}' />
                                @if($errors->has("job_title"))
                                <span class="help-block">{{ $errors->first("job_title") }}</span>
                                @endif
                            </div>
                             <div class="input-box @if($errors->has('job_pay')) has-error @endif">
                                <label class="select-label" for="job_pay">Job Title</label><br>
                                <input type="text" id="email" name="job_pay" class="bg-input" placeholder="Please Enter Pay" value='{{ old("job_pay")}}' />
                                @if($errors->has("job_pay"))
                                <span class="help-block">{{ $errors->first("job_pay") }}</span>
                                @endif
                            </div>
                             <div class="textarea-box margR0 @if($errors->has('job_description')) has-error @endif">
                                <label class="select-label" for="job_description">Job Description & Requirement</label><br>
                                <textarea id="job_description" name="job_description" class="bg-input" placeholder="Please Enter Job Description">{{ old("job_description")}}</textarea>
                                @if($errors->has("description"))
                                <span class="help-block">{{ $errors->first("description") }}</span>
                                @endif
                            </div>
                             <div class="clearfix"></div>
                              <div class="input-box">
                                <label class="select-label" for="logo">Logo / Banner</label><br>
                                <input type="file" name="logo">
                              </div>
                        </div>
                    </div>
                </div>
            </div>
             
            <div class="container">
                <div class="basic-configuration-inner select-box admin-create-update">

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">

                            <input name="save" value="Save" type="button" class="admin-add btn-admin" id="step_1">

                        </div>
                    </div>


                </div>



            </div>
        </section>

    </form>
</div>

</div>

@endsection

@section('footer-scripts')
@endsection
