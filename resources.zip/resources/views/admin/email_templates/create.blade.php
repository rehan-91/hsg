@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Email Templates / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Email Templates" href="{{ route('admin.email-templates.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.email-templates.store')}}" method="POST" >	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
                      <h2>Email Template Detail</h2>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('template_name')) has-error @endif">
					<label class="select-label" for="name">Email Template Name</label><br>
                            <input type="text" id="name" name="template_name" class="bg-input" placeholder="Please Enter Template Name" value='{{ is_null(old("template_name")) ? '' : old("content_title") }}' />
					@if($errors->has("template_name"))
						<span class="help-block">{{ $errors->first("template_name") }}</span>
					@endif
				</div>
				
                                 
				<div class="input-box margR0 @if($errors->has('from_email')) has-error @endif">
					<label class="select-label" for="from_email">From Email</label><br>
                                        <input type="text" id="from_email" name="from_email" class="bg-input" placeholder="Please Enter From Email" value='{{ is_null(old("from_email")) ? '' : old("from_email") }}' />
					@if($errors->has("from_email"))
						<span class="help-block">{{ $errors->first("from_email") }}</span>
					@endif
				</div>
                              <div class="input-box">
					<label class="select-label" for="name">From Name</label><br>
                                        <input type="text" id="from_name" name="from_name" class="bg-input" placeholder="Please Enter From Name" value='{{ is_null(old("from_name")) ? '' : old("from_name") }}' />
					
				</div>
                              <div class="input-box margR0 @if($errors->has('email_subject')) has-error @endif">
					<label class="select-label" for="email_subject">Subject</label><br>
                                        <input type="text" id="email_subject" name="email_subject" class="bg-input" placeholder="Please Enter Subject" value='{{ is_null(old("email_subject")) ? '' : old("email_subject") }}' />
					@if($errors->has("email_subject"))
						<span class="help-block">{{ $errors->first("email_subject") }}</span>
					@endif
				</div>
                              
                              <div class="input-box @if($errors->has('to_address')) has-error @endif">
					<label class="select-label" for="to_address">To Address</label><br>
                                        <input type="text" id="to_address" name="to_address" class="bg-input" placeholder="Please Enter To Address" value='{{ is_null(old("to_address")) ? '' : old("to_address") }}' />
					@if($errors->has("to_address"))
						<span class="help-block">{{ $errors->first("to_address") }}</span>
					@endif
				</div>
                                <div class="input-box margR0">
					<label class="select-label" for="contact">CC Address</label>
                                        <input type="text" name='cc_address'class="bg-input"  value="{{ !is_null(old("cc_address")) ?old("cc_address") :''}}">
				</div>
                              <div class="input-box">
					<label class="select-label" for="contact">BCC Address</label>
                                        <input type="text" name='bcc_address'class="bg-input"  value="{{ !is_null(old("bcc_address")) ?old("bcc_address") :''}}">
				</div>
				
                              <div  class="textarea-box">
					<label class="select-label" for="mail_html_content" >HTML Mail</label>
                                        <textarea name='mail_html_content' class="bg-input mail_html_content">{{ !is_null(old("mail_html_content")) ?old("mail_html_content") :''}}</textarea>
				@if($errors->has("mail_html_content"))
						<span class="help-block">{{ $errors->first("mail_html_content") }}</span>
					@endif
                              </div>
                               
                            
				
				
                              
                                
                            <div class="clearfix"></div>
                                <div class="input-box permissionTable">
                                    <label class="select-label margR0" for="status">Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if (!is_null(old("status")) && old("status") == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
                              
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.email-templates.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
<script>
jQuery(function() {

           jQuery('.mail_html_content').summernote({

             height:300,

           });

       });
</script>
@endsection