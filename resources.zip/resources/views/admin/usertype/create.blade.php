@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Listing Type  / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Listing Type" href="{{ route('admin.usertype.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.usertype.store')}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<h2>Listing Add</h2>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('title')) has-error @endif">
					<label class="select-label" for="name">Title</label><br>
                    <input type="text" id="name" name="title" class="bg-input" placeholder="Please Enter Title" value='{{ old("title")}}' />
					@if($errors->has("title"))
						<span class="help-block">{{ $errors->first("title") }}</span>
					@endif
				</div>
				<div class="input-box @if($errors->has('class_name')) has-error @endif">
					<label class="select-label" for="class_name">Class Name</label><br>
                    <input type="text" id="class_name" name="class_name" class="bg-input" placeholder="Please Enter Class Name" value='{{ is_null(old("class_name")) ? "" : old("class_name") }}' />
					@if($errors->has("class_name"))
						<span class="help-block">{{ $errors->first("class_name") }}</span>
					@endif
				</div>
				<div class="input-box">
					<label class="select-label" for="sort_order">Sort Order</label><br>
                    <input type="number" id="sort_order" min="0" name="sort_order" class="bg-input" placeholder="Please Enter Class Name" value='{{ is_null(old("sort_order")) ? "": old("sort_order") }}' />
					
				</div>
				<div class="input-box">
					<label class="select-label" for="name">Add Icon</label><br>
                    <input type="file" name="listing_type_icon">
				@if($errors->has("listing_type_icon"))
						<span class="help-block">{{ $errors->first("listing_type_icon") }}</span>
					@endif
				</div>
				
				
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.usertype.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
@endsection