@extends('admin.layouts.default_layout')

@section('header-css')

@endsection

@section('header-scripts')

@endsection

@section('header')
    <div class="bulk-top admin-title">
	<div class="container">
        <h1 class="blue pull-left">Content Page  / Create </h1>
		<a class="adminBorder-btn btn-cm arrow-left-icon" title="Back To Content Pages" href="{{ route('admin.content.index') }}">Back</a>
		</div>
    </div>
@endsection
@section('content')
    <section class="lime-bg paddingComm70">
	  <div class="container">
		<form  action="{{ route('admin.content.update', [$content->id])}}" method="POST" >	<!--class="form-inline"	-->
		{{ csrf_field() }}
		  <div class="basic-configuration-inner select-box admin-create-update">
			<h2>Page Details</h2>
			<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="row">
				<div class="input-box @if($errors->has('content_title')) has-error @endif">
					<label class="select-label" for="name">Title</label><br>
                    <input type="text" id="name" name="content_title" class="bg-input" placeholder="Please Enter Title" value='{{ is_null(old("content_title")) ? $content->content_title : old("content_title") }}' />
					@if($errors->has("content_title"))
						<span class="help-block">{{ $errors->first("content_title") }}</span>
					@endif
				</div>
				<div  class="textarea-box">
					<label class="select-label" for="contact" >Description</label>
                                        <textarea name='content_long_desc' class="bg-input long_description">{{ !is_null(old("content_long_desc")) ?old("content_long_desc") :''}}</textarea>
				</div>
				
				<div class="input-box ">
					<label class="select-label" for="contact" >Meta Title</label>
                                        <input type="text" name='content_meta_title'  class="bg-input" value="{{ !is_null(old("content_meta_title")) ?old("content_meta_title") :$content->content_title }}">
				</div>
                                <div class="input-box margR0">
					<label class="select-label" for="contact">Meta Keywords</label>
                                        <input type="text" name='content_meta_keywords'class="bg-input"  value="{{ !is_null(old("content_meta_keywords")) ?old("content_meta_keywords") :''}}">
				</div>
                            
                              <div class="textarea-box">
                                            <label class="select-label" for="contact">Meta Description</label>
                                        <textarea name='content_meta_description' class="bg-input">{{ !is_null(old("content_meta_description")) ?old("content_meta_description") :''}}</textarea>
				</div>
				
				
                                
                              
                                
                            <div class="clearfix"></div>
                                <div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if (!is_null(old("status")) && old("status") == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
                              
                              <div class="clearfix"></div>
                              
                              <input name="Submit" value="Add New" type="submit" class="admin-add btn-admin">
			     <input class="admin-cancel btn-admin" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.content.index') }}'" value="Cancel">
                             
			  </div>
			</div>
				
			
		  </div>
			
			
			
		  </form>
	  </div>
    </section>
@endsection

@section('footer-scripts')
<script>
jQuery(function() {

           jQuery('.long_description').summernote({

             height:300,

           });

       });
</script>
@endsection