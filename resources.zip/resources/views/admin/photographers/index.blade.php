@extends('admin.layouts.default_layout')
@section('header-css')
<link href="{{ asset('admin-vendors/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
@endsection
@section('header-scripts')
    <script src="{{ asset('admin-vendors/js/jquery.dataTables.js') }}"></script>
@endsection

@section('header')
	@section('header')
	<section class="manage-training admin-title paddingComm45">
	  <div class="container">
		<div class="row">
		  <div class="col-md-6 col-sm-6 col-xs-8 borderWdth">
			<h1 class="blue">Photographer</h1>
			<h2>Create/Update Ad</h2>
		  </div>
		
		  <div class="col-md-6 col-sm-6 col-xs-4 borderWdth">
			<a class="adminBorder-btn plus-icon" title="Create Ad" href="{{ route('admin.photographers.create', [$id]) }}">Create Ad</a>
		  </div>
		</div>
	  </div>
	</section>
@endsection

@endsection

@section('content')
  @if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
  @endif
  
  <section class="manage-quetion lime-bg table-width paddingComm45">
	<div class="container">
	  <div class="table-responsive search-gapTop paddR0 admin-table table-line-hgt">
		<table class="table" id="content-table">
			<thead>
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Phone</th>
					<th>Location</th>
                                        <th>Added On</th>
                                        <th>Status</th>
					<th>&nbsp;</th>
				</tr>
			</thead>
		</table>
	  </div>
	</div>
  </section>
@endsection

@section('footer-scripts')
<script>
	jQuery(function() {
        
        
		jQuery('#content-table').DataTable({
			"autoWidth": false,
                        stateSave: true,
			language: {
				searchPlaceholder: "Search",
				"paginate": {
					"first": "&verbar ;&lt;",
					"last": "&gt; &verbar;",
					"next": "&gt;",
					"previous": "&lt;"
				},
				"lengthMenu": " _MENU_ ",
				"info": "_START_ - _END_ of _TOTAL_ items",
				"infoEmpty": "0 - 0 of 0 items",
				"search": "search",
                                
                              
			},
			order: [],
			"dom": 'ftilrp',
			processing: true,
			serverSide: true,
                        
			ajax: '{!! route('admin.photographers.data', [$id]) !!}',
			columns: [
				{ data: 'name', name: 'name' },
				{ data: 'email', name: 'email' },
                                { data: 'phone', name: 'phone' },
                                { data: 'location', name: 'location' },
				{ data: 'created_at', name: 'created_at' },
				{ data: 'status', name: 'status' },
				{ data: 'action', name: 'action' }
			],
			"columnDefs": [
				{ "orderable": false, "targets": [5,6] }
		    ]
		});
	});
</script>
@endsection