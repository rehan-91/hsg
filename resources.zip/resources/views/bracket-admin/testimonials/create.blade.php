@extends('bracket-admin.includes.main')
@section('title',' Add New Testimonials')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Testimonials <span> Add New Testimonials ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Add New Testimonials</li>
        </ol>
      </div>
    </div> 
<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.testimonials.store')}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.testimonials.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To  Testimonials </a>  
              </div>
              <h4 class="panel-title">Testimonials Details</h4>
            </div>
            <div class="panel-body">

              <div class="row">
         		 <div class="col-sm-6 @if($errors->has('user_id')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label" for="from" >User</label>
                    <select name="user_id" class="select2 form-control" id="user_id">
                         <option value="">Select User</option>
                        @foreach($users as $u)
                        <option value="{{$u['id']}}" @if( $u['id'] ==  old('user_id')) selected  @endif >{{$u['email']}}</option>
                            @endforeach
                                    </select>
                                 @if($errors->has("user_id"))
                                <span class="help-block">{{ $errors->first("user_id") }}</span>
                                @endif       
                              </div>

                      </div><!-- col-sm-6 -->

                     	 <div class="form-group col-sm-6 @if($errors->has('test_user_name')) has-error @endif">
                                <label class="control-label" for="name">Name</label>
                                <input type="text" id="name" name="test_user_name" class="form-control" placeholder="Please Enter Name" value='{{ old("name")}}' />
                                @if($errors->has("test_user_name"))
                                <span class="help-block">{{ $errors->first("test_user_name") }}</span>
                                @endif
                            </div>
                            

              </div><!-- row -->        
             
              <div class="row">

                     	 <div class=" form-group col-sm-6 @if($errors->has('test_user_email')) has-error @endif">
                                <label class="control-label" for="email">Email</label>
                                <input type="email" id="test_user_email" name="test_user_email" class="form-control" placeholder="Please Enter Email" value='{{ old("email")}}' />
                                @if($errors->has("test_user_email"))
                                <span class="help-block">{{ $errors->first("test_user_email") }}</span>
                                @endif
                            </div><!---End col-sm--6-->
                            <div class="form-group col-sm-6 @if($errors->has('test_user_contactno')) has-error @endif">
                                <label class="control-label" for="phone">Phone</label><br>
                                <input type="text" id="phone" name="test_user_contactno" class="form-control" placeholder="Please Enter Phone" value='{{ old("phone")}}' />
                                
                                @if($errors->has("test_user_contactno"))
                                <span class="help-block">{{ $errors->first("test_user_contactno") }}</span>
                                @endif
                   			</div><!-- col-sm-6 -->

         		 
              </div><!-- row -->  


    <!-- Editor  -->
        <div class="row">
        	<div class="form-group col-sm-12 @if($errors->has('test_user_msg')) has-error @endif">
        		<label class="control-label" for="test_user_msg">Message</label>
         		<textarea  placeholder="Enter Message here..." class="form-control long_description" rows="10" name="test_user_msg">
            {{ !is_null(old("test_user_msg")) ?old("test_user_msg") :''}}</textarea>

         		@if($errors->has("test_user_msg"))
						<span class="help-block">{{ $errors->first("test_user_msg") }}</span>
					@endif
                
      			</div>
      	</div>
      	<!-- Editor end -->

             <div class="row">

            	<div class="form-group col-sm-6 @if($errors->has('test_user_location')) has-error @endif">
                                <label class="control-label" for="location">Location</label>
                                <input type="text" id="name" name="test_user_location" class="form-control" placeholder="Please Enter Location" value='{{ old("test_user_location")}}' />
                                @if($errors->has("test_user_location"))
                                <span class="help-block">{{ $errors->first("test_user_location") }}</span>
                                @endif
                            </div>

                            <div class="form-group col-sm-6 @if($errors->has('test_user_img')) has-error @endif">
                                <label class="control-label" for="location">Image</label>
                                <input type="file" id="name" name="test_user_img" class="form-control"  />
                                
                            </div>
           
              </div><!-- row -->                   
        		<div class="row">
        			 <div class="form-group @if($errors->has('status')) has-error @endif">
                       <label class="control-label" style="margin-left: 10px;">Status</label>
                        <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if (!is_null(old("status")) && old("status") == 1) checked @endif required> 
                        @if($errors->has("status"))
                                <span class="help-block">{{ $errors->first("status") }}</span>
                                @endif
                        <label for="status_1" class="lbl" id="switch-box"></label>   
        				</div>
        		</div>



            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Add Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.testimonials.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div><!--Content Panel--->
    
  </div><!-- mainpanel -->

<script>
    jQuery(document).ready(function(){
        
        "use strict";
        
        // Chosen Select
        jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});
    });
    
    jQuery('#acc').click(function(){
        jQuery('#cc').show();
        jQuery(this).hide();
        return false;
    });
    
    jQuery('#abcc').click(function(){
        jQuery('#bcc').show();
        jQuery(this).hide();
        return false;
    });
    
    // HTML5 WYSIWYG Editor
    jQuery('#wysiwyg').wysihtml5({color: true,html:true});

    // Tags Input
  jQuery('#tags').tagsInput({width:'auto'});
  
  
    
</script>
<script>
jQuery(function() {
$('#user_id').select2();
           jQuery('.long_description').summernote({

             height:300,

           });

       });
</script>



@endsection
