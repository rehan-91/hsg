@extends('bracket-admin.includes.main')
@section('title','Edit City Details')
@section('content')

 <div class="pageheader">
      <h2><i class="fa fa-home"></i> City <span>Edit   City...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Edit City Details</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.cities.update', [$data->id])}}" method="POST">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.cities.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To City List</a>  
              </div>
              <h4 class="panel-title">City Details</h4>
            </div>
            <div class="panel-body">

              <div class="row">
                <div class="col-sm-6  @if($errors->has('city_name')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">City Name</label>
                    <input type="text" id="name" name="city_name" class="form-control" placeholder="Please Enter City Name" value="{{ $data->name}}" />

                    @if($errors->has("city_name"))
						<span class="help-block">{{ $errors->first("city_name") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

                <div class="col-sm-6  @if($errors->has('notice')) has-error @endif">
                <div class="form-group ">
                    <label class="control-label">Notice</label>
                    <textarea  name="notice" id="notice" class="form-control" cols="1" rows="1">{{ $data->notice }}</textarea>
                  </div>
                </div>
              </div>
              <!-- row -->

             <!-- Coutry with states -->
             <div class="row">

                <div class=" col-sm-6 @if($errors->has('country_id')) has-error @endif">
                    <label class="control-label" for="country_id">Country</label><br>
                    <select name="country_id"  class="form-control" onchange="getStates(this.value)">
                    <option value="">Select Country</option>
                    @foreach($countries as $c)
                    <option value="{{ $c->id }}" @if( $c->id == $data->country_id ) selected  @endif >{{ $c->country_name }}</option>
                    @endforeach
                    </select>
                      @if($errors->has("country_id"))
                            <span class="help-block">{{ $errors->first("country_id") }}</span>
                      @endif
                </div>
                          
                       <div class="col-sm-6 @if($errors->has('state_id')) has-error @endif">
                          <label class="control-label" for="state_id">State</label><br>
                          <select name="state_id"  class="form-control" id="state_id">
                          <option value="">Select State</option>
                          @foreach($states as $s)
                            <option value="{{ $s->id }}" @if( $s->id == $data->state_id ) selected  @endif >{{ $s->name }}</option>
                          @endforeach
                                    
                          </select>
                            @if($errors->has("state_id"))
                                  <span class="help-block">{{ $errors->first("state_id") }}</span>
                            @endif
                       </div>
               </div>
             <!-- End country with states -->
                          
            <div class="row">

                <div class="col-sm-4  @if($errors->has('image')) has-error @endif" >
                  <div class="form-group">
                    <label class="control-label">City Image</label>
                    <input type="file" id="image" name="image" class="form-control"  value='{{ $data->city_name }}' />
                    <img src="{{ asset('uploads/ads_image/'.$blog->blog_featured_img)}}">

                    @if($errors->has("image"))
                     <span class="help-block">{{ $errors->first("image") }}</span>
                    @endif


                  </div>
                </div><!-- col-sm-4 -->

                <div class="col-sm-6  @if($errors->has('longitude')) has-error @endif" >
                  <div class="form-group">
                    <label class="control-label">Longitude Name</label>
                    <input type="text" id="longitude" name="longitude" class="form-control" placeholder="Please Enter Longitude Name" value='{{ $data->longitude }}'/>
                          @if($errors->has("longitude"))
                            <span class="help-block">{{ $errors->first("longitude") }}</span>
                                      @endif
                               </div>
                </div><!-- col-sm-6 -->
      
                <div class="col-sm-6  @if($errors->has('lattitude')) has-error @endif" >
                  <div class="form-group">
                    <label class="control-label">Lattitude Name</label>
                    <input type="text" id="lattitude" name="lattitude" class="form-control" placeholder="Please Enter Lattitude Name" value='{{ $data->lattitude }}'  />

                    @if($errors->has("city_name"))
                     <span class="help-block">{{ $errors->first("lattitude") }}</span>
                    @endif
                  </div>
                </div><!-- col-sm-6 -->
              </div><!-- row -->


							<div class="input-box permissionTable" style="margin-top: 10px;">
                <label>Status</label>
                <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden"  @if(old('status') == 1) checked @endif >
                <label for="status_1" class="lbl" id="switch-box"></label>           
							</div>

            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Add Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.cities.index') }}'">Cancel</button>
            </div>
          </div>
        </div></div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->

<script>
    function getStates(id){
        if(id !== ""){
        $.ajax({
             headers: {
                'X-CSRF-TOKEN': $('input[name="_token"]').val()
              },
           type:"post",
           url:"{!! route('admin.cities.fetchstate') !!}",
           data:{id:id},
           success: function(data){
              $("#state_id").html(data);
           }
        });
        }
    }
</script>
@endsection

