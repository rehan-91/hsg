@extends('bracket-admin.includes.main')
@section('title','Edit Country Details')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Country <span>Edit Country Details...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Edit Country Details</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.countries.update', [$data->id])}}" method="POST">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.countries.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Country List</a>  
              </div>
              <h4 class="panel-title">Country Details</h4>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Country Name</label>
                    <input type="text" name="country_name" id="country_name" class="form-control" placeholder="Please Enter Country Name" value='{{ $data->country_name }}' required="" />

                    @if($errors->has("country_name"))
						<span class="help-block">{{ $errors->first("country_name") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->
                <div class="col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Country Sort Name</label>
                    <input type="text" name="country_sort_name" class="form-control" id="country_sort_name" placeholder="Please Enter Country Sort name" value='{{ $data->country_sort_name }}'required="" />
                    @if($errors->has("country_sort_name"))
						<span class="help-block">{{ $errors->first("country_sort_name") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->
              </div><!-- row -->
              
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Country Phone Code</label>
                    <input type="text" id="country_phone_code" name="country_phone_code"  class="form-control" placeholder="Please Enter Country Phone Code" value='{{ $data->country_phone_code }}' required="" />
                  </div>
                </div><!-- col-sm-6 -->


              </div><!-- row -->

					<div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden"  @if($data->status == 1) checked @endif > 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
        </div>
          </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Add Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.countries.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection