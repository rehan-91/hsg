@extends('bracket-admin.includes.main')
@section('title','Edit State Details')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> State <span>Edit State...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">State Details</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.states.update', [$data->id])}}" method="POST">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.states.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To State List</a>  
              </div>
              <h4 class="panel-title">Edit State Details</h4>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-sm-6  @if($errors->has('state_name')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">State Name</label>
                    <input type="text" id="name" name="state_name" class="form-control" value='{{ $data->name }}' />

                    @if($errors->has("state_name"))
						<span class="help-block">{{ $errors->first("state_name") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

                <div class="col-sm-6 @if($errors->has('country_id')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label" for="country_id" >Country</label>
                    <select name="country_id" class="select2 form-control">
	 					@foreach($countries as $con)
	                    <option value="{{ $con->id }}" @if( $con->id == $data->country_id ) selected  @endif >{{ $con->country_name }}</option>
	                   @endforeach
                    </select>
        				@if($errors->has("country_id"))
                                <span class="help-block">{{ $errors->first("country_id") }}</span>
                          @endif
                  </div>

                </div><!-- col-sm-6 -->
              </div><!-- row -->

               	<div class="form-group ">
                    <label class="control-label">Notice</label>
                    <textarea  name="notice" id="notice" class="form-control" >{{ $data->notice }}</textarea>
                  </div>
                                <div class="input-box permissionTable">
                                    <label>Status</label>
                                    <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if($data->status == 1) checked @endif> 
                                    <label for="status_1" class="lbl" id="switch-box"></label>
                                    
				</div>
            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Update Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.states.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection