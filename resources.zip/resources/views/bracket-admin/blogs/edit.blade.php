@extends('bracket-admin.includes.main')
@section('title',' Blog')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Blog <span> All Blog ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Blog</li>
        </ol>
      </div>
    </div> 
<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.blog.update', [$data->id])}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.blog.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To  Blog </a>  
              </div>
              <h4 class="panel-title">Blog Details</h4>
            </div>
            <div class="panel-body">

              <div class="row">
         		 <div class="form-group col-sm-12 @if($errors->has('blog_title')) has-error @endif">
                    <label class="control-label">Title</label>
                    <input type="text" name="blog_title" id="name" class="form-control" placeholder="Please Enter Title" value='{{ is_null(old("blog_title")) ? $data->blog_title : old("blog_title") }}' />

                    @if($errors->has("blog_title"))
						      <span class="help-block">{{ $errors->first("blog_title") }}</span>
					       @endif
                  </div>

              </div><!-- row -->        
             
              <div class="row">

                  <div class="form-group col-sm-6 @if($errors->has('blog_category')) has-error @endif">
                    <label class="control-label">Category</label>
                    <input type="text" name="blog_category" class="form-control"  placeholder="Please Enter Blog Category" value='{{ $data->blog_category }}' />
                  @if($errors->has("blog_category"))
                    <span class="help-block">{{ $errors->first("blog_category") }}</span>
                  @endif
                          </div><!-- col-sm-6 -->
         		 <div class="form-group col-sm-6">
                    <label class="control-label">Tags</label>
                    <input type="text" name="blog_tags" id="tags" class="form-control" placeholder="Please Enter Blog Tags" value='{{ $data->blog_tags }}' />
					        </div>

              </div><!-- row -->  


    <!-- Editor  -->
        <div class="row">
        	<div class="form-group col-sm-12 @if($errors->has('blog_desc')) has-error @endif">
        		<label class="control-label" for="blog_desc">Description</label>
         		<textarea id="ckeditor" placeholder="Enter text here..." class="form-control long_description" rows="10" name="blog_desc">
            {{ !is_null(old("blog_desc")) ?old("blog_desc") :$data->blog_desc}}</textarea>

         		@if($errors->has("blog_desc"))
						<span class="help-block">{{ $errors->first("blog_desc") }}</span>
					@endif
                
      			</div>
      	</div>
      	<!-- Editor end -->


              <div class="row">

            <div class="form-group col-sm-6 ">
                    <label class="control-label" >Meta Title</label>
                       <input type="text" name='blog_meta_title'  class="form-control" value='{{ !is_null(old("blog_meta_title")) ?old("blog_meta_title") :$data->blog_meta_title }}'>
    

                   </div><!-- col-sm-6 -->

             <div class="form-group col-sm-6">
                    <label class="control-label">Meta Keywords</label>
                    <input type="text" name="blog_meta_keywords" id="name" class="form-control" placeholder="Please Enter Blog Meta Keywords" value='{{ !is_null(old("blog_meta_keywords")) ?old("blog_meta_keywords") :$data->blog_meta_keywords}}'>
                  </div>

              </div><!-- row --> 

              <div class="row">
                
                <div class="col-sm-6 @if($errors->has('user_id')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label" for="user_id" >Posted By</label>
                    <select name="user_id" class="select2 form-control" id="user_id">
                         <option value="">Select</option>
                        @foreach($users as $u)
                        <option value="{{$u['id']}}" @if( $u['id'] ==  $data->user_id ) selected  @endif >{{$u['email']}}</option>
                            @endforeach
                                    </select>
                                    @if($errors->has("user_id"))
                                <span class="help-block">{{ $errors->first("user_id") }}</span>
                                @endif       
                              </div>

                </div><!-- col-sm-6 -->


                                  
             <div class="form-group col-sm-6">
                    <label class="control-label">Sort Order</label>
                    <input type="number" name="sort_order" id="name" class="form-control" min="0"  value="{{ $data->sort_order }}">
                  </div>

              </div><!-- row --> 

              <div class="row">

             <div class="form-group col-sm-12">
                    <label class="control-label">Meta Discription</label>
                    <textarea  name="blog_meta_description"  class="form-control" min="0"  > {{ !is_null(old("blog_meta_description")) ?old("blog_meta_description") :$data->blog_meta_description}}</textarea>
                  </div>

              </div><!-- row --> 


              <div class="row">
                <div class="col-sm-6 ">
                  <div class="form-group">
                    <label class="control-label">Featured Image</label>
                    <input type="file" name="blog_featured_image" class="form-control" id="blog_featured_image" value='{{ old("blog_featured_image") }}'/>
                   
                  </div>
                </div><!-- col-sm-6 -->

            </div>            
                   
        		<div class="row">
        			 <div class="form-group">
                       <label class="control-label" style="margin-left: 10px;">Status</label>
                        <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if ($data->blog_status == 1) checked @endif> 
                        <label for="status_1" class="lbl" id="switch-box"></label>   
        				</div>
        		</div>



            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Update Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.blog.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div><!--Content Panel--->
    
  </div><!-- mainpanel -->

<script>
jQuery(document).ready(function(){
    
    "use strict";
    
  // HTML5 WYSIWYG Editor
  jQuery('#wysiwyg').wysihtml5({color: true,html:true});
  
  // CKEditor
  jQuery('#ckeditor').ckeditor();
  
  jQuery('#inlineedit1, #inlineedit2').ckeditor();
  
  // Uncomment the following code to test the "Timeout Loading Method".
  // CKEDITOR.loadFullCoreTimeout = 5;

  window.onload = function() {
  // Listen to the double click event.
  if ( window.addEventListener )
  document.body.addEventListener( 'dblclick', onDoubleClick, false );
  else if ( window.attachEvent )
  document.body.attachEvent( 'ondblclick', onDoubleClick );
  };

  function onDoubleClick( ev ) {
  // Get the element which fired the event. This is not necessarily the
  // element to which the event has been attached.
  var element = ev.target || ev.srcElement;

  // Find out the div that holds this element.
  var name;

  do {
    element = element.parentNode;
  }
  while ( element && ( name = element.nodeName.toLowerCase() ) &&
    ( name != 'div' || element.className.indexOf( 'editable' ) == -1 ) && name != 'body' );

  if ( name == 'div' && element.className.indexOf( 'editable' ) != -1 )
    replaceDiv( element );
  }

  var editor;

  function replaceDiv( div ) {
    if ( editor )
      editor.destroy();
    editor = CKEDITOR.replace( div );
  }

   // Tags Input
  jQuery('#tags').tagsInput({width:'auto'});
  
});
</script>

<script>
jQuery(function() {
$('#user_id').select2();
           jQuery('.long_description').summernote({

             height:300,

           });

       });
</script>

@endsection
