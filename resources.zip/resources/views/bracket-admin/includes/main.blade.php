<!DOCTYPE html>
<html  lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="author" content="">
         <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">


        <link rel="shortcut icon" href="{{asset('bracket_admin/images/favicon.ico')}}" type="image/png">

        <title>HOSG | @yield('title')</title>

        
        <link href="{{asset('bracket_admin/css/style.default.css')}}" rel="stylesheet">
        <link href="{{asset('bracket_admin/css/jquery.datatables.css')}}" rel="stylesheet">
        <!-- Alert -->
        <link href="{{asset('bracket_admin/css/jquery.gritter.css')}}" rel="stylesheet">
        <!-- Tags -->
        <link rel="stylesheet" href="{{asset('bracket_admin/css/jquery.tagsinput.css')}}" />


        <!-- Scripts -->
        <script src="{{asset('bracket_admin/js/jquery-1.11.1.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/jquery-migrate-1.2.1.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/modernizr.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/jquery.sparkline.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/toggles.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/retina.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/jquery.cookies.js')}}"></script>

        <!-- Email Temlplate -->
        <script src="{{asset('bracket_admin/js/wysihtml5-0.3.0.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/bootstrap-wysihtml5.js')}}"></script>
        <script src="{{asset('bracket_admin/js/ckeditor/ckeditor.js')}}"></script>
        <script src="{{asset('bracket_admin/js/ckeditor/adapters/jquery.js')}}"></script>
        <link rel="stylesheet" href="{{asset('bracket_admin/css/bootstrap-wysihtml5.css')}}" />

        <!-- tags -->
        <script src="{{asset('bracket_admin/js/jquery.tagsinput.min.js')}}"></script>
              <!-- Forms Wizard -->
        <script src="{{asset('bracket_admin/js/bootstrap-wizard.min.js')}}"></script>



        <script src="{{asset('bracket_admin/js/jquery.datatables.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/select2.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/custom.js')}}"></script> 
        
<!-- Ad more js -->
        <script src="{{ asset('bracket_admin/js/ad_more.js') }}"></script>

        <script src="{{ asset('bracket_admin/js/admin-custom.js') }}"></script>

<!-- Calender -->
        <link href="{{ asset('bracket_admin/css/fullcalendar.css')}}" rel="stylesheet">
        <script src="{{ asset('bracket_admin/js/fullcalendar.min.js')}}"></script>
        <script src="{{ asset('bracket_admin/js/jquery.ui.touch-punch.min.js')}}"></script>

  
      









    </head>

    <body>
        @include('bracket-admin.includes.left_sidebar')
        @include('bracket-admin.includes.header')

        @yield('content')

        @include('bracket-admin.includes.right_sidebar')

  <script>
    function deleteAction(model_id, id){
    if( confirm("Are you sure?") ){
      jQuery.ajax({
            headers: {
           'X-CSRF-TOKEN': $('input[name="_token"]').val()
                             },
        type: 'POST',
        dataType: "JSON",
      data : {model_id:model_id, id:id},
        url: "{!! route('admin.ajax.destroy') !!}",
        success: function(data) {
          if( data.access_error_msg ){
            show_error_container( data.access_error_msg );
          }
          else if( data.error ){
            show_error_container( data.error );
          }
          else if( data.success ){
            dTable.ajax.reload();
            show_success_container( data.success );
          }
        },
      });
    }
  }
</script>
<!-- Email -->
    </body>
</html>
