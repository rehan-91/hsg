
<div class="mainpanel">
 <div class="headerbar">
                    <a class="menutoggle"><i class="fa fa-bars"></i></a>

         

                    <div class="header-right">
                        <ul class="headermenu">
                           
                                <div class="btn-group">
                                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                        <img src="{{asset('bracket_admin/images/photos/loggeduser.png')}}" alt="" />
                                        {{ Auth::user()->name }}
                                        <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                                        @hasanyrole( ''.App\Models\Role::ROLE_SUPERADMIN.'|'.App\Models\Role::ROLE_SUBADMIN.'' )
                                        <li><a href="#"><i class="glyphicon glyphicon-user"></i> My Profile</a></li>

                                        <li><a href="{{ route('admin.settings.general') }}"><i class="glyphicon glyphicon-cog"></i>General Settings</a></li>

                                        <li><a href="{{ route('admin.email-templates.index') }}"><i class="glyphicon glyphicon-envelope"></i> Email</a></li>                                        
                                        <li><a href="{{ route('admin.content.index') }}"><i class="glyphicon glyphicon-edit"></i> Content Mannagement</a></li>
                                        <li><a href="{{ route('admin.blog.index') }}"><i class="glyphicon glyphicon-check"></i>Blogs</a></li>
                                        <li><a href="{{ route('admin.testimonials.index') }}"><i class="glyphicon glyphicon-user"></i>Testimonials</a></li>
                                        @endif
                                        <li><a href="{{ route('admin.changePassword') }}"><i class="glyphicon glyphicon-lock"></i> Change Password</a>
                                        <li><a href="{{ route('admin.logout') }}"><i class="glyphicon glyphicon-log-out"></i> Log Out</a></li>
                                    </ul>
                                </div>
                            </li>
                            
                        </ul>
                    </div><!-- header-right -->

                </div><!-- headerbar -->
