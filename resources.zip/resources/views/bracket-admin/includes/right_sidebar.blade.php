<!--    <div class="footer">
            <div class="pull-left">
                &copy; <b>{{ date('Y') }}</b>. All rights reserved.<span>
            </div>
            <div class="pull-right">
               Developed by:<a href="https://www.vocso.com/" target="_blank" rel="nofollow">VOCSO</a>
            </div>
        </div> -->


</section>
