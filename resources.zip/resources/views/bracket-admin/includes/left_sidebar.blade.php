<!-- Preloader -->
<div id="preloader">
    <div id="status"><i class="fa fa-spinner fa-spin"></i></div>
</div>
        <section>

            <div class="leftpanel">

                <div class="logopanel">
                    <h1><span>[</span> HOSG <span>]</span></h1>
                </div><!-- logopanel -->

                <div class="leftpanelinner">

                    <!-- This is only visible to small devices -->
                    <div class="visible-xs hidden-sm hidden-md hidden-lg">   
                        <div class="media userlogged">
             
                            <div class="media-body">
                                <h4>{{ Auth::user()->name }}</h4>
                                <span>"Life is so..."</span>
                            </div>
                        </div>

                        <h5 class="sidebartitle actitle">Account</h5>

            @hasanyrole( ''.App\Models\Role::ROLE_SUPERADMIN.'|'.App\Models\Role::ROLE_SUBADMIN.'' )
                        <ul class="nav nav-pills nav-stacked nav-bracket mb30">
                                        <li><a href="#"><i class="glyphicon glyphicon-user"></i> My Profile</a></li>

                                        <li><a href="{{ route('admin.settings.general') }}"><i class="glyphicon glyphicon-cog"></i>General Settings</a></li>

                                        <li><a href="{{ route('admin.email-templates.index') }}"><i class="glyphicon glyphicon-envelope"></i> Email Template</a></li>
                                        
                                        <li><a href="{{ route('admin.content.index') }}"><i class="glyphicon glyphicon-edit"></i> Content Mannagement</a></li>


                                        <li><a href="{{ route('admin.blog.index') }}"><i class="glyphicon glyphicon-edit"></i>Blogs</a></li>
                                        <li><a href="{{ route('admin.testimonials.index') }}"><i class="fa fa-quote-left"></i>Testimonials</a></li>

                                        <li><a href="{{ route('admin.changePassword') }}"><i class="glyphicon glyphicon-lock"></i> Change Password</a>
                                        <li><a href="{{ route('admin.logout') }}"><i class="glyphicon glyphicon-log-out"></i> Log Out</a></li>
                        </ul>
                            @endif
                    </div>
                    <h5 class="sidebartitle">Navigation</h5>
                    <ul class="nav nav-pills nav-stacked nav-bracket">
                        <li @if(\Request::is('admin/dashboard'))  @endif><a href="{{ route('admin.index') }}"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
                        <li @if( \Request::is('admin/plans') || \Request::is('admin/plans/*') ) class="active" @endif><a href="{{ route('admin.plans.index') }}"><i class="fa fa-columns"></i> <span>Plans</span></a></li>
                        <!-- <li class="nav-parent"><a href=""><i class="fa fa-edit"></i> <span>Masters</span></a> -->
                            <li><a href="{{ route('admin.masters.mastertab') }}"><i class="fa fa-database"></i> <span>Masters</span></a>
                            <ul class="children">
                                <li><a href="{{ route('admin.masters.age') }}"><i class="fa fa-caret-right"></i>Age</a></li>
                                <li><a href="{{ route('admin.masters.height') }}"><i class="fa fa-caret-right"></i> Height</a></li>
                                <li><a href="{{ route('admin.masters.weight') }}"><i class="fa fa-caret-right"></i> Weight</a></li>
                                <li><a href="{{ route('admin.masters.nationality') }}"><i class="fa fa-caret-right"></i> Nationality</a></li>
                                <li><a href="{{ route('admin.masters.orientation') }}"><i class="fa fa-caret-right"></i> Orientation</a></li>
                                <li><a href="{{ route('admin.masters.eyecolor') }}"><i class="fa fa-caret-right"></i> Eye color</a></li>
                                <li><a href="{{ route('admin.masters.haircolor') }}"><i class="fa fa-caret-right"></i>Hair Color</a></li>
                                <li><a href="{{ route('admin.masters.hairlength') }}"><i class="fa fa-caret-right"></i>Hair Length</a></li>
                                <li><a href="{{ route('admin.masters.bustsize') }}"><i class="fa fa-caret-right"></i> Bust Size</a></li>
                                <li><a href="{{ route('admin.masters.dresssize') }}"><i class="fa fa-caret-right"></i> Dress Size</a></li>
                                <li><a href="{{ route('admin.masters.shoessize') }}"><i class="fa fa-caret-right"></i> Shoes Size</a></li>
                                <li><a href="{{ route('admin.masters.personal') }}"><i class="fa fa-caret-right"></i>Personal</a></li>
                                <li><a href="{{ route('admin.masters.piercing') }}"><i class="fa fa-caret-right"></i>Piercing</a></li>
                                <li><a href="{{ route('admin.masters.favourite-things') }}"><i class="fa fa-caret-right"></i>Favourite Things</a></li>
                                <li><a href="{{ route('admin.masters.wishlist') }}"><i class="fa fa-caret-right"></i>Wishlists</a></li>
                                <li><a href="{{ route('admin.masters.service-type') }}"><i class="fa fa-caret-right"></i>Service Type</a></li>
                                <li><a href="{{ route('admin.masters.services-available') }}"><i class="fa fa-caret-right"></i> Services Available</a></li>
                                <li><a href="{{ route('admin.masters.service-available-for') }}"><i class="fa fa-caret-right"></i>Services Available For</a></li>
                            </ul>
                        </li>

                        <li class="nav-parent @if( \Request::is('admin/countries') || \Request::is('admin/countries/*') || \Request::is('admin/states/*')
                              || \Request::is('admin/states/*') || \Request::is('admin/cities/*') || \Request::is('admin/cities/*')) active @endif"><a href=""><i class="fa fa-map-marker"></i> <span>Location Management</span></a>
                            <ul class="children">
                                <li><a href="{{ route('admin.countries.index') }}"><i class="fa fa-caret-right"></i> Countries</a></li>
                                <li><a href="{{ route('admin.states.index') }}"><i class="fa fa-caret-right"></i> States</a></li>
                                <li><a href="{{ route('admin.cities.index') }}"><i class="fa fa-caret-right"></i>Cities</a></li>
                            </ul>
                        </li>
                        <li><a href="{{ route('admin.OtherAds') }}"><i class="fa fa-cog"></i> <span>Other Ads</span></a></li>

                          <li class="nav-parent">
                            <a href=""><i class="fa fa-cog"></i> <span>Independent Escort </span></a>
                            <ul class="children">
                                <li><a href="{{ route('admin.individual.index') }}"><i class="fa fa-caret-right"></i> View All Independent Escort</a></li>
                            </ul>
                        </li>
                        
                          <li><a href="{{ route('admin.fe-users.index') }}"><i class="fa fa-user"></i> <span>Users</span></a></li>

                        <li><a href="{{ route('admin.usertype.index') }}"><i class="fa fa-th-list"></i> <span>Listing Type</span></a></li>
                        
                        <li @if( \Request::is('admin/adminusers') || \Request::is('admin/adminusers/*') ) class="active"
                         @endif><a href="{{ route('admin.admins.index') }}"><i class="fa fa-user"></i> <span>Admin Users</span></a></li>

                        <li><a href="{{ route('admin.email-templates.index') }}"><i class="fa fa-envelope"></i> Email</a></li> 

                 <li class="nav-parent">
                    <a href="#"><i class="fa fa-map-marker"></i> <span>Identity Verification</span></a>
                            <ul class="children">
                                <li><a href="{{ route('admin.verificationIndex') }}"><i class="fa fa-caret-right"></i> All  Identity</a></li>
                                <li><a href="{{ route('admin.pendingIdentity') }}"><i class="fa fa-caret-right"></i> Pending Identity </a></li>
                                <li><a href="{{ route('admin.verifiedIdentity') }}"><i class="fa fa-caret-right"></i>Verified Identity</a></li>
                            </ul>
                        </li>
                    </ul>
                    </div><!-- infosummary -->

                </div><!-- leftpanelinner -->
            </div><!-- leftpanel -->

