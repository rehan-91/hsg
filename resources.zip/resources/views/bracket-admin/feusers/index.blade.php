@extends('bracket-admin.includes.main')
@section('title','All Users')
@section('content')
<script>
function timedMsg()
{
var t=setTimeout("document.getElementById('myMsg').style.display='none';",2000);
}
</script>
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Verification <span>All Data...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">All Users</li>
        </ol>
      </div>
    </div> 

  <div class="contentpanel">    
      <div class="panel panel-default">  
        <div class="panel-body">
          <!-- Info section -->
          <div id="myMsg">@include('bracket-admin.includes.info')</div> 
        <script language="JavaScript" type="text/javascript">timedMsg()</script>
        <!-- Info End here -->         
        <div class="btn-demo">
                    <a class="btn btn-primary" href="{{ route('admin.fe-users.create') }}"><i class="fa fa-plus"></i>Add New User</a>
               </div>
  <div class="table-responsive">
         <table class="table table-striped" id="table1">
              <thead>
                 <tr>   
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Added On</th>
                    <th>Identity Verification</th>
                    <th>Action</th>
                 </tr>
              </thead>
              <tbody>
                @foreach( $users as $user)

                 <tr class="odd gradeX">
                  
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>{{$user->phone}}</td>
                    <td><input type="checkbox" @if ($user->status == 1) checked @endif>
                      @if ($user->status == 1)
                      <label><span style="color: #008000;">Verified User</label>
                      @else
                      <label><span style="color: #FF0000;">Not Verified yet.</label>
                      @endif
                       </td>
                    <td class="center"> {{date("M d, Y", strtotime($user->created_at))}} at {{date("H:m a", strtotime($user->created_at))}}</td>

                    

                    <td>
                      <a href=""><i class="fa fa-pencil"></i></a>
                      <a href="" class="delete-row"><i class="fa fa-trash-o" title="Delete"></i></a>
                  </td>
                 </tr>
                 @endforeach
                 
              </tbody>
           </table>
          </div><!-- table-responsive -->
           
        </div><!-- panel-body -->
      </div><!-- panel -->
        
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->


<script>
  jQuery(document).ready(function() {
    
    "use strict";
    
    jQuery('#table1').dataTable();
    
    
    // Select2
    jQuery('select').select2({
        minimumResultsForSearch: -1
    });    
  
  });
</script>


@endsection
