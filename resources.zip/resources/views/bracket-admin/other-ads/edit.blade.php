@extends('bracket-admin.includes.main')
@section('title','Add New Other Ads')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Other Ads <span>Add New Other Ads...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Other Ads Details</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.other_ads_update', [$other_ads->id]) }}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.OtherAds')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Other Ads List</a>  
              </div>
              <h4 class="panel-title">Other Ads Details</h4>
            </div>
            
            <div class="panel-body">
              <div class="row">

                <div class="col-sm-6 @if($errors->has('other_ads_title')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Ads Title</label>
                    <input type="text" name="other_ads_title" id="other_ads_title" class="form-control" placeholder="Please Enter Ads Title " value="{{$other_ads->title}}" required="" />

                    @if($errors->has("other_ads_title"))
						<span class="help-block">{{ $errors->first("other_ads_title") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

               <div class="col-sm-6 @if($errors->has('other_ads_sort_order')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Sort Order</label>
                    <input type="text" id="other_ads_sort_order" name="other_ads_sort_order"  class="form-control" placeholder="Other Ads Sort order" value='{{ $other_ads->sort_order}}' required="" />
                    @if($errors->has("other_ads_sort_order"))
                            <span class="help-block">{{ $errors->first("other_ads_sort_order") }}</span>
                    @endif                   
                  </div>
                </div><!-- col-sm-6 -->

              </div><!-- row -->        
                    
              <div class="row">


                <div class="col-sm-6 @if($errors->has('other_ads_photo')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Ads Photos / Banner</label>
                    <span style="color:red;"> (Min Width : 500 required)</span>
                    <input type="file" name="other_ads_photo" class="form-control" id="other_ads_photo" value='{{ $other_ads->title }}' />
                    @if($errors->has("other_ads_photo"))
                <span class="help-block">{{ $errors->first("other_ads_photo") }}</span>
                    @endif
                    @if(!empty($other_ads->ad_photo))
                    @php
                    $imageurl = url('uploads/other_ads_photos/'.$other_ads->ad_photo);
                    @endphp
                     <img src="{{ $imageurl }}" width="20%"> 
                    @endif
                  <input type="hidden" name="old_other_ads_photos" value="{{ $other_ads->ad_photo }}">

                  </div>
                </div><!-- col-sm-6 -->

              </div><!-- row -->

            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Update Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.OtherAds') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection
