@extends('bracket-admin.includes.main')
@section('title',' Edit Content')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Content <span> Edit Content ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Edit Content</li>
        </ol>
      </div>
    </div> 
<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.content.update', [$content->id])}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.content.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To  All Content </a>  
              </div>
              <h4 class="panel-title">Edit Content Details</h4>
            </div>
            <div class="panel-body">

              <div class="row">
         		 <div class="form-group col-sm-6 @if($errors->has('content_title')) has-error @endif">
                    <label class="control-label">Content Title</label>
                    <input type="text" name="content_title" id="name" class="form-control" placeholder="Please Enter Content Title" value='{{ $content->content_title }}'/>
					@if($errors->has("content_title"))
						<span class="help-block">{{ $errors->first("content_title") }}</span>
					@endif
                  </div>

               <div class="form-group col-sm-6 @if($errors->has('content_short_desc')) has-error @endif">
        		<label class="control-label" for="content_short_desc">Short Description</label>
         		<input type="text"  class="form-control" name="content_short_desc" placeholder="Enter short description" value='{{ $content->content_short_desc }}' />

         		@if($errors->has("content_short_desc"))
						<span class="help-block">{{ $errors->first("content_short_desc") }}</span>
					@endif
                
      			</div>

              </div><!-- row -->

             <!-- Editor  -->
        <div class="row">
        	<div class="form-group col-sm-12 @if($errors->has('content_long_desc')) has-error @endif">
        		<label class="control-label" for="content_long_desc">Full Description</label>
         		<textarea  placeholder="Enter text here..." class="form-control long_description" rows="10" name="content_long_desc">
            {{ $content->content_long_desc}}</textarea>

         		@if($errors->has("content_long_desc"))
						<span class="help-block">{{ $errors->first("content_long_desc") }}</span>
					@endif
                
      			</div>
      	</div>
      	<!-- Editor end -->
  
              <div class="row">

            <div class="form-group col-sm-6 @if($errors->has('content_meta_title')) has-error @endif">
                    <label class="control-label" >Meta Title</label>
                       <input type="text" name='content_meta_title'  class="form-control" value="{{ $content->content_meta_title }}" placeholder="Please enter content Meta Title ">
                       @if($errors->has("content_meta_title"))
						<span class="help-block">{{ $errors->first("content_meta_title") }}</span>
					@endif
                   </div><!-- col-sm-6 -->

             <div class="form-group col-sm-6 @if($errors->has('content_meta_keywords')) has-error @endif">
                    <label class="control-label">Meta Keywords</label>
                    <input type="text" name="content_meta_keywords" id="name" class="form-control" placeholder="Please Enter Content Meta Keywords" value="{{$content->content_meta_keywords }}">
                    @if($errors->has("content_meta_keywords"))
						<span class="help-block">{{ $errors->first("content_meta_keywords") }}</span>
					@endif
                
                  </div>

              </div><!-- row --> 

              <div class="row">

             	<div class="form-group col-sm-12">
                    <label class="control-label">Meta Discription</label>
                    <textarea  name="content_meta_description"  class="form-control"  placeholder="Content Meta Description " > {{ $content->content_meta_description }}</textarea>
                  </div>

              </div><!-- row -->            
                   
        		<div class="row">
        			 <div class="form-group">
                       <label class="control-label" style="margin-left: 10px;">Status</label>
                        <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if ($content->content_status == 1) checked @endif> 
                        <label for="status_1" class="lbl" id="switch-box"></label>   
        				</div>
        		</div>


            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Update Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.content.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div><!--Content Panel--->
    
  </div><!-- mainpanel -->

<script>
jQuery(function() {
$('#user_id').select2();
           jQuery('.long_description').summernote({

             height:300,

           });

       });
</script>
@endsection
