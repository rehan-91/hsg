@extends('bracket-admin.includes.main')
@section('title','Content Management')
@section('content')

<script>
function timedMsg()
{
var t=setTimeout("document.getElementById('myMsg').style.display='none';",2000);
}
</script>
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Content Management <span>All Contents...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">All Contents </li>
        </ol>
      </div>
    </div> 

  <div class="contentpanel">    
      <div class="panel panel-default">  
        <div class="panel-body">
          <!-- Info section -->
          <div id="myMsg">@include('bracket-admin.includes.info')</div> 
        <script language="JavaScript" type="text/javascript">timedMsg()</script>
        <!-- Info End here -->
            <div class="btn-demo">
                    <a class="btn btn-primary" href="{{ route('admin.content.create') }}"><i class="fa fa-plus"></i>Add New Content</a>
               </div>         
    <div class="table-responsive">
          <table class="table table-striped" id="content-table">
              <thead>
                 <tr>
                    <th>Title</th>
					<th>Page URL</th>
					<th>Added On</th>
                    <th>Status</th>
					<th>Action&nbsp;</th>                
				</tr>
              </thead>
             
           </table>
         </div><!-- table-responsive -->  
        </div><!-- panel-body -->
      </div><!-- panel -->
        
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->
<script>
	jQuery(function() {
		jQuery('#content-table').DataTable({
			"autoWidth": false,
                        stateSave: true,
			language: {
				searchPlaceholder: "Search through Plan title",
				"paginate": {
					"first": "&verbar ;&lt;",
					"last": "&gt; &verbar;",
					"next": "&gt;",
					"previous": "&lt;"
				},
				"lengthMenu": " _MENU_ ",
				"info": "_START_ - _END_ of _TOTAL_ items",
				"infoEmpty": "0 - 0 of 0 items",
				"search": "search",
                                
                              
			},
			order: [],
			"dom": 'ftilrp',
			processing: true,
			serverSide: true,
                        
			ajax: '{!! route('admin.content.data') !!}',
			columns: [
				{ data: 'title', name: 'title' },
				{ data: 'page_slug', name: 'page_slug' },
				{ data: 'created_at', name: 'created_at' },
				{ data: 'content_status', name: 'content_status' },
				{ data: 'action', name: 'action' }
			],
			"columnDefs": [
				{ "orderable": false, "targets": [3,4] }
		    ]
		});
	});
</script>

@endsection
