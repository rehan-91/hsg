@extends('bracket-admin.includes.main')
@section('title','Edit User ')
@section('content')

  <div class="pageheader">
      <h2><i class="fa fa-user"></i> User <span>Edit User ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Edit User</li>
        </ol>
      </div>
    </div>

    <div class="contentpanel">            
      <div class="row">
      <form  action="{{route('admin.fe-users.update', $users->id)}}" method="POST" enctype="multipart/form-data"> 
    {{ csrf_field() }}
            
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.fe-users.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To All Users List</a>  
              </div>
              <h4 class="panel-title">User Details</h4>
            </div>
            <div class="panel-body">

              <div class="row">
             <div class="form-group col-sm-6 @if($errors->has('name')) has-error @endif">
                    <label class="control-label">Name</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Please Enter Title" value='{{ $users->name }}' />
                      @if($errors->has("name"))
            <span class="help-block">{{ $errors->first("name") }}</span>
          @endif
                  </div>

                  <div class="form-group col-sm-6 @if($errors->has('email')) has-error @endif">
                    <label class="control-label">Email</label>
                    <input type="email" name="email" class="form-control"  placeholder="Please Enter Email" value='{{ $users->email }}'/>
                      @if($errors->has("email"))
            <span class="help-block">{{ $errors->first("email") }}</span>
          @endif
                  </div>

                  <!-- col-sm-6 -->
              </div><!-- row -->      

               <div class="row">

                   <div class="form-group col-sm-6 @if($errors->has('phone')) has-error @endif">
                    <label class="control-label">Phone</label>
                    <input type="number" name="phone" id="phone" class="form-control" placeholder="Please Enter Phone" value='{{ $users->phone}}' />
                      @if($errors->has("phone"))
            <span class="help-block">{{ $errors->first("phone") }}</span>
          @endif
                  </div>

                  <div class="form-group col-sm-6 @if($errors->has('password')) has-error @endif">
                    <label class="control-label">Password &nbsp;(<span style="color:#777;">Leave blank if you don't want to change password.</span>)</label>
                    <input id="password-field" type="password" class="form-control" name="password" value="">
                  <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                    @if($errors->has("password"))
            <span class="help-block">{{ $errors->first("password") }}</span>
          @endif
                  </div><!-- col-sm-6 -->
                  

              </div><!-- row -->      

    <div class="row">
       <div class="form-group">
               <label >Status:
                <input type="checkbox" name="status" value="1" @if($users->status == 1) checked @endif> 
                </label>
                
        </div>               
    </div>

      <div class="panel-footer">
              <button class="btn btn-primary">Add Now </button>
            <button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.fe-users.index') }}'">Cancel</button>
            </div>

            </div><!-- panel-body -->
            
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel --> 
  <style type="text/css">
    .field-icon {
  float: right;
  margin-left: -25px;
  margin-top: -25px;
  position: relative;
  z-index: 2;
}

.container{
  padding-top:50px;
  margin: auto;
}
  </style>
  <script>
    $(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
  </script>
@endsection