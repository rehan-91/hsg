<?php

namespace App\Http\Controllers\Frontend;
use Illuminate\Support\Facades\Validator;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Subscriber;
use App\Models\Report;
use Response;



class SubscriberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
             $validator = Validator::make( $request->all(), [
            'subs_email' => 'required|email|unique:subscriber',
            'g-recaptcha-response' => 'required|captcha'
           
                    ], [
                        'subs_email.required' => 'Please enter Email.',
                        'g-recaptcha-response.required' => 'Before you proceed to the subscribe, please complete the captcha.'

                    ]);
             
         
        if ($validator->fails()) {
            
            return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
            
        }

        $subscribe_for = implode(',', $request->get('subs_for'));

        $subs = new Subscriber();
       
        $subs->subs_name = $request->input('subs_name');
        $subs->subs_email = $request->input('subs_email');
        $subs->subs_phone = $request->input('subs_phone');
        $subs->subs_for = $subscribe_for;
        $subs->ad_id = $request->input('test_ad_id');
        $subs->save();

       
       
       
        $subs->save();
        
       return Response::json(  array('success' => "Subscribe successfully."));
    }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function reportAd(Request $request){


        $validator = Validator::make( $request->all(), [
            'report_email' => 'required|email',
            'g-recaptcha-response' => 'required|captcha'
            
                    ], [
                        'report_email.required' => 'Please enter Email.',
                        'g-recaptcha-response.required' => 'Before you proceed to the report, please complete the captcha.'
                                            
                    ]);
                      
        if ($validator->fails()) {
            
            return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
            
        } 

        $report_for = implode(',', $request->get('report_for'));

        $subs = new Report();
        $subs->report_name = $request->input('report_name');
        $subs->report_email = $request->input('report_email');
        $subs->report_phone = $request->input('report_phone');
        $subs->other_report_type = $request->input('other_report');
        $subs->report_for = $report_for;
        $subs->ad_id = $request->input('ad_id');
        $subs->status = 0;

        $subs->save();
        
         return Response::json( array('success' => "Reported successfully."));
    } 

    
}
