@extends('bracket-admin.includes.main')
@section('title','Add Listing')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Listing <span>Add New Listing ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Add New Listing</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.usertype.store') }}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{ route('admin.usertype.index') }}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Listing</a>  
              </div>
              <h4 class="panel-title">Add Listing </h4>
            </div>
            <div class="panel-body">
              <div class="row">

                <div class="col-sm-6 @if($errors->has('title')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Title</label>
                    <input type="text" id="name" name="title" class="form-control" placeholder="Please Enter Title" value='{{ old("title")}}' />
					@if($errors->has("title"))
						<span class="help-block">{{ $errors->first("title") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

               <div class="col-sm-6 @if($errors->has('class_name')) has-error @endif">
					<label class="control-label" for="class_name">Class Name</label><br>
                    <input type="text" id="class_name" name="class_name" class="form-control" placeholder="Please Enter Class Name" value='{{ is_null(old("class_name")) ? "" : old("class_name") }}' />
					@if($errors->has("class_name"))
						<span class="help-block">{{ $errors->first("class_name") }}</span>
					@endif
				</div>

              </div><!-- row -->   

              <div class="row">

              	<div class="col-sm-6">
					<label class="control-label" for="sort_order">Sort Order</label><br>
                    <input type="number" id="sort_order" min="0" name="sort_order" class="form-control" placeholder="Please Enter Class Name" value='{{ is_null(old("sort_order")) ? "": old("sort_order") }}' />
	              </div> 

	              <div class="col-sm-6">
					<label class="control-label" for="name">Add Icon</label><br>
                    <input type="file" name="listing_type_icon" class="form-control">
				@if($errors->has("listing_type_icon"))
						<span class="help-block">{{ $errors->first("listing_type_icon") }}</span>
					@endif
				</div>

				</div><!--row-->   


              <div class="row">

              	<div class="col-sm-6">
					<label class="control-label" for="banner">Add Banner</label><br>
                    <input type="file" name="listing_type_banner" class="form-control"  />
                    @if($errors->has("listing_type_banner"))
						<span class="help-block">{{ $errors->first("listing_type_banner") }}</span>
					@endif
	              </div> 

	              <div class="col-sm-6">
					<label class="control-label" for="name">Disclaimer</label>
					<textarea  name="listing_type_disclaimer"  class="form-control" min="0"  placeholder="Enter Disclaimer here...." > {{ !is_null(old('listing_type_disclaimer')) ?old('listing_type_disclaimer') :''}}</textarea>
                  </div>
				</div>

				</div><!--row-->   
                    
             
            </div><!-- panel-body -->
            <div class="panel-footer">
              <input type="hidden" id="meta_name" name="meta_name" value="age">
              <button class="btn btn-primary">Add Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.usertype.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection
