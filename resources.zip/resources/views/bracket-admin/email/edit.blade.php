@extends('bracket-admin.includes.main')
@section('title',' Compose Email')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Email <span>Compose Email ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Compose Email</li>
        </ol>
      </div>
    </div> 
<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.email-templates.update', [$content->id])}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.email-templates.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Emails </a>  
              </div>
              <h4 class="panel-title">Email Template Details</h4>
            </div>
            <div class="panel-body">

              <div class="row">
         		 <div class="form-group col-sm-6 @if($errors->has('template_name')) has-error @endif">
                    <label class="control-label">Email Template Name</label>
                    <input type="text" name="template_name" id="name" class="form-control" placeholder="Please Enter Template Name" placeholder="Please Enter Template Name" value="{{$content->identifier_name}}" />

                    @if($errors->has("template_name"))
						<span class="help-block">{{ $errors->first("template_name") }}</span>
					@endif
                  </div>

                  <div class="form-group col-sm-6 @if($errors->has('from_email')) has-error @endif">
                    <label class="control-label">From Email</label>
                    <input type="text" name="from_email" class="form-control"  placeholder="Email From" value='{{ $content->from_address }}' />
					@if($errors->has("from_email"))
						<span class="help-block">{{ $errors->first("from_email") }}</span>
					@endif
                  </div><!-- col-sm-6 -->
              </div><!-- row -->        
             
              <div class="row">
         		 <div class="form-group col-sm-6 @if($errors->has('email_subject')) has-error @endif">
                    <label class="control-label">Subject</label>
                    <input type="text" name="email_subject" id="name" class="form-control" placeholder="Please Enter Subject" value='{{ $content->email_subject }}' />
					@if($errors->has("email_subject"))
						<span class="help-block">{{ $errors->first("email_subject") }}</span>
					@endif
                  </div>

                  <div class="form-group col-sm-6 @if($errors->has('to_address')) has-error @endif">
                    <label class="control-label">To Address</label>
                    <input type="text" name="to_address" class="form-control" placeholder="Please Enter To Address" value='{{ $content->to_address }}' />
					@if($errors->has("to_address"))
						<span class="help-block">{{ $errors->first("to_address") }}</span>
					@endif
                  </div><!-- col-sm-6 -->
              </div><!-- row -->  

               <div class="row">
         		 <div class="form-group col-sm-6">
                    <label class="control-label">CC Address</label>
                    <input type="text" name="cc_address" id="name" class="form-control" value="{{ $content->cc_address }}">
                  </div>

                  <div class="form-group col-sm-6 ">
                    <label class="control-label">BCC Address</label>
                    <input type="text" name="bcc_address" class="form-control"  value="{{$content->bcc_address}}">
                  </div><!-- col-sm-6 -->
              </div><!-- row -->   
 
    <!-- Editor  -->
        <div class="row">
        	<div class="form-group col-sm-12">
        		<label class="control-label" for="mail_html_content">HTML Mail Content Here </label>
         		<textarea id="ckeditor" placeholder="Enter text here..." class="form-control mail_html_content" rows="10" name="mail_html_content">{{ $content->email_message }}</textarea>

         		@if($errors->has("mail_html_content"))
						<span class="help-block">{{ $errors->first("mail_html_content") }}</span>
					@endif
                
      			</div>
      	</div>
      	<!-- Editor end -->
                   
		<div class="row">
			 <div class="form-group">
               <label class="control-label">Status</label>
                <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if ( $content->status == 1) checked @endif> 
                <label for="status_1" class="lbl" id="switch-box"></label>   
				</div>
		</div>


            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Update Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.email-templates.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div><!--Content Panel--->
    
  </div><!-- mainpanel -->
  <script>
jQuery(document).ready(function(){
    
    "use strict";
    
  // HTML5 WYSIWYG Editor
  jQuery('#wysiwyg').wysihtml5({color: true,html:true});
  
  // CKEditor
  jQuery('#ckeditor').ckeditor();
  
  jQuery('#inlineedit1, #inlineedit2').ckeditor();
  
  // Uncomment the following code to test the "Timeout Loading Method".
  // CKEDITOR.loadFullCoreTimeout = 5;

  window.onload = function() {
  // Listen to the double click event.
  if ( window.addEventListener )
	document.body.addEventListener( 'dblclick', onDoubleClick, false );
  else if ( window.attachEvent )
	document.body.attachEvent( 'ondblclick', onDoubleClick );
  };

  function onDoubleClick( ev ) {
	// Get the element which fired the event. This is not necessarily the
	// element to which the event has been attached.
	var element = ev.target || ev.srcElement;

	// Find out the div that holds this element.
	var name;

	do {
		element = element.parentNode;
	}
	while ( element && ( name = element.nodeName.toLowerCase() ) &&
		( name != 'div' || element.className.indexOf( 'editable' ) == -1 ) && name != 'body' );

	if ( name == 'div' && element.className.indexOf( 'editable' ) != -1 )
		replaceDiv( element );
	}

	var editor;

	function replaceDiv( div ) {
		if ( editor )
			editor.destroy();
		editor = CKEDITOR.replace( div );
	}

});
</script>

<script>
jQuery(function() {

           jQuery('.mail_html_content').summernote({

             height:300,

           });

       });
</script>

@endsection
