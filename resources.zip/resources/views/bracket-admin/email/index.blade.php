@extends('bracket-admin.includes.main')
@section('title','All Emails')
@section('content')

<script>
function timedMsg()
{
var t=setTimeout("document.getElementById('myMsg').style.display='none';",2000);
}
</script>


    <div class="pageheader">
      <h2><i class="fa fa-envelope"></i> Email <span>All Emails...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Email</li>
        </ol>
      </div>
    </div>
    
    <div class="contentpanel panel-email">

        <div class="row">
            <div class="col-sm-3 col-lg-2">
                <a  href="{{ route('admin.email-templates.create') }}" class="btn btn-danger btn-block btn-compose-email" title="Compose Mail">Compose Email</a>
                
                <ul class="nav nav-pills nav-stacked nav-email">
                    <li class="active">
                    <a href="{{ route('admin.email-templates.index') }}">
                        <span class="badge pull-right">2</span>
                        <i class="glyphicon glyphicon-inbox"></i> Inbox
                    </a>
                    </li>
                   
                </ul>
                
                
            </div><!-- col-sm-3 -->
            
            <div class="col-sm-9 col-lg-10">
                
                <div class="panel panel-default">
                    <div class="panel-body">
                      <!-- Info section -->
                        <div id="myMsg">@include('bracket-admin.includes.info')</div> 
                        <script language="JavaScript" type="text/javascript">timedMsg()</script>
                      <!-- Info End here -->                       
                        <div class="table-responsive">
                            <table class="table table-striped" id="content-table">
                            <thead>
                               <tr>
                              <th> Name</th>
                              <th>Subject</th>
                               <th>From </th>
                               <th>Added On</th>
                               <th>Staus</th>
                                <th>Action&nbsp;</th>
                             </tr>
                             </thead>
             
                          </table>
                        </div><!-- table-responsive -->
                        
                    </div><!-- panel-body -->
                </div><!-- panel -->
                
            </div><!-- col-sm-9 -->
            
        </div><!-- row -->
    
    </div> <!--End Content Panel--->
    
  </div><!-- mainpanel -->

<script>
  jQuery(function() {
    jQuery('#content-table').DataTable({
      "autoWidth": false,
                        stateSave: true,
      language: {
        searchPlaceholder: "Search Email",
        "paginate": {
          "first": "&verbar ;&lt;",
          "last": "&gt; &verbar;",
          "next": "&gt;",
          "previous": "&lt;"
        },
        "lengthMenu": " _MENU_ ",
        "info": "_START_ - _END_ of _TOTAL_ items",
        "infoEmpty": "0 - 0 of 0 items",
        "search": "search",
                                
                              
      },
      order: [],
      "dom": 'ftilrp',
      processing: true,
      serverSide: true,
                        
      ajax: '{!! route('admin.email-templates.data') !!}',
      columns: [
        { data: 'name', name: 'name' },
        { data: 'subject', name: 'subject' },
       { data: 'from_address', name: 'from_address' },
        { data: 'created_at', name: 'created_at' },
        { data: 'status', name: 'status' },
        { data: 'action', name: 'action' }
      ],
      "columnDefs": [
        { "orderable": false, "targets": [4,5] }
        ]
    });
  });
</script>
@endsection