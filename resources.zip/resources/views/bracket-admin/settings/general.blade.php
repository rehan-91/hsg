@extends('bracket-admin.includes.main')
@section('title',' Settings')
@section('content')
<script>
function timedMsg()
{
var t=setTimeout("document.getElementById('myMsg').style.display='none';",2000);
}
</script>

 <div class="pageheader">
      <h2><i class="fa fa-cog"></i> Settings <span>All Settings...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="">HOSG</a></li>
          <li><a href="{{ route('admin.settings.general')}}">Setting</a></li>
          <li class="active">All Settings</li>
        </ol>
      </div>
    </div>

    <div class="contentpanel">
      
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="panel panel-default">
           
            <div class="panel-body panel-body-nopadding">
        <!-- Info section -->
          <div id="myMsg">@include('bracket-admin.includes.info')</div> 
            <script language="JavaScript" type="text/javascript">timedMsg()</script>
        <!-- Info End here -->
          
              
              <!-- BASIC WIZARD -->
              <div id="basicWizard" class="basic-wizard">
                
                <ul class="nav nav-pills nav-justified" id="tabMenu">
                  <li><a href="#tab1" data-toggle="tab">General Setting</a></li>
                  <li><a href="#tab2" data-toggle="tab"> Configuration Setting</a></li>
                  <li><a href="#tab3" data-toggle="tab">Video Setting</a></li>
                </ul>
               
                <!-- General Setting  -->
                <div class="tab-content">                

                 <div class="tab-pane" id="tab1">
                   <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Agency Address</h4>                    
                  </div>
                  <!-- Enfd Panel heading -->
             <form class="form"  action="{{ route('admin.settings.updategeneralsettings') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
             <div class="row">

                    <div class="form-group col-sm-6 @if($errors->has('master_agency_name')) has-error @endif">
                    <label class="control-label" for="master_agency_name">Name</label>
                    <input type="text" name="master_agency_name" id="master_agency_name" class="form-control"  placeholder="Name" name="master_agency_name" value='{{ is_null(old("master_agency_name")) ? $generalsettings["master_agency_name"] : old("master_agency_name") }}' />
                      @if($errors->has("master_agency_name"))
                      <span class="help-block">{{ $errors->first("master_agency_name") }}</span>
                      @endif
                    </div><!-- col-sm-6 -->

                  <div class="form-group col-sm-6 @if($errors->has('master_agency_email')) has-error @endif">
                  <label class="control-label" for="master_agency_email">Email</label>
                  <input type="text" class="form-control" id="master_agency_email" placeholder="Email" name="master_agency_email" value='{{ is_null(old("master_agency_email")) ? $generalsettings["master_agency_email"] : old("master_agency_email") }}' />
                  @if($errors->has("master_agency_email"))
                  <span class="help-block">{{ $errors->first("master_agency_email") }}</span>
                  @endif
                </div>

              </div><!-- row -->  

              <div class="row">
                <div class="form-group col-sm-6 @if($errors->has('master_agency_contact_number')) has-error @endif">
                  <label class="control-label" for="master_agency_contact_number">Contact Number</label>
                  <input type="text" class="form-control" id="master_agency_contact_number" placeholder="Contact Number" name="master_agency_contact_number" value='{{ is_null(old("master_agency_contact_number")) ? $generalsettings["master_agency_contact_number"] : old("master_agency_contact_number") }}' />
                  @if($errors->has("master_agency_contact_number"))
                  <span class="help-block">{{ $errors->first("master_agency_contact_number") }}</span>
                  @endif
                </div>

                <div class="form-group col-sm-6 @if($errors->has('master_agency_contact_number')) has-error @endif">
                  <label class="control-label" for="master_agency_address">Address</label><br>
                  <textarea class="form-control" id="master_agency_address" placeholder="Address" name="master_agency_address" >{{ is_null(old("master_agency_address")) ? $generalsettings["master_agency_address"] : old("master_agency_address") }}</textarea>
                  @if($errors->has("master_agency_address"))
                  <span class="help-block">{{ $errors->first("master_agency_address") }}</span>
                  @endif
                </div>

              </div><!--row--->

                <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Logo/ Favicon / Watermark Image</h4>                    
                  </div>
                  <!-- heading end -->
                  <div class="row">
                       <div class="form-group col-sm-6 @if($errors->has('website_logo')) has-error @endif">
                        <label class="control-label" for="website_logo">Website Logo<span style="color:red;"> (Min Size : 480X281 required)</span></label>
                        <input type="file" id="website_logo" name="website_logo" class="form-control" />
                        <input type="hidden" name="old_website_logo" value="{{ $generalsettings['website_logo']}}">
                        @if($errors->has("website_logo"))
                        <span class="help-block">{{ $errors->first("website_logo") }}</span>
                        @endif
                        <br/>
                        @if(!empty($generalsettings['website_logo']))
                      <img src="{{ $models::get_image_data($generalsettings['website_logo'])}}" width="20%">
                      @endif
                      </div> <!--col-sm-6-->

                        <div class="form-group col-sm-6 @if($errors->has('website_favicon')) has-error @endif">
                          <label class="control-label" for="website_favicon">Favicon <span style="color:red;"> (Max Size : 16X16 required)</span></label>
                          <input type="file" id="website_favicon" name="website_favicon"  class="form-control" />
                          <input type="hidden" name="old_website_favicon" value="{{ $generalsettings['website_favicon']}}">
                           @if($errors->has("website_favicon"))
                          <span class="help-block">{{ $errors->first("website_favicon") }}</span>
                          @endif
                          <br/>
                          @if(!empty($generalsettings['website_favicon']))
                          <img src="{{ $models::get_image_data($generalsettings['website_favicon'])}}" >
                          @endif
                        </div> <!--col-sm-6-->
                                                      
                  </div> <!--row-->

                  <div class="row">
                      <div class="form-group col-sm-6 @if($errors->has('watermark_image')) has-error @endif">
                        <label class="control-label" for="watermark_image">Watermark Image</label>
                        <input type="file" id="watermark_image" name="watermark_image" class="form-control" />
                          <input type="hidden" name="old_watermark_image" value="{{ $generalsettings['watermark_image']}}">
                          @if($errors->has("watermark_image"))
                        <span class="help-block">{{ $errors->first("watermark_image") }}</span>
                        @endif
                        @if(!empty($generalsettings['watermark_image']))
                       <img src="{{ $models::get_image_data($generalsettings['watermark_image'])}}" width="20%">
                     @endif
                      </div>

                     <div class="form-group col-sm-6 @if($errors->has('watermark_image_position')) has-error @endif">
                        <label class="control-label" for="watermark_image_position">Watermark Image Position</label>
                        <select class="select2 " id="watermark_image_position" name="watermark_image_position">
                          <option value="">Please Select Image Position</option>
                                    @if (!empty($watermark_image_position_arr) && count($watermark_image_position_arr) > 0)
                          @foreach( $watermark_image_position_arr as $key => $value )
                            <option @if( !empty($generalsettings["watermark_image_position"]) && $generalsettings["watermark_image_position"] == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
                          @endforeach
                                    @endif
                          </select>
                          <input type="hidden" name="old_watermark_image_position" value="{{ $generalsettings['watermark_image_position']}}">
                          @if($errors->has("watermark_image_position"))
                        <span class="help-block">{{ $errors->first("watermark_image_position") }}</span>
                        @endif
                      </div>


                   </div><!--row-->


                <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">UPLOAD HOME PAGE VIDEO</h4>                    
                  </div>
                  <!-- heading end -->
                  <div class="row">
                    <div class="form-group col-sm-6 @if($errors->has('home_page_video')) has-error @endif">
                      <label class="control-label" for="home_page_video">UPLOAD VIDEO</label>
                      <input type="file" id="home_page_video" name="home_page_video" class="form-control" />
                      <input type="hidden" name="old_home_page_video" value="{{ $generalsettings['home_page_video']}}">
                      @if($errors->has("home_page_video"))
                      <span class="help-block">{{ $errors->first("home_page_video") }}</span>
                      @endif
                      <br/>
                      @if(!empty($generalsettings['home_page_video']))
                        <video width="320" height="240" controls><source src="{{ getS3VideoURL($generalsettings['home_page_video'])}}"></video>
                    @endif
                    </div>
                    

                   </div><!--row-->

                    <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">SEO Meta</h4>                    
                  </div>
                  <!-- heading end -->
                  <div class="row">

                     <div class="form-group col-sm-6">
                      <label class="control-label" for="meta_keywords">Meta Title</label><br>
                      <input type="text" class="form-control" id="meta_title" placeholder="Meta title" name="meta_title" value='{{ !is_null(old("meta_title")) ? old("meta_title") : empty($generalsettings["meta_title"])?'':$generalsettings["meta_title"] }}' />
                    </div>

                    <div class="form-group col-sm-6">
                      <label class="control-label" for="meta_keywords">Meta Keywords</label><br>
                      <input type="text" class="form-control" id="meta_keywords" placeholder="Meta keywords" name="meta_keywords" value='{{ !is_null(old("meta_keywords")) ? old("meta_keywords") : empty($generalsettings["meta_keywords"]) ? '' : $generalsettings["meta_keywords"] }}' />
                     
                    </div>
                    
                  </div> <!--row-->

                  <div class="row">

                    <div class="form-group col-sm-6">
                      <label class="control-label" for="meta_description">Meta Description</label><br>
                      <textarea class="form-control" id="meta_description" placeholder="Meta Description" name="meta_description" >{{ !is_null(old("meta_description")) ? old("meta_description") : empty($generalsettings["meta_description"]) ? '' : $generalsettings["meta_description"] }}</textarea>
                    </div>

                    <div class="form-group col-sm-6">
                      <label class="control-label" for="google_tag_manager">Google Tag Manager</label><br>
                      <textarea class="form-control" id="google_tag_manager" placeholder="Google Tag Manager" name="google_tag_manager" >{{ !is_null(old("google_tag_manager")) ? old("google_tag_manager") : empty($generalsettings["google_tag_manager"]) ? '' : $generalsettings["google_tag_manager"] }}</textarea>
                      
                    </div>

                  </div> <!--row-->

                  <div class="row">
                    
                    <div class="form-group col-sm-6">
                      <label class="control-label" for="meta_description">Google Analytics</label><br>
                      <textarea class="form-control" id="google_analytics" placeholder="Google Analytics" name="google_analytics" >{{ !is_null(old("google_analytics")) ? old("google_analytics") : empty($generalsettings["google_analytics"]) ? '' : $generalsettings["google_analytics"] }}</textarea>
                      
                    </div>

                  </div> <!--row-->

                  <!-- date seeting- -->

      @php
      $sel_date = is_null(old("date_format")) ? $generalsettings["date_format"] : old("date_format");
      $sel_time = is_null(old("time_format")) ? $generalsettings["time_format"] : old("time_format");
      @endphp
                 <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Date And Time</h4>                    
                  </div>
                  <!-- heading end -->

                    <div class="row">

                      <div class="form-group col-sm-6 @if($errors->has('date_format')) has-error @endif">
                            <label class="control-label" for="date_format">Date Format</label><br>
                            <select class="select2" id="date_format" name="date_format">
                            <option value="">Please Select Date Format</option>
                            @if (!empty($date_format_arr) && count($date_format_arr) > 0)
                            @foreach( $date_format_arr as $key => $value )
                              <option @if( $sel_date == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
                            @endforeach
                                                          @endif
                            </select>
                            @if($errors->has("date_format"))
                            <span class="help-block">{{ $errors->first("date_format") }}</span>
                            @endif
                          </div>

                      <div class="form-group col-sm-6 @if($errors->has('time_format')) has-error @endif">
                        <label class="control-label" for="time_format">Time Format</label><br>
                        <select class="select2" id="time_format" name="time_format">
                        <option value="">Please Select Time Format</option>
                       @if (!empty($time_format_arr) && count($date_format_arr) > 0)
                        @foreach( $time_format_arr as $key => $value )
                          <option @if( $sel_time == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
                        @endforeach
                        @endif
                        </select>
                        @if($errors->has("time_format"))
                        <span class="help-block">{{ $errors->first("time_format") }}</span>
                        @endif
                      </div>
                      
                    </div> <!--row-->

                       <!-- end date -->

              <!-- Currency -->
                  <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Date And Time</h4>                    
                  </div>
                  <!-- heading end -->

                    <div class="row">
                       <div class="form-group col-sm-6">
                          <label class="control-label" for="selected_currency">Currency</label><br>
                          <select class="select2" id="date_format" name="selected_currency">
                          <option value="">Please Select Currency</option>
                                    @if (!empty($currency_arr) && count($currency_arr) > 0)
                          @foreach( $currency_arr as $key => $value )
                            <option @if( !empty($generalsettings["selected_currency"]) && $generalsettings["selected_currency"] == $key ) selected  @endif value="{{ $key }}">{{ $value }}</option>
                          @endforeach
                                    @endif
                          </select>
                          @if($errors->has("date_format"))
                          <span class="help-block">{{ $errors->first("date_format") }}</span>
                          @endif
                        </div>

                    </div> <!--row-->
                    <!-- currency end -->
                      <div class="panel-footer">
                          <button class="btn btn-primary btn-lg">Save Changes </button>
                       
                        </div>

                     </form>
                  </div> <!--tab1--->

                  <!-- End general setting -->

                  <!-- Configuration Setting -->
                  <div class="tab-pane" id="tab2">
          <form class="form" action="{{ route('admin.settings.updateconfigsetting') }}" method="POST">
                  {{ csrf_field() }}
                     
                  <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Ad Image Setting</h4>                    
                  </div>
                  <!-- heading end -->
                  <div class="row">

                      <div class="form-group col-sm-6 @if($errors->has('ad_image_thumb_width')) has-error @endif">
                        <label class="control-label" for="ad_image_thumb_width">Ad Image Thumb Width</label>
                        <input type="text" class="form-control" id="ad_image_thumb_width" placeholder="Ad Image Thumb Width" name="ad_image_thumb_width" value='{{  !empty($generalsettings["ad_image_thumb_width"]) ? $generalsettings["ad_image_thumb_width"]:(is_null(old("ad_image_thumb_width")) ? old("ad_image_thumb_width"):'') }}' />
                        @if($errors->has("master_agency_name"))
                        <span class="help-block">{{ $errors->first("ad_image_thumb_width") }}</span>
                        @endif
                      </div>

                      <div class="form-group col-sm-6 @if($errors->has('ad_image_thumb_height')) has-error @endif">
                        <label class="control-label" for="ad_image_thumb_height">Ad Image Thumb Height</label><br>
                        <input type="text" class="form-control" id="ad_image_thumb_height" placeholder="Ad Image Thumb Height" name="ad_image_thumb_height" value='{{ !empty($generalsettings["ad_image_thumb_height"]) ? $generalsettings["ad_image_thumb_height"]:(is_null(old("ad_image_thumb_height")) ? old("ad_image_thumb_height"):'')  }}' />
                        @if($errors->has("master_agency_email"))
                        <span class="help-block">{{ $errors->first("ad_image_thumb_height") }}</span>
                        @endif
                      </div>

                  </div><!--row-->

                  <div class="row">

                      <div class="form-group col-sm-6 @if($errors->has('ad_image_quality')) has-error @endif">
                        <label class="control-label" for="ad_image_quality">Ad Image Thumb Quality</label><br>
                        <input type="text" class="form-control" id="ad_image_thumb_height" placeholder="Ad Image Quality" name="ad_image_quality" value='{{  !empty($generalsettings["ad_image_quality"]) ? $generalsettings["ad_image_quality"]:(is_null(old("ad_image_quality")) ? old("ad_image_quality"):'')  }}' />
                        @if($errors->has("master_agency_email"))
                        <span class="help-block">{{ $errors->first("ad_image_quality") }}</span>
                        @endif
                      </div>

                    <div class="form-group col-sm-6 @if($errors->has('ad_large_image_width')) has-error @endif">
                        <label class="control-label" for="ad_large_image_width">Ad Large Image Width</label><br>
                        <input type="text" class="form-control" id="ad_large_image_width" placeholder="Ad  Large Image Width" name="ad_large_image_width" value='{{  !empty($generalsettings["ad_large_image_width"]) ? $generalsettings["ad_large_image_width"]:(is_null(old("ad_large_image_width")) ? old("ad_large_image_width"):'')  }}' />
                        @if($errors->has("master_agency_email"))
                        <span class="help-block">{{ $errors->first("ad_large_image_width") }}</span>
                        @endif
                      </div>
                                    
                  </div><!--row-->

                  <div class="row">

                    <div class="form-group col-sm-6 @if($errors->has('ad_large_image_height')) has-error @endif">
                      <label class="control-label" for="ad_large_image_height">Ad Large Image Height</label><br>
                      <input type="text" class="form-control" id="ad_large_image_height" placeholder="Ad Large Image Height" name="ad_large_image_height" value='{{  !empty($generalsettings["ad_large_image_height"]) ? $generalsettings["ad_large_image_height"]:(is_null(old("ad_large_image_height")) ? old("ad_large_image_height"):'')  }}' />
                      @if($errors->has("master_agency_email"))
                      <span class="help-block">{{ $errors->first("ad_large_image_height") }}</span>
                      @endif
                    </div>

                      <div class="form-group col-sm-6 @if($errors->has('ad_large_image_quality')) has-error @endif">
                        <label class="control-label" for="ad_large_image_quality">Ad Large Image Quality</label><br>
                        <input type="text" class="form-control" id="ad_large_image_quality" placeholder="Ad Large Image Quality" name="ad_large_image_quality" value='{{  !empty($generalsettings["ad_large_image_quality"]) ? $generalsettings["ad_large_image_quality"]:(is_null(old("ad_large_image_quality")) ? old("ad_large_image_quality"):'')  }}' />
                        @if($errors->has("master_agency_email"))
                        <span class="help-block">{{ $errors->first("ad_large_image_quality") }}</span>
                        @endif
                      </div>
                    
                  </div><!--row-->

                   <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Email Notification Setting</h4>                    
                  </div>
                  <!-- heading end -->

                  <div class="row">

                    <div class="form-group col-sm-6">
                       <label class="control-label" for="from">Mail Protocol</label><br>
                       <select class="form-control" id="mail_protocol" name="mail_protocol" onchange="dispalyConfig(this.value)">
                          <option value="mail" @if( !empty($generalsettings["mail_protocol"]) && $generalsettings["mail_protocol"] =='mail' ) selected  @endif >Mail</option>
                          <option value="smtp"@if( !empty($generalsettings["mail_protocol"]) && $generalsettings["mail_protocol"] =='smtp' ) selected  @endif >SMTP</option>
                       </select>
                      </div>
                    
                  </div><!--row-->

                  <div id="smtp_config">
                   <div class="row">

                      <div class="form-group col-sm-6" > 
                        <label class="control-label" for="">From Email</label><br>
                        <input type="text" class="form-control" id="from_email" placeholder="From Email" name="from_email" value='{{ !empty($generalsettings["from_email"]) ? $generalsettings["from_email"]:(!is_null(old("from_email")) ? old("from_email"):'') }}' />                       
                      </div>
                                  
                  <div class="form-group col-sm-6">
                    <label class="control-label" for="">From Name</label><br>
                    <input type="text" class="form-control" id="from_name" placeholder="From Name" name="from_name" value='{{  !empty($generalsettings["from_name"]) ? $generalsettings["from_name"]:(!is_null(old("from_name")) ? old("from_name") :'') }}' />
                    </div> 
                  </div><!--row-->

                   <div class="row">

                   <div class="form-group col-sm-6">
                      <label class="control-label" for="">SMTP Host</label>
                      <input type="text" class="form-control" id="smtp_host" placeholder="SMTP Host" name="smtp_host" value='{{ !empty($generalsettings["smtp_host"]) ?$generalsettings["smtp_host"]:(!is_null(old("smtp_host")) ? old("smtp_host") : '') }}' />                 
                    </div>

                  <div class="form-group col-sm-6">
                    <label class="control-label" for="">SMTP Username</label>
                    <input type="text" class="form-control" id="smtp_host" placeholder="SMTP Username" name="smtp_username" value='{{!empty($generalsettings["smtp_username"]) ? $generalsettings["smtp_username"]: (!is_null(old("smtp_username")) ? old("smtp_username") : '') }}' />
                     </div>
                                
                  </div><!--row-->

              <div class="row">

                <div class="form-group col-sm-6">
                  <label class="control-label" for="">SMTP Password</label><br>
                  <input type="text" class="form-control" id="smtp_password" placeholder="SMTP Password" name="smtp_password" value='{{ !empty($generalsettings["smtp_password"]) ?$generalsettings["smtp_password"]:(!is_null(old("smtp_password")) ? old("smtp_password") : '') }}' />
               </div>

               <div class="form-group col-sm-6">
                <label class="control-label" for="">SMTP Port</label><br>
                <input type="text" class="form-control" id="smtp_port" placeholder="SMTP Port" name="smtp_port" value='{{ !empty($generalsettings["smtp_port"]) ? $generalsettings["smtp_port"]:(!is_null(old("smtp_port")) ? old("smtp_port") : '') }}' /> </div>

                </div> <!--row-->  

                  </div><!--id=smtp_config--> 


                  <div id="mail_config"> <!--mail-config-->
                    <div class="row">
                       <div class="form-group col-sm-6">
                          <label class="control-label" for="">From Email</label><br>
                          <input type="text" class="form-control" id="from_email" placeholder="From Email" name="from_email" value='{{ !empty($generalsettings["from_email"]) ? $generalsettings["from_email"]:(!is_null(old("from_email")) ? old("from_email") : '') }}' />                         
                        </div>

                      <div class="form-group col-sm-6">
                        <label class="control-label" for="">From Name</label><br>
                        <input type="text" class="form-control" id="from_name" placeholder="From Name" name="from_name" value='{{ !empty($generalsettings["from_name"]) ? $generalsettings["from_name"]:(!is_null(old("from_name")) ? old("from_name") : '') }}' />                       
                      </div>
                      
                    </div><!--row-->

                  </div><!--end mail-config-->

                <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Payment Gateway</h4>                    
                  </div>
                  <!-- heading end -->

                  <div class="row">
                    <div class="form-group col-sm-12">
                       <label class="control-label" for="from"></label>                      
                      </div>                    
                  </div><!--row-->

                      <div class="panel-footer">
                          <button class="btn btn-primary btn-lg">Save Changes </button>
                       
                        </div>

                    </form>
                  </div>
                  <!-- End configuration -->

                  <!-- Video setting -->

                  <div class="tab-pane" id="tab3">

                    <!-- Panel Heading -->
                  <div class="panel-heading">                    
                    <h4 class="panel-title">Video Setting</h4>                    
                  </div>
                  <!-- heading end -->
             <form class="form"action="{{ route('admin.settings.updatevideosetting') }}" method="POST">
                    {{ csrf_field() }}

                      <div class="row">

                        <div class="form-group col-sm-4">
                          <label class="control-label" for="video_resolution">Resolution</label><br>
                          <select class="select2" id="video_resolution" name="video_resolution">
                            <option value="">Please Select</option>
                            @if (!empty($resolutionarr) && count($resolutionarr) > 0)
                            @foreach( $resolutionarr as $value )
                                    <option value="{{ $value }}" @if (!empty($generalsettings['video_resolution']) && $generalsettings['video_resolution']==$value) selected @endif >{{ $value }}</option>
                            @endforeach
                            @endif
                        </select>
                        </div>

                        <div class="form-group col-sm-4">
                          <label class="control-label" for="video_resolution">Compression</label>
                          <select class="form-control" id="video_compression" name="video_compression">
                             <option value="">Please Select</option>
                            @if (!empty($compressionrr) && count($compressionrr) > 0)
                            @foreach( $compressionrr as $value )
                         <option value="{{ $value }}"  @if (!empty($generalsettings['video_compression']) && $generalsettings['video_compression']==$value) selected @endif >{{ $value }}</option>
                            @endforeach
                            @endif
                        </select>
                        </div>

                       <div class="form-group col-sm-4">
                           <label class="select-label" for="video_size">Size</label>
                        <input type="text" class="form-control" id="video_size" placeholder="Video Size" name="video_size" value='{{ !empty($generalsettings["video_size"]) ? $generalsettings["video_size"]:(is_null(old("video_size")) ? old("video_size") :'')   }}' />
                      
                      </div>
                        
                      </div><!--row-->

                       <div class="panel-footer">
                          <button class="btn btn-primary btn-lg">Save Changes </button>
                       
                        </div>
                     
                           
                      
                    </form>
                  </div>
                  <!-- video setting End  -->
                  
                  
                </div><!-- tab-content -->
                
              </div><!-- #basicWizard -->
              
            </div><!-- panel-body -->
          </div><!-- panel -->
        </div><!-- col-md-6 -->     
      </div><!-- row -->


    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->

<script>
jQuery(document).ready(function(){
    
    "use strict";

  // Basic Wizard
  jQuery('#basicWizard').bootstrapWizard();
  
  
  
  jQuery(".select2").select2({
    width: '100%',
    minimumResultsForSearch: -1
  });
  
  
});
</script>

  <script>
       function dispalyConfig(value){
              if(value == 'mail'){
                  $("#smtp_config").css('display', 'none');
                  $("#mail_config").css('display', 'block');
              }else{
                  $("#smtp_config").css('display', 'block');
                  $("#mail_config").css('display', 'none');
              }
          }
          
          $(document).ready(function(){
              var mail_protocol= '{{ $generalsettings["mail_protocol"] }}';
             
              if(mail_protocol.trim() == 'mail'){
             
                   $("#smtp_config").css('display', 'none');
                  $("#mail_config").css('display', 'block');
              }else{
                   
                  $("#smtp_config").css('display', 'block');
                  $("#mail_config").css('display', 'none');
              }
          })
   </script>
<!-- Return to specific tab -->
 <script>
$(document).ready(function () {
$('#tabMenu a[href="#{{ old('tab') }}"]').tab('show')
});
</script>

  @endsection