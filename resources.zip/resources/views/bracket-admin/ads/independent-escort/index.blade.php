@extends('bracket-admin.includes.main')
@section('title','All Independent Escort')
@section('content')
<script>
function timedMsg()
{
var t=setTimeout("document.getElementById('myMsg').style.display='none';",2000);
}
</script>
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Escort <span>All Independent Escort...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">All Independent Escort</li>
        </ol>
      </div>
    </div> 

  <div class="contentpanel">    
      <div class="panel panel-default">  
        <div class="panel-body">
          <!-- Info section -->
          <div id="myMsg">@include('bracket-admin.includes.info')</div> 
        <script language="JavaScript" type="text/javascript">timedMsg()</script>
        <!-- Info End here -->         
      
  <div class="table-responsive">
         <table class="table table-striped" id="table1">
              <thead>
                 <tr>   
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Slug</th>
                    <th>Status</th>
                    <th>Added On</th>
                    <th>Action</th>
                 </tr>
              </thead>
              <tbody>
                @foreach( $indpendent as $user)

                 <tr class="odd gradeX">
                  
                    <td>{{$user->ad_name}}</td>
                    <td>{{$user->ad_email}}</td>

                    <td>{{$user->ad_contactno}}</td>
                    <td>{{$user->slug}}</td>
                    <td><input type="checkbox" @if ($user->status == 1) checked @endif>
                    	@if($user->status == 1 )
                    	<span style="color: #008000;">Active</span>
                    	@else 
                    	<span style="color: #ff0000;">Not Active</span>
                    	@endif
                       </td>
                    <td class="center"> {{date("M d, Y", strtotime($user->created_at))}} at {{date("H:m a", strtotime($user->created_at))}}</td>
                    
                    <td>
                      <a href="{{ url('admin/individualad', $user->id)}}"><i class="fa fa-pencil"></i></a>
                      
                  </td>
                 </tr>
                 @endforeach
                 
              </tbody>
           </table>
          </div><!-- table-responsive -->
           
        </div><!-- panel-body -->
      </div><!-- panel -->
        
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->


<script>
  jQuery(document).ready(function() {
    
    "use strict";
    
    jQuery('#table1').dataTable();
    
    
    // Select2
    jQuery('select').select2({
        minimumResultsForSearch: -1
    });    
  
  });
</script>


@endsection
