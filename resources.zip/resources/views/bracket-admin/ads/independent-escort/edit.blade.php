@extends('bracket-admin.includes.main')
@section('title',' Independent Escort')
@section('content')
        
    <div class="pageheader">
      <h2><i class="fa fa-pencil"></i> Edit<span>  Independent Escort...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="index.html">Bracket</a></li>
          <li><a href="general-forms.html">Independent Escort</a></li>
          <li class="active">All data</li>
        </ol>
      </div>
    </div>
    
    <div class="contentpanel">
      
      <div class="row">
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-body panel-body-nopadding">
              
              <!-- BASIC WIZARD -->
              <div id="basicWizard" class="basic-wizard">
                
                <ul class="nav nav-pills nav-justified">
                  <li><a href="#tab1" data-toggle="tab"><span>Step 1:</span> Details</a></li>
                  <li><a href="#tab2" data-toggle="tab"><span>Step 2:</span> Upgrade</a></li>
                  <li><a href="#tab3" data-toggle="tab"><span>Step 3:</span> Services</a></li>
                  <li><a href="#tab4" data-toggle="tab"><span>Step 4:</span> Photos</a></li>
                  <!-- <li><a href="#tab5" data-toggle="tab"><span>Step 5:</span> Finished</a></li> -->
                </ul>
                
                <div class="tab-content">

   @if ($errors->any())
      <div class="alert alert-danger">
          <ul>
              @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
              @endforeach
          </ul>
      </div><br />
      @endif

                  <!-- Start Details -->
                  <div class="tab-pane" id="tab1">
                   <form action="{{ route('admin.individual.update')}}" method="POST">
                    {{ csrf_field() }}
                  
                     <input type="hidden" name="ad_listing_type_id" value="{{$ad_listing_type_id->ad_listing_type_id}}">
                     <input type="hidden" name="user_id" value="{{$ad_listing_type_id->ad_user_id}}">
                     <input type="hidden" name="user_ad_id" value="{{$user_ad_id}}">
                   


                       <div class="form-group">
                        <label class="col-sm-4">Gender:</label>
                        <div class="col-sm-8 @if($errors->has('rdo')) has-error @endif">

                          <div class="col-sm-4">
                           <input type="radio"  id="male" value="male" name="rdo"  {{!empty($listdata['metaData']['rdo']) && $listdata['metaData']['rdo'] == 'male'? 'checked' : ''}}>
                            <label for="male">Male</label>
                         </div>

                        <div class="col-sm-4">
                           <input type="radio" value="f" id="female" name="rdo" {{ !empty($listdata['metaData']['rdo']) && $listdata['metaData']['rdo'] == 'female'? 'checked' : ''}}>
                            <label for="female">Female</label>
                        </div>
                        
                        <div class="col-sm-4">
                          <input type="radio" value="T" id="Trans" name="rdo"{{ !empty($listdata['metaData']['rdo']) && $listdata['metaData']['rdo']== 'trans'? 'checked' : ''}}>
                            <label for="female">Trans</label>
                        </div>

                        @if($errors->has("rdo"))
                       <span class="help-block">{{ $errors->first("rdo") }}</span>
                    @endif

                          
                          </div>
                          
                      </div>

                      <div class="form-group">
                       
                        <div class="col-sm-4 @if($errors->has('ad_name')) has-error @endif">
                          <input type="text" class="form-control" placeholder="Name" name="ad_name" 
                            value="{{!empty($listdata['adName']) ? $listdata['adName']:'' }}" />
                           
                    @if($errors->has("ad_name"))
                       <span class="help-block">{{ $errors->first("ad_name") }}</span>
                    @endif

                        </div>
                        <div class="col-sm-4 @if($errors->has('ad_email')) has-error @endif">
                          <input type="email" name="ad_email" class="form-control" placeholder="Email" value="{{!empty($listdata['adEmail']) ? $listdata['adEmail']:'' }}" />
                          @if($errors->has("ad_email"))
                       <span class="help-block">{{ $errors->first("ad_email") }}</span>
                    @endif
                        </div>

                        <div class="col-sm-4 @if($errors->has('ad_contactno')) has-error @endif">
                          <input type="text" name="ad_contactno" class="form-control" placeholder="Phone"  value="{{!empty($listdata['adContact']) ? $listdata['adContact']:'' }}"/>
                          @if($errors->has("ad_contactno"))
                       <span class="help-block">{{ $errors->first("ad_contactno") }}</span>
                    @endif
                        </div>
                       

                      </div>

                      <div class="form-group">
                        <div class="col-sm-3 @if($errors->has('country_name')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="country_name" onchange="getCity(this.value)" id="country_name">
                            <option value="">Country</option>
                           @foreach($countries as $cn)
                            <option value='{{ $cn["id"] }}' >{{ $cn['country_name'] }}</option>
                           
                            @endforeach
                          </select>
                           @if($errors->has("country_name"))
                             <span class="help-block">{{ $errors->first("country_name") }}</span>
                          @endif
                              </div>

                        <div class="col-sm-3 @if($errors->has('city_name')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="city_name" id="city_name" placeholder="City">
                            <option value="">City</option>

                          </select>
                           @if($errors->has("city_name"))
                       <span class="help-block">{{ $errors->first("city_name") }}</span>
                    @endif
                        </div>

                         <div class="col-sm-3 @if($errors->has('suburbs')) has-error @endif">
                          <input type="text" name="suburbs" class="form-control" placeholder="Suburbs" value="{{!empty($listdata['adSuburbs']) ? $listdata['adSuburbs']:'' }}"/>
                          @if($errors->has("suburbs"))
                       <span class="help-block">{{ $errors->first("suburbs") }}</span>
                    @endif
                        </div>

                        <div class="col-sm-3">
                          <input type="text" name="website_url" class="form-control"placeholder="Website URL" value="{{!empty($listdata['metaData']['website_url']) ? $listdata['metaData']['website_url']:'' }}"/>
                        </div>

                      </div>

                  <div class="form-group col-sm-12 @if($errors->has('additional_information')) has-error @endif ">
                    <textarea class="form-control" name="additional_information" id="additional_information" rows="3" placeholder="Additinal infortmation e.g. I do not answer blocked / private numbers.">
                      {{!empty($listdata['metaData']['additional_information']) ? $listdata['metaData']['additional_information']:'' }}
                     
                    </textarea>
                    @if($errors->has("additional_information"))
                       <span class="help-block">{{ $errors->first("additional_information") }}</span>
                    @endif
                </div>
                      

            <div class="form-group col-sm-12 ">
                        <label class="col-sm-12"><h4>Social Media Links (optional)</h4></label>
           
                       @foreach($social_media_links as $mlinks)
            <div class="form-group col-sm-4">
              <span>@if(!empty($mlinks['icon']))<img src="{{ url('upload/'.$mlinks['icon']) }}">@endif</span>
                        <input type="text" class="form-control "
                         placeholder="{{$mlinks['value']}}" name="social_links_{{$mlinks['id']}}"
                         value="{{!empty($listdata['metaData']['social_links_'.$mlinks['id']]) ? $listdata['metaData']['social_links_'.$mlinks['id']]:'' }}">
                        </div>
                        @endforeach

                </div>

                <div class="form-group">
                    <label class="col-sm-12"><h4>Write Your Tagline (optional)</h4></label>
                    <div class="form-group col-sm-12 margin-bottom-zero">  
                             
                        <input type="text" class="form-control"  value="{{!empty($listdata['metaData']['tagline']) ? $listdata['metaData']['tagline']:'' }}" placeholder="Pristine glamour meets graciously elite discretion hot & sexy euro girl in sydney now " name="tagline">
                    
          </div>

                </div>

                <div class="form-group">
                   <label class="col-sm-12"> <h4>Preferred method of booking via:</h4></label><br>
                         @php
                             if(!empty($listdata['metaData']['booking_method']) ){
                                if(!is_array($listdata['metaData']['booking_method'])){
                                    $b_array = (array)$listdata['metaData']['booking_method'];
                                }else{
                                    $b_array = $listdata['metaData']['booking_method'];
                                }
                             }
                                @endphp
                       <div class="col-sm-3 @if($errors->has('booking_method')) has-error @endif">
                       <div class="checkbox block">
                        <label><input type="checkbox" name="booking_method[]" id="1" value="text message" {{!empty($b_array) && in_array('text message', $b_array) ? 'checked': ''}}> Text Message</label></div>
                       </div>

                        <div class="col-sm-3">
                       <div class="checkbox block">
                        <label><input type="checkbox" name="booking_method[]" id="2" value="call" {{!empty($b_array) && in_array('call', $b_array) ? 'checked': ''}}> Call</label></div>
                       </div>
                    

                      <div class="col-sm-3">
                       <div class="checkbox block">
                        <label><input type="checkbox" name="booking_method[]" id="3" value="email" {{!empty($b_array) && in_array('email', $b_array) ? 'checked': ''}}> Email</label></div>
                       </div>
                     
                     <div class="col-sm-3">
                       <div class="checkbox block">
                        <label><input type="checkbox" name="booking_method[]" id="3" value="watsapp"  {{!empty($b_array) && in_array('watsapp', $b_array) ? 'checked': ''}}> Whatsapp</label></div>
                       </div>
                    @if($errors->has("booking_method"))
                       <span class="help-block">{{ $errors->first("booking_method") }}</span>
                    @endif
                  </div>
                    
                 

                  <div class="form-group">
                    <label class="col-sm-12 @if($errors->has('personal')) has-error @endif"><h4>Personal</h4></label>
                    
                        @foreach($personal as $p)
                        <div class="col-sm-3 ">
                          <div class="checkbox block">
                          <label for="personal{{$p['id']}}">
                            <input type="checkbox" name="personal" id="personal{{$p['id']}}" value="{{$p['value']}}"
                            {{!empty($listdata['metaData']['personal']) && $listdata['metaData']['personal'] == $p['id'] ? 'checked': ''}}/>
                           {{ $p['value'] }}
                        </label>
                         
                      </div>
                        </div>
                        
                        @endforeach 
                        @if($errors->has("personal"))
                       <span class="help-block">{{ $errors->first("personal") }}</span>
                    @endif     
                    </div>

                <div class="form-group">
                    <label class="col-sm-12"><h4>My Attributes</h4></label>

                     <div class="form-group">
                        <div class="col-sm-3 @if($errors->has('age')) has-error @endif">
                        <input type="text" name="age" value="{{$listdata['metaData']['age']}}" class="form-control" placeholder="Age">
                         @if($errors->has("age"))
                       <span class="help-block">{{ $errors->first("age") }}</span>
                    @endif
                        </div>

                        <div class="col-sm-3 @if($errors->has('bustsize')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="bustsize" >
                            <option value=''>Bust size</option>
                            @foreach($bustsize as $bs)
                            <option value="{{$bs['id']}}" {{!empty($listdata['metaData']['bustsize']) && $listdata['metaData']['bustsize'] == $bs['id'] ? 'selected':''}}>{{ $bs['value'] }}</option>
                            @endforeach

                          </select>
                           @if($errors->has("bustsize"))
                               <span class="help-block">{{ $errors->first("bustsize") }}</span>
                            @endif
                        </div>

                         <div class="col-sm-3 @if($errors->has('gender')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="gender">
                            <option value=''>Gender</option>
                            <option value='male' {{!empty($listdata['metaData']['gender']) && $listdata['metaData']['gender'] == 'male' ? 'checked': ''}}>Male</option>
                            <option value='female' {{!empty($listdata['metaData']['gender']) && $listdata['metaData']['gender'] == 'female' ? 'selected': ''}}>Female</option>
                           

                        </select>
                         @if($errors->has("gender"))
                               <span class="help-block">{{ $errors->first("gender") }}</span>
                            @endif
                        </div>

                           
                          <div class="col-sm-3 @if($errors->has('weight')) has-error @endif">
                           <input type="text" name="weight" value="{{$listdata['metaData']['weight']}}" class="form-control" placeholder="Weight">
                            @if($errors->has("weight"))
                               <span class="help-block">{{ $errors->first("weight") }}</span>
                            @endif
                        </div>
                     </div>


                      <div class="form-group">
                        <div class="col-sm-3 @if($errors->has('nationality')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="nationality" >
                            <option value=''>Nationality</option>
                            @foreach($nationality as $n)
                            <option value="{{$n['id']}}" {{!empty($listdata['metaData']['nationality']) && $listdata['metaData']['nationality'] == $n['id'] ? 'selected':''}}>{{ $n['value'] }}</option>
                            @endforeach
                        </select>

                         @if($errors->has("nationality"))
                               <span class="help-block">{{ $errors->first("nationality") }}</span>
                            @endif                      
                        </div>

                        <div class="col-sm-3">
                          <input type="text"  id="ethnicity" class="form-control" name="ethinicity" value="{{$listdata['metaData']['ethnicity']}}" placeholder="Ethnicity" >
                        </div>


                         <div class="col-sm-3 @if($errors->has('height')) has-error @endif">
                          <input type="text" name="height" value="{{$listdata['metaData']['height']}}" class="form-control" placeholder="Height">
                          @if($errors->has("height"))
                               <span class="help-block">{{ $errors->first("height") }}</span>
                            @endif
                        </div>

                           
                          <div class="col-sm-3 @if($errors->has('orientation')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="orientation" >
                            <option value=''>Orientation</option>
                            @foreach($orientation as $o)
                            <option value="{{ $o['id'] }}" {{!empty($listdata['metaData']['orientation']) && $listdata['metaData']['orientation'] == $o['id'] ? 'selected':''}}>{{ $o['value'] }}</option>
                            @endforeach
                        </select>
                        @if($errors->has("orientation"))
                               <span class="help-block">{{ $errors->first("orientation") }}</span>
                            @endif
                        </div>
                     </div>


                      <div class="form-group">
                        <div class="col-sm-3 @if($errors->has('eyecolor')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="eyecolor" >
                            <option value=''>Eye color</option>
                            @foreach($eyecolor as $e)
                            <option value='{{ $e["id"] }}' {{!empty($listdata['metaData']['eyecolor']) && $listdata['metaData']['eyecolor'] == $e['id'] ? 'selected':''}}>{{ $e['value'] }}</option>
                            @endforeach
                        </select>
                        @if($errors->has("eyecolor"))
                               <span class="help-block">{{ $errors->first("eyecolor") }}</span>
                            @endif
                        </div>

                       <div class="form-group">
                        <div class="col-sm-3 @if($errors->has('haircolor')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="haircolor" >
                            <option value=''>Hair color</option>
                            @foreach($haircolor as $h)
                            <option value='{{ $h["id"] }}' {{!empty($listdata['metaData']['haircolor']) && $listdata['metaData']['haircolor'] == $h['id'] ? 'selected':''}}>{{ $h['value'] }}</option>
                            @endforeach
                        </select>
                        @if($errors->has("haircolor"))
                               <span class="help-block">{{ $errors->first("haircolor") }}</span>
                            @endif
                        </div>



                         <div class="col-sm-3 @if($errors->has('hairlength')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="hairlength" >
                            <option value=''>Hair length</option>
                            @foreach($hairlength as $hl)
                            <option value='{{ $hl["id"] }}' {{!empty($listdata['metaData']['hairlength']) && $listdata['metaData']['hairlength'] == $hl['id'] ? 'selected':''}}>{{ $hl['value'] }}</option>
                            @endforeach
                        </select>
                        @if($errors->has("hairlength"))
                               <span class="help-block">{{ $errors->first("hairlength") }}</span>
                            @endif
                        </div>

                           
                          <div class="col-sm-3 @if($errors->has('dresssize')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="dresssize" >
                            <option value=''>Dress Size</option>
                            @foreach($dresssize as $ds)
                            <option value='{{ $ds["id"] }}' {{!empty($listdata['metaData']['dresssize']) && $listdata['metaData']['dresssize'] == $ds['id'] ? 'selected':''}}>{{ $ds['value'] }}</option>
                            @endforeach
                        </select>
                            @if($errors->has("dresssize"))
                               <span class="help-block">{{ $errors->first("dresssize") }}</span>
                            @endif

                        </div>
                     </div>


                      <div class="form-group">
                        <div class="col-sm-3 @if($errors->has('shoessize')) has-error @endif">
                          <select class="select2" data-placeholder="Choose One" name="shoessize" >
                            <option value=''>Shoes Size</option>
                            @foreach($shoessize as $ss)
                            <option value='{{ $ss["id"] }}' {{!empty($listdata['metaData']['shoessize']) && $listdata['metaData']['shoessize'] == $ss['id'] ? 'selected':''}}>{{ $ss['value'] }}</option>
                            @endforeach
                        </select>

                        @if($errors->has("shoessize"))
                               <span class="help-block">{{ $errors->first("shoessize") }}</span>
                            @endif
                        </div>

                       
          <div class="col-sm-3">

              <div class="btn-group mr5">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                  Body Type <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu">
                      @php
                        if(!empty($listdata['metaData']['body-type'])){
                                if(!is_array($listdata['metaData']['body-type'])){
                                    $body_array = (array)$listdata['metaData']['body-type'];
                                }else{
                                    $body_array = $listdata['metaData']['body-type'];
                                }
                        }
                        @endphp
                        @foreach($bodytype as $body)
                  <li>
                    <div class="checkbox block">
                        <label for="checkbox{{$body['id']}}" >
                      
                        <input type="checkbox"  id="checkbox{{$body['id']}}" {{!empty($body_array) && in_array($body['id'], $body_array) ? 'checked':''}} name="body-type[]" value="{{ $body['id'] }}" />
                        {{$body['value']}}</label>
                    </div>
                  </li>
                  @endforeach


                </ul>
              </div><!-- btn-group -->

          </div>

                      <div class="col-sm-3">
                       <div class="checkbox block"><label><input type="checkbox" name="is_tall" id="is_tall" {{!empty($listdata['metaData']['is_tall']) && $listdata['metaData']['is_tall'] == 'on' ? 'checked': ''}}> Tall<span>(Optional)</span></label></div>
                       </div>

                      <div class="col-sm-3">
                       <div class="checkbox block"><label><input type="checkbox" name="is_short" id="is_short" {{!empty($listdata['metaData']['is_short']) && $listdata['metaData']['is_short'] == 'on' ? 'checked': ''}}> Short<span>(Optional)</span></label></div>
                       </div>

                     </div>


                     
                  <div class="form-group">
                   
                    <div class="col-sm-12">
                      <textarea rows="3" id="description" class="form-control" name="about_description" id="description" rows="3" placeholder="Describe Yourself">{{!empty($listdata['aboutDescription']) ? $listdata['aboutDescription']:''}}</textarea>
                    </div>
                  </div>

                  <div class="form-group">
                        <label class="col-sm-12"><h4>Tattos <span>(optional):</span></h4></label>
                        <div class="col-sm-8">

                          <div class="col-sm-4">
                           <label for="tattoos1">
                            <input type="radio" name="tattoos" id="tattoos1" value="yes" {{!empty($listdata['metaData']['tattoos']) && $listdata['metaData']['tattoos'] == 'yes' ? 'checked': ''}} />
                           Yes
                        </label>
                         </div>

                          <div class="col-sm-4">
                           <label for="tattoos2">
                            <input type="radio" name="tattoos" id="tattoos2" value="no"  checked {{!empty($listdata['metaData']['tattoos']) && $listdata['metaData']['tattoos'] == 'no' ? 'checked': ''}} />
                            No
                        </label>
                         </div>
                       </div>
                          
                      </div>

                    <div class="form-group">
                      <label class="col-sm-12"><h4>Piercing <span>(optional):</span></h4></label>
                      @php
                    if(!empty($listdata['metaData']['piercing'])){
                        if(!is_array($listdata['metaData']['piercing'])){
                            $piercing_array = (array)$listdata['metaData']['piercing'];
                        }else{
                            $piercing_array = $listdata['metaData']['piercing'];
                        }
                    }
                    @endphp
                    @foreach($piercing as $p)
                    <div class="col-sm-3">
                      <div class="checkbox block">
                      <label for="piercing{{ $p['id'] }}">
                        <input type="checkbox" name="piercing[]" value="{{ $p['id'] }}" id="piercing{{ $p['id'] }}" {{!empty($piercing_array) && in_array( $p['id'],  $piercing_array) ? 'checked':''}}/>
                        {{ $p['value'] }}</label>
                      </div>
                    </div>
                    @endforeach
                      </div>

                     <div class="form-group">
                        <label class="col-sm-12"><h4>Smoker <span>(optional):</span></h4></label><br>
                        <div class="col-sm-8">

                          <div class="col-sm-4">
                           <label for="smoker">
                            <input type="radio" name="smoker" id="smoker" value="smoker" class="form-control" 
                            {{!empty($listdata['metaData']['smoker']) && $listdata['metaData']['smoker'] == 'smoker' ? 'checked':'checked'}}/>
                           Smoker
                        </label>
                         </div>

                          <div class="col-sm-4">
                           <label for="Non-Smoker">
                            <input type="radio" name="smoker" id="non-smoker" class="form-control" value="non smoker" 
                            {{!empty($listdata['metaData']['smoker']) && $listdata['metaData']['smoker'] == 'non smoker' ? 'checked': 'checked'}} />
                            Non Smoker
                        </label>
                         </div>

                          <div class="col-sm-4">
                           <label for="Occasional-Smoker">
                            <input type="radio" name="smoker" id="occasional-smoker" class="form-control" value="occasional smoker" {{!empty($listdata['metaData']['smoker']) && $listdata['metaData']['smoker'] == 'occasional smoker' ? 'checked': 'checked'}}/>
                            Occasional-Smoker
                        </label>
                         </div>
                       </div>
                          
                      </div>

                  <div class="form-group">
                      <label class="col-sm-12"><h4>Drink <span>(optional):</span></h4></label><br>
                             <div class="col-sm-8">

                          <div class="col-sm-4">
                           <label for="smoker">
                            <input type="radio" name="drink" id="regular-drink" value="regular drink" class="form-control" 
                            {{!empty($listdata['metaData']['drink']) && $listdata['metaData']['drink'] == 'regular drink' ? 'checked': ''}} />
                            <span class="label"></span>Regular Drink
                        </label>
                         </div>

                          <div class="col-sm-4">
                           <label for="Non-Smoker">
                            <input type="radio" name="drink" id="non-drink" class="form-control" value="non drink"  
                            {{!empty($listdata['metaData']['drink']) && $listdata['metaData']['drink'] == 'non drink' ? 'checked': ''}}/>
                            <span class="label"></span>Non Drink
                        </label>
                         </div>

                          <div class="col-sm-4">
                           <label for="Occasional-Smoker">
                            <input type="radio"  name="drink" id="occasional-drink" class="form-control" value="occasional drink" {{!empty($listdata['metaData']['drink']) && $listdata['metaData']['drink'] == 'occasional drink' ? 'checked': ''}}/>
                            <span class="label"></span>Occasional Drink
                        </label>
                         </div>
                       </div>
                     <div class="col-sm-12">
                      <textarea name="about_description" rows="3" id="description" class="form-control" rows="5" name="additional_information" id="additional_information" rows="3" placeholder="Additinal infortmation e.g. *I have tattoos that have been removed from my images for my privacy*">
                        {{!empty($listdata['metaData']['additional_information']) ?  $listdata['metaData']['additional_information']:''}}
                      </textarea>
                    </div>
          
                      </div>
        
                 </div>

                 <div class="form-group">
                   <label class="col-sm-12"><h4>My Hobbie & Interest</h4></label>
                   <textarea class="form-control" name="hobbies_interest" id="hobbies_interest" rows="3" 
                    placeholder="Yoga / the mind / creativity / spirituality / the arts / simplicity / business / scuba diving / hip hop / music etc...">{{!empty($listdata['metaData']['hobbies_interest']) ?  $listdata['metaData']['hobbies_interest']:''}}</textarea>

                 </div>


                    <div class="form-group fav-things">
                    <label class="col-sm-12"><h4>My Favourites Things</h4></label>
                        
                        @php
                            $favcount = 1;
                            @endphp
                            @foreach($favthings as $fav)
                            
                            <div class="col-sm-6 favthings">
                             
                                <div class="form-group row">
                                    <label for="inputText" class="col-sm-2">{{ $fav['value'] }}</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="fav_things_{{$fav['id']}}" class="form-control" id="inputText" placeholder="Place your text" value="{{!empty($listdata['metaData']['fav_things_'.$fav['id']])  ? $listdata['metaData']['fav_things_'.$fav['id']]:''}}">
                                    </div>
                                </div>
                                
                            </div>
                           
                            @endforeach
                           
                               <div class="col-sm-12 favthings_placeholder"></div>
              
                             <a href="javascript:void(0)" class="btn btn-primary btn-sm" onclick="addFavThings()"><i class="fa fa-plus"></i>Add More </a>

                           
                           
                    </div>


          <div class="form-group fav-things wishlist-box wishlist_things">
                    <label class="col-sm-12"><h4>My Wishlists</h4></label>
                        
                        @php
                            $wishcount = 1;
                            @endphp
                            @foreach($wishlistthings as $wt)
                            
                                <div class="col-sm-6 row">
                                  <div class="form-group">
                                     <label for="inputText" class="col-sm-2">{{ $wt['value'] }}</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="wish_things_{{$wt['id']}}" class="form-control" id="inputText" placeholder="Place your text" value="{{!empty($listdata['metaData']['wish_things_'.$wt['id']])  ? $listdata['metaData']['wish_things_'.$wt['id']]:''}}">
                                    </div>
                                  </div>  
                                </div>
                
                            @endforeach
           
              <div class="col-sm-12 wishlist_placeholder"></div>
              <a href="javascript:void(0)" class="btn btn-primary btn-sm " onclick="addWishThings()"> <i class="fa fa-plus"></i>Add More  </a>
      
                       

                    </div>
        </div>
                     
                     <button type="submit" class="btn btn-primary btn-sm" class="form-control">Save Changes</button> 
                  <!--  <ul class="pager wizard">
                    <li class="previous"><a href="javascript:void(0)">Previous</a></li>
                    <li class="next"><a href="javascript:void(0)">Save & Next</a></li>
                    </a>
                    </li>
                  </ul> -->
                    </form>
                  </div>
                  <!-- End details -->












                  <!-- Start upgrades -->
                  <div class="tab-pane" id="tab2">
                    <form class="form">
                      <div class="form-group">
                         <h2 class="text-danger mb-5 mt-3"><img src="{{ asset('frontend/images/ad-plan-heading.png') }}" alt="ad-plan-heading.png" class="img-fluid"></h2>
                      </div>
                      
                      <div class="form-group">
                       
            
                     @php
                    $count = 1;
                    @endphp
                    @foreach($plans as $p)
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6 price-cards ">
                        <div class="card @if($count == 1) red-border @elseif($count == 2) purple-border @elseif($count==3) magenta-border @endif" id="plan-section-div{{$p->id}}">
                            <div class="card-header text-center border-bottom-0 bg-transparent">
                                <h5>{{ strtoupper($p->plan_name) }}</h5>
                            </div>
                            <div class="card-body">
                                <h1>{{ price_format($p->plan_price_base) }}</h1>
                                <h5 class="text-center"><small>Ad duration :
                                        <span>{{ $p->plan_duration." ".$p->plan_duration_unit}}</span></small>
                                </h5>
                            </div>
                            <ul class="list-group list-group-flush" id="hide-more-features{{$p->id}}">
                                @php
                                $plans_features = explode("\n", $p->plan_features);
                                $fcount = 1;

                                @endphp
                                @foreach($plans_features as $pf)
                                @php
                                $planClass = ($fcount > 3) ? "hide-more-features" : '';
                                $style = ($fcount > 3) ? "style=display:none" :'';
                                @endphp
                                <li class="list-group-item {{ $planClass }}" {{ $style }}><i
                                        class="fa fa-check mx-2"></i><span>{{ $pf }}</span></li>
                                @php $fcount++; @endphp
                                @endforeach
                            </ul>
                            @if(count($plans_features) > 3)
                            <p class="text-left small read-more-features" onclick="readMoreFeatures({{$p->id}})"><span id="read-more-features{{$p->id}}">Read More</span><img src="{{ asset('frontend/images/next-arrow.png') }}" alt="next-arrow" class="img-fluid"></p>
                            @endif
              
              <div class="plan-adon-features">
                <div class="plan-firstHeading">Ad-Ons Features</div>
                
            
               
            <div class="dropdown dropdown-select">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="false">
                            Featured Sexy Girls
                            <span class="caret"></span>             
                        </button>
            
            
                        <ul id="style-2" class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -433px, 0px); top: 0px; left: 0px; will-change: transform;">
               <h5>Select Days</h5>
            
                            <li role="presentation">
                                <input type="radio" name="radiog_dark" id="radio6" class="css-checkbox">
                <label for="radio6" class="css-label radio2">1 Day  - $2.99</label>             
                            </li>
                            <li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio7" class="css-checkbox">
                <label for="radio7" class="css-label radio2">2 Day - $4.99</label>                              
                            </li>
                                        
              <li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio8" class="css-checkbox">
                <label for="radio8" class="css-label radio2">3 Day - $ 6.99</label>                              
                            </li>             
                        </ul>
          </div>
                
                
                <div class="dropdown dropdown-select">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="false">
                            Sexy Teaser Video
                            <span class="caret"></span>             
                        </button>
            
            
                        <ul id="style-2" class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -433px, 0px); top: 0px; left: 0px; will-change: transform;">
               <h5>Select Days</h5>
            
                            <li role="presentation">
                                <input type="radio" name="radiog_dark" id="radio6" class="css-checkbox">
                <label for="radio6" class="css-label radio2">1 Day  - $2.99</label>             
                            </li>
                            <li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio7" class="css-checkbox">
                <label for="radio7" class="css-label radio2">2 Day - $4.99</label>                              
                            </li>
                                        
              <li role="presentation">                              
                                <input type="radio" name="radiog_dark" id="radio8" class="css-checkbox">
                <label for="radio8" class="css-label radio2">3 Day - $ 6.99</label>                              
                            </li>             
                        </ul>
          </div>
                
                
                
                
                
                
              </div>
              
                            <div class="card-footer border-top-0 upgrade-btn text-center">
                                <a href="#" class="text-uppercase">select</a>
                            </div>
                        </div>
                    </div>
                    @php
                    $count++;
                    @endphp
                    @endforeach
  


                      </div> 


                         <ul class="pager wizard">
                        <li class="previous"><a href="javascript:void(0)">Previous</a></li>
                        <li class="next"><a href="javascript:void(0)">Save & Next</a></li>
                      </ul>


                                      </form>
                  </div>
<!-- End UPGRADE -->












  <!--  Start services-->
                  <div class="tab-pane" id="tab3">
                    <form method="post" action="#" id="form_step_3" onsubmit="return false;">
                     {{ csrf_field() }}

                      <div class="form-group">
                        <label class="col-sm-12"><h4>Available For</h4></label>
                            @php
                        if(!empty($listdata['metaData']['service-avail-for'])){
                                if(!is_array($listdata['metaData']['service-avail-for'])){
                                    $service_avail_array = (array)$listdata['metaData']['service-avail-for'];
                                }else{
                                    $service_avail_array = $listdata['metaData']['service-avail-for'];
                                }
                        }
                        @endphp
               @foreach($serviceavailablefor as $saf)
                       
               <div class="col-sm-12">
                <label for="service-avail-for{{$saf['id']}}">
                    <input type="checkbox" value="{{$saf['id']}}" 
                    {{!empty($service_avail_array) && in_array($saf['id'], $service_avail_array) ? 'checked':''}}
                    name="service-avail-for[]" id="service-avail-for{{$saf['id']}}"/>
                    {{$saf['value']}}</label>
               </div>
                        @endforeach
                         <div id="service-avail-for-error2"></div>
                      </div>
                      
      <div class="form-group pink-label">
               <label class="col-sm-12"><h4>Service type</h4></label>
               @php
                        if(!empty($listdata['metaData']['service-type'])){
                                if(!is_array($listdata['metaData']['service-type'])){
                                    $service_type_array = (array)$listdata['metaData']['service-type'];
                                }else{
                                    $service_type_array = $listdata['metaData']['service-type'];
                                }
                        }
                        @endphp
               @foreach($servicetype as $st)

               <div class="col-sm-12">
                 <label for="service-type{{$st['id']}}">
                    <input type="checkbox" value="{{$st['id']}}" name="service-type[]"
                    {{!empty($service_type_array) && in_array($st['id'], $service_type_array) ? 'checked':''}}
                     id="service-type{{$st['id']}}" />
                   {{$st['value']}}</label>
               </div>

               @endforeach
              
               <div id="service-type-error2"></div>



          </div>
                      
  <div class="form-group">
     <label class="col-sm-12"><h4>My Fees</h4></label>
        @if(count($listdata['rate']) > 0)
        @php $listcount = 0; @endphp
        @foreach($listdata['rate'] as $r)
 <div class="col-sm-12 add-userroles services_rates" id="test">
          <div class="rates_section">
               <div class="col-sm-6">
               <h6>Time<sup>*</sup></h6>
                    <select id="services_rates_{{$listcount}}" class="select2"
                         name="service[{{$listcount}}][service_time]">
                         @php
                         $rates_time = get_rate_time();
                         @endphp
                         @foreach($rates_time as $key=>$t)
                         <option value="{{$key}}" {{$t == $r->ad_time ? 'selected' : ''}}>{{ $t }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="form-group">
               <h6 class="col-sm-12">In Call <sup>*</sup></h6>
                    <input type="text" name="service[{{$listcount}}][service_incall_charge]"
                         class="form-control service_incall_charge" placeholder="Charges" value="{{$r->incall_charge}}">
               </div>
               <div class="form-group">
               <h6 class="col-sm-12">Out Call <sup>*</sup></h6>
                    <input type="text" name="service[{{$listcount}}][service_outcall_charge]"
                         class="form-control service_outcall_charge" placeholder="Charges"  value="{{$r->outcall_charge}}">
               </div>
               <div class="service_box" data-toggle="modal" data-target="#serviceIncluded-popup" data-backdrop="static">
                    <h6 class="col-sm-12">Service Included <sup>*</sup></h6>
                      @if(!empty($r->ad_services))
                      @php 
                      $services="";
                      $servicesarraylist = explode(",", $r->ad_services);
                      @endphp
                      @foreach($servicesarraylist as $adsr)
                      @php
                      $services .= ",".getServiceName($adsr);
                      @endphp
                    
                      @endforeach
                      @endif
          <input type="text" id="service_name{{$listcount}}"
                         class="form-control service_name" placeholder="Choose Services" onclick="setId(this.id)" 
                         value="{{!empty($services) ?trim($services, ','):'' }}">

          <input type="hidden" name="service[{{$listcount}}][service_name]"
                         class="form-control service_name_hidden" id="service_name_hidden{{$listcount}}"  value="{{!empty($r->ad_services) ? $r->ad_services :'' }}">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
               </div>
               <div class="button_box my-feesbtn"> 
                    <a href="javascript:void(0)" class="servicefee-btn-add add-rate"
                         onclick="addRate()"><i class="fa fa-plus"></i></a>
                        @if($listcount > 0)
                                   <a href="javascript:void(0)" class="servicefee-btn-remove remove-rate" onclick="removeRate()"><i
                              class="fa fa-minus"></i></a>
                       @endif
         </div>
       </div>
     </div>
        @php $listcount++; @endphp

        @endforeach
      @else
     <div class="form-group add-userroles services_rates" id="test">
          <div class="col-sm-12 rates_section">
               <div class="col-sm-12 drop_box services_select_box">
               <h6 class="col-sm-12">Time<sup>*</sup></h6>
                    <select id="services_rates_0" class="select2 service_select_box service_time"
                         name="service[0][service_time]">
                         @php
                         $rates_time = get_rate_time();
                         @endphp
                         @foreach($rates_time as $key=>$t)
                         <option value="{{$key}}">{{ $t }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="charges_box">
               <h6 class="col-sm-12">In Call <sup>*</sup></h6>
                    <input type="text" name="service[0][service_incall_charge]"
                         class="form-control service_incall_charge" placeholder="Charges">
               </div>
               <div class="charges_box">
               <h6 class="col-sm-12">Out Call <sup>*</sup></h6>
                    <input type="text" name="service[0][service_outcall_charge]"
                         class="form-control service_outcall_charge" placeholder="Charges">
               </div>
               <div class="service_box" data-toggle="modal" data-target="#serviceIncluded-popup" data-backdrop="static">
                    <h6 class="col-sm-12">Service Included <sup>*</sup></h6>
          
          <input type="text" id="service_name0"
                         class="form-control service_name" placeholder="Choose Services" onclick="setId(this.id)">

          <input type="hidden" name="service[0][service_name]"
                         class="form-control service_name_hidden" id="service_name_hidden0" >
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
               </div>
               <div class="button_box my-feesbtn"> 
                    <a href="javascript:void(0)" class="servicefee-btn-add add-rate"
                         onclick="addRate()"><i class="fa fa-plus"></i></a>

                    <a href="javascript:void(0)" class="servicefee-btn-remove remove-rate" onclick="removeRate()"><i
                              class="fa fa-minus"></i></a></div>
          </div>
     </div>
     @endif
     <div id="tool-placeholder"></div>
</div>
              
      <div class="form-group personal-radiobutton-box pink-label">
                  <label class="col-sm-12"><h4>Extra Service Fee</h4></label>
                  @if(count($listdata['extraService']) > 0)
                    @php $excount = 0; @endphp
                  @foreach($listdata['extraService'] as $lex)
                     <div class="col-sm-12 add-userroles extraservice_fee">
                    <div class="col-sm-12 rates_section">
                      <div class="drop_box">                        
                       <input type="text" class="form-control extraservice_price" name="extra_services[{{$excount}}][price]" placeholder="$300" value="{{$lex->ad_fee}}">
                      </div>
                      @if(!empty($lex->ad_services))
                      @php 
                      $exservices="";
                      $exservicesarraylist = explode(",", $lex->ad_services);
                      @endphp
                      @foreach($exservicesarraylist as $adsr)
                      @php
                      $exservices .= ",".getServiceName($adsr);
                      @endphp

                      @endforeach
                      @endif
                      <div class="form-group" data-toggle="modal" data-target="#extraserviceIncluded-popup" data-backdrop="static">
                         <!--<h6 class="labelwhite">Service Included <sup>*</sup></h6>-->
          
          <input type="text" id="extra_service_name{{$excount}}"
                         class="form-control extra_service_name" value="{{!empty($exservices) ?trim($exservices, ','):'' }}" placeholder="Choose Services" onclick="setExtraId(this.id)">

          <input type="hidden" name="extra_services[{{$excount}}][service_name]"
                         class="form-control extra_service_name_hidden" id="extra_service_name_hidden{{$excount}}" value="{{!empty($lex->ad_services) ? $lex->ad_services :'' }}">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
                    </div>
                    
                      <div class="button_box my-feesbtn">
                         <a href="javascript:void(0)" class="servicefee-btn-add" onclick="addServiceFee()"><i class="fa fa-plus"></i></a>
                       @if($excount > 0)
                      <a href="javascript:void(0)" class="servicefee-btn-remove remove-service-rate" onclick="removeServiceFee()"><i class="fa fa-minus"></i></a>
                      @endif
                      </div>
                    </div>
                   
                  </div>
                    @php $excount++; @endphp
                  @endforeach
                  @else
                  <div class="add-userroles extraservice_fee">
                    <div class="rates_section">
                      <div class="drop_box">                        
                       <input type="text" class="form-control extraservice_price" name="extra_services[0][price]" placeholder="$300">
                      </div>
                          
                      <div class="form-group" data-toggle="modal" data-target="#extraserviceIncluded-popup" data-backdrop="static">
                         <!--<h6 class="labelwhite">Service Included <sup>*</sup></h6>-->
          
          <input type="text" id="extra_service_name0"
                         class="form-control extra_service_name" placeholder="Choose Services" onclick="setExtraId(this.id)">

          <input type="hidden" name="extra_services[0][service_name]"
                         class="form-control extra_service_name_hidden" id="extra_service_name_hidden0">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
                    </div>
                    
                      <div class="button_box my-feesbtn">
                         <a href="javascript:void(0)" class="servicefee-btn-add" onclick="addServiceFee()"><i class="fa fa-plus"></i></a>
                      
                      <a href="javascript:void(0)" class="servicefee-btn-remove remove-service-rate" onclick="removeServiceFee()"><i class="fa fa-minus"></i></a></div>
                    </div>
                   
                  </div>
                  @endif
                  <div id="service-placeholder"></div>
            
           <div class="personal-radiobutton-box pink-label">
                    <div class="form-group mt-4">
                      <textarea class="form-control custom-textarea bg-theme-dark-form" name="services_additional_information"  id="exampleFormControlTextarea1" rows="3" placeholder="Addtional Information">{{$listdata['metaData']['services_additional_information']}}</textarea>
                    </div>
                    
                    
                  </div>                         
                </div>


        <div class="form-group">
               <label class="col-sm-12"><h4>Working Hours</h4></label>
              
                    <div class="col-sm-12">
                         @for($i=1; $i <= 7; $i++) 
                              <div class="col-sm-3"><label>{{ getDay($i) }}</label></div>
                             
                                   <div class="col-sm-3">
                                  
                                        <select id="{{ getDay($i) }}_from" class="select_box"
                                             name="{{ strtolower(getDay($i))}}_from">
                                             <option value="">From</option>

                                             @php echo get_times($listdata['metaData'][strtolower(getDay($i)).'_from']) @endphp
                                        </select>
                                   </div>
                                   <div class="col-sm-3">
                                        <select id="{{ getDay($i) }}_to" class="select_box"
                                             name="{{ strtolower(getDay($i))}}_to">
                                             <option value="">To</option>
                                             @php echo get_times($listdata['metaData'][strtolower(getDay($i)).'_to']) @endphp
                                        </select>
                                   </div>
                   
                    
                    <div class="col-sm-3">
                      @php
                      $dayoff = $listdata['metaData']['dayoff_'.strtolower(getDay($i))];
                      @endphp
                  <input type="checkbox" name="dayoff_{{ strtolower(getDay($i))}}" id="dayoff{{$i}}" {{  $dayoff == "on" ? 'checked': ''}}>
                          <label for="dayoff{{$i}}" >Day off</label>
                        </div> 
                    @if($i % 4 == 0)
               </div>
               <div class="col-sm-12">
                    @endif
                    @if($i === 7)
               </div>
               @endif
               @endfor
         
         <div class="form-group mt-4">
                      <textarea class="form-control custom-textarea bg-theme-dark-form" id="exampleFormControlTextarea1" rows="3" name="working_additional_information" placeholder="Working Additional Information">{{$listdata['metaData']['working_additional_information']}}</textarea>
                    </div>
      

        </div>

                 <div class="form-group">
                      <label class="col-sm-12"><h4>Run Special (Optional)</h4></label>       
                           <input type="text" class="form-control" name="run_specials" placeholder="15mins $100 Quickies, Full Service Mutual Kissing" value="{{$listdata['metaData']['run_specials']}}">
                            <p>Max. 20 words</p>
                         
                      </div>

                  <ul class="pager wizard">
                    <li class="previous"><a href="javascript:void(0)">Previous</a></li>
                    <li class="next"><a href="javascript:void(0)">Save & Next</a></li>
                  </ul>
                  
                    </form>
                  </div>


                  <!-- end servicesss -->





















                  <!-- PHOTOS UPLOAD TART -->
                  <div class="tab-pane" id="tab4">
                     <form id="form_step_4"  onsubmit="return false;" >
                           {{ csrf_field() }}

                      <div class="form-group">
                        <label class="col-sm-12"><h2 class="text-danger">Photos & Videos </h2></label>
                          <div class="col-sm-12">
                           <h4>Requirements</h4>
                               <p><i class="fa fa-check" aria-hidden="true"></i>Upload high quality photos, selfie upto 30</p>
                               <p><i class="fa fa-check" aria-hidden="true"></i>Upload high quality videos, upto 3</p>
                               <p><i class="fa fa-check" aria-hidden="true"></i>House of Sexy Girls accept your Genuine photos and videos only</p>
                               <p><i class="fa fa-check" aria-hidden="true"></i>We will contact you for your profile verification.   <span> (Any fake profile will be removed, no refund)</span></p>
                               <p><i class="fa fa-check" aria-hidden="true"></i>Keep it real, Keep it Fun</p>
                               <p><span class="text-danger"> HOUSE OF SEXY GIRLS HAS ZERO TOLARENCE FOR FAKE AND MISLEADING INFORMATION</span></p>
                           </div>

                           <label class="col-sm-12">
                            <h2 class="text-danger"><sup class="text-danger">*</sup>Profile Photos </h2></label>
                           <div class="col-sm-12">
                             <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"
                             multiple>
                             <div class="col-sm-12">High Quality Max. 30</div>
                             @if(!empty($listdata['adImage']))
                              @foreach($listdata['adImage'] as $imm)
                              <div class="col-sm-12-{{$imm->id}}">
                              
                             <img id="pro-img-{{$imm->id}}" src="{{getS3ImageURL($imm->media_filename,'202*182')}}">
                              </div>
                             
                              @endforeach
                              @endif
                           </div>
                         


                         <label class="col-sm-12">
                            <h2 class="text-danger"><sup class="text-danger">*</sup>Profile Videos </h2>
                            <span>
                              (Highly recommended)
                            </span></label>
                           <div class="col-sm-12">
                             <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"
                             multiple>
                            
                              @if(!empty($listdata['adVideo']))
                              @foreach($listdata['adVideo'] as $vd)
                              <div class="col-sm-12-{{$vd->id}}">
                              
                             <video video width="250" height="200" controls>
                             <source src="{{getS3VideoURL($vd->media_filename)}}"></source>
                             </video>
                              </div>
                             
                              @endforeach
                              @endif
                              <div class="col-sm-12"><span>Max length 2 mins. HD Video</span></div>
                           </div>


                      <label class="col-sm-12">
                            <h2 class="text-danger"><sup class="text-danger">*</sup>Teaser Videos </h2></label>
                           <div class="col-sm-12">
                             <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"
                             multiple>
                            
                              @if(!empty($listdata['adTeaser']))
                              @foreach($listdata['adTeaser'] as $atd)
                              <div class="col-sm-12-{{$atd->id}}">
                              
                             <video video width="250" height="200" controls>
                             <source src="{{getS3VideoURL($atd->media_filename)}}"></source>
                             </video>
                              </div>
                             
                              @endforeach
                              @endif
                              <div class="col-sm-12"><span>Max length 7 sec. HD Video</span></div>
                           </div>


                    </div>

                   <ul class="pager wizard">
                    <li class="previous"><a href="javascript:void(0)">Previous</a></li>
                    <li class="next"><a href="#">Finish</a></li>
                  </ul>

                    </form>
                  </div>
                  <!-- END  PHOTOS UPLOAD -->










                  <!-- FINISH TAB START -->
                  <!-- <div class="tab-pane" id="tab5">
                    <form method="post" action="#" id="form_step_3" onsubmit="return false;">
                     {{ csrf_field() }}

                      <div class="form-group">

                  <div id="finished_crackerss"></div>
                      <h2>Congratulation Alice</h2>
                    <p>Your ad is succesfully created</p>
                  
        
                    <a href="#" class="green_gredient_btn gr_pink">View Dashoard</a>
                  </div>
                    </form>
                  </div> -->
                  <!-- END  FINISH TAB -->

                  
                  
                </div><!-- tab-content -->
                
            
                
              </div><!-- #basicWizard -->
              
            </div><!-- panel-body -->
          </div><!-- panel -->
        </div><!-- col-md-12 -->
        
    
        
      </div><!-- row -->
      
     
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->
  
 
</section>




<!-- service Included modal pop up start -->
<div class="modal fade services-steps-form" id="serviceIncluded-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
         <h2>Please select services</h2>    
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToTextbox()">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">
              
        <div class="service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
      
                            
          @foreach($servicesavailable as $sa)    
                        <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" value="{{$sa['id']}}" name="service-available"  id="service-available{{$sa['id']}}" class="css-checkbox services_include" >
                               
                                <label for="service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                              </div>
                        </li>
                        @endforeach
                 
                    </ul>
                          <input type="hidden" value="" id="service_available">    
      </div>        
          </div>
      </div>  
    </div>
  </div>
</div>
<!-- service Included modal pop up End -->
<!-- extra service Included modal pop up start -->
<div class="modal fade services-steps-form" id="extraserviceIncluded-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">   
<h2>Please select services</h2>     
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToExtraTextbox()">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">
              
        <div class="extra_service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
      
                            
          @foreach($servicesavailable as $sa)    
                        <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" value="{{$sa['id']}}" name="extra-service-available"  id="extra-service-available{{$sa['id']}}" class="css-checkbox extra_services_include" >
                               
                                <label for="extra-service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                              </div>
                        </li>
                        @endforeach
                           
                
                    </ul>
                          <input type="hidden" value="" id="extra_service_available">    
      </div>        
          </div>
      </div>  
    </div>
  </div>
</div>




<script>
jQuery(document).ready(function(){
    
    "use strict";

  // Basic Wizard
  jQuery('#basicWizard').bootstrapWizard();

  
  // Progress Wizard
  $('#progressWizard').bootstrapWizard({
    'nextSelector': '.next',
    'previousSelector': '.previous',
    onNext: function(tab, navigation, index) {
      var $total = navigation.find('li').length;
      var $current = index+1;
      var $percent = ($current/$total) * 100;
      jQuery('#progressWizard').find('.progress-bar').css('width', $percent+'%');
    },
    onPrevious: function(tab, navigation, index) {
      var $total = navigation.find('li').length;
      var $current = index+1;
      var $percent = ($current/$total) * 100;
      jQuery('#progressWizard').find('.progress-bar').css('width', $percent+'%');
    },
    onTabShow: function(tab, navigation, index) {
      var $total = navigation.find('li').length;
      var $current = index+1;
      var $percent = ($current/$total) * 100;
      jQuery('#progressWizard').find('.progress-bar').css('width', $percent+'%');
    }
  });
  
  // Disabled Tab Click Wizard
  jQuery('#disabledTabWizard').bootstrapWizard({
    tabClass: 'nav nav-pills nav-justified nav-disabled-click',
    onTabClick: function(tab, navigation, index) {
      return false;
    }
  });
  
  
  jQuery(".select2").select2({
    width: '100%',
    minimumResultsForSearch: -1
  });
  
  
});
</script>

<script type="text/javascript">
var imagePostURL = "{!! route('ajaximageupload') !!}";
var videoPostURL = "{!! route('ajaxvideoupload') !!}";
var teaservideoPostURL = "{!! route('ajaxteaservideoupload') !!}";
var fetchcityURL = "{!! route('fetchcitiesbycountry') !!}";
</script>
<script src="{{ asset('frontend/js/ad_post_script.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/jquery.imgareaselect.pack.js') }}"></script>

@endsection
