@extends('bracket-admin.includes.main')
@section('title','Master Panel')
@section('content')

	<div class="pageheader">
      <h2><i class="fa fa-home"></i> Dashboard <span>Master Panel...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">Bracket</a></li>
          <li class="active">Master Panel</li>
        </ol>
      </div>
    </div>   
   
    <div class="contentpanel">  
      <div class="row">   

        <div class="col-sm-6 col-md-3">
          <div class="panel panel-success panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-user.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Age</small>
                      <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.age') }}">Age setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        

        <div class="col-sm-6 col-md-3">
          <div class="panel panel-danger panel-stat">
            <div class="panel-heading">   
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Height</small>
                    <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.height') }}">Height setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>    
              </div><!-- stat -->             
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-primary panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Weight</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.weight') }}">Weight setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
               
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-dark panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-money.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Nationality</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.nationality') }}">Nationality setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->

        <div class="col-sm-6 col-md-3">
          <div class="panel panel-success panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-user.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Orientation</small>
                      <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.orientation') }}">Orientation setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-danger panel-stat">
            <div class="panel-heading">   
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Hair color</small>
                    <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.haircolor') }}">Hair Color setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>    
              </div><!-- stat -->             
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-primary panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Hair length</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.hairlength') }}">Hair length setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
               
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-dark panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-money.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Eye color</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.eyecolor') }}">Manage Eye color</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->

        <div class="col-sm-6 col-md-3">
          <div class="panel panel-success panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-user.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Bust Size</small>
                      <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.bustsize') }}">Bust Size setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-danger panel-stat">
            <div class="panel-heading">   
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Dress Size</small>
                    <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.dresssize') }}">Dress Size setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>    
              </div><!-- stat -->             
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-primary panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Shoe Size</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.shoessize') }}">Shoe Size Setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
               
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-dark panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-money.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Personal</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.personal') }}">Personal setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->

        <div class="col-sm-6 col-md-3">
          <div class="panel panel-success panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-user.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Piercing</small>
                      <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.piercing') }}">Piercing setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-danger panel-stat">
            <div class="panel-heading">   
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label"> Favourite Things</small>
                    <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.favourite-things') }}">Favourite Things</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>    
              </div><!-- stat -->             
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-primary panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Wishlist</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.wishlist') }}"> Wishlist setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
               
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-dark panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-money.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Service Type</small>
                   <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.service-type') }}">Service Type setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->

        <div class="col-sm-6 col-md-3">
          <div class="panel panel-success panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-user.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label"> Available Services</small>
                      <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.services-available') }}">Available Service</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-danger panel-stat">
            <div class="panel-heading">   
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Available Services For</small>
                    <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.service-available-for') }}"> Services For </a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>    
              </div><!-- stat -->             
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-3">
          <div class="panel panel-primary panel-stat">
            <div class="panel-heading">   
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-document.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Manage Body Type</small>
                    <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.body-type') }}">Body Type setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>    
              </div><!-- stat -->             
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        

        <div class="col-sm-6 col-md-3">
          <div class="panel panel-dark panel-stat">
            <div class="panel-heading">   
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <img src="{{asset('bracket_admin/images/is-money.png')}}" alt="" />
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Social Media Links</small>
                    <div class="btn-demo">
                    <a class="btn btn-darkblue" href="{{ route('admin.masters.social-media-links') }}">Social Media setting</a>
                      </div>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>    
              </div><!-- stat -->             
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->


      </div><!-- row -->
      </div><!-- contentpanel -->
  </div><!-- mainpanel -->
@endsection