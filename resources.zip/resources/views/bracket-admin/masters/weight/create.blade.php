@extends('bracket-admin.includes.main')
@section('title','Add New Weight')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Weight <span>Add New Weight ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Add New Weight</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.masters.weightstore') }}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{ route('admin.masters.weight') }}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Weight lists</a>  
              </div>
              <h4 class="panel-title">Weight Details </h4>
            </div>
            <div class="panel-body">
              <div class="row">

                <div class="col-sm-6 @if($errors->has('weight_value')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Weight</label>
                    <input type="text" name="weight_value" id="weight_value" class="form-control"  placeholder="Please Enter Weight " value="{{ old('weight_value')}}" />

                    @if($errors->has("weight_value"))
						<span class="help-block">{{ $errors->first("weight_value") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

              </div><!-- row -->        
                    
             
            </div><!-- panel-body -->
            <div class="panel-footer">
              <input type="hidden" id="meta_name" name="meta_name" value="weight">
              <button class="btn btn-primary">Add Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.masters.weight') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection
