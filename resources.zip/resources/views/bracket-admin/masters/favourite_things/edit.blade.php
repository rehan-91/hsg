@extends('bracket-admin.includes.main')
@section('title',' Edit Favourite Things')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Favourite Things <span>Edit Favourite Things ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Edit Favourite Things</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.masters.favourite-things-update', $data->id) }}" method="POST" enctype="multipart/form-data">	
      		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{ route('admin.masters.favourite-things') }}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Favourite Things</a>  
              </div>
              <h4 class="panel-title"> Favourite Things Details </h4>
            </div>
            <div class="panel-body">
              <div class="row">

                <div class="col-sm-6 @if($errors->has('fav_things_value')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Piercing</label>
                    <input type="text" name="fav_things_value" id="fav_things_value" class="form-control" placeholder="Please Enter Favourite Things " value="{{ $data->meta_value }}" />

                    @if($errors->has("fav_things_value"))
						<span class="help-block">{{ $errors->first("fav_things_value") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

              </div><!-- row -->        
                    
             
            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Update Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.masters.favourite-things') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection
