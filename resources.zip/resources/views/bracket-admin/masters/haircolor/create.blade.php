@extends('bracket-admin.includes.main')
@section('title','Add New Hair Color')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Hair Color <span>Add New Hair Color ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Add New Hair Color</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.masters.haircolorstore') }}" method="POST" enctype="multipart/form-data">	
      		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{ route('admin.masters.haircolor') }}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Hair Color lists</a>  
              </div>
              <h4 class="panel-title"> Hair Color Details </h4>
            </div>
            <div class="panel-body">
              <div class="row">

                <div class="col-sm-6 @if($errors->has('haircolor_value')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Orientation</label>
                    <input type="text" name="haircolor_value" id="haircolor_value" class="form-control" placeholder="Please Enter Your Hair Color " value="{{ old('haircolor_value')}}" />

                    @if($errors->has("haircolor_value"))
						<span class="help-block">{{ $errors->first("haircolor_value") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

              </div><!-- row -->        
                    
             
            </div><!-- panel-body -->
            <div class="panel-footer">
              <input type="hidden" id="meta_name" name="meta_name" value="haircolor">
              <button class="btn btn-primary">Add Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.masters.haircolor') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection
