@extends('bracket-admin.includes.main')
@section('title','Add New Age')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Age <span>Add New Age ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Add New Age</li>
        </ol>
      </div>
    </div> 


	<div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.masters.heightstore') }}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{ route('admin.masters.height') }}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Height lists</a>  
              </div>
              <h4 class="panel-title">Add Height </h4>
            </div>
            <div class="panel-body">
              <div class="row">

                <div class="col-sm-6 @if($errors->has('height_value')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Height</label>
                    <input type="text" name="height_value" id="height_value" class="form-control" maxlength="3" placeholder="Please Enter Your Height " value="{{ old('height_value')}}" />

                    @if($errors->has("height_value"))
						<span class="help-block">{{ $errors->first("height_value") }}</span>
					@endif
                  </div>
                </div><!-- col-sm-6 -->

              </div><!-- row -->        
                    
             
            </div><!-- panel-body -->
            <div class="panel-footer">
              <input type="hidden" id="meta_name" name="meta_name" value="height">
              <button class="btn btn-primary">Add Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.masters.height') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection
