@extends('bracket-admin.includes.main')
@section('title','Height')
@section('content')
<script>
function timedMsg()
{
var t=setTimeout("document.getElementById('myMsg').style.display='none';",2000);
}
</script>

 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Height <span>Height Setting...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Height Setting</li>
        </ol>
      </div>
    </div> 

	<div class="contentpanel">    
      <div class="panel panel-default">  
        <div class="panel-body">
          
           
           <!-- Info section -->
          <div id="myMsg">@include('bracket-admin.includes.info')</div> 
  			<script language="JavaScript" type="text/javascript">timedMsg()</script>
	      <!-- Info End here -->
         
          	<div class="btn-demo">
                    <a class="btn btn-primary" href="{{ route('admin.masters.heightcreate') }}"><i class="fa fa-plus"></i> Add Height</a>
                    {{csrf_field()}} 
               </div>
         
		<div class="table-responsive">
          <table class="table table-striped" id="plans-table">

              <thead>
                 <tr>
                   <th>Height Value</th>
					<th>Added On</th>
					<th>Action&nbsp;</th>
                 </tr>
              </thead>
             
           </table>
         </div><!-- table-responsive -->  
        </div><!-- panel-body -->
      </div><!-- panel -->
        
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->

<script>
	var dTable;
	jQuery(function() {
		dTable = jQuery('#plans-table').DataTable({
			"autoWidth": false,
                        stateSave: true,
			language: {
				searchPlaceholder: "Search through Plan title",
				"paginate": {
					"first": "&verbar ;&lt;",
					"last": "&gt; &verbar;",
					"next": "&gt;",
					"previous": "&lt;"
				},
				"lengthMenu": " _MENU_ ",
				"info": "_START_ - _END_ of _TOTAL_ items",
				"infoEmpty": "0 - 0 of 0 items",
				"search": "search",
                                
                              
			},
			order: [],
			"dom": 'ftilrp',
			processing: true,
			serverSide: true,
                        
			ajax: '{!! route('admin.masters.heightdata') !!}',
			columns: [
				{ data: 'title', name: 'title' },
				
				{ data: 'created_at', name: 'created_at' },
				
				{ data: 'action', name: 'action' }
			],
			"columnDefs": [
				{ "orderable": false, "targets": [2] }
		    ]
		});
	});
</script>
@endsection

