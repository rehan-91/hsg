@extends('bracket-admin.includes.main')
@section('title','Edit Social links ')
@section('content')
 <div class="pageheader">
      <h2><i class="fa fa-home"></i> Social links <span>Edit Social links ...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Edit Social links</li>
        </ol>
      </div>
    </div> 
  <div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.masters.social-media-links-update', [$social_media_links->id]) }}" method="POST" enctype="multipart/form-data"> 
          {{ csrf_field() }}
            
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{ route('admin.masters.social-media-links')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Social links</a>  
              </div>
              <h4 class="panel-title"> Social links Details </h4>
            </div>
            <div class="panel-body">
              <div class="row">

                <div class="col-sm-6 @if($errors->has('social_media_links_value')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Social links</label>
                    <input type="text" name="social_media_links_value" id="social_media_links_value" class="form-control" placeholder="Please Enter Social links" value="{{  $social_media_links->meta_value}}" />

                    @if($errors->has("social_media_links_value"))
                      <span class="help-block">{{ $errors->first("social_media_links_value") }}</span>
                    @endif
                            </div>
                </div><!-- col-sm-6 -->


                <div class="col-sm-6 @if($errors->has('social_media_links_value')) has-error @endif">
                  <div class="form-group">
                    <label class="control-label">Social Icon</label>
                    <input type="file" name="social_media_icon" class="form-control" id="social_media_icon" value='{{ old("social_media_icon") }}'  />
                    @if($errors->has("social_media_icon"))
                 <span class="help-block">{{ $errors->first("social_media_icon") }}</span>
                 @endif        
                 @if(!empty($social_media_links->meta_icon))
                    <img src="{{url('upload/'.$social_media_links->meta_icon)}}">
                    <input type="hidden" value="{{$social_media_links->meta_icon}}" name="old_social_media_icon" class="form-control">
                    @endif
                    
             	</div>
                </div><!-- col-sm-6 -->
              </div><!-- row -->        
                    
             
            </div><!-- panel-body -->
            <div class="panel-footer">
             
              <button class="btn btn-primary">Update Now </button>
            <button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.masters.social-media-links') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel -->
@endsection
