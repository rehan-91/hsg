<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="author" content="">
         <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="shortcut icon" href="{{asset('bracket_admin/images/favicon.ico')}}" type="image/png">
  <title>HOSG || Admin Login  </title>

  <link href="{{asset('bracket_admin/css/style.default.css')}}" rel="stylesheet">
</head>

<body class="signin">

	@php
	$shown_container = is_null( old('shown_container') ) ? 0 : old('shown_container');
	@endphp
	
<section class="master_section" id="login_section" @if( intval( $shown_container ) != 0 ) style="display:none;" @endif>
  
    <div class="signinpanel">     
        <div class="row">
            <div class="col-md-7">              
               <div class="signin-info">
                    <div class="logopanel">
                        <h1><span>[</span> HOSG <span>]</span></h1>
                    </div><!-- logopanel -->
                
                    <div class="mb20"></div>
                
                    <h5><strong>Welcome to HOSG Admin Panel!</strong></h5>
                    <ul>
                        <li><i class="fa fa-arrow-circle-o-right mr5"></i> Fully Responsive Layout</li>
                        <li><i class="fa fa-arrow-circle-o-right mr5"></i> HTML5/CSS3 Valid</li>
                        <li><i class="fa fa-arrow-circle-o-right mr5"></i> Retina Ready</li>
                        <li><i class="fa fa-arrow-circle-o-right mr5"></i> WYSIWYG CKEditor</li>
                        <li><i class="fa fa-arrow-circle-o-right mr5"></i> and much more...</li>
                    </ul>
                    <!-- 
                    <div class="mb20"></div>
                    <strong>Not a member? <a href="">Sign Up</a></strong> -->
                </div><!-- signin0-info -->
            
            </div><!-- col-sm-7 -->
            
           <div class="col-md-5">
      @php	$logout_done = 0;	@endphp
			@if (\Session::has('logout_message'))
			  @php	$logout_done = 1;	@endphp
			  <div class="alert alert-success" style="margin-top:15px;">
				{!! \Session::get('logout_message') !!}
			  </div>
			@endif
			
                <form method="post" action="{{ route('admin.login') }}">
                	{{ csrf_field() }}
                    <h4 class="nomargin">Sign In</h4>
                    <p class="mt5 mb20">Login to access your account.</p>
                	
                <div class="@if($errors->has('password')) has-error @endif">
                    <input type="text" id="email" name="email" class="form-control uname" placeholder="Username" value="{{ old('email') }}" />
                    @if($errors->has("email"))
					<span class="help-block">{{ $errors->first("email") }}</span>
					@endif
                </div>

                <div class="@if($errors->has('password')) has-error @endif">
                    <input type="password" id="password" name="password" class="form-control pword" placeholder="Password" />
                    @if($errors->has("password"))
					<span class="help-block">{{ $errors->first("password") }}</span>
					@endif
                </div>

                 <span class="pull-right">
                   
             <a href="Javascript:void(0);"  onclick="show_section('forgot_section');">Forgot Password</a>
                </span>

					  <span class="pull-left">
						<input type="checkbox" name="checkboxG5" id="checkboxG5" class="css-checkbox">
                        <label for="checkboxG5" class="css-label radGroup1"> Remember Me</label>
					  </span>
		            <button class="btn btn-success btn-block">Sign In</button>
                    
                </form>
            </div><!-- col-sm-5 -->
                 
        </div><!-- row -->
        
        <div class="signup-footer">
            <div class="pull-left">
                &copy; <b>{{ date('Y') }}</b>. All rights reserved.<span>
            </div>
            <div class="pull-right">
               Developed by:<a href="https://www.vocso.com/" target="_blank" rel="nofollow">VOCSO</a>
            </div>
        </div>
        
    </div><!-- signin -->
  
</section>

<!-- New forget password  -->
<section class="master_section" id="forgot_section" @if( intval( $shown_container ) == 2 ) @else style="display:none" @endif> 
    <div class="lockedpanel">
        <div class="locked">
            <i class="fa fa-lock"></i>
        </div>
        <div class="loginuser">
        <!-- <img src="images/photos/loggeduser.png" alt="" /> -->
        </div>
        <div class="logged">
            <h4>Forgot Password</h4>
            <!-- <small class="text-muted">username@domain.com</small> -->
        </div>

        @if (\Session::has('forgot_message'))
              <div class="alert alert-success">
                {!! \Session::get('forgot_message') !!}
              </div>
            @endif
            
        <form method="post" action="{{ route('admin.forgotpassword') }}">
            {{ csrf_field()}}
            <input type="hidden" name="shown_container" value="2">

         <div class="@if($errors->has('password')) has-error @endif">
        <input type="email" id="forgot_email" class="form-control" name="forgot_email" placeholder="Enter your email" value="{{ old('forgot_email') }}" />
                 @if($errors->has("forgot_email"))
                    <span class="help-block">{{ $errors->first("forgot_email") }}</span>
                 @endif
        </div>
            <button class="btn btn-success btn-block">Resend Password Link</button>
        </form>
        <a href="Javascript:void(0);" class="pull-left frgt" onclick="show_section('login_section');"> <i class="fa fa-arrow-circle-o-left"></i> Back to Login</a>
        
    </div><!-- lockedpanel --> 
</section>
<!-- End new  -->


 <!-- Scripts -->
        <script src="{{asset('bracket_admin/js/jquery-1.11.1.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/jquery-migrate-1.2.1.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/modernizr.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/jquery.sparkline.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/toggles.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/retina.min.js')}}"></script>
        <script src="{{asset('bracket_admin/js/jquery.cookies.js')}}"></script>
        <script src="{{asset('bracket_admin/js/custom.js')}}"></script> 


<!-- <script>
    jQuery(document).ready(function(){
        
        // Please do not use the code below
        // This is for demo purposes only
        var c = jQuery.cookie('change-skin');
        if (c && c == 'greyjoy') {
            jQuery('.btn-success').addClass('btn-orange').removeClass('btn-success');
        } else if(c && c == 'dodgerblue') {
            jQuery('.btn-success').addClass('btn-primary').removeClass('btn-success');
        } else if (c && c == 'katniss') {
            jQuery('.btn-success').addClass('btn-primary').removeClass('btn-success');
        }
    });
</script> -->
<!-- Ajax Delete admins -->
<script>
    function deleteAction(model_id, id){
		if( confirm("Are you sure?") ){
			jQuery.ajax({
                                    headers: {
                                    'X-CSRF-TOKEN': $('input[name="_token"]').val()
                             },
				type: 'POST',
				dataType: "JSON",
                                data : {model_id:model_id, id:id},
				url: "{!! route('admin.ajax.destroy') !!}",
				success: function(data) {
					if( data.access_error_msg ){
						show_error_container( data.access_error_msg );
					}
					else if( data.error ){
						show_error_container( data.error );
					}
					else if( data.success ){
						dTable.ajax.reload();
						show_success_container( data.success );
					}
				},
			});
		}
	}
</script>
<!-- Forgot Password  Section -->
<script>
      var logout_done = "{{ $logout_done }}";
      jQuery(document).ready(function(){
         if( parseInt( logout_done ) == 1 ){
            history.pushState(null, null, location.href);
            window.onpopstate = function () {
                history.go(1);
            };
         }
      });
      
      function show_section( section_name ){
          jQuery(".master_section").fadeOut('fast');
          jQuery("#"+section_name).fadeIn('fast');
      }
    </script>

</body>
</html>
