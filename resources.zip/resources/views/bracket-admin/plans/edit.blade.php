@extends('bracket-admin.includes.main')
@section('title','Edit Plan')
@section('content')

 	<div class="pageheader">
      <h2><i class="fa fa-home"></i> Plans <span>Edit Plan...</span></h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <li><a href="#">HOSG</a></li>
          <li class="active">Edit Plan</li>
        </ol>
      </div>
    </div>

    <div class="contentpanel">            
      <div class="row">
      <form  action="{{ route('admin.plans.update', [$plans->id])}}" method="POST" enctype="multipart/form-data">	<!--class="form-inline"	-->
		{{ csrf_field() }}
		        
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="panel-btns">
                <a href="{{route('admin.plans.index')}}" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back To Plan List</a>  
              </div>
              <h4 class="panel-title">Plan Details</h4>
            </div>
            <div class="panel-body">

          <div class="row">
         		 <div class="form-group col-sm-6 @if($errors->has('title')) has-error @endif">
                    <label class="control-label">Title</label>
                    <input type="text" name="title" id="name" class="form-control" placeholder="Please Enter Title" value='{{ is_null(old("title")) ? $plans->plan_name : old("title") }}'  />
                  </div>

                  <div class="form-group col-sm-6 @if($errors->has('base_price')) has-error @endif">
                    <label class="control-label">Base Price</label>
                    <input type="number" name="base_price" class="form-control"  placeholder="Please Enter Base Price" value='{{ is_null(old("base_price")) ? $plans->plan_price_base : old("base_price") }}'/>
                  </div><!-- col-sm-6 -->
              </div><!-- row -->  
            
         <div class="row">
         		 <div class="form-group col-sm-6 @if($errors->has('boost_price')) has-error @endif">
                    <label class="control-label">Boost Price</label>
                    <input type="number" name="boost_price" id="name" class="form-control" placeholder="Please Enter Boost Price" value='{{is_null(old("boost_price")) ? $plans->plan_price_boost : old("boost_price") }}' />
                  </div>

                  <div class="form-group col-sm-6 @if($errors->has('featured_price')) has-error @endif">
                    <label class="control-label">Featured Price</label>
                    <input type="number" name="featured_price" class="form-control"  placeholder="Please Enter Featured Price" value='{{ is_null(old("featured_price")) ? $plans->plan_price_featured : old("featured_price") }}'/>
                  </div><!-- col-sm-6 -->
              </div><!-- row -->  

          <div class="row">
         		 <div class="form-group col-sm-6 @if($errors->has('allowed_photos')) has-error @endif">
                    <label class="control-label">Allowed photos</label>
                    <input type="number" name="allowed_photos" id="name" class="form-control" placeholder="Please Enter Allowed Photos" value='{{ is_null(old("allowed_photos")) ? $plans->plan_allowed_photos : old("allowed_photos") }}' />
                  </div>

                  <div class="form-group col-sm-6 @if($errors->has('allowed_videos')) has-error @endif">
                    <label class="control-label">Allowed videos</label>
                    <input type="number" name="allowed_videos" class="form-control"  placeholder="Please Enter Number of Allowed videos " value='{{ is_null(old("allowed_videos")) ? $plans->plan_allowed_videos : old("allowed_videos") }}'/>
                  </div><!-- col-sm-6 -->
              </div><!-- row -->        
             
              <div class="row">
         		   <div class="form-group col-sm-6 @if($errors->has('user_type_id')) has-error @endif">
                    <label class="control-label">Listing Type</label>
                    <select id="user_type_id" class="select2 form-control" id="user_type_id" name="user_type_id">
 					@foreach($usertype as $utype)
                    <option value="{{$utype['id']}}" @if( $utype['id'] == $plans->user_type_id ) selected  @endif >{{$utype['title']}}</option>
                   @endforeach
                    </select>
                  </div>

				    <div class="form-group col-sm-6 @if($errors->has('duration')) has-error @endif">
                    <label class="control-label">Duration</label>
                    <input type="number" id="contact" name="duration" class="form-control"  placeholder="Please Enter Duration" value='{{ $plans->plan_duration}}' />
                    <select id="duration" class="select2 form-control" name="plan_duration_unit" >
                      <option value="hours" @if($plans->plan_duration_unit == 'hours') 'selected' @endif>Hours</option>
                      <option value="day" @if($plans->plan_duration_unit == 'day') 'selected' @endif>Day</option>
                     </select>
                  </div>              
              </div><!-- row -->        

 				 <div class="row">
            <div class="form-group col-sm-12">
             <label class="control-label" for="from">Features(One fetaure per line)</label>
                <textarea name="plan_features" class="form-control" >{{ $plans->plan_features }}</textarea>
              </div>
        		</div>
<!-- AddOn Json data  -->
			@if(!empty($utype['addon_features']))
              @php

              $addonfeaturedata = json_decode($utype['addon_features']);
              @endphp
              @foreach($addonfeaturedata as $addon)
		<div class="row add-n-features-more" >
			<div class="form-group col-sm-6">		
           	 <input type="text" id="addon_features" name="addon_features[0]['feature']" class="form-control" placeholder="Please Enter Base Features"  value="{{$addon[0]['feature']}}" />
			</div>	

			<div class="form-group col-sm-6">			
	          <input type="text" id="addon_features" name="addon_features[0]['price']" class="form-control" placeholder="Please Enter Price" value="{{$addon[0]['price']}}" />	
			</div>
		</div>
		@endforeach

		@else

		<div class="row add-n-features-more" >
			<div class="form-group col-sm-6">		
           	 <input type="text" id="addon_features" name="addon_features[0]['feature']" class="form-control" placeholder="Please Enter Base Features"  value="#" />
			</div>	

			<div class="form-group col-sm-6">			
	          <input type="text" id="addon_features" name="addon_features[0]['price']" class="form-control" placeholder="Please Enter Price" value="#" />	
			</div>
	
		@endif
		
			<div class="row favthings_placeholder"></div>
 				<div class="btn-demo" style="margin-left: 10px;">
                    <a class="btn btn-default" href="javascript:void(0)" onclick="addmore()"><i class="fa fa-plus"></i> Add More</a>
               </div>		
			</div> <!--row add--->
		
			<!-- End json data -->
			

          <div class="input-box permissionTable">
            <label>Status</label>
            <input type="checkbox" id="status_1" name="status" value="1" class="cbx hidden" @if($plans->plan_status == 1) checked @endif> 
            <label for="status_1" class="lbl" id="switch-box"></label>
            
			</div>
          <div class="input-box permissionTable">
                <label>Recommended</label>
                <input type="checkbox" id="recommended" name="recommended" value="1"  class="cbx hidden" @if($plans->plan_is_recommended == 1)checked @endif> 
                <label for="recommended" class="lbl" id="switch-box"></label>
		    </div>


            </div><!-- panel-body -->
            <div class="panel-footer">
              <button class="btn btn-primary">Update Now </button>
          	<button class="btn btn-default" name="cancel" type="reset" onclick="window.location.href='{{ route('admin.plans.index') }}'">Cancel</button>
            </div>
          </div>
        </div>
    </form>
        
      </div><!-- row -->
      
    </div>
    
  </div><!-- mainpanel --> 
@endsection