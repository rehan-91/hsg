<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Redirect;
use Response;
use Input;
use Hash;
use Auth;
use Session;
use DB;
use File;
use App\Models\User;
use App\Models\MainMaster;
use App\Models\Invoices;

use App\Models\Role;
use App\Models\VerifyUser;
use App\Models\UserOtps;
use App\Models\EmailMessage;
use App\Models\addOnsUpgrade;
use App\Models\MetaData;
use App\Models\Plans;
use App\Models\Image;
use App\Models\Cities;
use App\Models\Countries;
use App\Models\Testimonials;
use App\Models\AdRate;
use App\Models\AdMeta;
use App\Models\OtherAds;
use App\Models\UserAdvertisement;
use App\Models\AdExtraServices;
use App\Models\UserAdMeta;
use App\Models\AdsTouring;
use App\Models\AdStepsUpdate;
use App\Models\EmojisReactionAd;
use App\Models\Order;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\ShortList;
use App\Models\Suburbs;
use App\Models\Guests;
use App\Models\AgencyDetails;
use App\Models\AdWorkingHours;
use App\Models\AgencyImages;
use App\Models\AgencyMeta;
use App\Models\ClubDetails;
use App\Models\ClubImages;
use App\Models\AdStats;
use App\Models\ClubMeta;
use App\Models\AdultJobs;
use App\Models\AdultJobsImages;
use App\Models\AdsAddOnFeatures;
use App\Models\AdBoostLog;
use App\Models\Usertype;
use App\Models\Ethinicity;

use Imageupload;
use Carbon\Carbon;
class AdPostController extends Controller
{
    //
    private $is_draft_redirect = 'No';
	public function __construct( ) {
	   $this->generalSettings = generalSettings();
	   $this->middleware(function ($request, $next) {
		$this->user= Auth::user();
  
		return $next($request);
	 });
    }
    
	function ads(){
			
			$listingtype = listingtype();
		\Request::session()->forget('user_ad_id');
		 \Request::session()->forget('form_step');
		if(!empty($this->user)){

				$listingDetail = listingtype($this->user->listing_type);

				if(count($listingDetail) > 0){
				
					if($listingDetail[$this->user->listing_type]['show_category']==1){
						if(is_agency()){
						if(!empty(\Request::session()->get('agency_id'))){
							return view('frontend.ads.listings')->with('listingtype', $listingtype)->with("generalsettings", $this->generalSettings )->with("register", false);
						}else{
							return redirect()->route('post-ad.', $listingDetail[$this->user->listing_type]['slug']);
						}
					}
					if(is_club()){
						if(!empty(\Request::session()->get('club_id'))){
							return view('frontend.ads.listings')->with('listingtype', $listingtype)->with("generalsettings", $this->generalSettings )->with("register", false);
						}else{
							return redirect()->route('post-ad.', $listingDetail[$this->user->listing_type]['slug']);
						}
					}


						
					}
					return redirect()->route('post-ad.', $listingDetail[$this->user->listing_type]['slug']);
				}else{
					return back();
				}

		}else{

			return view('frontend.ads.listings')->with('listingtype', $listingtype)->with("generalsettings", $this->generalSettings )->with("register", true);
		}
	}


	function index(Request $request){
		//$res = getAddedItemDetail(78, NULL, true);
		//die("Ff");
	   // \Request::session()->forget('form_step');
		$req = $request->all();
		$slug = \Request::segment(2);
		
		
		if(is_agency() && $slug =='photographer' ){
			return redirect()->route('PageError')->with('restrict_access', 'Sorry you are not authorized to access this feature!');
			 return redirect()->back()->with('success', ['your message,here']);  
		}
		if(is_club() && $slug =='photographer' ){
			return redirect()->route('PageError')->with('restrict_access', 'Sorry you are not authorized to access this feature!');
		}

		$slug2 = \Request::segment(3);
		/*if(is_club()){
			if(empty(\Request::session()->get('club_id'))){
				return back();
			}
		}
		*/
		$listdata  = array();
		$ad_listing_type_id = getListingId($slug);
		$availableService = getMasterServiceByListing($ad_listing_type_id);
		
		$detailList = listingtype($this->user->listing_type);

		if($ad_listing_type_id != $this->user->listing_type && $detailList[$this->user->listing_type]['show_category']==0){
			return abort(404);
		}
		$user_ad_id = \Request::session()->get('user_ad_id');

		if(!empty($user_ad_id)){
			
			$listdata = getAddedItemDetail($user_ad_id, $ad_listing_type_id);

			DB::connection()->enableQueryLog();
			$order = Order::where('ad_id', $user_ad_id)->where('plan_expired','>=',strtotime(date('Y-m-d')) )->where('order_status', 'Success')->OrderBy('id', 'desc')->first();
			/*
			if(count($order)){
					$planstartday = date('Y-m-d', $order->plan_purchased);
					
					$planstartday = $order->plan_purchased;
					$orderplan = getPlanDetail($order->plan_id);

					$orderplan_duration = $orderplan->plan_duration;
					if($orderplan_duration < 7){
						$expdate = 7 - $orderplan_duration;
						 $planendday = strtotime("+ ".$expdate." days", $order->plan_expired);
						
					}else{
						$planendday = $order->plan_expired;
					}
					
			}*/
		}



		if($ad_listing_type_id == $this->user->listing_type && $detailList[$this->user->listing_type]['cat_type']=='agency'){
			
			$listdata = $this->getAgencyDetail($ad_listing_type_id, $this->user->id );
			
		}

			if($ad_listing_type_id == $this->user->listing_type && $detailList[$this->user->listing_type]['cat_type']=='club'){

			
			$listdata = $this->getClubDetail($ad_listing_type_id, $this->user->id );
		}
	

		if(!empty($slug2)){
			$slugdata = UserAdvertisement::all()->where('slug', $slug2)->where('ad_listing_type_id', $ad_listing_type_id)->where('ad_user_id', Auth::user()->id);
			
			if(count($slugdata) > 0){
				$user_ad_id = $slugdata->first()->id;
				
				
			$listdata = getAddedItemDetail($slugdata->first()->id);
			$order = Order::where('ad_id', $user_ad_id)->where('plan_expired','>=',strtotime(date('Y-m-d')) )->where('order_status', 'Success')->OrderBy('id', 'desc')->first();
			
			/*
			if(count($order)){
					$planstartday = date('Y-m-d', $order->plan_purchased);
					
					$planstartday = $order->plan_purchased;
					$orderplan = getPlanDetail($order->plan_id);

					$orderplan_duration = $orderplan->plan_duration;
					if($orderplan_duration < 7){
						$expdate = 7 - $orderplan_duration;
						 $planendday = strtotime("+ ".$expdate." days", $order->plan_expired);
						
					}else{
						$planendday = $order->plan_expired;
					}
					
			}*/
			
			}else{
				return abort(404);
			}
		}
		$curr_date = strtotime(date("Y-m-d"));
		if($listdata['old_plan_expired'] >= $curr_date){

			$oldorder = Order::where('ad_id', $user_ad_id)->where('id', $listdata['old_order_id'] )->first();
			$planstartday = $oldorder->plan_purchased;
			
		}else{
			$planstartday = $listdata['plan_purchased'];
		}
	
		
		$orderplan = getPlanDetail($listdata['plan_id']);

		$orderplan_duration = $orderplan->plan_duration;
		if($orderplan_duration < 7){
			$expdate = 7 - $orderplan_duration;
			 $planendday = strtotime("+ ".$expdate." days", $listdata['plan_expired']);
			
		}else{
			$planendday = $listdata['plan_expired'];
		}

		if($listdata['status']==1){
			$res = getAddedItemDetail($user_ad_id, NULL, true);
			

			$is_draft = false;
			if(count($res) > 0){
				$steps =  (int)$res['step_1'] + (int)$res['step_2'] + (int)$res['step_3'] + (int)$res['step_4'];
				if($steps > 0){
					$listdata = $res;
					$is_draft = true;
				}
			}
		}
		
		

		$ad_gender = !empty($listdata['metaData']['gender']) ? $listdata['metaData']['gender'] : '';
		$orientation = getOrientation($slug, $ad_gender);

		$bustsize = getBustsize($slug, $ad_gender);

		$dresssize = getDressSize($slug, $ad_gender);

		// $wishlistthings = getWishlist($slug, $ad_gender);
		// $favthings = getFavlist($slug, $ad_gender);
	
		$bodytype = getBodyType($slug, $ad_gender);
		
		$cat_type =  $detailList[$this->user->listing_type]['cat_type'];
		
		$master_arr = fetchAllMasterData();
		$age = $master_arr['age'];
		$ethinicity =$master_arr['ethinicity'];
		$social_media_links = $master_arr['social_media_link'];
		$generalsettings = $this->generalSettings;
		$height = $master_arr['height'];
		$weight = $master_arr['weight'];
		$waistsize = $master_arr['waistsize'];
		$penissize = $master_arr['penissize'];
		$peniscircum = $master_arr['peniscircum'];
		$orientation = $orientation['orientation'];
		$nationality = $master_arr['nationality'];
		$haircolor = $master_arr['haircolor'];
		$hairlength = $master_arr['hairlength'];
		$dresssize = $dresssize['dresssize'];
		$shoessize = $master_arr['shoessize'];
		$eyecolor = $master_arr['eyecolor'];
		$bustsize = $bustsize['bustsize'];
		$serviceavailablefor =  $master_arr['service-available-for'];
		$servicesavailable =  $availableService['service-available'];
		$servicetype =$master_arr['service-type'];
		$bodytype = $bodytype['body-type'];
		$personal = $master_arr['personal'];
		$piercing = $master_arr['piercing'];
		$wishlistthings = $master_arr['wishlist-things'];

		
		$favthings_male = MainMaster::all()->where('meta_name','fav_things')->whereIn('gender',['Male','male'])->where('is_public','=', 0);
		$favthings_female = MainMaster::all()->where('meta_name','fav_things')->whereIn('gender',['female','trans'])->where('is_public','=', 0);

		$favthings_male_self = MainMaster::all()->where('meta_name','fav_things')->whereIn('gender',['Male','male'])->where('created_ad_id','=',$user_ad_id)->where('is_public','=', 1);
		$favthings_female_self = MainMaster::all()->where('meta_name','fav_things')->whereIn('gender',['female','trans'])->where('created_ad_id','=',$user_ad_id)->where('is_public','=', 1);

		$wishlistthings_male = MainMaster::all()->where('meta_name','wishlist-things')->whereIn('gender',['Male','male'])->where('is_public','=', 0);
		$wishlistthings_female = MainMaster::all()->where('meta_name','wishlist-things')->whereIn('gender',['female','trans'])->where('is_public','=', 0);

		$wishlistthings_male_self = MainMaster::all()->where('meta_name','wishlist-things')->whereIn('gender',['Male','male'])->where('created_ad_id','=',$user_ad_id)->where('is_public','=', 1);
		$wishlistthings_female_self = MainMaster::all()->where('meta_name','wishlist-things')->whereIn('gender',['female','trans'])->where('created_ad_id','=',$user_ad_id)->where('is_public','=', 1);

		//print_r($wishlistthings_female_self);

		// if(count($wishlistthings_male_self)>0){
		// 	$wishlistthings_male = array_merge($wishlistthings_male_public,$wishlistthings_male_self);
		// }else{
		// 	$wishlistthings_male = $wishlistthings_male_public;
		// }
		
		// if(count($wishlistthings_female_self)>0){
		// 	$wishlistthings_female = array_merge($wishlistthings_female_public,$wishlistthings_female_self);
		// }else{
		// 	$wishlistthings_female = $wishlistthings_female_public;
		// }
		// print_r($wishlistthings_female);
		// exit();
		// if(count($favthings_female_self)>0){
		// 	$favthings_female = array_merge($favthings_female_public,$favthings_female_self);
		// }else{
		// 	$favthings_female = $favthings_female_public;
		// }

		// if(count($favthings_male_self)>0){
		// 	$favthings_male = array_merge($favthings_male_public,$favthings_male_self);
		// }else{
		// 	$favthings_male = $favthings_male_public;
		// }
	
		//$freeplans = array();
		//if(is_New_User($this->user->id)){
			$freeplans = DB::table('plans')->where('plan_type', 'Free')->where('plan_status', 1)->where('listing_type_id',  $ad_listing_type_id)->get();
		//}

		$plans = DB::table('plans')->where('listing_type_id', $ad_listing_type_id)->where('plan_type', 'Paid')->where('plan_is_recommended', '0')->where('plan_status', 1)->orderBy('plan_sort_order', 'asc')->get();
			$recommends_plans= DB::table('plans')->where('listing_type_id', $ad_listing_type_id)->where('plan_type', 'Paid')->where('plan_is_recommended', '1')->where('plan_status', 1)->orderBy('plan_sort_order', 'asc')->get();
		
		$tourcountries = Countries::where('is_touring', '1')->where(id, getDefaultCountry())->get();
		$intertourcountries = Countries::where('is_touring', '1')->where(id,'!=' ,getDefaultCountry())->orderBy('sort_order')->get();
		//$cities = Cities::all();
		$countries = Countries::where('id',getDefaultCountry())->get();
		$disclaimer = array();
		$disclasimer = Usertype::where('id', $ad_listing_type_id)->first()->disclaimer;

		if(!empty($disclasimer)){
			$disclaimer = explode("\n", $disclasimer);

		}
		
		$user_ad_id =$listdata['adId'];
		/*if($is_draft){
			if($this->is_draft_redirect == 'No'){
				$check_for_draft_data = AdStepsUpdate::where('ad_id',$listdata['adId'])->first();
			
				$getUserSlug =UserAdvertisement::where('id',$listdata['parent_id'])->first();
				if($check_for_draft_data->step_1 == 1 ){
					$returnURL = url('edit-profile/'.$slug.'/'.$getUserSlug->slug.'?step=1');
					return redirect()->to($returnURL);

				}else if($check_for_draft_data->step_2 == 1 ){
					$returnURL = url('edit-profile/'.$slug.'/'.$getUserSlug->slug.'?step=2');
					return redirect()->to($returnURL);
				}else if($check_for_draft_data->step_3 == 1 ){
					$returnURL = url('edit-profile/'.$slug.'/'.$getUserSlug->slug.'?step=3');
					return redirect()->to($returnURL);
				}else if($check_for_draft_data->step_4 == 1 ){
					$returnURL = url('edit-profile/'.$slug.'/'.$getUserSlug->slug.'?step=4');
					return redirect()->to($returnURL);
				}
				$this->is_draft_redirect = 'Yes';
			}
			
			
		}*/
		
		


		 return view('frontend.ads.'.$slug.'/index', compact('age','generalsettings','height','weight','haircolor',
		 'hairlength','dresssize','shoessize','eyecolor','nationality','orientation','bodytype','serviceavailablefor','servicesavailable',
		 'servicetype','servicetype','piercing','personal','wishlistthings_female','wishlistthings_male','wishlistthings_female_self','wishlistthings_male_self','bustsize','favthings_male','favthings_female','favthings_male_self','favthings_female_self','plans','recommends_plans','countries',
		 'social_media_links','ad_listing_type_id','listdata','cities','user_ad_id','disclaimer', 'cat_type','order', 'tourcountries','freeplans','agencyEscort','ethinicity','waistsize', 'intertourcountries','planstartday','planendday','orderplan_duration','is_draft','peniscircum','penissize'));
	
	}

	public function clubProfile($slug){
		
 		$slug = \Request::segment(2);
 		$Notexits= ClubDetails::all()->where('slug',$slug)->first();
 		if(empty($Notexits)){
 			return redirect()->route('PageError');
 		}else{

 		$datas = $this->getClubDetail("","",$slug);

 		if(empty($datas)){

 			return redirect()->route('PageError');
 		}
 		
 		$data['data'] = $datas[0];
 		$data['generalsettings'] = $this->generalSettings;
 		$id = $data['data']['clubID'];
 		$countEmoji = EmojisReactionAd::where('ad_id', $id)->sum('emoji_value');

 		$emojiarray = array();
		$emojiarray['winiking_face'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'winiking_face')->sum('emoji_value');
		$emojiarray['heart_eyes_face'] = EmojisReactionAd::where('ad_id',$id)->where('emoji_key', 'heart_eyes_face')->sum('emoji_value');
		$emojiarray['rose'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'rose')->sum('emoji_value');
		$emojiarray['lips'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'lips')->sum('emoji_value');
		$emojiarray['heart'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'heart')->sum('emoji_value');
		$emojiarray['like'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'like')->sum('emoji_value');

 		

 		$array = array("club_id" => $id);
 		$data['list'] = fetchFeatuedListing($array);
 		$social_media_links = MainMaster::all()->where('meta_name','social_media_link');

		return view('frontend.ads.clubs.ad_profile', $data, compact('social_media_links','countEmoji'))->with("emoji", $emojiarray);
 		}
 		

	}

	public function agencyProfile($slug){
 		$slug = \Request::segment(2);
 		$Notexits= AgencyDetails::all()->where('slug',$slug)->first();
 		if(empty($Notexits)){
 			return redirect()->route('PageError');
 		}else{

 		$datas = $this->getAgencyDetail("","",$slug);

 		if(empty($datas)){

 			return redirect()->route('PageError');
 		}
 	
 		$data['data'] = $datas[0];
 		$data['generalsettings'] = $this->generalSettings;
 		$id = $data['data']['agencyId'];

 		$countEmoji = EmojisReactionAd::where('ad_id', $id)->sum('emoji_value');

 		$emojiarray = array();
		$emojiarray['winiking_face'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'winiking_face')->sum('emoji_value');
		$emojiarray['heart_eyes_face'] = EmojisReactionAd::where('ad_id',$id)->where('emoji_key', 'heart_eyes_face')->sum('emoji_value');
		$emojiarray['rose'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'rose')->sum('emoji_value');
		$emojiarray['lips'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'lips')->sum('emoji_value');
		$emojiarray['heart'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'heart')->sum('emoji_value');
		$emojiarray['like'] = EmojisReactionAd::where('ad_id', $id)->where('emoji_key', 'like')->sum('emoji_value');

 		$array = array("agency_id" => $id);
 		$data['list'] = fetchFeatuedListing($array);
 		$social_media_links = MainMaster::all()->where('meta_name','social_media_link');

			return view('frontend.ads.escort-agency.ad_profile', $data, compact('social_media_links','countEmoji'))->with("emoji", $emojiarray);
 		}
 		

	}
	public function viewProfile($slug){
	  $slug = \Request::segment(2);

		$userad = new UserAdvertisement();
		$profileData = $userad->getProfileData($slug);
		$curr_date = strtotime(date("Y-m-d H:i a"));

	 $getAllOrderData = getAllOrderData($profileData['adUserId'],$profileData['adId']);
	 if(count($getAllOrderData)>0){
	 	$Expireds = "No";
			}else{
				$Expireds = "Yes";
			}

		if(count($profileData) == 0){

			return back();
		} else{
			
			if($profileData['old_plan_expired'] >= $curr_date){


				$oldorder = Order::where('ad_id', $profileData['adId'])->where('id', $profileData['old_order_id'] )->first();
				$profileData['planstartday']= $oldorder->plan_purchased;
				
			}else{
				$profileData['planstartday'] = $profileData['plan_purchased'];
			}
		
			
			$orderplan = getPlanDetail($profileData['plan_id']);

			$orderplan_duration = $orderplan->plan_duration;
			// if($orderplan_duration < 7){
			// 	$expdate = 7 - $orderplan_duration;
			// 	 $profileData['planendday'] = strtotime("+ ".$orderplan_duration." days", $profileData['plan_expired']);
				
			// }else{
				$profileData['planendday'] = $profileData['plan_expired'];
			//}
			$testimonials = Testimonials::all()->where('test_ad_id',$profileData['adId'])->where('status', 1);
			$stats = array();	
			$stats = AdStats::where('stat_ad_id',$profileData['adId'] )->first();

			if(count($stats) == 0){
				
				$statss = new AdStats();
				$statss->stat_views = 1;
				$statss->stat_ad_id = $profileData['adId'];

				$statss->save();
			}else{
				
				$statss = AdStats::findOrFail($stats->id);
				
				$statss->stat_views = $stats->stat_views + 1;
				$statss->save();
			}

			$social_media_links = MainMaster::all()->where('meta_name','social_media_link');
			$fav_things = MainMaster::all()->where('meta_name','fav_things');
			$wish_things = MainMaster::all()->where('meta_name','wishlist-things');
			//print_r($wish_things);
			$listing_type_id = $profileData['adListingTypeId'];
			$slug = listingtype($listing_type_id);
	 		
	 		$image_gallery = $profileData['images'];
	 		$image_videos = $profileData['videos'];
			$today =  strtotime(date('y-m-d'));
			 //$querys = "select * from tbl_ads_touring where (ad_id='".$profileData['adId']."' and ".$today." between from_date and to_date) or (from_date > ".$today." and ad_id='".$profileData['adId']."') order by from_date";
			 $querys = "select * from tbl_ads_touring where ad_id='".$profileData['adId']."' and (".$today." between from_date and to_date or from_date >= '".$today."') order by from_date";
			$tourData = DB::select($querys);
			
			//$tourData = AdsTouring::all()->where('ad_id',  $profileData['adId']  )->where('');

			$fav_data = DB::table('user_ad_meta')
				        ->where('ad_id', '=', $profileData['adId'])     
				        ->where('meta_key', 'LIKE', "%"."fav_things"."%")      
				        ->count(); 
			$social_links_check = DB::table('user_ad_meta')
				        ->where('ad_id', '=', $profileData['adId'])     
				        ->where('meta_key', 'LIKE', "%"."social_links_"."%")      
				        ->count(); 
			$wish_data = DB::table('user_ad_meta')
				        ->where('ad_id', '=', $profileData['adId'])     
				        ->where('meta_key', 'LIKE', "%"."wish_things"."%")      
				        ->count();    
			$countEmoji = EmojisReactionAd::where('ad_id', $profileData['adId'])->sum('emoji_value');
			
				        
			$data = array();
			$data['winiking_face'] = EmojisReactionAd::where('ad_id', $profileData['adId'])->where('emoji_key', 'winiking_face')->sum('emoji_value');
			$data['heart_eyes_face'] = EmojisReactionAd::where('ad_id',$profileData['adId'])->where('emoji_key', 'heart_eyes_face')->sum('emoji_value');
			$data['rose'] = EmojisReactionAd::where('ad_id', $profileData['adId'])->where('emoji_key', 'rose')->sum('emoji_value');
			$data['lips'] = EmojisReactionAd::where('ad_id', $profileData['adId'])->where('emoji_key', 'lips')->sum('emoji_value');
			$data['heart'] = EmojisReactionAd::where('ad_id', $profileData['adId'])->where('emoji_key', 'heart')->sum('emoji_value');
			$data['like'] = EmojisReactionAd::where('ad_id', $profileData['adId'])->where('emoji_key', 'like')->sum('emoji_value');
			$users = User::all()->where('id', $profileData['adUserId'])->first();


			return view("frontend.ads.".$slug[$listing_type_id]['slug'].".ad_profile", compact('tourData','fav_data','wish_data','social_links_check','countEmoji'))
			->with('social_media_links', $social_media_links)
			->with('data', $profileData)->with("generalsettings", $this->generalSettings )
			->with('fav_things',$fav_things)->with("emoji", $data)->with('image_gallery',$image_gallery)->with('testimonials', $testimonials)->with('users',$users )->with('wish_things', $wish_things)->with('image_videos', $image_videos)->with("Expired",$Expireds);
		
		}
	} 

	 
	 
	
	function saveIndividualDetails(Request $request){

		if($request->input('savetype') != 'autosave'){
			    $validator = Validator::make( $request->all(),  [
                "ad_name" => 'required|min:3',
                "ad_email" =>'required',
                "ad_contactno" => 'required',
                'country_name' => 'required',
               
                'city_name' => 'required',
                'suburbs' => 'required',
                'rdo' => 'required',
                'booking_method' => 'required',
                'about_description' => 'required',
                'personal' => 'sometimes|required',
                'age' => 'required',
                'bustsize' => 'required',
                'gender' => 'required',
                'weight' => 'required',
                //'nationality' => 'required',
                'height' => 'required',
                'orientation' => 'required',
                'eyecolor' => 'required',
                'haircolor' => 'required',
                'hairlength' => 'required',
                'dresssize' => 'required',
                //'busttype' => 'required',
                'shoessize' => 'required',
                'tagline' => 'max:50',
                'ethinicity' => 'required',
                'body-type'=>'required'


                
            ],[
                "ad_name.required" => "Please enter name.",
                "ad_name.min" => "Your name must be atleast 3 character long.",
                "ad_email.required" => "Please enter email.",
               
                "ad_contactno.required" => "Please enter phone number.",
                "country_name.required" => "Please choose country.",
                "city_name.required" => "Please choose city name.",
                "suburbs.required" => "Please enter your Suburbs/Local area.",
                "rdo.required" => "Please choose your gender .",
                "booking_method.required" => "Please choose booking method.",
                "personal.required" => "Please choose one personal type.",
                 "height.required" => "Please enter your height.",
                'age.required' => 'Please enter your age.',
                'ethinicity.required' => 'Please choose  ethinicity.',
                'orientation.required' => 'Please choose  orientation.',
                'bustsize.required' => ' Please select your bustsize.',
                'gender.required' => 'Please select your gender.',
                'weight.required' => 'Enter your weight.',
                //'nationality.required' => 'Please choose nationality.',
                'eyecolor.required' => 'Please choose eye color.',
                'about_description.required' => 'Please enter about yourself.',
                'haircolor.required' => 'Please choose hair color.',
                'hairlength.required' => 'Please choose hair length .',
                'dresssize.required' => 'Please choose dress size .',
                'shoessize.required' => 'Please choose shoes size .',
                'body-type.required' => 'Please select your body type.',
                
                 'tagline.max' => 'Tagline should not be  greater than 50 character.',
                //'busttype.required' => 'Please choose bust type.'
                
            ]);
	if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			exit();
		}
		}
		if(empty($request->input('ad_name')) && empty($request->input('ad_email')) && empty($request->input('ad_contactno')) && empty($request->input('country_name')) && empty($request->input('suburbs')) && empty($request->input('suburbs'))  && empty($request->input('city_name'))){
			
			return;
		}

		\DB::enableQueryLog();
		$user_data = Auth::user();
		
		if(empty($request->input("ad_listing_type_id"))){

			return;
		}
		$listingExistOrNot = listingtype($request->input("ad_listing_type_id"));
		if(count($listingExistOrNot) == 0){
			return;
		}
		if(!empty($request->input('user_ad_id'))){
		$user_ad_id = $request->input('user_ad_id');
		}else{
		$user_ad_id = $request->session()->get('user_ad_id');	
		}

		//$ads_id = $request->input('user_ad_id');

		
		/*if(!empty($ads_id)){
		$userAds = UserAdvertisement::findOrFail($ads_id);
		if($userAds->ad_listing_type_id != $request->input("ad_listing_type_id")){
			$user_ad_id = "";
		}
		}*/

		if(!empty($user_ad_id)){
			$AdExist = UserAdvertisement::findOrFail($user_ad_id);

			if($AdExist->ad_listing_type_id != $request->input("ad_listing_type_id")){
				$user_ad_id = "";
			}
		}
		if((int)$AdExist->parent_id == 0){
			
			$getParentAd = 	UserAdvertisement::where('parent_id', $user_ad_id)->first();
			$ad_draft_id = $getParentAd->id;

		}else{
			
			$ad_draft_id = $AdExist->id;
		}

		if($AdExist->status == 1 && $request->input('is_draft') ==1){
				
				if ((int)$ad_draft_id > 0) {
					$userAd = UserAdvertisement::findOrFail($ad_draft_id);
			
					$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
					$userAd->ad_name = $request->input("ad_name");
					$userAd->ad_email = $request->input("ad_email");
					$userAd->ad_contactno = $request->input("ad_contactno");
					$userAd->ad_country = $request->input("country_name");
					$userAd->ad_location = $request->input("city_name");
					$userAd->ad_suburbs = $request->input("suburbs");
					$userAd->draft = 1;
					//$userAd->parent_id = $user_ad_id;
					$userAd->about_description = $request->input("about_description");
					if($userAd->ad_name != $request->input("ad_name")){
					$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
					$userAd->slug = $slug;
					}
					if(!empty($request->session()->get('agency_id'))){
						$userAd->agency_id = $request->session()->get('agency_id');
					}

					if(!empty($request->session()->get('club_id'))){
						$userAd->club_id = $request->session()->get('club_id');
					}
					
					
					$userAd->save();
				}else{
				$userAd = new UserAdvertisement();
				$userAd->ad_user_id = $user_data->id;
				$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
				$userAd->ad_name = $request->input("ad_name");
				$userAd->ad_email = $request->input("ad_email");
				$userAd->ad_contactno = $request->input("ad_contactno");
				$userAd->ad_country = $request->input("country_name");
				$userAd->ad_location = $request->input("city_name");
				$userAd->ad_suburbs = $request->input("suburbs");
				$userAd->about_description = $request->input("about_description");
				$userAd->status = 0;
				$userAd->draft = 1;
				$userAd->step = 2;
				$userAd->parent_id = $request->input('user_ad_id') ? $request->input('user_ad_id') : $AdExist->id;
				$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
				$userAd->slug = $slug;
				if(!empty($request->session()->get('agency_id'))){
					$userAd->agency_id = $request->session()->get('agency_id');
				}
				if(!empty($request->session()->get('club_id'))){
					$userAd->club_id = $request->session()->get('club_id');
				}
				
				$userAd->save();
				
				}
				$ad_id = $userAd->id;


				$ad_step_status = AdStepsUpdate::where('ad_id', $ad_id)->first();
				if(count($ad_step_status) > 0){
					$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
					$rec->step_1 = 1;
					$rec->save();

				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $ad_id;
					$rec->step_1 = 1;
					$rec->save();
				}
			}else{
				if(!empty($user_ad_id)){
					$userAd = UserAdvertisement::findOrFail($user_ad_id);
					if((int)$userAd->parent_id > 0){
						$user_ad_id = $userAd->parent_id;
						$parent_id = $user_ad_id;
					}
			}
			//echo $user_ad_id;
			if(count($userAd) >0){

			
			$ad_id = $user_ad_id;

			$userAd = UserAdvertisement::findOrFail($ad_id);
			
			$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
			$userAd->ad_name = $request->input("ad_name");
			$userAd->ad_email = $request->input("ad_email");
			$userAd->ad_contactno = $request->input("ad_contactno");
			$userAd->ad_country = $request->input("country_name");
			$userAd->ad_location = $request->input("city_name");
			$userAd->ad_suburbs = $request->input("suburbs");

			$userAd->about_description = $request->input("about_description");
			if($userAd->ad_name != $request->input("ad_name") && (int)$parent_id==0){
			$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
			$userAd->slug = $slug;
			}
			if(!empty($request->session()->get('agency_id'))){
				$userAd->agency_id = $request->session()->get('agency_id');
			}

			if(!empty($request->session()->get('club_id'))){
				$userAd->club_id = $request->session()->get('club_id');
			}
			
			
			$userAd->save();
			

		}else{
			$userAd = new UserAdvertisement();
			$userAd->ad_user_id = $user_data->id;

			$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
			$userAd->ad_name = $request->input("ad_name");
			$userAd->ad_email = $request->input("ad_email");
			$userAd->ad_contactno = $request->input("ad_contactno");
			$userAd->ad_country = $request->input("country_name");
			$userAd->ad_location = $request->input("city_name");
			$userAd->ad_suburbs = $request->input("suburbs");
			$userAd->about_description = $request->input("about_description");
			$userAd->status = 0;
			$userAd->draft = 1;
			$userAd->step = 2;
			$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
			$userAd->slug = $slug;
			if(!empty($request->session()->get('agency_id'))){
				$userAd->agency_id = $request->session()->get('agency_id');
			}
			if(!empty($request->session()->get('club_id'))){
				$userAd->club_id = $request->session()->get('club_id');
			}
			
			$userAd->save();
			$ad_id = $userAd->id;
		}
		$neadid = !empty($ad_draft_id) ? $ad_draft_id:$ad_id;
		$ad_step_status = AdStepsUpdate::where('ad_id', $neadid)->first();
				if(count($ad_step_status) > 0){
					if ($request->input('is_draft') ==1) {
						$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
						$rec->step_1 = 1;
						$rec->save();
					}else{
						$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
						$rec->step_1 = 0;
						$rec->save();
					}
					
				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $ad_id;
					$rec->step_1 = 0;
					$rec->save();
				}
		}
		if(!empty($request->input("suburbs"))){
				$subname = $request->input("suburbs");
				$cname = $request->input("country_name");
				$cityname = $request->input("city_name");
				$suburb = Suburbs::where("suburbs_name", $subname)->where("country_id", $cname)->where("city_id", $cityname)->get();
				if(count($suburb) == 0){
					$subsobj = new Suburbs();
					$subsobj->country_id = $cname;
					$subsobj->city_id = $cityname;
					$subsobj->suburbs_name = $subname;
					$subsobj->save();
				}

			}
		$request->session()->put('user_ad_id', $ad_id);
		
		$requestData = $request->all();

		unset($requestData['ad_listing_type_id']);
		unset($requestData['ad_name']);
		unset($requestData['ad_email']);
		unset($requestData['ad_contactno']);
		unset($requestData['country_name']);
		unset($requestData['city_name']);
		unset($requestData['suburbs']);
		unset($requestData['about_description']);
		unset($requestData['_token']);
		unset($requestData['is_draft']);
		unset($requestData['savetype']);
		
		if(!empty($requestData['custom_fav_things'])){
			
			
			foreach($requestData['custom_fav_things'] as $custkey=>$fav){				
					$masterObjArray = [
						'meta_name' => 'fav_things',
						'gender' => $requestData['rdo'],
						'created_ad_id' => $ad_id,
						'is_public' => 1,
						'meta_value' => $fav['label']
					];
				// print_r($masterObjArray);
				
					$mainMaster = MainMaster::updateOrCreate([
					['meta_name', '=', 'fav_things'],
					['gender', '=', $requestData['rdo']],
					['created_ad_id', '=', $ad_id],
					['meta_value', '=', $fav['label']]
					],$masterObjArray );
					$masterid = $mainMaster->id;
				$key = "fav_things_".$masterid;
				$favValue = $fav['value'];				
				$data_array = [
					'meta_key' => $key,
					'meta_value' => $favValue,
					'ad_id'=> $ad_id
				 ];
				 
				$fetchExistData  = UserAdMeta::updateOrCreate([
					['meta_key', '=', $key],
					['ad_id', '=', $ad_id],
				], $data_array);
				
			}
		}
	

		if(!empty($requestData['custom_wish_things'])){
			foreach($requestData['custom_wish_things'] as $wishkey=>$cusw){
				$masterObjArray = [
					'meta_name' => 'wishlist-things',
					'gender' => $requestData['rdo'],
					'created_ad_id' => $ad_id,
					'is_public' => 1,
					'meta_value' => $cusw['label']
				];
			
				$mainMaster = MainMaster::updateOrCreate([
				['meta_name', '=', 'wishlist-things'],
				['gender', '=', $requestData['rdo']],
				['created_ad_id', '=', $ad_id],
				['meta_value', '=', $cusw['label']]
				],$masterObjArray );
				$wmasterid = $mainMaster->id;
				$wkey = "wish_things_".$wmasterid;
				$wishValue = $cusw['value'];
				$data_array = [
					'meta_key' => $wkey,
					'meta_value' => $wishValue,
					'ad_id'=> $ad_id
				 ];
				 
				$fetchExistData  = UserAdMeta::updateOrCreate([
					['meta_key', '=', $wkey],
					['ad_id', '=', $ad_id],
				], $data_array);
			}
		}


		

		if(!empty($requestData['disclaimer'])){
			
			
				$data_array = [
					'meta_key' => 'disclaimer',
					'meta_value' => 'yes',
					'ad_id'=> $ad_id
				 ];
				 
				$fetchExistData  = UserAdMeta::updateOrCreate([
					['meta_key', '=', 'disclaimer'],
					['ad_id', '=', $ad_id],
				], $data_array);
			
		}
		unset($requestData['custom_fav_things']);
		unset($requestData['custom_wish_things']);
		unset($requestData['disclaimer']);
		foreach($requestData as $key => $req){
			$fetchExistData  = UserAdMeta::select()->where([
				['meta_key', '=', $key],
				['ad_id', '=', $ad_id],
			]);	
			
					$fetchExistData->delete();
			
				if(is_array($requestData[$key])){
				
					foreach($req as $r){
						if(!empty($r)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = $ad_id;
						//print_r($user_ad_meta);
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));
						}
						
					}
				}else{
					
						if(!empty($req)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->ad_id = $ad_id;
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));

						}
			}

		}


		$request->session()->put('form_step', '2');
		return Response::json(array('ad_id' => $ad_id, "draft_id" => $userAd->parent_id));
		//return $ad_id;



	}


function saveOrderDetails(Request $request){
		$user_ad_id = $request->input('post_ad_id');
		$data =$request->all();

		if(!empty($user_ad_id)){
			\Request::session()->put('user_ad_id', $user_ad_id);
		}else{
			$user_ad_id = $request->session()->get('user_ad_id');
		}
		$new_plan_details = Plans::where('id', $request->input('plan_id'))->first();
		 $new_plan_duration = $new_plan_details->plan_duration;
		
		
		//$user_ad_id = $request->session()->get('user_ad_id');
		$getallPlanDuration = "select sum(plan.plan_duration) as plan_duration from tbl_order as  orders inner join tbl_plans as plan on orders.plan_id = plan.id where orders.ad_id = '".$user_ad_id."' and orders.order_status='Success' and orders.plan_expired>='".strtotime(date('Y-m-d'))."' group by orders.ad_id ";

		$dbPlan = DB::select($getallPlanDuration);

		$total_plan_duration = $new_plan_duration+$dbPlan[0]->plan_duration;
		
		if($total_plan_duration > 90){
			return Response::json(array("no_of_days_exceeded"=> 'You can not buy more than 90 days'  ));
		}else{

		$get_old_plan_id = Order::where('ad_id', $user_ad_id)->where('order_status','Success')->where('plan_expired', '>=',strtotime(date('Y-m-d')))->orderBy('id','DESC')->take(1)->first();
		
		$old_plan_details = Plans::where('id', $get_old_plan_id->plan_id)->first();
		 $old_plan_duration = $old_plan_details->plan_duration;
		 $old_plan_duration_unit = $old_plan_details->plan_duration_unit;
		 $old_plan_price = $old_plan_details->plan_price_base;
		$current_plan_id = $request->input('plan_id');
		$current_plan_details =  Plans::where('id', $current_plan_id)->first();

		$current_plan_price = $current_plan_details->plan_price_base;
		
		
		$plan_featured_price = $request->input('featured_profile_price');
		$plan_teaser_price = $request->input('teaser_video_price');
		$plan_featured_banner_price = $request->input('featured_banner_price');
		$plan_featured_banner_day = $request->input('featured_banner_day');
		$plan_teaser_video_two_day = $request->input('teaser_video_two_day');
		$plan_teaser_video_two_price = $request->input('teaser_video_two_price');
		$plan_super_speed_day = $request->input('super_speed_day');
		$plan_super_speed_price = $request->input('super_speed_price');
		/*if(!empty($old_plan_duration_unit) &&  $old_plan_duration_unit =='days'){
			$old_plan_expiry = $get_old_plan_id->plan_expired;
			$today =time(); 
			if($old_plan_expiry > $today){
				 $diffrence = calculateDayDiffrence($today, $old_plan_expiry);

			}

			$old_perday_price = round($old_plan_price / $old_plan_duration);
			$settled_amount = $old_perday_price * $diffrence;
			$new_price = $current_plan_price - $settled_amount;
			$discounted_price = round($current_plan_price - $settled_amount, 2);
		}else{
			$new_price = $current_plan_price;
			
		}
		if($new_price <= 0){
			return Response::json(array("error"=>"You can not downgrade your supscription."));
		}*/
		
		$total_amount_price = round($current_plan_price + $plan_featured_price + $plan_teaser_price + $plan_featured_banner_price +$plan_teaser_video_two_price + $plan_super_speed_price, 2);
		
		 $latest_order = Order::latest()->first();

      
		$useremail = $this->user->email;
		$details = new Order();
		$details->ad_id = $user_ad_id;
		//$details->user_id = $this->user->id;
		$details->order_status = "Pending";
		$details->plan_id = $request->input('plan_id');
		
		$details->total_amount = $total_amount_price;
		$details->featured_profile_price  = $plan_featured_price;
		$details->featured_profile_day = $request->input('featured_profile_day');
		$details->teaser_video_day = $request->input('teaser_video_day');
		$details->teaser_video_price = $plan_teaser_price;
		$details->featured_banner_price = $plan_featured_banner_price;
		$details->featured_banner_day = $plan_featured_banner_day;
		$details->teaser_video_two_day = $plan_teaser_video_two_day;
		//extra multiple days new code
		$details->featured_profile_days = $request->input('featured_profile_day');
		$details->teaser_video_days = $request->input('teaser_video_day');
		$details->featured_banner_days = $plan_featured_banner_day;
		$details->teaser_video_two_days = $plan_teaser_video_two_day;
		$details->super_speed_boost_days = $plan_super_speed_day;
		//end multiple new code
		$details->teaser_video_two_price = $plan_teaser_video_two_price;
		$details->super_speed_boost_day = $plan_super_speed_day;
		$details->super_speed_boost_price = $plan_super_speed_price;
		$details->plan_actual_price = $current_plan_price;
		//$details->plan_discounted_price = $discounted_price;
		$details->save();


 		$encrypted_order_id = Crypt::encryptString($details->id);
		//print_r($details);
		return Response::json(array("total_amount_price"=> price_format($total_amount_price), 
			"actual_plan_price"=>price_format($current_plan_price), "new_price" => !empty($new_price)?price_format($new_price):'', "order_id"=>$encrypted_order_id, "featured_profile_price"=> !empty($plan_featured_price)?price_format($plan_featured_price):'', "plan_teaser_price"=>!empty($plan_teaser_price)?price_format($plan_teaser_price):'', "plan_teaser_two_price"=>!empty($plan_teaser_video_two_price)?price_format($plan_teaser_video_two_price):'',"plan_super_speed"=>!empty($plan_super_speed_price)?price_format($plan_super_speed_price):'',"plan_featured_banner_price"=>!empty($plan_featured_banner_price)?price_format($plan_featured_banner_price):'', 'formdata'=> $html));		

		
		}

	}

	function saveOrderDetails1(Request $request){
		$user_ad_id = $request->input('post_ad_id');
		$data =$request->all();

		if(!empty($user_ad_id)){
			\Request::session()->put('user_ad_id', $user_ad_id);
		}else{
			$user_ad_id = $request->session()->get('user_ad_id');
		}
		
		//$user_ad_id = $request->session()->get('user_ad_id');
		$get_old_plan_id = Order::where('ad_id', $user_ad_id)->where('order_status','Success')->where('plan_expired', '>=',strtotime(date('Y-m-d')))->orderBy('id','DESC')->take(1)->first();
		
		$old_plan_details = Plans::where('id', $get_old_plan_id->plan_id)->first();
		 $old_plan_duration = $old_plan_details->plan_duration;
		 $old_plan_duration_unit = $old_plan_details->plan_duration_unit;
		 $old_plan_price = $old_plan_details->plan_price_base;
		$current_plan_id = $request->input('plan_id');
		$current_plan_details =  Plans::where('id', $current_plan_id)->first();

		$current_plan_price = $current_plan_details->plan_price_base;
		
		
		$plan_featured_price = $request->input('featured_profile_price');
		$plan_teaser_price = $request->input('teaser_video_price');
		$plan_featured_banner_price = $request->input('featured_banner_price');
		$plan_featured_banner_day = $request->input('featured_banner_day');
		$plan_teaser_video_two_day = $request->input('teaser_video_two_day');
		$plan_teaser_video_two_price = $request->input('teaser_video_two_price');
		$plan_super_speed_day = $request->input('super_speed_day');
		$plan_super_speed_price = $request->input('super_speed_price');
		/*if(!empty($old_plan_duration_unit) &&  $old_plan_duration_unit =='days'){
			$old_plan_expiry = $get_old_plan_id->plan_expired;
			$today =time(); 
			if($old_plan_expiry > $today){
				 $diffrence = calculateDayDiffrence($today, $old_plan_expiry);

			}

			$old_perday_price = round($old_plan_price / $old_plan_duration);
			$settled_amount = $old_perday_price * $diffrence;
			$new_price = $current_plan_price - $settled_amount;
			$discounted_price = round($current_plan_price - $settled_amount, 2);
		}else{
			$new_price = $current_plan_price;
			
		}
		if($new_price <= 0){
			return Response::json(array("error"=>"You can not downgrade your supscription."));
		}*/
		
		$total_amount_price = round($current_plan_price + $plan_featured_price + $plan_teaser_price + $plan_featured_banner_price +$plan_teaser_video_two_price + $plan_super_speed_price, 2);
		
		 $latest_order = Order::latest()->first();

      //   if (!$latest_order) {
      //       $invoice_no =  'HOSG-000000001';
      //   }else{
      //   $order_id = preg_replace("/[^0-9\.]/", '', $latest_order->id);
      //   $invoice_no = 'HOSG'.'-'. sprintf('%09d', $order_id+1);
      // }
         //print_r($invoice_no);
        //die('');
		

		//print_r($details);
		return Response::json(array("total_amount_price"=> price_format($total_amount_price), 
			"actual_plan_price"=>price_format($current_plan_price), "new_price" => !empty($new_price)?price_format($new_price):'',  "featured_profile_price"=> !empty($plan_featured_price)?price_format($plan_featured_price):'', "plan_teaser_price"=>!empty($plan_teaser_price)?price_format($plan_teaser_price):'', "plan_teaser_two_price"=>!empty($plan_teaser_video_two_price)?price_format($plan_teaser_video_two_price):'',"plan_super_speed"=>!empty($plan_super_speed_price)?price_format($plan_super_speed_price):'',"plan_featured_banner_price"=>!empty($plan_featured_banner_price)?price_format($plan_featured_banner_price):'', 'formdata'=> $html));		

		
		

	}


	
	function redirectToPayment(Request $request){

			$data = $request->all(); 

			$dcrypted_order_id = Crypt::decryptString($data['token']);
		  $orderDetail = Order::where('id', $dcrypted_order_id)->first();


		   $general_setting = generalSettings();
		  $currencyCode = $general_setting['selected_payment_currency'];
		  if(count($orderDetail) > 0){
		  $html = '<form action="'.route('paypax').'" method="post" id="paxpay_form">';
		  $html .= '<input name="Quantity" value="1" type="hidden"/>';
		  $html .= '<input name="Reference"  value="ref" type="hidden"/>';
		  $html .= '<input name="_token"  value="'.csrf_token().'" type="hidden"/>';
		  $html .= '<input name="Address1"  value="'.$orderDetail->id.'" type="hidden"/>';
		  $html .= '<input name="Address2"  value="'. $this->user->id.'" type="hidden"/>';
		  $html .= '<input name="Address3" value="" type="hidden"/>';
		  $html .= '<input name="Price" value="'.$orderDetail->total_amount.'" type="hidden"/>';
		  $html .= '<input name="CurrencyCode" value="'.$currencyCode.'" type="hidden"/>';
		  //$html .= '<input name="Userid" value="'.$this->user->id.'" type="hidden"/>';
		  $html .= '<input name="EmailAddress" value="'.$this->user->email.'" type="hidden"/>';
		  $html .= '<input type="hidden" name="ForcePaymentMethod" value="Account2Account">';
		  $html .= '<input name="returnURL" value="'.route('paypaxsuccess').'" type="hidden"/>'	;
		   $html .= '</form>';
		  $data['html'] = $html;

		 
		  return view('frontend.paypax.payment_form', $data);
		}


		  
	}

	function saveIndividualServices(Request $request){
	if($request->input('savetype') != 'autosave'){
	 $validator = Validator::make( $request->all(),  [
               
                "service-avail-for" => 'required',
                "service-type" =>'required',
                'service_name.*'=>'required|array',
                 "service_time.*" => 'required|array',
                'service-available.*' => 'required|array'
               
                
            ],[
                "service-avail-for.required" => "Please choose atleast one option.",
                "service-type.required" => "Please choose service type.",
                'service_name.required'=>'Please Choose Service Name',
                "service_time.required" => "Please choose service time.",
                "service-available.required" => "Please choose atleast one service."
               
            ]);
	if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			   
		}
}
		$questdata = $request->all();

		

		

		
		 $user_ad_id = !empty($questdata['user_ad_id']) ? $questdata['user_ad_id'] : $request->session()->get('user_ad_id');
		 if(!empty($user_ad_id)){
			$AdExist = UserAdvertisement::findOrFail($user_ad_id);
			
		}
		if($AdExist->parent_id == 0){
			
			$getParentAd = 	UserAdvertisement::where('parent_id', $user_ad_id)->first();
			$ad_draft_id = $getParentAd->id;

		}else{
				$ad_draft_id = $AdExist->id;
		}
		if($AdExist->status == 1 && $request->input('is_draft') ==1){ 
			if (!empty($ad_draft_id)) {
				$user_ad_id = $ad_draft_id;
			}else{
				$userAd = new UserAdvertisement();
				$userAd->ad_user_id = $AdExist->ad_user_id;
				$userAd->ad_listing_type_id = $AdExist->ad_listing_type_id;
				$userAd->ad_name = $AdExist->ad_name;
				$userAd->ad_email = $AdExist->ad_email;
				$userAd->ad_contactno = $AdExist->ad_contactno;
				$userAd->ad_country = $AdExist->ad_country;
				$userAd->ad_location = $AdExist->ad_location;
				$userAd->ad_suburbs = $AdExist->ad_suburbs;
				$userAd->about_description = $AdExist->about_description;
				$userAd->status = 0;
				$userAd->draft = 1;
				$userAd->step = 3;
				$userAd->parent_id = $AdExist->id;
				$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
				$userAd->slug = $slug;
				if(!empty($request->session()->get('agency_id'))){
					$userAd->agency_id = $request->session()->get('agency_id');
				}
				if(!empty($request->session()->get('club_id'))){
					$userAd->club_id = $request->session()->get('club_id');
				}
				
				$userAd->save();
				$user_ad_id = $userAd->id;
				}
			
		}else{

			if((int)$AdExist->parent_id > 0){
				$user_ad_id = $AdExist->parent_id;
			}
		}
		unset($questdata['_token']);
		$serviceData = AdRate::select()->where('ad_id', $user_ad_id);
		$serviceData->delete();
		
		DB::connection()->enableQueryLog();
		
		foreach($questdata['service'] as $serv){
			if(!empty($serv['service_incall_charge']) && 
				!empty($serv['service_outcall_charge'])){
				$service_rates_obj = new AdRate();
				$service_rates_obj->ad_id = $user_ad_id;
				$service_rates_obj->ad_time = $serv['service_time'];
				$service_rates_obj->incall_charge = $serv['service_incall_charge'];
				$service_rates_obj->outcall_charge = $serv['service_outcall_charge'];
				$service_rates_obj->ad_services = $serv['service_name'];
				$service_rates_obj->save();
			}
			
		}

		unset($questdata['service']);
		
		$request->session()->put('form_step', '4');
		$extraServiceData = AdExtraServices::select()->where('ad_id', $user_ad_id);
		$extraServiceData->delete();
		
		foreach($questdata['extra_services'] as $serv){
			if(!empty($serv['price'])){
			$extra_services_obj = new AdExtraServices();
			$extra_services_obj->ad_id = $user_ad_id;
			$extra_services_obj->ad_fee = $serv['price'];
			$extra_services_obj->ad_services = $serv['service_name'];
			$extra_services_obj->save();
			}
		}

		unset($questdata['extra_services']);
	
		$tourData = AdsTouring::select()->where('ad_id', $user_ad_id);
		$tourData->delete();
		$updatedates = array();
		echo "<script>console.log('".print_r($questdata['old_tour'])."')</script>";
		if(!empty($questdata['old_tour']) && !empty($questdata['new_tour'])){
			$localTourData = array_merge($questdata['old_tour'], $questdata['new_tour']);
		}elseif(!empty($questdata['old_tour']) && empty($questdata['new_tour'])){
			$localTourData = $questdata['old_tour'];
		}else{
			$localTourData = $questdata['new_tour'];
		}
		
		
		foreach($localTourData as $tour){
			
			if(!empty($tour['city']) && !empty($tour['country']) && !empty($tour['startdate']) && !empty($tour['enddate'])){
				
			/*$start_tour_date = strtotime(str_replace("/","-",$tour['startdate']));
			$end_tour_date = strtotime(str_replace("/","-",$tour['enddate']));
			$rec = AdsTouring::where('from_date', $start_tour_date)->where('to_date', $end_tour_date)->where('ad_id', $user_ad_id)->where('country_id', getDefaultCountry())->first();
			if(count($rec) > 0){
				$adtour_obj = AdsTouring::findOrFail($rec->id);
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->save();
			}else{*/
				/*$trange = explode(" - ",$tour['startdate']);
				$tstart = $trange[0];
				$tend = $trange[1];*/
				
				DB::connection()->enableQueryLog();
				$queries = DB::getQueryLog();
				$adtour_obj = new AdsTouring();
				$adtour_obj->ad_id = $user_ad_id;
				$adtour_obj->from_date = strtotime(str_replace("/","-",$tour['startdate']));
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->to_date = strtotime(str_replace("/","-",$tour['enddate']));
				$adtour_obj->save();
				//$updatedates[] = $tour['stratdate'];
				$last_query = end($queries);

			/*}*/
			
			}

		}
		
		if(!empty($questdata['old_inter_tour']) && !empty($questdata['new_inter_tour'])){
			$interTourData = array_merge($questdata['old_inter_tour'], $questdata['new_inter_tour']);
		}elseif(!empty($questdata['old_inter_tour']) && empty($questdata['new_inter_tour'])){
			$interTourData = $questdata['old_inter_tour'];
		}else{
			$interTourData = $questdata['new_inter_tour'];
		}
	
		
		foreach($interTourData as $tour){
			
			if(!empty($tour['city']) && !empty($tour['country']) && !empty($tour['startdate']) && !empty($tour['enddate'])){

			/*$start_tour_date = strtotime(str_replace("/","-",$tour['startdate']));
			$end_tour_date = strtotime(str_replace("/","-",$tour['enddate']));
			DB::connection()->enableQueryLog();

			$rec = AdsTouring::where('from_date', $start_tour_date)->where('to_date', $end_tour_date)->where('ad_id', $user_ad_id)->where('country_id','!=', getDefaultCountry())->first();
			
			
			
			if(count($rec) > 0){
				
				$adtour_obj = AdsTouring::findOrFail($rec->id);
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->save();
			}else{
				*/
				$adtour_obj = new AdsTouring();
				$adtour_obj->ad_id = $user_ad_id;
				$adtour_obj->from_date = strtotime(str_replace("/","-",$tour['startdate']));
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->to_date = strtotime(str_replace("/","-",$tour['enddate']));
				$adtour_obj->save();
				//$updatedates[] = $tour['stratdate'];
			//}
			
			}

		}

		$userData = UserAdvertisement::where('id', $user_ad_id)->first();
		if((count($questdata['new_tour']) > 0 && !empty($adtour_obj->id))|| (count($questdata['new_inter_tour']) > 0 && !empty($adtour_obj->id))){
			
			$ss = getSubscribeForByid('touring');
			$subscribers = getAdSubscriber($user_ad_id, $ss);
			
			if(count($subscribers) > 0){
				foreach($subscribers as $sb){
				$email_content_sub = array();
				$email_content_sub["user_name"] = !empty($sb->subs_name) ? $sb->subs_name : $sb->subs_email;
				$profile_url = url('profile/'.$userData->slug);
				$email_content_sub["content"] =$userData->ad_name.' has updated touring details.';
				$email_content_sub["view_profile_link"] = "View <a href=".$profile_url.">profile</a> for more details.";
				$email_message_admin = new EmailMessage();
					//$admin_notification_email = 'sushma@vocso.com';
				$email_message_admin->singleMailSendIntegration( $sb->subs_email,'AdNotification', $email_content_sub );
				}
				
			}
		}
		unset($questdata['tour']);
		unset($questdata['user_ad_id']);
		unset($questdata['old_tour']);
		unset($questdata['old_inter_tour']);

		if(count($questdata['working_hours']) > 0){
			foreach($questdata['working_hours'] as $d){
				$working_date = $d['working_date'];
				$working_start_time = strtotime($d['working_start_time']);
				$working_end_time = strtotime($d['working_end_time']);
				$real_working_start_time = strtotime($working_date.' '.$d['working_start_time']);
				$real_working_end_time = strtotime($working_date.' '.$d['working_end_time']);
				$dayoff = $d['working_dayoff'];
				if(!empty($working_start_time) && !empty($working_end_time) || $dayoff=='on'){
				$working_hours = AdWorkingHours::where('ad_id', $user_ad_id)->where('working_date', $working_date)->first();

				if(count($working_hours) > 0){
					$working = AdWorkingHours::findOrFail($working_hours->id);
					if($dayoff == 'on'){
			          $working->working_start_time = NULL;
			          $working->working_end_time = NULL;
			          $working->dayoff = 'yes';
			          $working->save();
			        }else{
			          $working->working_start_time = $real_working_start_time;
			          $working->working_end_time = $real_working_end_time;
			          $working->dayoff = NULL;
			          $working->save();
			        }
				}else{
			        $working =new AdWorkingHours();
			        if($dayoff == 'on'){
				          $working->ad_id = $user_ad_id;
				          $working->working_date = $working_date;
				          $working->working_start_time = NULL;
				          $working->working_end_time = NULL;
				          $working->dayoff = 'yes';
				          $working->save();
			        }else{
				        $working->ad_id = $user_ad_id;
				        $working->working_date = $working_date;
				        $working->working_start_time = $real_working_start_time;
				        $working->working_end_time = $real_working_end_time;
				        $working->dayoff = NULL;
				        $working->save();
			        }
			      }
			  }

			}
		}
		unset($questdata['working_hours']);
				if(!empty($questdata['run_specials'])){

		$checkMeta = UserAdMeta::where('meta_key','run_specials')->where('ad_id', $user_ad_id)->first();
		
		if(count($checkMeta) > 0){
			if($checkMeta->meta_value !== $questdata['run_specials']){
				$ss = getSubscribeForByid('special_rates');
				$subscribers = getAdSubscriber($user_ad_id, $ss);
				
				if(count($subscribers) > 0){
					foreach($subscribers as $sb){
					$email_content_sub = array();
					$email_content_sub["user_name"] = !empty($sb->subs_name) ? $sb->subs_name : $sb->subs_email;
					$profile_url = url('profile/'.$userData->slug);
					$email_content_sub["content"] =$userData->ad_name.' has updated specials.';
					$email_content_sub["view_profile_link"] = "View <a href=".$profile_url.">profile</a> for more details.";
					$email_message_admin = new EmailMessage();
					$admin_notification_email= $this->generalSettings['admin_notification_email'];
					//$admin_notification_email = 'sushma@vocso.com';
					$email_message_admin->singleMailSendIntegration($sb->subs_email,'AdNotification', $email_content_sub );
					}
					
				}
			}
		}
		
		
		}

		foreach($questdata as $key => $req){
			
			
				
				if(is_array($questdata[$key])){

					$fetchExistData  = UserAdMeta::select()->where([
						['meta_key', '=', $key],
						['ad_id', '=', $user_ad_id],
					]);
								if(count($fetchExistData) > 0){
									$fetchExistData->delete();
								}
					
					
					foreach($questdata[$key] as $r){
						if(!empty($r)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = $user_ad_id;
						$user_ad_meta->save();
						}
					}
				}else{
					
					

						
						if(!empty($req)){
						
						$data_array = array(
							"meta_key" => $key,
							"meta_value" => $req,
							"ad_id" =>$user_ad_id
						);

						$user_ad_meta = UserAdMeta::updateOrCreate([
							['meta_key', '=', $key],
							['ad_id', '=', $user_ad_id],
						], $data_array);

						//$user_ad_meta->meta_key = $key;
						//$user_ad_meta->meta_value = $req;
						//$user_ad_meta->ad_id = $user_ad_id;
						//$user_ad_meta->save();
						}
					
				}

			
				
		
		}

		



		if($AdExist->status == 1 && $request->input('is_draft') ==1){ 
		$ad_step_status = AdStepsUpdate::where('ad_id', $user_ad_id)->first();
				if(count($ad_step_status) > 0){
					$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
					$rec->step_3 = 1;
					$rec->save();
				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $user_ad_id;
					$rec->step_3 = 1;
					$rec->save();
				}
			}else{
				 $neadid = !empty($ad_draft_id) ? $ad_draft_id:$user_ad_id;
				$ad_step_status = AdStepsUpdate::where('ad_id', $neadid)->first();
				if(count($ad_step_status) > 0){
					if ($request->input('is_draft') ==1) {
						$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
						$rec->step_3 = 1;
						$rec->save();
					}else{
						$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
						$rec->step_3 = 0;
						$rec->save();
					}
					
				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $neadid;
					$rec->step_3 = 0;
					$rec->save();
				}

			}



	}
	function saveSecondStep(Request $request){
		$request->session()->put('form_step', '3');
	}

	function saveIndividualImages(Request $request){
		
		$request->session()->forget('form_step');
		$data = $request->all();

		/*var_dump($data);
		exit;*/
		
		$images  = $data['imageurl'];
		$newImages = $data['new_imageurl'];
		$videos = $data['videourl'];
		$teaservideo = $data['teaservideourl'];
		$dedicatedvideourl = $data['dedicatedvideourl'];

		$old_images = $data['old_imageurl'];
		$old_videos = $data['vold_ideourl'];
		$old_teaservideo = $data['old_teaservideourl'];
		$old_dedicatedvideo = $data['old_dedicatedvideourl'];		

		$user_ad_id = !empty($data['user_ad_id']) ? $data['user_ad_id'] : $request->session()->get('user_ad_id');
		if(!empty($user_ad_id)){
			$AdExist = UserAdvertisement::findOrFail($user_ad_id);
			
		}
		if($AdExist->parent_id == 0){
			
			$getParentAd = 	UserAdvertisement::where('parent_id', $user_ad_id)->first();
			$ad_draft_id = $getParentAd->id;

		}else{
				  $ad_draft_id = $AdExist->id;
		}
		if($AdExist->status == 1 && $request->input('is_draft') ==1){ 
			if (!empty($ad_draft_id)) {
				$user_ad_id = $ad_draft_id;
			}else{
				$userAd = new UserAdvertisement();
				$userAd->ad_user_id = $AdExist->ad_user_id;
				$userAd->ad_listing_type_id = $AdExist->ad_listing_type_id;
				$userAd->ad_name = $AdExist->ad_name;
				$userAd->ad_email = $AdExist->ad_email;
				$userAd->ad_contactno = $AdExist->ad_contactno;
				$userAd->ad_country = $AdExist->ad_country;
				$userAd->ad_location = $AdExist->ad_location;
				$userAd->ad_suburbs = $AdExist->ad_suburbs;
				$userAd->about_description = $AdExist->about_description;
				$userAd->status = 0;
				$userAd->draft = 1;
				$userAd->step = 4;
				$userAd->parent_id = $AdExist->id;
				$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
				$userAd->slug = $slug;
				if(!empty($request->session()->get('agency_id'))){
					$userAd->agency_id = $request->session()->get('agency_id');
				}
				if(!empty($request->session()->get('club_id'))){
					$userAd->club_id = $request->session()->get('club_id');
				}
				
				$userAd->save();
				$user_ad_id = $userAd->id;
				}
				
		}else{

			if((int)$AdExist->parent_id > 0){
				$user_ad_id = $AdExist->parent_id;
			}
		}
		$userData = UserAdvertisement::findOrFail($user_ad_id);
		
		/*if(check_verification_video_status($user_ad_id) > 0){
			if($userData->parent_id == 0){

				$userData->status = 1;
				$userData->draft = 0;
			}
			
		}else{
			$userData->status = $userData->status == 1 ? 1 :0;
			$userData->draft = $userData->status == 1 ? 0 : 1;
		}*/

		if($userData['plan_id'] > 0 && check_verification_video_status($user_ad_id) > 0){
			$userData->status = 1;
			$userData->draft = 0;
		}
		
		$userData->step = 4;
		$userData->save();

		if(!empty(is_agency(\Request::session('agency_id')))){
			$escort_from = AgencyDetails::where('user_id', Auth::user()->id)->first()->name;
		}
		if(!empty(is_club(\Request::session('club_id')))){
			$escort_from = ClubDetails::where('user_id', Auth::user()->id)->first()->name;
			
		}

		$username = UserAdvertisement::where('id', $user_ad_id)->first()->ad_name;
		$country_id = UserAdvertisement::where('id', $user_ad_id)->first()->ad_country;
		$location = getCountry($country_id);
		$image_thumb_width =  $this->generalSettings['ad_image_thumb_width'];
		$image_thumb_height =  $this->generalSettings['ad_image_thumb_height'];
		$image_large_width = $this->generalSettings['ad_image_large_width'];
		$image_large_height = $this->generalSettings['ad_image_large_height'];
		$watermark_image = $this->generalSettings['watermark_image'];
		$watermark_position = $this->generalSettings['watermark_image_position'];
		if(count($images) > 0){
		/*$imagesExists = Image::where('media_ad_id', $user_ad_id)
		->where("media_type", "Images");
		*/
			//if(count($imagesExists) > 0){
			//$imagesExists->delete();
			//}
		

		$user_folder = md5(Auth::user()->id);
		$folder_path = public_path('upload/ads_image/'.$user_folder);
   
	    if(!File::isDirectory($folder_path)){
	        File::makeDirectory($folder_path, 0777, true, true);
	    }
		foreach($images as $keys=>$img){
			$image_name = $img['image'];
			if(!empty($image_name)){
			$pathinfo = pathinfo($img['image']);
			$filename =  $pathinfo['filename'].'.'.$pathinfo['extension'];
			
			//echo 'python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position.','.$user_folder.' 2>&1';

			$path = exec('python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position.','.$user_folder.' 2>&1', $out);	
			//print_r($out);

			$imageObj = new Image();
			$imageObj->media_filename = $filename;
			if(!empty($img['img_is_add_default'])){
				$update = DB::table('ad_media')->where('media_ad_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

				$imageObj->media_is_default = 1;
			}else{
				if($keys == 0){
					$update = DB::table('a_media')->where('media_ad_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

					$imageObj->media_is_default = 1;
				}
			}


			$imageObj->media_type = "Images"; 
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->media_status = "Verified";
			$imageObj->save();
			// $imagesa = array(

			// 	$filename,$filename."_508*762.jpg",$filename."_252*384.jpg",$filename."_202*182.jpg",$filename."_377*625.jpg",$filename."_982*560.jpg"
			// );
			// foreach($imagesa as $im){
				
			// 		@unlink(public_path('uploads/ads_image/'.$im));
			// 		}
		}
		}

// extra

		if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){

			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id, 'activity_message'=>"$username of $escort_from posted new photos.","type"=>"images","created_at" => date("Y-m-d h:i:s"),"updated_at"=> date("Y-m-d h:i:s")]);
		}else{
		
		DB::table('activity_log')->insert(
			['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id,'activity_message'=>" $username posted new photos.","type"=>"images","created_at" => date("Y-m-d h:i:s"),"updated_at"=>date("Y-m-d h:i:s")]);
		}
		//end extra



		$live_data['user_lattitude'] = $_COOKIE['user_latitude'];
		$live_data['user_longitude'] = $_COOKIE['user_longitude'];
		$live_data['action'] = 'updateactivity';
		//sendRequesToServer($live_data);
		$ss = getSubscribeForByid('photos');
		$subscribers = getAdSubscriber($user_ad_id, $ss);
		
		if(count($subscribers) > 0){
			foreach($subscribers as $sb){
			$email_content_sub = array();
			$email_content_sub["user_name"] = !empty($sb->subs_name) ? $sb->subs_name : $sb->subs_email;
			$profile_url = url('profile/'.$userData->slug);
			$email_content_sub["content"] =$userData->ad_name.' has posted new photos.';
			$email_content_sub["view_profile_link"] = "View <a href=".$profile_url.">Profile</a>";
			$email_message_admin = new EmailMessage();
			$admin_notification_email= $this->generalSettings['admin_notification_email'];
			//$admin_notification_email = 'sushma@vocso.com';
			$email_message_admin->singleMailSendIntegration( $sb->subs_email,'AdNotification', $email_content_sub );
			}
			
		}
			
	}

	//old img
if(count($old_images) > 0){
		$user_folder = md5(Auth::user()->id);
		$folder_path = public_path('upload/ads_image/'.$user_folder);
		foreach($old_images as $keys=>$img){
			//$newImgsfT = str_replace(".", 's3.', $img);
			if($newImages[$keys] != $img){
				$newImgsf = url('/uploads/ads_image/'.$user_folder.'/'.$img);
				var_dump($newImgsf);
				$pathinfo = pathinfo($newImgsf);
				$filename =  $pathinfo['filename'].'.'.$pathinfo['extension'];
				$path = exec('python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position.','.$user_folder.' 2>&1', $out);
			}
			

			$imagesExists = DB::table('ad_media')->where('media_ad_id', $user_ad_id)
							->where("media_type", "Images")->where('media_filename',$img)->get();
		
			if(count($imagesExists) == 0){

			$imageObj = new Image();
			$imageObj->media_filename = $img;
			$imageObj->media_type = "Images"; 
			$imageObj->media_status = "Verified";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
			}
		}
		}
	//end old imgs
	
		if(count($videos) > 0){
	
		foreach($videos as $vid){
			if(!empty($vid)){
			$imageObj = new Image();
			$imageObj->media_filename = $vid;
			$imageObj->media_type = "Videos";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->media_storage = 'Cloudflare';

			$imageObj->save();
		}
	}

	if(count($old_videos) > 0){
		foreach($old_videos as $vid){

			$videosExists = DB::table('ad_media')->where('media_ad_id', $user_ad_id)
							->where("media_type", "Videos")->where('media_filename',$vid)->get();
		
			if(count($videosExists) == 0){

			$imageObj = new Image();
			$imageObj->media_filename = $vid;
			$imageObj->media_type = "Videos"; 
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
			}
		}
}

	


		if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){
			
			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id, 'activity_message'=>"New video posted by $username from $escort_from","type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> date("Y-m-d h:i:s")]);
		}else{
		
		DB::table('activity_log')->insert(

			['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id,'activity_message'=>"New video posted by $username", "type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}


		// DB::table('activity_log')->insert(
		// 	['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id,'activity_message'=>" Checkout $username's video on her profile.", "type"=>"videos"]
		// );
		$live_data['user_lattitude'] = $_COOKIE['user_latitude'];
		$live_data['user_longitude'] = $_COOKIE['user_longitude'];
		$live_data['action'] = 'updateactivity';
		//sendRequesToServer($live_data);
		$ss = getSubscribeForByid('videos');
		$subscribers = getAdSubscriber($user_ad_id, $ss);
		
		if(count($subscribers) > 0){
			foreach($subscribers as $sb){
			$email_content_sub = array();
			$email_content_sub["user_name"] = !empty($sb->subs_name) ? $sb->subs_name : $sb->subs_email;
			$profile_url = url('profile/'.$userData->slug);
			$email_content_sub["content"] =$userData->ad_name.' has posted new videos.';
			$email_content_sub["view_profile_link"] ="View <a href=".$profile_url.">Profile</a>";
			$email_message_admin = new EmailMessage();
			$admin_notification_email= $this->generalSettings['admin_notification_email'];
			//$admin_notification_email = 'sushma@vocso.com';
			$email_message_admin->singleMailSendIntegration($sb->subs_email,'AdNotification', $email_content_sub );
			}
			
		}
		
	}
		if(count($teaservideo) > 0){
		
		foreach($teaservideo as $tvid){

			if(!empty($tvid)){
			$imageObj = new Image();
			$imageObj->media_filename = $tvid;
			$imageObj->media_type = "Teaser Video";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->media_storage = 'Cloudflare';
			$imageObj->save();
		}
		}
	}

	if(count($old_teaservideo) > 0){
		foreach($old_teaservideo as $tvid){

			$videosExists = DB::table('ad_media')->where('media_ad_id', $user_ad_id)
							->where("media_type", "Teaser Video")->where('media_filename',$tvid)->get();
		
			if(count($videosExists) == 0){

			$imageObj = new Image();
			$imageObj->media_filename = $tvid;
			$imageObj->media_type = "Teaser Video"; 
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
			}
		}
}

if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){
			
			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id, 'activity_message'=>"New teaser video posted by $username from $escort_from","type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}else{
		
		DB::table('activity_log')->insert(

			['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id,'activity_message'=>"New teaser video posted by $username", "type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}


	if(count($dedicatedvideourl) > 0){

		foreach($dedicatedvideourl as $dvid){
			if(!empty($dvid)){
			$imageObj = new Image();
			$imageObj->media_filename = $dvid;
			$imageObj->media_type = "Dedicated Video";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->media_storage = 'Cloudflare';
			$imageObj->save();
		}
	}
	}

if(count($old_dedicatedvideo) > 0){
		foreach($old_dedicatedvideo as $dvid){

			$videosExists = DB::table('ad_media')->where('media_ad_id', $user_ad_id)
							->where("media_type", "Dedicated Video")->where('media_filename',$dvid)->get();
		
			if(count($videosExists) == 0){

			$imageObj = new Image();
			$imageObj->media_filename = $dvid;
			$imageObj->media_type = "Dedicated Video"; 
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
			}
		}
}

if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){
			
			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id, 'activity_message'=>"New video posted by $username from $escort_from","type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}else{
		
		DB::table('activity_log')->insert(

			['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id,'activity_message'=>"New  video posted by $username", "type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}


	if(!empty($requestData['photo_disclaimer'])){
			
			
				$data_array = [
					'meta_key' => 'photo_disclaimer',
					'meta_value' => 'yes',
					'ad_id'=> $user_ad_id
				 ];
				 
				$fetchExistData  = UserAdMeta::updateOrCreate([
					['meta_key', '=', 'photo_disclaimer'],
					['ad_id', '=', $user_ad_id],
				], $data_array);
			
		}
			if($userData->mail_sent == 0){
				//update activity tab
		if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){

			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id, 'activity_message'=>"$username of $escort_from from $location  is now on HouseofSexyGirls","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}else{
		
				DB::table('activity_log')->insert(
			['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id,'activity_message'=>"  $username from $location is now on HouseofSexyGirls","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
			}	


		$live_data['user_lattitude'] = $_COOKIE['user_latitude'];
		$live_data['user_longitude'] = $_COOKIE['user_longitude'];
		$live_data['action'] = 'updateactivity';
		//sendRequesToServer($live_data);


			$email_content_admin = array();
			$email_content_admin["user_name"] = 'Admin';
			$email_content_admin["ad_name"] =$userData->ad_name;
			$listing_name = listingtype($userData->ad_listing_type_id);
		
			$email_content_admin["listing_type"] =$listing_name[$userData->ad_listing_type_id]['title'];
			$email_content_admin["verify_link"] = '<a href="'.url('/admin/posts/'.$listing_name[$userData->ad_listing_type_id]['slug']).'" target="_blank">Click Here</a>';
			$email_message_admin = new EmailMessage();
			$admin_notification_email= $this->generalSettings['admin_notification_email'];
			//$admin_notification_email = 'sushma@vocso.com';
			$email_message_admin->singleMailSendIntegration( $admin_notification_email, "NewAdPostAdded", $email_content_admin );
			$newUserData = UserAdvertisement::findOrFail($userData->id);
			$newUserData->mail_sent = 1;
			$newUserData->save();
			}
			
		if($AdExist->status == 1 && $request->input('is_draft') ==1){ 
		$ad_step_status = AdStepsUpdate::where('ad_id', $user_ad_id)->first();
				if(count($ad_step_status) > 0){
					$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
					$rec->step_4 = 1;
					$rec->save();
				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $user_ad_id;
					$rec->step_4 = 1;
					$rec->save();
				}
			}else{
				 $neadid = !empty($ad_draft_id) ? $ad_draft_id:$user_ad_id;
				$ad_step_status = AdStepsUpdate::where('ad_id', $neadid)->first();
				if(count($ad_step_status) > 0){
					if ($request->input('is_draft') ==1) {
						$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
						$rec->step_4 = 1;
						$rec->save();
					}else{
						$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
						$rec->step_4 = 0;
						$rec->save();
					}
					
				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $neadid;
					$rec->step_4 = 0;
					$rec->save();
				}

			}
		
			if(!empty(check_verification_video($user_ad_id)) && empty($data['update'])){
				$request->session()->forget('user_ad_id');
			}

			
		return $username;
	}

	
	//......end of individualad....
	

	function savePhotographerDetails(Request $request){
$validator = Validator::make( $request->all(),  [
                "ad_name" => 'required|min:3',
                "ad_email" =>'required',
                "ad_contactno" => 'required',
                'country_name' => 'required',
                'city_name' => 'required',
                'suburbs' => 'required',
                'booking_method' => 'required',
                'about_description' => 'required',
                'tagline' => 'max:50',
                'rate' =>'required',
               
                
            ],[
                "ad_name.required" => "Please enter your name.",
                "ad_name.min" => "Your name must be atleast 3 character long.",
                "ad_email.required" => "Please enter your  email.",
                "ad_contactno.required" => "Please enter phone number.",
                'rate.required' => 'Please enter your rate',
                "country_name.required" => "Please choose your country.",
                "city_name.required" => "Please choose your city name.",
                "suburbs.required" => "Please enter your Suburbs/Local area.",             
                "booking_method.required" => "Please choose booking method.",
                
                'about_description.required' => 'Please write  about yourself.',
                'disclaimer.required' => 'Please accept disclaimer',
                'tagline.max' => 'Tagline should not be  greater than 50 character.'
   
            ]);

	if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			   
		}

		$images  = $request->input('imageurl');
		$videos = $request->input('videourl');
		$banners = $request->input('banner');

		$old_images  = $request->input('old_imageurl');
		$old_videos = $request->input('vold_ideourl');
		$old_banners = $request->input('old_bannerurl');

		$user_data = Auth::user();

		$username = $request->input('ad_name');
		$country_id = $request->input('country_name');
		$location = getCountry($country_id);

		if(!empty(is_agency(\Request::session('agency_id')))){
			$escort_from = AgencyDetails::where('user_id', Auth::user()->id)->first()->name;
		}
		if(!empty(is_club(\Request::session('club_id')))){
			$escort_from = ClubDetails::where('user_id', Auth::user()->id)->first()->name;
			
		}
		//NEW DATA 
		if(empty($request->input("ad_listing_type_id"))){

			return;
		}
		$listingExistOrNot = listingtype($request->input("ad_listing_type_id"));
		if(count($listingExistOrNot) == 0){
			return;
		}
		if(!empty($request->input('user_ad_id'))){
		$user_ad_id = $request->input('user_ad_id');
		}else{
		$user_ad_id = $request->session()->get('user_ad_id');	
		}

		if(!empty($user_ad_id)){
			$AdExist = UserAdvertisement::findOrFail($user_ad_id);

			if($AdExist->ad_listing_type_id != $request->input("ad_listing_type_id")){
				$user_ad_id = "";
			}
		}
		if((int)$AdExist->parent_id == 0){
			
			$getParentAd = 	UserAdvertisement::where('parent_id', $user_ad_id)->first();
			$ad_draft_id = $getParentAd->id;

		}else{
			
			$ad_draft_id = $AdExist->id;
		}

		if($AdExist->status == 1 && $request->input('is_draft') ==1){
				
				if ((int)$ad_draft_id > 0) {
					$userAd = UserAdvertisement::findOrFail($ad_draft_id);
			
					$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
					$userAd->ad_name = $request->input("ad_name");
					$userAd->ad_email = $request->input("ad_email");
					$userAd->ad_contactno = $request->input("ad_contactno");
					$userAd->ad_country = $request->input("country_name");
					$userAd->ad_location = $request->input("city_name");
					$userAd->ad_suburbs = $request->input("suburbs");
					$userAd->draft = 0;
					//$userAd->parent_id = $user_ad_id;
					$userAd->about_description = $request->input("about_description");
					if($userAd->ad_name != $request->input("ad_name")){
					$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
					$userAd->slug = $slug;
					}
					if(!empty($request->session()->get('agency_id'))){
						$userAd->agency_id = $request->session()->get('agency_id');
					}

					if(!empty($request->session()->get('club_id'))){
						$userAd->club_id = $request->session()->get('club_id');
					}
					
					
					$userAd->save();
				}else{
				$userAd = new UserAdvertisement();
				$userAd->ad_user_id = $user_data->id;
				$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
				$userAd->ad_name = $request->input("ad_name");
				$userAd->ad_email = $request->input("ad_email");
				$userAd->ad_contactno = $request->input("ad_contactno");
				$userAd->ad_country = $request->input("country_name");
				$userAd->ad_location = $request->input("city_name");
				$userAd->ad_suburbs = $request->input("suburbs");
				$userAd->about_description = $request->input("about_description");
				$userAd->status = 0;
				$userAd->draft = 1;
				$userAd->step = 2;
				$userAd->parent_id = $request->input('user_ad_id') ? $request->input('user_ad_id') : $AdExist->id;
				$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
				$userAd->slug = $slug;
				if(!empty($request->session()->get('agency_id'))){
					$userAd->agency_id = $request->session()->get('agency_id');
				}
				if(!empty($request->session()->get('club_id'))){
					$userAd->club_id = $request->session()->get('club_id');
				}
				
				$userAd->save();
				
				}
				$ad_id = $userAd->id;


				$ad_step_status = AdStepsUpdate::where('ad_id', $ad_id)->first();
				if(count($ad_step_status) > 0){
					$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
					$rec->step_1 = 1;
					$rec->save();

				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $ad_id;
					$rec->step_1 = 1;
					$rec->save();
				}
			}else{
				if(!empty($user_ad_id)){
					$userAd = UserAdvertisement::findOrFail($user_ad_id);
					if((int)$userAd->parent_id > 0){
						$user_ad_id = $userAd->parent_id;
						$parent_id = $user_ad_id;
					}
			}
			//echo $user_ad_id;
			if(count($userAd) >0){

			
			$ad_id = $user_ad_id;


			$userAd = UserAdvertisement::findOrFail($ad_id);
			
			$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
			$userAd->ad_name = $request->input("ad_name");
			$userAd->ad_email = $request->input("ad_email");
			$userAd->ad_contactno = $request->input("ad_contactno");
			$userAd->ad_country = $request->input("country_name");
			$userAd->ad_location = $request->input("city_name");
			$userAd->ad_suburbs = $request->input("suburbs");

			$userAd->about_description = $request->input("about_description");
			if($userAd->ad_name != $request->input("ad_name") && (int)$parent_id==0){
			$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
			$userAd->slug = $slug;
			}
			if(!empty($request->session()->get('agency_id'))){
				$userAd->agency_id = $request->session()->get('agency_id');
			}

			if(!empty($request->session()->get('club_id'))){
				$userAd->club_id = $request->session()->get('club_id');
			}
			
			
			$userAd->save();
			

		}else{
			$userAd = new UserAdvertisement();
			$userAd->ad_user_id = $user_data->id;

			$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
			$userAd->ad_name = $request->input("ad_name");
			$userAd->ad_email = $request->input("ad_email");
			$userAd->ad_contactno = $request->input("ad_contactno");
			$userAd->ad_country = $request->input("country_name");
			$userAd->ad_location = $request->input("city_name");
			$userAd->ad_suburbs = $request->input("suburbs");
			$userAd->about_description = $request->input("about_description");
			$userAd->status = 0;
			$userAd->draft = 1;
			$userAd->step = 2;
			$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
			$userAd->slug = $slug;
			if(!empty($request->session()->get('agency_id'))){
				$userAd->agency_id = $request->session()->get('agency_id');
			}
			if(!empty($request->session()->get('club_id'))){
				$userAd->club_id = $request->session()->get('club_id');
			}
			
			$userAd->save();
			$ad_id = $userAd->id;
		}
		$neadid = !empty($ad_draft_id) ? $ad_draft_id:$ad_id;
		$ad_step_status = AdStepsUpdate::where('ad_id', $neadid)->first();
				if(count($ad_step_status) > 0){
					$rec = AdStepsUpdate::findOrFail($ad_step_status->id);
					$rec->step_1 = 0;
					$rec->save();
				}else{
					$rec = new AdStepsUpdate();
					$rec->ad_id = $ad_id;
					$rec->step_1 = 1;
					$rec->save();
				}
		}
		if(!empty($request->input("suburbs"))){
				$subname = $request->input("suburbs");
				$cname = $request->input("country_name");
				$cityname = $request->input("city_name");
				$suburb = Suburbs::where("suburbs_name", $subname)->where("country_id", $cname)->where("city_id", $cityname)->get();
				if(count($suburb) == 0){
					$subsobj = new Suburbs();
					$subsobj->country_id = $cname;
					$subsobj->city_id = $cityname;
					$subsobj->suburbs_name = $subname;
					$subsobj->save();
				}

			}
		
		//END NEW DATA 


		// if(empty($request->input("ad_listing_type_id"))){

		// 	return;
		// }
		// $listingExistOrNot = listingtype($request->input("ad_listing_type_id"));
		// if(count($listingExistOrNot) == 0){
		// 	return;
		// }
		// $user_ad_id = $request->input('user_ad_id');
		// $ads_id = $request->input('user_ad_id');
		// if(!empty($ads_id)){
		// $userAds = UserAdvertisement::findOrFail($ads_id);
		// if($userAds->ad_listing_type_id != $request->input("ad_listing_type_id")){
		// 	$user_ad_id = "";
		// }
		// }
		// if(!empty($user_ad_id)){
		// 	$userAd = new UserAdvertisement();
		// 	$ad_id = $request->input('user_ad_id');
		// 	$userAd = UserAdvertisement::findOrFail($ad_id);
		// 	$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
		// 	$userAd->ad_name = $request->input("ad_name");
		// 	$userAd->ad_email = $request->input("ad_email");
		// 	$userAd->ad_contactno = $request->input("ad_contactno");
		// 	$userAd->ad_country = $request->input("country_name");
		// 	$userAd->ad_location = $request->input("city_name");
		// 	$userAd->ad_suburbs = $request->input("suburbs");
		// 	$userAd->about_description = $request->input("about_description");

		// 	if($userAd->ad_name != $request->input("ad_name")){
		// 	$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
		// 	$userAd->slug = $slug;
		// 	}

		// 	if(!empty($request->session()->get('agency_id'))){
		// 		$userAd->agency_id = $request->session()->get('agency_id');
		// 	}

		// 	if(!empty($request->session()->get('club_id'))){
		// 		$userAd->club_id = $request->session()->get('club_id');
		// 	}
			

		// 	$userAd->save();
			

		// }else{		
		// 	$userAd = new UserAdvertisement();
		// 	$userAd->ad_user_id = $user_data->id;
		// 	$userAd->slug = $slug;
		// 	$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
		// 	$userAd->ad_name = $request->input("ad_name");
		// 	$userAd->ad_email = $request->input("ad_email");
		// 	$userAd->ad_contactno = $request->input("ad_contactno");
		// 	$userAd->ad_country = $request->input("country_name");
		// 	$userAd->ad_location = $request->input("city_name");
		// 	$userAd->ad_suburbs = $request->input("suburbs");
		// 	$userAd->about_description = $request->input("about_description");
		// 	$userAd->status = 0;
		// 	$userAd->draft = 1;
		// 	$slug = createSlug($request->input("ad_name"),'UserAdvertisement', 'slug');
		// 	$userAd->slug = $slug;

		// 	if(!empty($request->session()->get('agency_id'))){
		// 		$userAd->agency_id = $request->session()->get('agency_id');
		// 	}
		// 	if(!empty($request->session()->get('club_id'))){
		// 		$userAd->club_id = $request->session()->get('club_id');
		// 	}

		// 	$userAd->save();
		// 	$ad_id = $userAd->id;
		// }
		
		// if(!empty($request->input("suburbs"))){
		// 		$subname = $request->input("suburbs");
		// 		$cname = $request->input("country_name");
		// 		$cityname = $request->input("city_name");
		// 		$suburb = Suburbs::where("suburbs_name", $subname)->where("country_id", $cname)->where("city_id", $cityname)->get();
		// 		if(count($suburb) == 0){
		// 			$subsobj = new Suburbs();
		// 			$subsobj->country_id = $cname;
		// 			$subsobj->city_id = $cityname;
		// 			$subsobj->suburbs_name = $subname;
		// 			$subsobj->save();
		// 		}

		// 	}
		if(count($images) > 0){
		$image_thumb_width =  $this->generalSettings['ad_image_thumb_width'];
		$image_thumb_height =  $this->generalSettings['ad_image_thumb_height'];
		$image_large_width = $this->generalSettings['ad_image_large_width'];
		$image_large_height = $this->generalSettings['ad_image_large_height'];
		$watermark_image = $this->generalSettings['watermark_image'];
		$watermark_position = $this->generalSettings['watermark_image_position'];
		$user_folder = md5(Auth::user()->id);
		$folder_path = public_path('upload/ads_image/'.$user_folder);
   
	    if(!File::isDirectory($folder_path)){
	        File::makeDirectory($folder_path, 0777, true, true);
	    }
		foreach($images as $img){

			$image_name = $img['image'];
			if(!empty($image_name)){

			$pathinfo = pathinfo($img['image']);
			$filename =  $pathinfo['filename'].'.'.$pathinfo['extension'];

			 $path = exec('python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position.','.$user_folder.' 2>&1', $out);
			
			$imageObj = new Image();
			$imageObj->media_ad_id = $ad_id;
			$imageObj->media_filename = $filename;
			$imageObj->media_status = 'Verified';
			if(!empty($img['img_is_add_default'])){
				$update = DB::table('ad_media')->where('media_ad_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

				$imageObj->media_is_default = 1;
			}else{
				if($keys == 0){
					$update = DB::table('ad_media')->where('media_ad_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

					$imageObj->media_is_default = 1;
				}
			}
			$imageObj->media_type = "Images";

			$imageObj->save();

		}
			/*$imagesa = array(

				$filename,$filename."_508*762.jpg",$filename."_252*384.jpg",$filename."_202*182.jpg",$filename."_377*625.jpg",$filename."_982*560.jpg"
			);
			foreach($imagesa as $im){
				
					@unlink(public_path('uploads/ads_image/'.$im));
					}
					*/
		
		}

		if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){

			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$ad_id, 'activity_message'=>"$username of $escort_from posted new photos.","type"=>"images","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}else{
		
		DB::table('activity_log')->insert(
			['user_id' => Auth::user()->id, 'ad_id'=>$ad_id,'activity_message'=>" $username posted new photos.","type"=>"images","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}

		$live_data['user_lattitude'] = $_COOKIE['user_latitude'];
		$live_data['user_longitude'] = $_COOKIE['user_longitude'];
		$live_data['action'] = 'updateactivity';
		//sendRequesToServer($live_data);
		$ss = getSubscribeForByid('photos');
		$subscribers = getAdSubscriber($user_ad_id, $ss);
		
		if(count($subscribers) > 0){
			foreach($subscribers as $sb){
			$email_content_sub = array();
			$email_content_sub["user_name"] = !empty($sb->subs_name) ? $sb->subs_name : $sb->subs_email;
			$profile_url = url('profile/'.$userAd->slug);
			$email_content_sub["content"] =$username.' has posted new photos.';
			$email_content_sub["view_profile_link"] = "View <a href=".$profile_url.">Profile</a>";
			$email_message_admin = new EmailMessage();
			$admin_notification_email= $this->generalSettings['admin_notification_email'];
			//$admin_notification_email = 'sushma@vocso.com';
			$email_message_admin->singleMailSendIntegration($sb->subs_email,'AdNotification', $email_content_sub );
			}
			
		}
	}
//old_images
	if(count($old_images) > 0){
		foreach($old_images as $keys=>$img){

			$imagesExists = DB::table('ad_media')->where('media_ad_id', $ad_id)
							->where("media_type", "Images")->where('media_filename',$img)->get();
		
			if(count($imagesExists) == 0){

			$imageObj = new Image();
			$imageObj->media_filename = $img;
			$imageObj->media_type = "Images"; 
			$imageObj->media_ad_id = $ad_id;
			$imageObj->save();
			}
		}
		}
//end old images	
	
	
		if(count($videos) > 0){

		foreach($videos as $vid){
			if(!empty($vid)){
			$imageObj = new Image();
			$imageObj->media_ad_id = $ad_id;
			$imageObj->media_filename = $vid;
			$imageObj->media_status = 'Under Review'; 
			$imageObj->media_type = "Videos";
			$imageObj->media_storage = 'Cloudflare';
		
			$imageObj->save();
		}
		}

		if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){

			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$ad_id, 'activity_message'=>"$username of $escort_from checkout video on her profile..","type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}else{
		
		DB::table('activity_log')->insert(
			['user_id' => Auth::user()->id, 'ad_id'=>$ad_id,'activity_message'=>" Checkout $username's video on her profile.","type"=>"videos","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}
		
		$live_data['user_lattitude'] = $_COOKIE['user_latitude'];
		$live_data['user_longitude'] = $_COOKIE['user_longitude'];
		$live_data['action'] = 'updateactivity';
		//sendRequesToServer($live_data);
		$ss = getSubscribeForByid('videos');
		$subscribers = getAdSubscriber($user_ad_id, $ss);
		
		if(count($subscribers) > 0){
			foreach($subscribers as $sb){
			$email_content_sub = array();
			$email_content_sub["user_name"] = !empty($sb->subs_name) ? $sb->subs_name : $sb->subs_email;
			$profile_url = url('profile/'.$userAd->slug);
			$email_content_sub["content"] =$username.' has posted new videos.';
			$email_content_sub["view_profile_link"] ="Checkout <a href=".$profile_url.">".$userData->ad_name."\'s profile.</a>";
			$email_message_admin = new EmailMessage();
			$admin_notification_email= $this->generalSettings['admin_notification_email'];
			//$admin_notification_email = 'sushma@vocso.com';
			$email_message_admin->singleMailSendIntegration($sb->subs_email,'AdNotification', $email_content_sub );
			}
			
		}
	}

	//old_videos
	if(count($old_videos) > 0){
		foreach($old_videos as $vid){

			$videosExists = DB::table('ad_media')->where('media_ad_id', $ad_id)
							->where("media_type", "Videos")->where('media_filename',$vid)->get();
		
			if(count($videosExists) == 0){

			$imageObj = new Image();
			$imageObj->media_filename = $vid;
			$imageObj->media_type = "Videos"; 
			$imageObj->media_ad_id = $ad_id;
			$imageObj->save();
			}
		}
}
//end_old_videos

		if(count($banners) > 0){

		foreach($banners as $bnn){
			if(!empty($bnn)){
			$imageObj = new Image();
			$imageObj->media_ad_id = $ad_id;
			$imageObj->media_filename = $bnn;
			$imageObj->media_status = 'Verified'; 
			$imageObj->media_type = "Banners";
		
			$imageObj->save();
		}
		}
	}

//old_banners
	if(count($old_banners) > 0){
		foreach($old_banners as $oib){

			$videosExists = DB::table('ad_media')->where('media_ad_id', $ad_id)
							->where("media_type", "Banners")->where('media_filename',$oib)->get();
		
			if(count($videosExists) == 0){

			$imageObj = new Image();
			$imageObj->media_filename = $oib;
			$imageObj->media_type = "Banners"; 
			$imageObj->media_ad_id = $ad_id;
			$imageObj->save();
			}
		}
}
//end_old_banners


	$request->session()->put('user_ad_id', $ad_id);
		$requestData = $request->all();
		unset($requestData['ad_listing_type_id']);
		unset($requestData['ad_name']);
		unset($requestData['ad_email']);
		unset($requestData['ad_contactno']);
		unset($requestData['country_name']);
		unset($requestData['city_name']);
		unset($requestData['suburbs']);
		unset($requestData['about_description']);
		unset($requestData['_token']);
		unset($requestData['user_ad_id']);
		unset($requestData['imageurl']);
		unset($requestData['videourl']);
		unset($requestData['old_imageurl']);
		unset($requestData['vold_ideourl']);
		unset($requestData['banner']);
		unset($requestData['img_is_default']);




		if(!empty($requestData['disclaimer'])){
			
			
				$data_array = [
					'meta_key' => 'disclaimer',
					'meta_value' => 'yes',
					'ad_id'=> $ad_id
				 ];
				 
				$fetchExistData  = UserAdMeta::updateOrCreate([
					['meta_key', '=', 'disclaimer'],
					['ad_id', '=', $ad_id],
				], $data_array);
			
		}
		
		unset($requestData['disclaimer']);

		foreach($requestData as $key => $req){
			$fetchExistData  = UserAdMeta::select()->where([
				['meta_key', '=', $key],
				['ad_id', '=', $ad_id],
			]);	
			if(count($fetchExistData) > 0){
					$fetchExistData->delete();
			}
				if(is_array($requestData[$key])){
				
					foreach($req as $r){
						if(!empty($r)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = $ad_id;
						$user_ad_meta->save();
						}
						
					}
				}else{
					
						if(!empty($req)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->ad_id = $ad_id;
						$user_ad_meta->save();
						}
			}

		}

		if($userAd->mail_sent == 0){


				if(is_agency(\Request::session('agency_id')) || is_club(\Request::session('club_id'))){

			DB::table('activity_log')->insert(
				['user_id' => Auth::user()->id, 'ad_id'=>$ad_id, 'activity_message'=>"$username from $location of $escort_from is now on HouseofSexyGirls","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
		}else{
		
				DB::table('activity_log')->insert(
			['user_id' => Auth::user()->id, 'ad_id'=>$ad_id,'activity_message'=>"  $username from $location is now on HouseofSexyGirls","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]);
			}


			// 	DB::table('activity_log')->insert(
			// ['user_id' => Auth::user()->id, 'ad_id'=>$user_ad_id,'activity_message'=>$userAd->ad_name." from ".$userAd->ad_location." is now on HouseofSexyGirls"]);
			$email_content_admin = array();
			$email_content_admin["user_name"] = 'Admin';
			$email_content_admin["ad_name"] =$userAd->ad_name;
			$listing_name = listingtype($userAd->ad_listing_type_id);
		
			$email_content_admin["listing_type"] =$listing_name[$userAd->ad_listing_type_id]['title'];
			$email_content_admin["verify_link"] = '<a href="'.url('/admin/posts/'.$listing_name[$userAd->ad_listing_type_id]['slug']).'" target="_blank">Click Here</a>';
			$email_message_admin = new EmailMessage();
			$admin_notification_email= $this->generalSettings['admin_notification_email'];
			//$admin_notification_email = 'sushma@vocso.com';
			$email_message_admin->singleMailSendIntegration( $admin_notification_email, "NewAdPostAdded", $email_content_admin );
			$newUserData = UserAdvertisement::findOrFail($userAd->id);
			$newUserData->mail_sent = 1;
			$newUserData->save();
			}
	
		return $request->input('ad_name');

	}
	

	
		function saveAgencyDetails(Request $request){

		$images  = $request->input('imageurl');
		$video = $request->input('videourl');
		$banners = $request->input('banner');
		$user_data = Auth::user();
		if(!empty($request->input('agency_id'))){

		$userAd = AgencyDetails::findOrFail($request->input('agency_id'));
		$userAd->user_id = $user_data->id;
		$userAd->listing_type_id = $request->input("listing_type_id");
		$userAd->name = $request->input("name");
		$userAd->email = $request->input("email");
		$userAd->phone = $request->input("contact");
		$userAd->country = $request->input("country_name");
		$userAd->city = $request->input("city_name");
		$userAd->suburbs = $request->input("suburbs");
		$userAd->website = $request->input("website");
		$userAd->description = $request->input("agency_details");
		$userAd->slug =str_slug($request->input("name"));
		$userAd->status = 1;
		$userAd->save();
		$ad_id = $userAd->id;
		}else{


		$userAd = new AgencyDetails();
		$userAd->user_id = $user_data->id;
		$userAd->listing_type_id = $request->input("listing_type_id");
		$userAd->name = $request->input("name");
		$userAd->email = $request->input("email");
		$userAd->phone = $request->input("contact");
		$userAd->country = $request->input("country_name");
		$userAd->city = $request->input("city_name");
		$userAd->suburbs = $request->input("suburbs");
		$userAd->website = $request->input("website");
		$userAd->description = $request->input("agency_details");
		$userAd->slug = str_slug($request->input("name"));
		$userAd->status = 1;
		$userAd->save();
		$ad_id = $userAd->id;
		}
	if(!empty($request->input("suburbs"))){
				$subname = $request->input("suburbs");
				$cname = $request->input("country_name");
				$cityname = $request->input("city_name");
				$suburb = Suburbs::where("suburbs_name", $subname)->where("country_id", $cname)->where("city_id", $cityname)->get();
				if(count($suburb) == 0){
					$subsobj = new Suburbs();
					$subsobj->country_id = $cname;
					$subsobj->city_id = $cityname;
					$subsobj->suburbs_name = $subname;
					$subsobj->save();
				}

			}
	if(count($images) > 0){
		$image_thumb_width =  $this->generalSettings['ad_image_thumb_width'];
		$image_thumb_height =  $this->generalSettings['ad_image_thumb_height'];
		$image_large_width = $this->generalSettings['ad_image_large_width'];
		$image_large_height = $this->generalSettings['ad_image_large_height'];
		$watermark_image = $this->generalSettings['watermark_image'];
		$watermark_position = $this->generalSettings['watermark_image_position'];
		$user_folder = md5(Auth::user()->id);
		$folder_path = public_path('upload/ads_image/'.$user_folder);
   
	    if(!File::isDirectory($folder_path)){
	        File::makeDirectory($folder_path, 0777, true, true);
	    }
		foreach($images as $img){
			$image_name = $img['image'];

			if(!empty($image_name)){
				$pathinfo = pathinfo($img['image']);
			$filename =  $pathinfo['filename'].'.'.$pathinfo['extension'];
			

			$path = exec('python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position.','.$user_folder.' 2>&1', $out);	
			// print_r($out);
			// die('jj');
			$imageObj = new AgencyImages();
			$imageObj->agency_id = $ad_id;
			$imageObj->media_filename = $filename;
			$imageObj->media_status = 'Verified';
		if(!empty($img['img_is_add_default'])){
				$update = DB::table('agency_images')->where('agency_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

				$imageObj->media_is_default = 1;
			}
			$imageObj->media_type = "Images";

			$imageObj->save();

			}
			
			/*$imagesa = array(

				$filename,$filename."_508*762.jpg",$filename."_252*384.jpg",$filename."_202*182.jpg",$filename."_377*625.jpg",$filename."_982*560.jpg"
			);
			foreach($imagesa as $im){
				
					@unlink(public_path('uploads/ads_image/'.$im));
					}
					*/
		
		}
	}
	
	
	
		if(count($video) > 0){

		foreach($video as $vid){
			if(!empty($vid)){
			$imageObj = new AgencyImages();
			$imageObj->agency_id = $ad_id;
			$imageObj->media_filename = $vid;

			$imageObj->media_status = 'Under Review'; 
			$imageObj->media_type = "Videos";
			$imageObj->media_storage = 'Cloudflare';
		
			$imageObj->save();
			}
			
		}
	}

	
		if(count($banners) > 0){

		foreach($banners as $bnn){
			if(!empty($bnn)){
				$imageObj = new AgencyImages();
			$imageObj->agency_id = $ad_id;
			$imageObj->media_filename = $bnn;
			$imageObj->media_status = 'Verified'; 
			$imageObj->media_type = "Banners";
		
			$imageObj->save();
			}
			
		}
	}

	$request->session()->put('agency_id', $ad_id);
		$requestData = $request->all();
		unset($requestData['listing_type_id']);
		unset($requestData['name']);
		unset($requestData['email']);
		unset($requestData['contact']);
		unset($requestData['country_name']);
		unset($requestData['city_name']);
		unset($requestData['suburbs']);
		unset($requestData['agency_details']);
		unset($requestData['website']);
		unset($requestData['_token']);
		unset($requestData['agency_id']);
		unset($requestData['imageurl']);
		unset($requestData['teaservideourl']);
		unset($requestData['banner']);
		unset($requestData['old_imageurl']);
		unset($requestData['old_videourl']);
		unset($requestData['img_is_default']);

		foreach($requestData as $key => $req){
			$fetchExistData  = AgencyMeta::select()->where([
				['meta_key', '=', $key],
				['agency_id', '=', $ad_id],
			]);	
			if(count($fetchExistData) > 0){
					$fetchExistData->delete();
			}
				if(is_array($requestData[$key])){
				
					foreach($req as $r){
						if(!empty($r)){
						$user_ad_meta = new AgencyMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->agency_id = $ad_id;
						//print_r($user_ad_meta);
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));
						}
						
					}
				}else{
					
						if(!empty($req)){
						$user_ad_meta = new AgencyMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->agency_id = $ad_id;
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));
						}
			}

		}
		
	return $request->input('name');
		//return $ad_id;


// return redirect()->route('index');
 		//return $ad_id;
	}
	

//save and update club data start
	function saveClubDetails(Request $request){

		$images  = $request->input('imageurl');
		$video = $request->input('videourl');
		$banners = $request->input('banner');
		$user_data = Auth::user();
		if(!empty($request->input('club_id'))){

		$userAd = ClubDetails::findOrFail($request->input('club_id'));
		$userAd->user_id = $user_data->id;
		$userAd->listing_type_id = $request->input("listing_type_id");
		$userAd->name = $request->input("name");
		$userAd->email = $request->input("email");
		$userAd->phone = $request->input("contact");
		$userAd->country = $request->input("country_name");
		$userAd->city = $request->input("city_name");
		$userAd->suburbs = $request->input("suburbs");
		$userAd->website = $request->input("website");
		$userAd->description = $request->input("agency_details");
		$userAd->slug = str_slug($request->input("name"));
		$userAd->status = 1;
		$userAd->save();
		$ad_id = $userAd->id;
		}else{

		$userAd = new ClubDetails();
		$userAd->user_id = $user_data->id;
		$userAd->listing_type_id = $request->input("listing_type_id");
		$userAd->name = $request->input("name");
		$userAd->email = $request->input("email");
		$userAd->phone = $request->input("contact");
		$userAd->country = $request->input("country_name");
		$userAd->city = $request->input("city_name");
		$userAd->suburbs = $request->input("suburbs");
		$userAd->website = $request->input("website");
		$userAd->description = $request->input("agency_details");
		$userAd->slug = str_slug($request->input("name"));
		$userAd->status = 1;
		$userAd->save();
		$ad_id = $userAd->id;
		}
	if(!empty($request->input("suburbs"))){
				$subname = $request->input("suburbs");
				$cname = $request->input("country_name");
				$cityname = $request->input("city_name");
				$suburb = Suburbs::where("suburbs_name", $subname)->where("country_id", $cname)->where("city_id", $cityname)->get();
				if(count($suburb) == 0){
					$subsobj = new Suburbs();
					$subsobj->country_id = $cname;
					$subsobj->city_id = $cityname;
					$subsobj->suburbs_name = $subname;
					$subsobj->save();
				}

			}
	if(count($images) > 0){
		$image_thumb_width =  $this->generalSettings['ad_image_thumb_width'];
		$image_thumb_height =  $this->generalSettings['ad_image_thumb_height'];
		$image_large_width = $this->generalSettings['ad_image_large_width'];
		$image_large_height = $this->generalSettings['ad_image_large_height'];
		$watermark_image = $this->generalSettings['watermark_image'];
		$watermark_position = $this->generalSettings['watermark_image_position'];
		$user_folder = md5(Auth::user()->id);
		$folder_path = public_path('upload/ads_image/'.$user_folder);
   
	    if(!File::isDirectory($folder_path)){
	        File::makeDirectory($folder_path, 0777, true, true);
	    }

		foreach($images as $img){

			$image_name = $img['image'];
			if(!empty($image_name)){
				$pathinfo = pathinfo($img['image']);
			$filename =  $pathinfo['filename'].'.'.$pathinfo['extension'];

			 $path = exec('python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position.','.$user_folder.' 2>&1', $out);	

			$imageObj = new ClubImages();
			$imageObj->club_id = $ad_id;
			$imageObj->media_filename = $filename;
			$imageObj->media_status = 'Verified';
			if(!empty($img['img_is_add_default'])){
				$update = DB::table('club_images')->where('club_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

				$imageObj->media_is_default = 1;
			}
			$imageObj->media_type = "Images";

			$imageObj->save();

			}	
		}
	}
	
	
	
		if(count($video) > 0){

		foreach($video as $vid){
			if(!empty($vid)){
			$imageObj = new ClubImages();
			$imageObj->club_id = $ad_id;
			$imageObj->media_filename = $vid;

			$imageObj->media_status = 'Verified'; 
			$imageObj->media_type = "Videos";
			$imageObj->media_storage = 'Cloudflare';
		
			$imageObj->save();
		}
	}
	}

	
		if(count($banners) > 0){

		foreach($banners as $bnn){
			if(!empty($bnn)){
			$imageObj = new ClubImages();
			$imageObj->club_id = $ad_id;
			$imageObj->media_filename = $bnn;
			$imageObj->media_status = 'Verified'; 
			$imageObj->media_type = "Banners";
		
			$imageObj->save();
		}
	}
	}

	$request->session()->put('club_id', $ad_id);
		$requestData = $request->all();
		unset($requestData['listing_type_id']);
		unset($requestData['name']);
		unset($requestData['email']);
		unset($requestData['contact']);
		unset($requestData['country_name']);
		unset($requestData['city_name']);
		unset($requestData['suburbs']);
		unset($requestData['agency_details']);
		unset($requestData['website']);
		unset($requestData['_token']);
		unset($requestData['club_id']);
		unset($requestData['imageurl']);
		unset($requestData['teaservideourl']);
		unset($requestData['banner']);
		unset($requestData['old_imageurl']);
		unset($requestData['old_videourl']);
		unset($requestData['img_is_default']);

		foreach($requestData as $key => $req){
			$fetchExistData  = ClubMeta::select()->where([
				['meta_key', '=', $key],
				['club_id', '=', $ad_id],
			]);	
			if(count($fetchExistData) > 0){
					$fetchExistData->delete();
			}
				if(is_array($requestData[$key])){
				
					foreach($req as $r){
						if(!empty($r)){
						$user_ad_meta = new ClubMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->club_id = $ad_id;
						$user_ad_meta->save();
						}
						
					}
				}else{
					
						if(!empty($req)){
						$user_ad_meta = new ClubMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->club_id = $ad_id;
						$user_ad_meta->save();
						}
			}

		}
	
		return $request->input('name');
		//return $ad_id;
	}
	

//end club saving and update	
function postListing(Request $request){
		$input = $request->all();

		//print_r($input);

    	$slug = \Request::segment(2);
    	$res = DB::table('listing_type')->where("slug", $slug)->first();
    	//print_r($input);

    	$filtergender = getListingTypeCat($slug);
    	$filtergender = !empty($input['gender']) ? $input['gender'] : $filtergender;
    	$orientations = '';
    	//$orientation = '';
    	if(isset($input['orientation']) && $input['orientation'] != '' ){
    		if(is_numeric($input['orientation'])){
    			$orientations = $input['orientation'];
    		}else{
    			$orientation = getOrientationId($slug,$input['orientation'],$filtergender);

    	  		$orientations = (count($orientation) > 0) ? $orientation['orientation'][0]['id'] : '';
    		}
    		
    	}
  
    
    	$master_age = MainMaster::all()->where('meta_name','age');
		$master_body_type = MainMaster::all()->where('meta_name','body-type')->where('gender', ucfirst($filtergender));
		$master_nationality = MainMaster::all()->where('meta_name','nationality');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		$master_service_available = MainMaster::all()->where('meta_name','service-available')->where('listing_type_id', $res->id);
		if(count($master_service_available) == 0){
			$master_service_available = MainMaster::all()->where('meta_name','service-available')->where('listing_type_id', 1);
		}
		$master_piercing = MainMaster::all()->where('meta_name','piercing');
		$master_hair_length = MainMaster::all()->where('meta_name','hairlength');
		$master_dress_size = MainMaster::all()->where('meta_name','dresssize')->where('gender', ucfirst($filtergender));
		$master_bust_size = MainMaster::all()->where('meta_name','bustsize')->where('gender', ucfirst($filtergender));
		$master_orientation =MainMaster::all()->where('meta_name','orientation')->where('gender', ucfirst($filtergender));
		
		$master_shoe_size = MainMaster::all()->where('meta_name','shoessize');
		$master_eyecolor = MainMaster::all()->where('meta_name','eyecolor');
		$master_haircolor = MainMaster::all()->where('meta_name','haircolor');
		$cities_list = array();
		$cities = new Cities;
		$ethinicity = MainMaster::all()->where('meta_name','ethinicity');
		$countries = Countries::all();

    	
		
		if(count($res) == 0){
			
			$list = array();



			return view($url)->with('list', $list)
			->with('generalsettings', $this->generalSettings )->with('master_age',$master_age)
			->with('countries',$countries)
			->with('master_age',$master_age)
			->with('master_orientation',$master_orientation)
			->with('master_body_type',$master_body_type)
			->with('master_service_type',$master_service_type)
			->with('master_nationality',$master_nationality)
			->with('master_dress_size', $master_dress_size)
			->with('master_bust_size', $master_bust_size)
			->with('master_shoe_size', $master_shoe_size)
			->with('master_haircolor', $master_haircolor)
			->with('master_eyecolor', $master_eyecolor)
			->with('master_hair_length', $master_hair_length)
			->with('master_piercing', $master_piercing)
			->with('master_eyecolor', $master_eyecolor)
			->with('slug', $slug)
			->with('orientations', $orientations)
			->with('liveactivity', $liveact)
			->with('ethinicity', $ethinicity)
			->with('inputdata', $input)
			->with('gender', $gender);

		}
		
		$liveact = getLiveUpdates(array('listing_type_id' => $res->id, "gender" => $input['gender'] ));
	    $today = strtotime(date("Y-m-d H:i:s"));		
	    $query = "select t1.* from 
		tbl_user_advertisement t1 where
		t1.plan_expired IS NOT NULL and t1.plan_purchased IS NOT NULL 
		and t1.plan_expired >='".$today."' and t1.status=1 and from_unixtime(next_boost_time) <= now()";
		$query1 = "select t2.* from
		tbl_user_advertisement t2 where
		t2.plan_expired IS NOT NULL and t2.plan_purchased IS NOT NULL 
		and t2.plan_expired >='".$today."' and t2.status=1 and from_unixtime(next_boost_time) >= now()";
	    $filterquery ="";
	    $queryOffline = "select t1.* from 
		tbl_user_advertisement t1 where
		t1.plan_expired IS NOT NULL and t1.plan_purchased IS NOT NULL 
		and t1.plan_expired <'".$today."' and t1.status=1 ";
		$query1Offline = "select t2.* from
		tbl_user_advertisement t2 where
		t2.plan_expired IS NOT NULL and t2.plan_purchased IS NOT NULL 
		and t2.plan_expired <'".$today."' and t2.status=1 ";
	    
	    if($res->cat_type!='club' && $res->cat_type!='agency'){
	    	
		    if(!empty($res->id) && $res->cat_type != 'job'){
			
		    $filterquery .= " and ad_listing_type_id ='".$res->id."' and club_id=0 and agency_id=0";
			}else{
				$filterquery .= " and ad_listing_type_id ='".$res->id."'";
			}

	    }
	    
	  	if(!empty($input['name'])){
	    	$filterquery .= " and LCASE(ad_name) like '%".strtolower($input['name'])."%'";
		}
		
		if($res->cat_type == 'club' || $res->cat_type == 'agency'){
			$only_indi = getOnlyIndividualType();

	    	$filterquery .= " and ad_listing_type_id  in (".implode(',', $only_indi).")";
		}

		if(!empty($input['list_type'] == 'club') || $res->cat_type == 'club'){

	    	$filterquery .= " and club_id >0";
		}
		if(!empty($input['list_type'] == 'agency') || $res->cat_type == 'agency'){
	    	$filterquery .= " and agency_id >0";
		}
		
	    if(!empty($input['gender'])){
	    	
	    	$gender = $input['gender'];
	    	
		    
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value = "'.$gender.'" and meta_key="gender")';
	    }
	   
	    if(count($input['age']) > 0){
		    $age = implode(", ", $input['age']);
		    $filterquery .=" and uad.id in(select ad_id from tbl_user_ad_meta where meta_value in(".$age.") and meta_key='age')";
	    }
	  

	    if(!empty($input['height'])){
		    $height = explode("-", $input['height']);
		    $height1 = $height[0];
		    $height2 = $height[1];
		    if($height2  == 'above'){
		    	$filterquery .=" and id in(select ad_id from tbl_user_ad_meta where meta_value >= ".$height1." and meta_key='height')";
		    }else{
		    	$filterquery .=" and id in(select ad_id from tbl_user_ad_meta where meta_value >= ".$height1." and meta_value <=".$height2." and meta_key='height')";
		    }
		    
	    }

	    if(!empty($input['weight'])){
		    $weight = explode("-", $input['weight']);
		    $weight1 = $weight[0];
		    $weight2 = $weight[1];
		    
		  	if($weight2  == 'above'){
		     	$filterquery .=" and id in(select ad_id from tbl_user_ad_meta where meta_value >= ".$weight1." and meta_key='weight')";
		    }else{
		   		$filterquery .=" and id in(select ad_id from tbl_user_ad_meta where meta_value >= ".$weight1." and meta_value <=".$weight2." and meta_key='weight')";
		    }		    
	    }

	    if(!empty($input['dressize'])){
		
		  	$dresssize = $input['dressize'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $dresssize) . '") and meta_key="dresssize")';
		    
		    
	    }
	    if(!empty($input['bustsize'])){
		
		  	$bustsize = $input['bustsize'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $bustsize) . '") and meta_key="bustsize")';
		    
		    
	    }
	    if(!empty($input['shoessize'])){
		
		  	$shoessize = $input['shoessize'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $shoessize) . '") and meta_key="shoessize")';
		    
		    
	    }
	    if(!empty($input['eyecolor'])){
		
		  	$eyecolor = $input['eyecolor'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $eyecolor) . '") and meta_key="eyecolor")';
		    
		    
	    }
	    if(!empty($input['haircolor'])){
		
		  	$haircolor = $input['haircolor'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $haircolor) . '") and meta_key="haircolor")';
		    
		    
	    }
	    /*var_dump($orientations);
	    exit;*/
		if($res->cat_type == 'club' || $res->cat_type == 'agency' || $res->cat_type == 'photographer' || $res->category_name == 'trans' || $res->cat_type == 'job'){
	 		if(!empty($input['orientation'])){

		  		$orientation = $input['orientation'];
		  
	   			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $orientation) . '") and meta_key="orientation")';	    
	    	}
		}else{
			

			if(count($orientations) > 0 && $input['gender'] != 'trans' && $orientations != ''){
		
		  		$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value = "'.$orientations.'" and meta_key="orientation")';
	    	}else{
	   			if(!empty($input['orientation'])){
		
		  			$orientation = $input['orientation'];
		  
	   				$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $orientation) . '") and meta_key="orientation")';	    
	    		}
	  		}

		}

	

	    if(!empty($input['smoker'])){
		
		  	$smoker = $input['smoker'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $smoker) . '") and meta_key="smoker")';
		    
		    
	    }
	    if(!empty($input['smoker'])){
		
		  	$smoker = $input['smoker'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $smoker) . '") and meta_key="smoker")';
		    
		    
	    }
	    if(!empty($input['drink'])){
		
		  	$drink = $input['drink'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $drink) . '") and meta_key="drink")';
		    
		    
	    }
	    if(!empty($input['piercing'])){
		
		  	$drink = $input['piercing'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $drink) . '") and meta_key="drink")';
		    
		    
	    }
	    if(!empty($input['tattoo'])){
		
		  	$tattoo = $input['tattoo'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $tattoo) . '") and meta_key="tattoo")';
		    
		    
	    }
	    if(!empty($input['busttype'])){
		
		  	$busttype = $input['busttype'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $busttype) . '") and meta_key="busttype")';
		    
		    
	    }
	    if(!empty($input['hairlength'])){
		
			$hairlength = $input['hairlength'];
			$filterquery .= ' and id in(select ad_id from tbl_user_ad_meta where meta_value in("' . implode('", "', $hairlength) . '") and meta_key="hairlength")';
		    
		    
	    }
		/*
			     if(!empty($input['age'])){
				    $age = explode("-", $input['age']);
				    $age1 = $age[0];
				    $age2 = $age[1];
				    if($age2  == 'above'){
				    	$query .=" and id in(select ad_id from tbl_user_ad_meta where meta_value >= ".$age1." and meta_key='age')";
				    }else{
				    	$query .=" and id in(select ad_id from tbl_user_ad_meta where meta_value >= ".$age1." and meta_value <=".$age2." and meta_key='age')";
				    }
				    
			    }
		*/

	    if(!empty($input['countries'])){
			$countries = $input['countries'];
			$filterquery .=" and uad.ad_country ='".$countries."'";
		}
		if(!empty($input['cities'])){
			$cities = implode(", ", $input['cities']);
			$filterquery .=" and uad.ad_location in (".$cities.")";
		
		}

 		if(!empty($input['suburbs'])){
			$suburbs = $input['suburbs'];
			$filterquery .=" and uad.ad_suburbs like '%".$suburbs."%'";
		}

		if(!empty($input['bodytype'])){
			$bodytype = implode(", ", $input['bodytype']);
			$filterquery .=" and id in(select ad_id from tbl_user_ad_meta where meta_value in(".$bodytype.") and  meta_key='body-type')";
		}
		
		if(!empty($input['etihnicity'])){
			$ethnicity = implode(", ",$input['ethinicity']);
			$filterquery .=" and id in(select ad_id from tbl_user_ad_meta where meta_value  in(".$ethnicity.") and meta_key='ethinicity')";
		}
		
		if(!empty($input['services'])){
			$services = implode(", ", $input['services']);
			$filterquery .=" and id in(select ad_id from tbl_user_ad_meta where meta_value in(".$services.") and meta_key='service-type')";
		}


		if(!empty($input['price'])){
			$price =  explode("-", $input['price']);
			$price1 = $price[0];
			$price2 = $price[1];
			if($price2=='over'){
				$filterquery .=" and  id in(select ad_id from tbl_ad_rate where incall_charge > ".$price1." or outcall_charge > ".$price2.")";
			}else{
				$filterquery .=" and  id in(select ad_id from tbl_ad_rate where (incall_charge between ".$price1." and ".$price2.") or  (outcall_charge between ".$price1." and ".$price2."))";
			}
		}
		//var_dump($filterquery);
		if($filterquery){
			if(!empty($input['page'])){
			$pagen =$input['page'];

			}else{
				$pagen =1;
			}
			
			$limit = $this->generalSettings['page_limit'];
   			$start_from = ($pagen-1) * $limit;
   			$limit_query = " limit $start_from, $limit"; 

		   	  $queryy = $query." Union ".$query1;
		  	  $newQuery = "SELECT * FROM ( ".$queryy." ) as uad where 1=1 ".$filterquery." and uad.ad_status=1 order by uad.ad_status desc".$limit_query;
		  	//print_r($newQuery);
		     $newQuery1 = "SELECT * FROM ( ".$queryy." ) as uad where 1=1 ".$filterquery." and uad.ad_status=1 order by uad.ad_status desc";
			//print_r($newQuery1);
			// die();
			\DB::connection()->enableQueryLog();
			$ress = DB::select($newQuery);
			$ress1 = DB::select($newQuery1);
			$queryyOffline = $queryOffline." Union ".$query1Offline;
		  	$newQueryOffline = "SELECT * FROM ( ".$queryyOffline." ) as uad where 1=1 ".$filterquery." and uad.ad_status=1 order by uad.ad_status desc".$limit_query;
		    $newQuery1Offline = "SELECT * FROM ( ".$queryyOffline." ) as uad where 1=1 ".$filterquery." and uad.ad_status=1 order by uad.ad_status desc";
 			\DB::connection()->enableQueryLog();
			$ressOffline = DB::select($newQueryOffline);
			$ress1Offline = DB::select($newQuery1Offline);
		}else{
			$ress = array();
			$ressOffline = array();
		}
		// echo "<pre>";
		//  var_dump($ress);
		$AvailableRecord = array();
		$BreakRecord = array();
		$busyRecord = array();
		$noWorkingRecordArray = array();

		if(count($ress) > 0){
			foreach($ress as $key => $r){
				//extra code avl
	            $current_time = strtotime(date('h:i A'));
	    		$current_time_1 = strtotime(date('h:i A'));
	          	$booking_day_data = get_booking_day($r->id);
	        
		       	foreach($booking_day_data as $bd){
			   		$booking_start_time[$bd->id][] =!empty($bd->booking_start_time) ?  $bd->booking_start_time:''; 
			   		$booking_end_time[$bd->id][] = !empty($bd->booking_end_time) ?  $bd->booking_end_time:'';
			   		$booking_ad_id[$bd->id][] = $bd->ad_id;
		  		} 

			 	$break_time = get_break_time($r->id);

		  		foreach($break_time as $bt){
			   		$break_start_time[$bt->id][] =!empty($bt->booking_start_time) ? $bt->booking_start_time:'';
			   		$break_end_time[$bt->id][] = !empty($bt->booking_end_time) ? $bt->booking_end_time:'';
			    	$break_ad_id[$bt->id][] = $bt->ad_id;
		  		}

	  			$nextavaildaytime = getNextWorkingDayTime($r->id, $r->plan_expired);
	  			
				foreach($nextavaildaytime as $nd){
	  				$next_start_time[$nd->id][] =!empty($nd->working_start_time) ?$nd->working_start_time:'';
	  				$next_day_name[$nd->id][] = !empty($nd->working_date) ? $nd->working_date:'';
	  			}
	  			$get_today_working_hours = array();
	            
	            $next_time = getNextAvailableTime($r->id,$booking_end_time[$bd->id][0]) + 900;            
	            $get_today_working_hours[] = get_working_hours($r->id, date('Y-m-d'));
	            $today_working_hours = $get_today_working_hours[0]->working_start_time;

	               


	            $today_start_time =$get_today_working_hours[0]->working_start_time;
	    		$today_end_time = $get_today_working_hours[0]->working_end_time ;
				//end extra code avl


	    		//condtionbnextra avl
	    		if ($current_time > $booking_start_time[$bd->id][0] && $current_time <= $booking_end_time[$bd->id][0] && $r->id == $booking_ad_id[$bd->id][0] ){
			    	if($r->ad_status == 1){
			    		
			    		$busyRecord[] = $r;
	       				unset($ress[$key]);
	       				continue;
			    	}else{
			        	if(count($nextavaildaytime )> 0){

			        	}else{
			        		$noWorkingRecordArray[] = $r;
			        		unset($ress[$key]);
			        		continue;
			        	}
			        }
	    		    	
	         	}else if($current_time_1 > $break_start_time[$bt->id][0] && $current_time_1 <= $break_end_time[$bt->id][0] && $r->id == $break_ad_id[$bt->id][0] ){
		         	if($r->ad_status == 1){
			     		$BreakRecord[] = $r;
		   				unset($ress[$key]);
		   				continue;
		    		}else{
			        	if(count($nextavaildaytime )> 0){

			        	}else{
			        		$noWorkingRecordArray[] = $r;
			        		unset($ress[$key]);
			        		continue;
			        	}
			        }

		       	}else{          
			        if($r->ad_status == 1 && count($get_today_working_hours)> 0 && $current_time > $today_start_time && $current_time <= $today_end_time ){
			           
			           $AvailableRecord[] = $r;
			           unset($ress[$key]);
			        }else{
			        	if(count($nextavaildaytime )> 0){

			        	}else{
			        		$noWorkingRecordArray[] = $r;
			        		unset($ress[$key]);
			        		continue;
			        	}
			        }
	       		}

	    	}
		}
		
		if($res->cat_type != 'job'){

			$newResult = array_merge($AvailableRecord,$busyRecord,$BreakRecord,$ress);

		}else{
			$newResult = array_merge($AvailableRecord,$busyRecord,$BreakRecord,$ress,$noWorkingRecordArray);
		}
		
		
		
		$list = array();
		
		//echo  $request->fullUrl();
		if(count($newResult) > 0){	
			$page_links = paginateResults(count($newResult), $request->fullUrl(), !empty($input['page']) ? $input['page'] : 1);
	
			foreach($newResult as $r){
			
				$metaData = getAllMetaData($r->id);

				$banner = Image::where('media_ad_id', $r->id)->where('media_type','Banners')
						->limit(1)->get();
				$login_status=fetchLoginStatus($r->ad_user_id);
				$allimage = Image::where('media_ad_id', $r->id)->where('media_type','Images')
				->where('media_status','!=', 'Reject')->where('media_is_default', 1 )->get();
				$image = Image::where('media_ad_id', $r->id)->where('media_type','Images')
				->where('media_status','!=', 'Reject')->where('media_is_default', 1 )->first();
				$verified = mediaStatusCheckbyId($image->id);
		        if($verified){
		            $short_image = $image->media_filename;
		        }else{
		            $short_image = "unverified_".$image->media_filename;
		        }
				$rate  = AdRate::select()->where('ad_id', $r->id)->min('incall_charge');
				$list[] = array(
					"adId" => $r->id,
					"slug" => $r->slug,
					"adUserId" => $r->ad_user_id,
					"adListingTypeId" => $r->ad_listing_type_id,
					"adName" => $r->ad_name,
					"adEmail" => $r->ad_email,
					"adContact" => $r->ad_contactno,
					"adLocation" => $r->ad_location,
					"adSuburbs" => $r->ad_suburbs,
					"login_status" => $r->ad_status,
					"aboutDescription" => $r->about_description,
					"adCountry" => $r->ad_country,
					"plan_expiry" => $r->plan_expired,
					"short_image" =>$short_image,
					"adImage" => $allimage,
					"adBanner" => $banner,
					"rate" => $rate,
					"page_links" =>$page_links,
					"metaData" => $metaData,
					"agency_id" =>  (int)$r->agency_id,
					"club_id" =>  (int)$r->club_id,
					"Expired" => "not"
				);
			}
		}
		$ressOffline = array();
		$listOffline = array();
		if(count($ressOffline) > 0){	
			$page_linksOffline = paginateResults(count($ress1Offline), $request->fullUrl(), !empty($input['page']) ? $input['page'] : 1);
			/*print_r($ressOffline);
			die('jjj');*/
	
			foreach($ressOffline as $rOffline){
			
				$metaDataOffline = getAllMetaData($rOffline->id);

				$bannerOffline = Image::where('media_ad_id', $rOffline->id)->where('media_type','Banners')
						->limit(1)->get();
				$login_statusOffline=fetchLoginStatus($rOffline->ad_user_id);
				$allimageOffline = Image::where('media_ad_id', $rOffline->id)->where('media_type','Images')
				->where('media_status','!=', 'Reject')->where('media_is_default', 1 )->get();
				$imageOffline = Image::where('media_ad_id', $rOffline->id)->where('media_type','Images')
				->where('media_status','!=', 'Reject')->where('media_is_default', 1 )->first();
				$verifiedOffline = mediaStatusCheckbyId($imageOffline->id);
		        if($verified){
		            $short_imageOffline = $imageOffline->media_filename;
		        }else{
		            $short_imageOffline = "unverified_".$imageOffline->media_filename;
		        }
				$rateOffline  = AdRate::select()->where('ad_id', $r->id)->min('incall_charge');
				$listOffline[] = array(
					"adId" => $rOffline->id,
					"slug" => $rOffline->slug,
					"adUserId" => $rOffline->ad_user_id,
					"adListingTypeId" => $rOffline->ad_listing_type_id,
					"adName" => $rOffline->ad_name,
					"adEmail" => $rOffline->ad_email,
					"adContact" => $rOffline->ad_contactno,
					"adLocation" => $rOffline->ad_location,
					"adSuburbs" => $rOffline->ad_suburbs,
					"login_status" => $rOffline->ad_status,
					"aboutDescription" => $rOffline->about_description,
					"adCountry" => $rOffline->ad_country,
					"short_image" =>$short_imageOffline,
					"adImage" => $allimageOffline,
					"adBanner" => $bannerOffline,
					"rate" => $rateOffline,
					"page_links" =>$page_linksOffline,
					"metaData" => $metaDataOffline,
					"agency_id" =>  (int)$rOffline->agency_id,
					"club_id" =>  (int)$rOffline->club_id,
					"Expired" => "Yes"
				);
			}
		}
		//var_dump($ress);


		if(!empty($res->id)){

			$ss = boostingProfiles(array('listing_type_id'=> $res->id, 'gender'=>$gender,'orientation' => $orientations));
			$teaservideo =	getTeaserVideo(array('listing_type_id'=> $res->id, 'gender'=>$gender));
			if($filtergender == 'Male'){
				$dedcated_video = getDedicatedVideo(array('listing_type_id'=>$res->id,'gender'=>'male'));
			}else if($res->cat_type=='photographer'){
				$dedcated_video = getDedicatedVideo(array('listing_type_id'=>$res->id));
			}else{
				$dedcated_video = getDedicatedVideo(array('listing_type_id'=>$res->id,'gender'=>$gender));
			}
			
		}
		if($res->cat_type == 'agency'){
			$only_indi = getOnlyIndividualType();
			$ss = boostingProfiles(array('is_agency'=> true, "only_indi" => $only_indi));
			$teaservideo =	getTeaserVideo(array('is_agency'=> true));
			$dedcated_video = getDedicatedVideo(array('is_agency'=>true,'gender'=>$input['gender']));
		}
		if($res->cat_type == 'club'){
			$only_indi = getOnlyIndividualType();
			$ss = boostingProfiles(array('is_club'=> true, "only_indi" => $only_indi));
			$teaservideo =	getTeaserVideo(array('is_club'=> true));
			$dedcated_video = getDedicatedVideo(array('is_club'=>true,'gender'=>$input['gender']));
		}

		

		$boostprofiles = array_chunk($ss, ceil(count($ss)/4));
		
		$url = 'frontend.ads.'.$slug.'.post_listing';
		
			return view($url)->with('list', $list)
		->with('listOffline', $listOffline)
		->with('generalsettings', $this->generalSettings )
		->with('master_age',$master_age)
		->with('countries',$countries)
		->with('master_age',$master_age)
		->with('master_body_type',$master_body_type)
		->with('master_service_type',$master_service_type)
		->with('master_nationality',$master_nationality)
		->with('master_dress_size', $master_dress_size)
		->with('master_bust_size', $master_bust_size)
		->with('master_service_available', $master_service_available)
		->with('master_shoe_size', $master_shoe_size)
		->with('master_haircolor', $master_haircolor)
		->with('master_eyecolor', $master_eyecolor)
		->with('master_hair_length', $master_hair_length)
		->with('master_piercing', $master_piercing)
		->with('title', $title)
		->with('ethinicity', $ethinicity)
		->with('slug', $slug)
		->with('gender', $gender)
		->with('orientation', $orientation)
		->with('orientations', $orientations)
		->with('page_links', $page_links)
		->with('inputdata', $input)
		
		->with('master_orientation', $master_orientation)
		->with('boostprofiles', $boostprofiles)
		->with('filtergender', $filtergender)
		->with('liveactivity', $liveact)
		->with('dedicated_video', $dedcated_video)
		->with('teaservideo', $teaservideo)->with('listingtype_id', $res->id);

	}
	function postListing1(){
		 $gender = \Request::query('gender');
		
		$model = new MetaData;
		
		$master_age = MainMaster::all()->where('meta_name','age');
		$master_body_type = MainMaster::all()->where('meta_name','body-type');
		$master_nationality = MainMaster::all()->where('meta_name','nationality');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		$master_service_type = MainMaster::all()->where('meta_name','service-type');
		$master_dress_size = MainMaster::all()->where('meta_name','dresssize');
		$master_bust_size = DB::table('master')->where('meta_name','bustsize')->groupBy('meta_value')->get();
	
		$master_shoe_size = MainMaster::all()->where('meta_name','shoessize');
		$master_eyecolor = MainMaster::all()->where('meta_name','eyecolor');
		$master_haircolor = MainMaster::all()->where('meta_name','haircolor');
		 $cityids = getNearByCitiesByIp($_COOKIE['user_latitude'], $_COOKIE['user_longitude']);
		$slug = \Request::segment(2);
		$countries = Countries::all();

		$res = DB::table('listing_type')->where("slug", $slug)->get();
		if(count($res) == 0){
			
			$list = array();

		}else{

			if($res[0]->cat_type == 'agency'){
				$only_indi = getOnlyIndividualType();
				$list = fetchFeatuedListing(array("is_agency" => true, "cityids" => $cityids,"ad_type" => "individual","only_indi" => $only_indi));
				$title = $res[0]->title;
				$ss = boostingProfiles(array('is_agency'=> true));
				$teaservideo =	getTeaserVideo(array('is_agency'=> true));
     	


			}else if($res[0]->cat_type == 'club'){
				$only_indi = getOnlyIndividualType();
				$list = fetchFeatuedListing(array("is_club" => true, "cityids" => $cityids, "ad_type" => "individual","only_indi" => $only_indi));
				$title = $res[0]->title;
				$teaservideo =	getTeaserVideo(array('is_club'=> true));
				$ss = boostingProfiles(array('is_club'=> true));

			}else{

				if(!empty($gender)){
					
					$records = UserAdMeta::where("meta_key","gender")->where('meta_value', $gender)->get();
					$ad_ids = array();
					if(count($records) > 0){
						foreach($records as $rs){
							$ad_ids[] = $rs->ad_id;
						}
						$array = array(
							"listing_type_id" => $res[0]->id,
							"ad_ids" =>implode(',',$ad_ids),
							"cityids" => $cityids,
							"ad_type" =>$res[0]->cat_type
						);

						$list = fetchFeatuedListing($array);
						$title = $res[0]->title." ".$gender;
					}else{
						$list = array();
					}

				}else{
					$array = array(
							"listing_type_id" => $res[0]->id,
							"cityids" => $cityids,
							"ad_type" =>$res[0]->cat_type
						);

					
					$list = fetchFeatuedListing($array);
					$title = $res[0]->title;
				}
				$ss = boostingProfiles(array('listing_type_id'=> $res[0]->id));
				$teaservideo =	getTeaserVideo(array('listing_type_id'=> $res[0]->id));
			}
				
	 }


		$liveact = getLiveUpdates();

		$boostprofiles = array_chunk($ss, ceil(count($ss)/4));
	
		
		$url = 'frontend.ads.'.$slug.'.post_listing';
			
			return view($url)->with('list', $list)
		->with('generalsettings', $this->generalSettings )->with('master_age',$master_age)
		->with('countries',$countries)
		->with('master_age',$master_age)
		->with('master_body_type',$master_body_type)
		->with('master_service_type',$master_service_type)
		->with('master_nationality',$master_nationality)
		->with('master_dress_size', $master_dress_size)
		->with('master_bust_size', $master_bust_size)
		->with('master_shoe_size', $master_shoe_size)
		->with('master_haircolor', $master_haircolor)
		->with('master_eyecolor', $master_eyecolor)
		->with('title', $title)
		->with('slug', $slug)
		->with('gender', $gender)
		->with('boostprofiles', $boostprofiles)
		->with('liveactivity', $liveact)
		->with('teaservideo', $teaservideo)->with('listingtype_id', $res[0]->id);
		
	}

	//adult jobs start
	function saveAdultJobs(Request $request){

		$validator = Validator::make( $request->all(),  [
                "ad_name" => 'required|min:3',
                "ad_email" =>'required',
                "ad_contactno" => 'required',
                'country_name' => 'required',
                'city_name' => 'required',
                'suburbs' => 'required',
                'job_title' => 'required',
                'about_description' => 'required'
                
                
            ],[
                "ad_name.required" => "Please enter your name.",
                "ad_name.min" => "Your name must be atleast 3 character long.",
                "ad_email.required" => "Please enter your  email.",
                "ad_contactno.required" => "Please enter phone number.",
                "country_name.required" => "Please choose your country.",
                "city_name.required" => "Please choose your city name.",
                "suburbs.required" => "Please enter your Suburbs/Local area.",             
                "job_title.required" => "Please enter job title.",
                'about_description.required' => "Please enter job description."
               
   
            ]);

	if ($validator->fails()) {
			
			return Response::json( array( 'errors' => $validator->getMessageBag()->toArray() ) );
			   
		}


		$images  = $request->input('imageurl');
		$video = $request->input('videourl');
		$banners = $request->input('banner');
		
		$user_data = Auth::user();
		$user_ad_id =$request->input('user_ad_id');
		$ads_id = $request->input('user_ad_id');
		if(!empty($ads_id)){
		$userAds = UserAdvertisement::findOrFail($ads_id);
		if($userAds->ad_listing_type_id != $request->input("ad_listing_type_id")){
			$user_ad_id = "";
		}
	}
		if(!empty($user_ad_id)){
		
		$userAd = UserAdvertisement::findOrFail($request->input('user_ad_id'));
		$userAd->ad_user_id = $user_data->id;
		$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
		$userAd->ad_name = $request->input("ad_name");
		$userAd->ad_email = $request->input("ad_email");
		$userAd->ad_contactno = $request->input("ad_contactno");
		$userAd->ad_country = $request->input("country_name");
		$userAd->ad_location = $request->input("city_name");
		$userAd->ad_suburbs = $request->input("suburbs");
		$userAd->about_description = $request->input("about_description");
		$userAd->slug = str_slug($request->input("ad_name"));

		if(!empty($request->session()->get('agency_id'))){
				$userAd->agency_id = $request->session()->get('agency_id');
			}
			if(!empty($request->session()->get('club_id'))){
				$userAd->club_id = $request->session()->get('club_id');
			}
		//$userAd->status = 1;
		$userAd->save();
		
		$ad_id = $userAd->id;
		
	}else{

		$userAd = new UserAdvertisement();
		$userAd->ad_user_id = $user_data->id;
		$userAd->ad_listing_type_id = $request->input("ad_listing_type_id");
		$userAd->ad_name = $request->input("ad_name");
		$userAd->ad_email = $request->input("ad_email");
		$userAd->ad_contactno = $request->input("ad_contactno");
		$userAd->ad_country = $request->input("country_name");
		$userAd->ad_location = $request->input("city_name");
		$userAd->ad_suburbs = $request->input("suburbs");
		$userAd->about_description = $request->input("about_description");
		$userAd->slug = str_slug($request->input("ad_name"));

		if(!empty($request->session()->get('agency_id'))){
				$userAd->agency_id = $request->session()->get('agency_id');
			}
			if(!empty($request->session()->get('club_id'))){
				$userAd->club_id = $request->session()->get('club_id');
			}
		$userAd->status = 0;
		$userAd->draft = 1;
		$userAd->save();
		
		$ad_id = $userAd->id;
		
	}
	if(!empty($request->input("suburbs"))){
				$subname = $request->input("suburbs");
				$cname = $request->input("country_name");
				$cityname = $request->input("city_name");
				$suburb = Suburbs::where("suburbs_name", $subname)->where("country_id", $cname)->where("city_id", $cityname)->get();
				if(count($suburb) == 0){
					$subsobj = new Suburbs();
					$subsobj->country_id = $cname;
					$subsobj->city_id = $cityname;
					$subsobj->suburbs_name = $subname;
					$subsobj->save();
				}

			}

	if(count($images) > 0){
		$image_thumb_width =  $this->generalSettings['ad_image_thumb_width'];
		$image_thumb_height =  $this->generalSettings['ad_image_thumb_height'];
		$image_large_width = $this->generalSettings['ad_image_large_width'];
		$image_large_height = $this->generalSettings['ad_image_large_height'];
		$watermark_image = $this->generalSettings['watermark_image'];
		$watermark_position = $this->generalSettings['watermark_image_position'];

		$user_folder = md5(Auth::user()->id);
		$folder_path = public_path('upload/ads_image/'.$user_folder);
   
	    if(!File::isDirectory($folder_path)){
	        File::makeDirectory($folder_path, 0777, true, true);
	    }
		foreach($images as $img){
			if(!empty($img['image'])){
			$image_name = $img['image'];
			$pathinfo = pathinfo($img['image']);
			$filename =  $pathinfo['filename'].'.'.$pathinfo['extension'];

			 $path = exec('python3'.' '.public_path('photoscript/test.py ').' '.$filename.','.$image_large_width.','.$image_large_height.','.$image_thumb_width.','.$image_thumb_height.','.$watermark_image.','.$watermark_position.','.$user_folder.' 2>&1', $out);	

			$imageObj = new Image();
			$imageObj->media_ad_id = $ad_id;
			$imageObj->media_filename = $filename;
			$imageObj->media_status = 'Verified';
			if(!empty($img['img_is_add_default'])){
				$update = DB::table('ad_media')->where('media_ad_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

				$imageObj->media_is_default = 1;
			}else{
				if($keys == 0){
					$update = DB::table('ad_media')->where('media_ad_id', $ad_id)->where('media_type','Images')->update(array('media_is_default'=> 0));

					$imageObj->media_is_default = 1;
				}
			}
			$imageObj->media_type = "Images";

			$imageObj->save();
			/*$imagesa = array(

				$filename,$filename."_508*762.jpg",$filename."_252*384.jpg",$filename."_202*182.jpg",$filename."_377*625.jpg",$filename."_982*560.jpg"
			);
			foreach($imagesa as $im){
				
			@unlink(public_path('uploads/ads_image/'.$im));
			}
			*/
		}
		}
	}
	
	
	
		if(count($video) > 0){

		foreach($video as $vid){
			if(!empty($vid)){
			$imageObj = new Image();
			$imageObj->media_ad_id = $ad_id;
			$imageObj->media_filename = $vid;
			$imageObj->media_status = 'Verified'; 
			$imageObj->media_type = "Videos";
			$imageObj->media_storage = 'Cloudflare';
			$imageObj->save();
		}
		}
	}

	
		if(count($banners) > 0){

		foreach($banners as $bnn){
			if(!empty($bnn)){
			$imageObj = new Image();
			$imageObj->media_ad_id = $ad_id;
			$imageObj->media_filename = $bnn;
			$imageObj->media_status = 'Verified'; 
			$imageObj->media_type = "Banners";
		
			$imageObj->save();
		}
		}
	}

		$request->session()->put('user_ad_id', $ad_id);
		$requestData = $request->all();
		unset($requestData['ad_listing_type_id']);
		unset($requestData['ad_name']);
		unset($requestData['ad_email']);
		unset($requestData['ad_contactno']);
		unset($requestData['country_name']);
		unset($requestData['city_name']);
		unset($requestData['suburbs']);
		unset($requestData['about_description']);
		unset($requestData['user_ad_id']);
		unset($requestData['_token']);
		unset($requestData['imageurl']);
		unset($requestData['teaservideourl']);
		unset($requestData['banner']);
	
		$request->session()->put('form_step', '2');
		foreach($requestData as $key => $req){
			$fetchExistData  = UserAdMeta::select()->where([
				['meta_key', '=', $key],
				['ad_id', '=', $ad_id],
			]);	
			if(count($fetchExistData) > 0){
					$fetchExistData->delete();
			}
				if(is_array($requestData[$key])){
				
					foreach($req as $r){
						if(!empty($r)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $r;
						$user_ad_meta->ad_id = $ad_id;
						//print_r($user_ad_meta);
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));
						}
						
					}
				}else{
					
						if(!empty($req)){
						$user_ad_meta = new UserAdMeta();
						$user_ad_meta->meta_key = $key;
						$user_ad_meta->meta_value = $req;
						$user_ad_meta->ad_id = $ad_id;
						$user_ad_meta->save();
						//$query = \DB::getQueryLog();
						//print_r(end($query));
						}
			}

		}

		if($userAd->mail_sent == 0){

			DB::table('activity_log')->insert(
			['user_id' => Auth::user()->id, 'ad_id'=>$ad_id,'activity_message'=>$userAd->ad_name." has posted a job","created_at" => date("Y-m-d h:i:s"),"updated_at"=> ("Y-m-d h:i:s")]
			);
			$live_data['user_lattitude'] = $_COOKIE['user_latitude'];
			$live_data['user_longitude'] = $_COOKIE['user_longitude'];
			$live_data['action'] = 'updateactivity';
			//sendRequesToServer($live_data);

			$email_content_admin = array();
			$email_content_admin["user_name"] = 'Admin';
			$email_content_admin["ad_name"] =$userAd->ad_name;
			$listing_name = listingtype($userAd->ad_listing_type_id);
		
			$email_content_admin["listing_type"] =$listing_name[$userAd->ad_listing_type_id]['title'];
			$email_content_admin["verify_link"] = '<a href="'.url('/admin/posts/'.$listing_name[$userAd->ad_listing_type_id]['slug']).'" target="_blank">Click Here</a>';
			$email_message_admin = new EmailMessage();
			$admin_notification_email= $this->generalSettings['admin_notification_email'];
			//$admin_notification_email = 'sushma@vocso.com';
			$email_message_admin->singleMailSendIntegration( $admin_notification_email, "NewAdPostAdded", $email_content_admin );
			$newUserData = UserAdvertisement::findOrFail($userAd->id);
			$newUserData->mail_sent = 1;
			$newUserData->save();
			}
	
}
	//end adult jobs details
public function saveJobFeaturedBanner(Request $request){
		
		$data = $request->all();
		$featuredbanners  = $data['featuredbanners'];
		$user_ad_id = $request->input('user_ad_id');
		$userData = UserAdvertisement::findOrFail($user_ad_id);
		$userData->status = 1;
		$userData->draft = 0;
		$userData->save();
		$username = UserAdvertisement::where('id', $user_ad_id)->first()->ad_name;
	
		if(count($featuredbanners) > 0){
		foreach($featuredbanners as $vid){
			if(!empty($vid)){
			$imageObj = new Image();
			$imageObj->media_filename = $vid;
			$imageObj->media_type = "Featured Banner";
			$imageObj->media_status = "Verified";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->save();
		}
		}
	}
	
		return $username;
	}
	



public function allAdultJobs(){

		$master_arr = fetchAllMasterData();
		$social_media_links = $master_arr['social_media_link'];
		$other_ads = new OtherAds;
		$otherAds = OtherAds::select()
		->orderBy('sort_order')->skip(0)
		->take(4)->get();

	return view('frontend.ads.adult-jobs.adult_all_jobs')
		->with("generalsettings", $this->generalSettings)	
		->with('social_media_links',$social_media_links)
		->with('other_ads',$otherAds);
}


public function jobdetail(){

		$master_arr = fetchAllMasterData();
		$social_media_links = $master_arr['social_media_link'];
		$other_ads = new OtherAds;
		$otherAds = OtherAds::select()
		->orderBy('sort_order')->skip(0)
		->take(4)->get();

	return view('frontend.ads.adult-jobs.adult_job_details')
		->with("generalsettings", $this->generalSettings)	
		->with('social_media_links',$social_media_links)
		->with('other_ads',$otherAds);
}


function getAgencyDetail($id="", $user_id = "", $slug=""){
	$metadata = array();
	$newRes = array();
	if(empty($id) && empty($user_id) && empty($slug)){
		return array();
	}
	$details = AgencyDetails::where('listing_type_id', $id)->where('status', '1')->get();
	if(!empty($user_id)){
		$details = AgencyDetails::where('listing_type_id', $id)->where('status', '1')->where('user_id', $user_id)->get();
	}
	if(!empty($slug)){
		$details = AgencyDetails::where('slug', $slug)->where('status', '1')->get();
	}

	foreach($details as $r){
		 $agencyMeta = \App\Models\AgencyMeta::where('agency_id', $r->id)->get();
           foreach($agencyMeta as $data){
            
                $metadata[$data->meta_key][] = $data->meta_value;
            
           }
		$image = AgencyImages::where('agency_id', $r->id)->where('media_type','Images')->get();
		$video = AgencyImages::where('agency_id', $r->id)->where('media_type','Videos')->get();
		$banner = AgencyImages::where('agency_id', $r->id)->where('media_type','Banners')->limit(1)->get();
		$login_status=fetchLoginStatus($r->user_id);
		$newRes[] = array(
			"agencyId" => $r->id,
			"UserId" => $r->user_id,
			"slug" => $r->slug,
			"name" => $r->name,
			"email" => $r->email,
			"plan_id" => $r->plan_id,
			"plan_purchased" =>$r->plan_purchased,
			"plan_expired" => $r->plan_expired,
			"escorts_limit" => $r->escorts_limit,
			"phone" => $r->phone,
			"listingtypeid" => $r->listing_type_id,
			"city" => $r->city,
			"country" => $r->country,
			"website" => $r->website,
			"description" => $r->description,
			"suburbs" => $r->suburbs,
			"agencyImage" => $image,
			"agencyBanner" => $banner,
			"agencyVideo" => $video,
			"login_status" => $login_status,
			'metaData' =>$metadata
		);
		
	}

	return $newRes;
}
	

//get club details start
function getClubDetail($id="", $user_id = "", $slug=""){

	$metadata = array();
	$newRes = array();
	if(empty($id) && empty($user_id) && empty($slug)){
		return array();
	}
	$details = ClubDetails::where('listing_type_id', $id)->where('status', '1')->get();
	if(!empty($user_id)){
		$details = ClubDetails::where('listing_type_id', $id)->where('status', '1')->where('user_id', $user_id)->get();
	}
	if(!empty($slug)){
		$details = ClubDetails::where('slug', $slug)->where('status', '1')->get();
	}

	foreach($details as $r){

		 $clubMeta = \App\Models\ClubMeta::where('club_id', $r->id)->get();
           foreach($clubMeta as $data){
            
                $metadata[$data->meta_key][] = $data->meta_value;
            
           }

		$image = ClubImages::where('club_id', $r->id)->where('media_type','Images')->get();
		

		$video = ClubImages::where('club_id', $r->id)->where('media_type','Videos')->get();
		$banner = ClubImages::where('club_id', $r->id)->where('media_type','Banners')->get();
		$login_status=fetchLoginStatus($r->user_id);
		$newRes[] = array(
			"clubID" => $r->id,
			"UserId" => $r->user_id,
			"slug" => $r->slug,
			"name" => $r->name,
			"email" => $r->email,
			"phone" => $r->phone,
			"plan_id" => $r->plan_id,
			"plan_purchased" =>$r->plan_purchased,
			"plan_expired" => $r->plan_expired,
			"escorts_limit" => $r->escorts_limit,
			"listingtypeid" => $r->listing_type_id,
			"city" => $r->city,
			"country" => $r->country,
			"description" => $r->description,
			"website" => $r->website,
			"suburbs" => $r->suburbs,
			"clubImages" => $image,
			"clubVideo" => $video,
			"clubBanner" => $banner,
			"login_status" => $login_status,
			'metaData' =>$metadata
		);
		
	}

	return $newRes;
}

//end club details

function savegencyplandetails(Request $request){
		$today = time();
		$requestData = $request->all();
		// print_r($requestData);
		// die('ff');
		$escorts = $requestData['number_of_escorts_selected'];
		$plan_id = $requestData['escort_selected_plan'];
		$agency_id = $request->session()->get('agency_id');
		$plans = Plans::where('id', $plan_id)->first();
		$duration = $plans->plan_duration;
		$duration_unit = $plans->plan_duration_unit;
		$expiry_date = strtotime('+ '.$duration.' '.$duration_unit, time());
		$expiry = $expiry_date;
		$agencyObj = AgencyDetails::findOrFail($agency_id);
		$agency_name = AgencyDetails::findOrFail($agency_id)->first()->name;
		$agencyObj->plan_id = $plan_id;
		$agencyObj->plan_purchased = $today;
		$agencyObj->plan_expired = $expiry_date;
		$agencyObj->escorts_limit = $escorts;
		$agencyObj->save();
		// print_r($agencyObj);
		// die('jj');
		return $agency_name;

	}
	function saveclubplandetails(Request $request){
		$today = time();
		$requestData = $request->all();
		// print_r($requestData);
		// die('ff');
		$escorts = $requestData['number_of_escorts_selected'];
		$plan_id = $requestData['escort_selected_plan'];
		$club_id = $request->session()->get('club_id');
		$plans = Plans::where('id', $plan_id)->first();
		$duration = $plans->plan_duration;
		$duration_unit = $plans->plan_duration_unit;
		$expiry_date = strtotime('+ '.$duration.' '.$duration_unit, time());
		$expiry = $expiry_date;
		$clubObj = ClubDetails::findOrFail($club_id);
		$club_name = ClubDetails::findOrFail($club_id)->first()->name;
		$clubObj->plan_id = $plan_id;
		$clubObj->plan_purchased = $today;
		$clubObj->plan_expired = $expiry_date;
		$clubObj->escorts_limit = $escorts;
		$clubObj->save();
		// print_r($clubObj);
		// die('jj');
		return $club_name;
	}

function SaveTrialDetails(Request $request){

	$current_plan_id = $request->input('plan_id');
	$type = $request->input('frontend');
 		
		$current_plan_details =  Plans::where('id', $current_plan_id)->first();
		$number_of_days = $current_plan_details->plan_duration;

		if(empty($this->user) ){
			
			 return Response::json( array( 'message' =>'login/create account to post your Free Trial Ad.'));
			
		}

		if($type == 'frontend' && !empty($this->user)){
			if(!is_New_User($this->user->id) || was_user_mobile_deleted($this->user->phone) || was_user_email_deleted($this->user->email) || $agencyad>8){
		  		return Response::json(array("message" => "Oops... sorry, you can't get another Free trial because it's looks like that your current ad is still running. 21 Days Free trial can be used only one time."));
			}else{
			if(is_agency() && is_club()){
				return Response::json(array("message" => "Agecy"));
				
			}else{
				return Response::json(array("message" => "individual"));
				
			}
		}
		}

		if(is_agency()){
			    $agencyData = getAgencyDataByUserId($this->user->id);
			    $agencyad = getAgencyAd($agencyData->id);
			}elseif(is_club()){
			     $agencyData = getClubDataByUserId($this->user->id);
			     $agencyad = getclubyAd($agencyData->id);
			   
			}
		if(!is_agency() && !is_club()){
			if(!is_New_User($this->user->id) || was_user_mobile_deleted($this->user->phone) || was_user_email_deleted($this->user->email) || $agencyad>8){
		   return Response::json(array("message" => "Oops... sorry, you can't get another Free trial because it's looks like that your current ad is still running. $number_of_days Days Free trial can be used only one time."));
		}

		}else{
			if(was_user_mobile_deleted($this->user->phone) || was_user_email_deleted($this->user->email) || $agencyad>8){
		   return Response::json(array("message" => "Oops... sorry, you can't get another Free trial because it's looks like that your current ad is still running. $number_of_days Days Free trial can be used only one time."));
			}
		}	
		
		$today= time();

		$current_plan_id = $request->input('plan_id');
 		
		$current_plan_details =  Plans::where('id', $current_plan_id)->first();
	
		$listDetails =  DB::table('listing_type')->where("id", $request->input('listing_type_id'))->first();
		

	
		$current_plan_price = $current_plan_details->plan_price_base;

		$duration = $current_plan_details->plan_duration;
		$duration_unit = $current_plan_details->plan_duration_unit;
		$expiry_date = strtotime('+ '.$duration.' '.$duration_unit, time());
		$expiry = $expiry_date;

		
		$user_ad_id = !empty($request->input('trail_ad_id')) ?$request->input('trail_ad_id') :$request->session()->get('user_ad_id');


		for ($i=0; $i<$duration ; $i++) {
			$daysArray[] = $i; 
		}
		$userAdDataGender = DB::table('user_ad_meta')->where('ad_id',$user_ad_id)->where('meta_key','rdo')->first();
		$implodeDays = implode(",", $daysArray);
		$trial_details = new Order();
		$trial_details->ad_id = $user_ad_id;
		$trial_details->user_id = Auth::user()->id;
		//$trial_details->invoice_no = $invoice_no;
		$trial_details->email = Auth::user()->email;
		$trial_details->order_status = "Success";
		$trial_details->plan_purchased = $today;
		$trial_details->plan_expired = $expiry;

		$trial_details->plan_id = $request->input('plan_id');
		$trial_details->total_amount = $current_plan_price;
		$trial_details->plan_actual_price = $current_plan_price;
		if($listDetails->cat_type == 'individual' || $listDetails->cat_type == 'male'){
			$trial_details->featured_profile_price  = $duration * 1.99;
			$trial_details->featured_profile_day = $duration;
			$trial_details->teaser_video_day = $duration;
			$trial_details->teaser_video_price = $duration * 1.99;;
			$trial_details->super_speed_boost_day = $duration;
			$trial_details->super_speed_boost_price = $duration * 1.99;;
			$trial_details->featured_profile_days = $implodeDays;
			$trial_details->teaser_video_days = $implodeDays;
			$trial_details->super_speed_boost_days = $implodeDays;
		}

		if($listDetails->cat_type == 'individual'||$listDetails->cat_type == 'photographer' || $listDetails->cat_type == 'male'){
			$trial_details->teaser_video_two_day = $duration;
			$trial_details->teaser_video_two_price = $duration * 1.99;;
			$trial_details->teaser_video_two_days = $implodeDays;
		}
		if($listDetails->cat_type == 'job'  || $listDetails->cat_type == 'photographer'){
			$trial_details->featured_banner_price  = $duration * 1.99;;
			$trial_details->featured_banner_day = $duration;
			$trial_details->featured_banner_days = $implodeDays;
			
		}
	
		$trial_details->save();

		//save transection  data to invoices table
	if($trial_details->order_status ='Success'){
		$invoice = new Invoices();
		$invoice->ad_id = $trial_details->ad_id;
		$invoice->order_id = $trial_details->id;
		$invoice->user_id = $trial_details->user_id;
		$invoice->plan_id = $trial_details->plan_id;
		$invoice->plan_purchased = $trial_details->plan_purchased;
		$invoice->plan_expired = $trial_details->plan_expired;
		$invoice->featured_profile_price = $trial_details->featured_profile_price;
		$invoice->teaser_video_price = $trial_details->teaser_video_price;
		$invoice->featured_banner_price = $trial_details->featured_banner_price;
		$invoice->teaser_video_two_price = $trial_details->teaser_video_two_price;
		$invoice->super_speed_boost_price = $trial_details->super_speed_boost_price;
		$invoice->total_amount = $trial_details->total_amount;
		$invoice->order_status ='Success' ;
		$invoice->txntype = '';
		$invoice->response_text = '';
		$invoice->merchant_reference = '';
		$invoice->paid_amount = '';
		$invoice->client_ip = \Request::ip();
		$invoice->email = $trial_details->email;
		$invoice->bank_auth_code = '';
		$invoice->save();
}


		$todaytimes = date('Y-m-d');
		if($listDetails->cat_type == 'individual' || $listDetails->cat_type == 'male'){
		$deletedRows = AdsAddOnFeatures::where('ad_id', $trial_details->ad_id)->where('feature_name', 'featured_profiles')->delete();	
		
		$addon = new AdsAddOnFeatures();
		$explodeDays = explode(',',$implodeDays);
		$addOnExpiryDateMultiple = '';
		foreach ($explodeDays as $key => $daysvals) {
			$newdaysVal = $daysvals;
			$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$todaytimes +$newdaysVal days"));
			if($key < (count($explodeDays)-1)){
				$addOnExpiryDateMultiple .= ",";
			}
			//var_dump($daysvals);
		}
		$addon->multiple_expiry = $addOnExpiryDateMultiple;
		$addon->feature_name = "featured_profiles";
		$addOnExpiryDate = $expiry_date;
		$addon->expiry = $addOnExpiryDate;
		$addon->status = 1;
		$addon->ad_id = $trial_details->ad_id;
		$addon->save();
		$deletedRows = AdsAddOnFeatures::where('ad_id', $trial_details->ad_id)->where('feature_name', 'teaser_video')->delete();
		$addon = new AdsAddOnFeatures();
		$explodeDays = explode(',',$implodeDays);
		$addOnExpiryDateMultiple = '';
		foreach ($explodeDays as $key => $daysvals) {
			$newdaysVal = $daysvals;
			$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$todaytimes +$newdaysVal days"));
			if($key < (count($explodeDays)-1)){
				$addOnExpiryDateMultiple .= ",";
			}
			//var_dump($daysvals);
		}
		$addon->multiple_expiry = $addOnExpiryDateMultiple;
		$addon->feature_name = "teaser_video";
		$addOnExpiryDate = $expiry_date;
		$addon->expiry = $addOnExpiryDate;
		$addon->status = 1;
		$addon->ad_id = $trial_details->ad_id;
		$addon->save();
		$deletedRows = AdsAddOnFeatures::where('ad_id', $trial_details->ad_id)->where('feature_name', 'super_speed_boost')->delete();
		$addon = new AdsAddOnFeatures();
		$explodeDays = explode(',',$implodeDays);
		$addOnExpiryDateMultiple = '';
		foreach ($explodeDays as $key => $daysvals) {
			$newdaysVal = $daysvals;
			$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$todaytimes +$newdaysVal days"));
			if($key < (count($explodeDays)-1)){
				$addOnExpiryDateMultiple .= ",";
			}
			//var_dump($daysvals);
		}
		$addon->multiple_expiry = $addOnExpiryDateMultiple;
		$addon->feature_name = "super_speed_boost";
		$addOnExpiryDate = $expiry_date;
		$addon->expiry = $addOnExpiryDate;
		$addon->status = 1;
		$addon->ad_id = $trial_details->ad_id;
		$addon->save();

		}
		if($listDetails->cat_type == 'individual' || $listDetails->cat_type == 'photographer' || $listDetails->cat_type == 'male'){
			$deletedRows = AdsAddOnFeatures::where('ad_id', $trial_details->ad_id)->where('feature_name', 'teaser_video_two')->delete();
		$addon = new AdsAddOnFeatures();
		$explodeDays = explode(',',$implodeDays);
		$addOnExpiryDateMultiple = '';
		foreach ($explodeDays as $key => $daysvals) {
			$newdaysVal = $daysvals;
			$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$todaytimes +$newdaysVal days"));
			if($key < (count($explodeDays)-1)){
				$addOnExpiryDateMultiple .= ",";
			}
			//var_dump($daysvals);
		}
		$addon->multiple_expiry = $addOnExpiryDateMultiple;
		$addon->feature_name = "teaser_video_two";
		$addOnExpiryDate = $expiry_date;
		$addon->expiry = $addOnExpiryDate;
		$addon->status = 1;
		$addon->ad_id = $trial_details->ad_id;
		$addon->save();
		}
		if($listDetails->cat_type == 'job' || $listDetails->cat_type == 'photographer'){
			$deletedRows = AdsAddOnFeatures::where('ad_id', $trial_details->ad_id)->where('feature_name', 'featured_banner')->delete();
			$addon = new AdsAddOnFeatures();
			$explodeDays = explode(',',$implodeDays);
			$addOnExpiryDateMultiple = '';
			foreach ($explodeDays as $key => $daysvals) {
				$newdaysVal = $daysvals;
				$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$todaytimes +$newdaysVal days"));
				if($key < (count($explodeDays)-1)){
					$addOnExpiryDateMultiple .= ",";
				}
				//var_dump($daysvals);
			}
			$addon->multiple_expiry = $addOnExpiryDateMultiple;
			$addon->feature_name = "featured_banner";
			$addOnExpiryDate = $expiry_date;
			$addon->expiry = $addOnExpiryDate;
			$addon->status = 1;
			$addon->ad_id = $trial_details->ad_id;
			$addon->save();
		}
		if($listDetails->cat_type == 'individual' && $userAdDataGender->meta_value == 'female'){
		$msg = "Hi Congratulations! You have qualified for the $number_of_days days free trial thats including Ultra Premium Ad plus following ADD-ONs - Featured Sexy Girl + Sexy Girls Teaser";
		}

		if($listDetails->cat_type == 'individual' && $userAdDataGender->meta_value == 'trans'){
		$msg = "Hi Congratulations! You have qualified for the $number_of_days days free trial thats including Ultra Premium Ad plus following ADD-ONs - Featured Sexy Girl + Sexy Girls Teaser";
		}

		if($listDetails->cat_type == 'individual' && $userAdDataGender->meta_value == 'male'){
		$msg = "Hi Congratulations! You have qualified for the $number_of_days days free trial thats including Ultra Premium Ad plus following ADD-ONs - Featured Sexy Male + Sexy Male Teaser";
		}
		if($listDetails->cat_type == 'photographer'){
		$msg = "Hi Congratulations! You have qualified for the $number_of_days days free trial thats including Ultra Premium Ad";
		}
		if($listDetails->cat_type == 'job'){
		$msg = "Hi Congratulations! You have qualified for the $number_of_days days free trial thats including Ultra Premium Ad";
		}
		if($listDetails->cat_type == 'male'){
			$msg = "Hi Congratulations! You have qualified for the $number_of_days days free trial thats including Ultra Premium Ad plus following ADD-ONs - Featured Sexy Male + Sexy Male Teaser";	
		}

		$ad_id = $trial_details->ad_id;
		$boost_interval = "10 minutes";
		
		$t1 = time();
		$t2 = $expiry_date;
		$diff = $t2 - $t1;
		$hours = $diff / ( 60 * 60 );
		$interval = round(($hours * 60) / 10);
		$total_boost =  $interval;
		/*$res = AdBoostLog::where('ad_id', $ad_id)->first();
		if(count($res) > 0){
			$vi = AdBoostLog::findOrFail($res->id);
			$vi->ad_id = $ad_id;
			$vi->boost_interval = $boost_interval;
			$vi->total_boost = $total_boost;
			$vi->next_boost_time = strtotime('+ 20 minutes', time());
			$vi->save();
		}else{
			$vi = new AdBoostLog();
			$vi->ad_id = $ad_id;
			$vi->boost_interval = $boost_interval;
			$vi->total_boost = $total_boost;
			$vi->next_boost_time = strtotime('+ 20 minutes', time());
			$vi->save();
		}*/
		$userData = UserAdvertisement::findOrFail($user_ad_id);
		$userData->plan_purchased = $today;
		/*
		if(check_verification_video_status() > 0){
		$userData->status = 1;
		$userData->draft =0;
		}else{
			$userData->status == $userData->status ==1 ? 1 :0;
			$userData->draft =$userData->status ==1 ? 0 :1;
		}
		*/
		$userData->status = $userData->status ==1 ? 1 :0;
		
		$userData->plan_expired = $expiry;
		$userData->plan_id = $current_plan_id;
		$userData->next_boost_time = strtotime('+ 20 minutes', time());
		$userData->save();
		$user = Auth::user();

		$admin_notification_email = $this->generalSettings['admin_notification_email'];
	 	$site_name = $this->generalSettings['master_agency_name'];
	  	$address = $this->generalSettings['master_agency_address'];
	   	$site_address = html_entity_decode($address);
	   	$encrypted_link = Crypt::encryptString($invoice->id."&".$invoice->ad_id);
	$planDetails = Plans::findOrFail($invoice->plan_id);
	// $dump_data = json_encode($planDetails);
	// $insert_DUmpDAta =  DB::table('dump_data')->insert(['dump_data' => $dump_data]);

		$email_content = array();
		$email_content["user_name"] = ucwords( $user->name );
		$email_content["expiry_date"] = date("j<\s\up>S<\/\s\up> M Y", $expiry);
		$email_content["amount"] = $current_plan_price;
		$admin_notification_email = $this->generalSettings['admin_notification_email'];
		$email_content1 = array();
		$email_content1["user_name"] = ucwords( $user->name );
		$email_content1["expiry_date"] = date("j<\s\up>S<\/\s\up> M Y", $expiryDate);
		$email_content1["amount"] = $current_plan_price;

		// NEW
					$email_content2 = array();
					$email_content2["user_name"] = ucwords( $user->name );
					$email_content2["user_email"] = $user->email;
					$email_content2["user_phone"] = $user->phone;
					$email_content2["invoice_no"] = 'HOSG-'.$invoice->id;
					$email_content2["site_name"] = $site_name;
					$email_content2["site_address"] = $site_address;
					if($invoice->plan_id != ''){
					$email_content2["plan_name"] = $planDetails->plan_name;
					$email_content2["plan_details"] = substr($planDetails->plan_features, 0, 100);
					$email_content2["plan_unit_price"] = $planDetails->plan_price_base;
					}else{
					$email_content2["plan_name"] = '';
					$email_content2["plan_details"] = '';
					$email_content2["plan_unit_price"] = '';
					}
					

					if($invoice->featured_profile_price != ''){
						$email_content2["featured_sexy_profile"] = 'Featured Sexy Girl';
						$email_content2["featured_sexy_price"] = $invoice->featured_profile_price;
					}else{
						$email_content2["featured_sexy_profile"] = '';
						$email_content2["featured_sexy_price"] = '';
					}

					if($invoice->teaser_video_price != ''){
						$email_content2["featured_sexy_teaser_video"] = "Sexy Girl Teaser Video";
						$email_content2["featured_sexy_teaser_price"] = $invoice->teaser_video_price;
					}else{
						$email_content2["featured_sexy_teaser_video"] = "";
						$email_content2["featured_sexy_teaser_price"] = '';
					}
					if($invoice->teaser_video_two_price != ''){
						$email_content2["dedicated_sexy_teaser_video"] = 'Dedicated Teaser Video';
						$email_content2["dedicated_sexy_teaser_price"] = $invoice->teaser_video_two_price;
					}else{
						$email_content2["dedicated_sexy_teaser_video"] = '';
						$email_content2["dedicated_sexy_teaser_price"] = '';
					}
					if($invoice->super_speed_boost_price != ''){
						$email_content2["super_boost"] = "Super Boost";
						$email_content2["super_boost_price"] = $invoice->super_speed_boost_price;
					}else{
						$email_content2["super_boost"] = "";
						$email_content2["super_boost_price"] = '';
					}
					if($invoice->featured_banner_price != ''){
						$email_content2["featured_banner"] = "Featured Banner";
						$email_content2["featured_banner_price"] = $invoice->featured_banner_price;
					}else{
						$email_content2["featured_banner"] = "";
						$email_content2["featured_banner_price"] = '';
					}	
					
		$email_content2["total_price"] = $planDetails->plan_price_base + $invoice->featured_profile_price + $invoice->teaser_video_price + $invoice->teaser_video_two_price+$invoice->super_speed_boost_price+$invoice->featured_banner_price;
					$email_content2["ad_id"] = $invoice->ad_id;
					$email_content2["order_id"] = $invoice->order_id;
					$email_content2["invoice_date"] = date('d-m-y h:i A', strtotime($invoice->created_at));
					$email_content2["download_pdf"] = route('downloadAsPdf',$encrypted_link);
					

					$email_message = new EmailMessage();
					$email_message->singleMailSendIntegration( $user->email, "Invoice", $email_content2 );
					$email_message->singleMailSendIntegration( $admin_notification_email, "Invoice", $email_content2 );

		// END NEW 

		$email_message = new EmailMessage();
		$email_message->singleMailSendIntegration( $user->email, "PaymentConfirm", $email_content );
		$email_message->singleMailSendIntegration( $admin_notification_email, "PaymentConfirm", $email_content1 );
		return Response::json(array("message" => $msg));
}

function FreeTrialUsed(){

    return view('frontend.free_trial_used')
    	->with("generalsettings", $this->generalSettings );
}



		function upgradeAdOns(Request $request){
			
		$this->validate($request, [
			'order_id' => [ 'required'],
			/*'featured_sexy_girls' => ['required_without_all:sexy_girl_teaser_video, dedicated_teaser_video,super_boost,featured_banner'],
			'sexy_girl_teaser_video' => ['required_without_all:featured_sexy_girls,dedicated_teaser_video,super_boost,featured_banner'],
			'dedicated_teaser_video' => ['required_without_all:dedicated_teaser_video,super_boost,featured_banner,featured_sexy_girls'],
			'super_boost' => ['required_without_all:super_boost'],
			'featured_banner' => ['required_without_all:dedicated_teaser_video,super_boost,dedicated_teaser_video,featured_sexy_girls'],*/
			
        ], [
            'order_id.required' => 'Something worng. Please try again later.',
            /*'featured_sexy_girls.required_without_all' => 'Please select atleast one add Ons',
            'sexy_girl_teaser_video.required_without_all' => 'Please select atleast one add Ons',
            'dedicated_teaser_video.required_without_all' => 'Please select atleast one add Ons',
            'super_boost.required_without_all' => 'Please select atleast one add Ons',
            'featured_banner.required_without_all' => 'Please select atleast one add Ons',*/
            
        ]);
		$data = $request->all();

		$order_id = $data['order_id'];
		$details = Order::findOrFail($order_id);


		$featured_sexy_girls = $data['featured_sexy_girls'];
		$original_featured_sexy_girls = explode("-",$data['original_featured_sexy_girls']);

		$sexy_girl_teaser = $data['sexy_girl_teaser_video'];
		$original_sexy_girl_teaser_video = explode("-",$data['original_sexy_girl_teaser_video']);

		$featured_banner = $data['featured_banner'];
		$original_featured_banner = explode("-",$data['original_featured_banner']);

		$teaser_video_two = $data['dedicated_teaser_video'];
		$original_dedicated_teaser_video = explode("-",$data['original_dedicated_teaser_video']);

		$super_speed = $data['super_boost'];
		$original_super_boost = explode("-",$data['original_super_boost']);

		$featured_plan_price = $featured_sexy_girls;
		$fetaured_plan_day = $data['original_featured_sexy_girls'];
		$fetaured_plan_days = $data['original_featured_sexy_girls'];

		$teaser_plan_price = $sexy_girl_teaser;
		$teaser_plan_day = $data['original_sexy_girl_teaser_video'];
		$teaser_plan_days = $data['original_sexy_girl_teaser_video'];
	
		$featured_banner_price= $featured_banner;
		$featured_banner_day = $data['original_featured_banner'];
		$featured_banner_days = $data['original_featured_banner'];

		
		$teaser_video_two_price = $teaser_video_two;
		$teaser_video_two_day = $data['original_dedicated_teaser_video'];
		$teaser_video_two_days = $data['original_dedicated_teaser_video'];

		$super_speed_price = $super_speed;
		$super_speed_day = $data['original_super_boost'];
		$super_speed_days = $data['original_super_boost'];

		$datas = array();
		 $orderExpire = strtotime(date('Y-m-d', $details->plan_expired));
		 $request->session()->put('user_ad_id',$details->ad_id);
		if(!empty($teaser_plan_day) && !empty($teaser_plan_price)){
			$datas['teaser_plan_day'] = $teaser_plan_day;
			$datas['teaser_plan_price'] = $teaser_plan_price;
			$today = $details->plan_purchased;
			if($teaser_plan_day ==1){
				$teaserday = $today;
			}else{
				$teaserday = strtotime('+ '.($teaser_plan_day-1).' days', $today);
			}
			
			
			  $tocheckday= strtotime(date('Y-m-d', $teaserday));
			
			
			if($orderExpire <= $tocheckday){
				
				$msg =  "Please choose sexy teaser add ons days less than your plan expiry day";
				return back()->with('message', $msg);
				/// return ['sexy_girl_teaser.required_without' => $msg,];
			}
		}
		if(!empty($fetaured_plan_day) && !empty($featured_plan_price)){
			$datas['fetaured_plan_day'] = $fetaured_plan_day;
			$datas['featured_profile_price'] = $featured_plan_price;
			$today = $details->plan_purchased;
			if($fetaured_plan_day ==1){
				$fday = $today;
			}else{
				 $fday = strtotime('+ '.($fetaured_plan_day-1).' days', $today);
			}
			
			  $tocheckfday= strtotime(date('Y-m-d', $fday));
			if($orderExpire <= $tocheckfday){
				$msg =  "Please choose featured sexy girls add ons days less than your plan expiry day";
				return back()->with('message', $msg);
				//return ['featured_sexy_girls.required_without' => $msg,];
			}
		}
		if(!empty($featured_banner_day) && !empty($featured_banner_price)){
			$datas['featured_banner_day'] = $featured_banner_day;
			$datas['featured_banner_price'] = $featured_banner_price;
			$today = $details->plan_purchased;
			if($featured_banner_day ==1){
				$fbday = $today;
			}else{
				  $fbday = strtotime('+ '.($featured_banner_day-1).' days', $today);
			}
			
			$tocheckfbday= strtotime(date('Y-m-d', $fbday));
			
			if($orderExpire <= $tocheckfbday){
				$msg = "Please choose featured banner add ons days less than your plan expiry day";
				return back()->with('message', $msg);
				//retrun $validator->errors()->add('featured_banner.required_without', $msg);
				//return ['featured_banner.required_without' => $msg,];
			}
		}

		if(!empty($teaser_video_two_day) && !empty($teaser_video_two_price)){
			$datas['teaser_video_two_day'] = $teaser_video_two_day;
			$datas['teaser_video_two_price'] = $teaser_video_two_price;
			$today = $details->plan_purchased;
			 
			
			if($teaser_video_two_day ==1){
				$fbday = $today;
			}else{
				  $fbday = strtotime('+ '.($teaser_video_two_day-1).' days', $today);
			}
			$tocheckfbday= strtotime(date('Y-m-d', $fbday));
			if($orderExpire <= $tocheckfbday){
				$msg = "Please choose featured banner add ons days less than your plan expiry day";
				return back()->with('message', $msg);
				//retrun $validator->errors()->add('featured_banner.required_without', $msg);
				//return ['featured_banner.required_without' => $msg,];
			}
		}

		if(!empty($super_speed_day) && !empty($super_speed_price)){
			$datas['super_speed_boost_day'] = $super_speed_day;
			$datas['super_speed_boost_price'] = $super_speed_price;
			$today = $details->plan_purchased;
			if($super_speed_day ==1){
				$fbday = $today;
			}else{
				 $fbday = strtotime('+ '.($super_speed_day-1).' days', $today);
			}
			 
			$tocheckfbday= strtotime(date('Y-m-d', $fbday));
			
			if($orderExpire <= $tocheckfbday){
				$msg = "Please choose featured banner add ons days less than your plan expiry day";
				return back()->with('message', $msg);
				//retrun $validator->errors()->add('featured_banner.required_without', $msg);
				//return ['featured_banner.required_without' => $msg,];
			}
		}
		
		if(count($datas) > 0){
		//$addons = json_encode($datas);
		//$request->session()->put('update_addons', $addons);
		}

			$total = 0;
			if(!empty($teaser_plan_price)){
				$total += $teaser_plan_price;
			}
			if(!empty($featured_plan_price)){
				$total += $featured_plan_price;
			}

			if(!empty($featured_banner_price)){
				$total += $featured_banner_price;
			}
			
			if(!empty($super_speed_price)){
				$total += $super_speed_price;
			}

			if(!empty($teaser_video_two_price)){
				$total += $teaser_video_two_price;
			}

			$total_amount = round($total, 2);
		$addOnsUpgrade = new addOnsUpgrade();
		$addOnsUpgrade->featured_profile_price = $featured_plan_price;
		$addOnsUpgrade->teaser_video_price = $teaser_plan_price;
		$addOnsUpgrade->featured_banner_price = $featured_banner_price;
		$addOnsUpgrade->teaser_video_day = $teaser_plan_day;
		$addOnsUpgrade->featured_profile_day = $fetaured_plan_day;
		$addOnsUpgrade->featured_banner_day = $featured_banner_day;
		$addOnsUpgrade->teaser_video_two_day = $teaser_video_two_day;
		$addOnsUpgrade->teaser_video_two_price = $teaser_video_two_price;
		$addOnsUpgrade->super_speed_boost_day = $super_speed_day;
		$addOnsUpgrade->super_speed_boost_price = $super_speed_price;
		$addOnsUpgrade->teaser_video_days = $teaser_plan_days;
		$addOnsUpgrade->featured_profile_days = $fetaured_plan_days;
		$addOnsUpgrade->featured_banner_days = $featured_banner_days;
		$addOnsUpgrade->teaser_video_two_days = $teaser_video_two_days;
		$addOnsUpgrade->super_speed_boost_days = $super_speed_days;
		$addOnsUpgrade->order_id = $order_id;
		$addOnsUpgrade->total_pay_amount = $total_amount;

		$addOnsUpgrade->save();

		
		//new amount 
		// $upgrade_price = $featured_plan_price + $teaser_plan_price);
		// print_r($upgrade_price);
		// die('done');

		$encrypted_order_id = Crypt::encryptString($addOnsUpgrade->id);
		$url = url('redirectaddonspayform?token='.$encrypted_order_id);
		return redirect($url);

	}
			function redirectAddOnsPayForm(Request $request){

		$updates  = $request->session()->get('update_addons');
			//$addsData = json_decode($updates, true);
			$teaser_plan_day = $addsData['teaser_plan_day'];
			$teaser_plan_price =  $addsData['teaser_plan_price'];
			$fetaured_plan_day =  $addsData['fetaured_plan_day'];
			$featured_profile_price =  $addsData['featured_profile_price'];
			$featured_banner_day =  $addsData['featured_banner_day'];
			$featured_banner_price =  $addsData['featured_banner_price'];
			$total = 0;
			if(!empty($teaser_plan_price)){
				$total += $teaser_plan_price;
			}
			if(!empty($featured_profile_price)){
				$total += $featured_profile_price;
			}
			if(!empty($featured_banner_price)){
				$total += $featured_banner_price;
			}
		$total_amount = round($total, 2);
		
		$data = $request->all(); 
		$dcrypted_order_id = Crypt::decryptString($data['token']);
		$orderDetail = addOnsUpgrade::where('id', $dcrypted_order_id)->first();
		$general_setting = generalSettings();
		
		$currencyCode = $general_setting['selected_payment_currency'];
		if(count($orderDetail) > 0){
		$html = '<form action="'.route('paypax').'" method="post" id="paxpay_form">';
		$html .= '<input name="Quantity" value="1" type="hidden"/>';
		$html .= '<input name="Reference"  value="ref" type="hidden"/>';
		$html .= '<input name="_token"  value="'.csrf_token().'" type="hidden"/>';
		$html .= '<input name="Address1"  value="'.$orderDetail->id.'" type="hidden"/>';
		$html .= '<input name="Address2"  value="'. $this->user->id.'" type="hidden"/>';
		$html .= '<input name="Address3" value="addons-upgrade" type="hidden"/>';
		$html .= '<input name="Price" value="'.$orderDetail->total_pay_amount.'" type="hidden"/>';
		$html .= '<input name="CurrencyCode" value="'.$currencyCode.'" type="hidden"/>';
		//$html .= '<input name="Userid" value="'.$this->user->id.'" type="hidden"/>';
		$html .= '<input name="EmailAddress" value="'.$this->user->email.'" type="hidden"/>';
		$html .= '<input type="hidden" name="ForcePaymentMethod" value="Account2Account">';
		$html .= '<input typ name="returnURL" value="'.route('paypaxsuccess').'" type="hidden"/>'	;
		$html .= '</form>';
		$data['html'] = $html;
		
		return view('frontend.paypax.payment_add_on_form', $data);
	}
	}

function photographerAddons(Request $request){
		$data = $request->all();
		$featuredbanners  = $data['featuredbanners'];
		$dedicatedvideourl = $data['dedicatedvideourl'];
		$user_ad_id = !empty($data['user_ad_id']) ? $data['user_ad_id'] : $request->session()->get('user_ad_id');
		$userData = UserAdvertisement::findOrFail($user_ad_id);
		$userData->status = 1;
		$userData->draft = 0;
		$userData->save();
		$username = UserAdvertisement::where('id', $user_ad_id)->first()->ad_name;
	
		if(count($featuredbanners) > 0){
			foreach($featuredbanners as $vid){
				if(!empty($vid)){
				$imageObj = new Image();
				$imageObj->media_filename = $vid;
				$imageObj->media_type = "Featured Banner";
				$imageObj->media_ad_id = $user_ad_id;
				$imageObj->media_status = 'Verified';
				$imageObj->save();
			}
		}
	}
	if(count($dedicatedvideourl) > 0){

		foreach($dedicatedvideourl as $dvid){
			if(!empty($dvid)){
			$imageObj = new Image();
			$imageObj->media_filename = $dvid;
			$imageObj->media_type = "Dedicated Video";
			$imageObj->media_ad_id = $user_ad_id;
			$imageObj->media_storage = 'Cloudflare';
			$imageObj->save();
		}
	}
}
///start new working code
		if(count($data['working_hours']) > 0){
			foreach($data['working_hours'] as $d){
				$working_date = $d['working_date'];
				$working_start_time = strtotime($d['working_start_time']);
				$working_end_time = strtotime($d['working_end_time']);
				$real_working_start_time = strtotime($working_date.' '.$d['working_start_time']);
				$real_working_end_time = strtotime($working_date.' '.$d['working_end_time']);
				$dayoff = $d['working_dayoff'];
				if(!empty($working_start_time) && !empty($working_end_time) || $dayoff=='on'){
				$working_hours = AdWorkingHours::where('ad_id', $user_ad_id)->where('working_date', $working_date)->first();

				if(count($working_hours) > 0){
					$working = AdWorkingHours::findOrFail($working_hours->id);
					if($dayoff == 'on'){
			          $working->working_start_time = NULL;
			          $working->working_end_time = NULL;
			          $working->dayoff = 'yes';
			          $working->save();
			        }else{
			          $working->working_start_time = $real_working_start_time;
			          $working->working_end_time = $real_working_end_time;
			          $working->dayoff = NULL;
			          $working->save();
			        }
				}else{
			        $working =new AdWorkingHours();
			        if($dayoff == 'on'){
				          $working->ad_id = $user_ad_id;
				          $working->working_date = $working_date;
				          $working->working_start_time = NULL;
				          $working->working_end_time = NULL;
				          $working->dayoff = 'yes';
				          $working->save();
			        }else{
				        $working->ad_id = $user_ad_id;
				        $working->working_date = $working_date;
				        $working->working_start_time = $real_working_start_time;
				        $working->working_end_time = $real_working_end_time;
				        $working->dayoff = NULL;
				        $working->save();
			        }
			      }
			  }

			}
		}

		$tourData = AdsTouring::select()->where('ad_id', $user_ad_id);
		$tourData->delete();
		$updatedates = array();
		if(!empty($data['old_tour']) && !empty($data['new_tour'])){
			$localTourData = array_merge($data['old_tour'], $data['new_tour']);
		}elseif(!empty($data['old_tour']) && empty($data['new_tour'])){
			$localTourData = $data['old_tour'];
		}else{
			$localTourData = $data['new_tour'];
		}
		
		
		foreach($localTourData as $tour){
			
			if(!empty($tour['city']) && !empty($tour['country']) && !empty($tour['startdate']) && !empty($tour['enddate'])){
				
			/*$start_tour_date = strtotime(str_replace("/","-",$tour['startdate']));
			$end_tour_date = strtotime(str_replace("/","-",$tour['enddate']));
			$rec = AdsTouring::where('from_date', $start_tour_date)->where('to_date', $end_tour_date)->where('ad_id', $user_ad_id)->where('country_id', getDefaultCountry())->first();
			if(count($rec) > 0){
				$adtour_obj = AdsTouring::findOrFail($rec->id);
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->save();
			}else{*/
				DB::connection()->enableQueryLog();
				$queries = DB::getQueryLog();
				$adtour_obj = new AdsTouring();
				$adtour_obj->ad_id = $user_ad_id;
				$adtour_obj->from_date = strtotime(str_replace("/","-",$tour['startdate']));
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->to_date = strtotime(str_replace("/","-",$tour['enddate']));
				$adtour_obj->save();
				//$updatedates[] = $tour['stratdate'];
				$last_query = end($queries);

			/*}*/
			
			}

		}
		
		if(!empty($data['old_inter_tour']) && !empty($data['new_inter_tour'])){
			$interTourData = array_merge($data['old_inter_tour'], $data['new_inter_tour']);
		}elseif(!empty($data['old_inter_tour']) && empty($data['new_inter_tour'])){
			$interTourData = $data['old_inter_tour'];
		}else{
			$interTourData = $data['new_inter_tour'];
		}
	
		
		foreach($interTourData as $tour){
			
			if(!empty($tour['city']) && !empty($tour['country']) && !empty($tour['startdate']) && !empty($tour['enddate'])){

			/*$start_tour_date = strtotime(str_replace("/","-",$tour['startdate']));
			$end_tour_date = strtotime(str_replace("/","-",$tour['enddate']));
			DB::connection()->enableQueryLog();

			$rec = AdsTouring::where('from_date', $start_tour_date)->where('to_date', $end_tour_date)->where('ad_id', $user_ad_id)->where('country_id','!=', getDefaultCountry())->first();
			
			
			
			if(count($rec) > 0){
				
				$adtour_obj = AdsTouring::findOrFail($rec->id);
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->save();
			}else{
				*/
				$adtour_obj = new AdsTouring();
				$adtour_obj->ad_id = $user_ad_id;
				$adtour_obj->from_date = strtotime(str_replace("/","-",$tour['startdate']));
				$adtour_obj->city_id = $tour['city'];
				$adtour_obj->country_id = $tour['country'];
				$adtour_obj->to_date = strtotime(str_replace("/","-",$tour['enddate']));
				$adtour_obj->save();
				//$updatedates[] = $tour['stratdate'];
			//}
			
			}

		}

		$userData = UserAdvertisement::where('id', $user_ad_id)->first();
		if((count($questdata['new_tour']) > 0 && !empty($adtour_obj->id))|| (count($questdata['new_inter_tour']) > 0 && !empty($adtour_obj->id))){
			
			$ss = getSubscribeForByid('touring');
			$subscribers = getAdSubscriber($user_ad_id, $ss);
			
			if(count($subscribers) > 0){
				foreach($subscribers as $sb){
				$email_content_sub = array();
				$email_content_sub["user_name"] = !empty($sb->subs_name) ? $sb->subs_name : $sb->subs_email;
				$profile_url = url('profile/'.$userData->slug);
				$email_content_sub["content"] =$userData->ad_name.' has updated touring details.';
				$email_content_sub["view_profile_link"] = "View <a href=".$profile_url.">profile</a> for more details.";
				$email_message_admin = new EmailMessage();
					//$admin_notification_email = 'sushma@vocso.com';
				$email_message_admin->singleMailSendIntegration( $sb->subs_email,'AdNotification', $email_content_sub );
				}
				
			}
		}
		unset($data['tour']);
		unset($data['user_ad_id']);
		unset($data['old_tour']);
		unset($data['old_inter_tour']);

return $username;
///new working jcode end


}


}
