 {{-- Start Status Ad  --}}
  @php

    $current_time = date('h:i A');

    $current_time_1 = date('h:i A');
    
 $booking_day_data = get_booking_day($data['adId'],$current_time);
  
    foreach($booking_day_data as $key =>$bd){
    $booking_start_time[$bd->id][] =!empty($bd->booking_start_time) ? date("h:i A", $bd->booking_start_time):''; 
    $booking_end_time[$bd->id][] = !empty($bd->booking_end_time) ? date("h:i A", $bd->booking_end_time):'';
  } 

  $break_time = get_break_time($data['adId']);
foreach($break_time as $bt){
    $break_start_time[$bt->id][] =!empty($bt->booking_start_time) ? date("h:i A",$bt->booking_start_time):'';            
  $break_end_time[$bt->id][] = !empty($bt->booking_end_time) ? date("h:i A", $bt->booking_end_time):'';
  }

  $next_time_timestamp = getNextAvailableTime($data['adId'],$booking_end_time[$bd->id][0]);
  $next_time = $next_time_timestamp + 60;
  
 $nextavaildaytime = getNextWorkingDayTime($data['adId'], $data['plan_expired']);

foreach($nextavaildaytime as $nd){
  $nextstartTime_Timestamp[$nd->id][] = !empty($nd->working_start_time) ? $nd->working_start_time:'';
  $next_start_time[$nd->id][] =!empty($nd->working_start_time) ? date("h:i A",$nd->working_start_time):'';            
 $next_day_name[$nd->id][] = !empty($nd->working_date) ? $nd->working_date:'';
  }

  $getNextDayBooking = getNextDayBooking($data['adId'],$nextstartTime_Timestamp[$nd->id][0]);

    $get_today_working_hours = get_working_hours($data['adId'], date('Y-m-d'));
    $today_start_time =date("Y-m-d h:i A",$get_today_working_hours->working_start_time);
    $today_end_time = date("Y-m-d  h:i A",$get_today_working_hours->working_end_time );

     $getfutureworking = getFutureWorkingDayTime($data['adId'],$getNextDayBooking['booking_end_time']-900); 

     foreach($getfutureworking as $fd){
      $next_start_time[$fd->id][] =!empty($fd->working_start_time) ? date("h:i A",$fd->working_start_time):'';            
      $next_day_name[$fd->id][] = !empty($fd->working_date) ? $fd->working_date:'';
  }

 // print_r($getfutureworking);
@endphp
       
      @if (strtotime($current_time) >= strtotime($booking_start_time[$bd->id][0]) && strtotime($current_time) <= strtotime($booking_end_time[$bd->id][0]))
            
           @if($data['login_status'] == 1)
                      @if(strtotime($today_end_time) == ($next_time_timestamp -840) )
                        @if($getNextDayBooking['booking_start_time'] == $nextstartTime_Timestamp[$nd->id][0] )
                        <div class="live-btnpositon  Busy-btnpositon"> 
                            <span>Currently Busy 
                               <br>Next Avail : {{date("D",strtotime($next_day_name[$nd->id][0]))}},
                               {{date("h.iA",$getNextDayBooking['booking_end_time'])}} </span> 
                        
                       </div>
                       @else
                         <div class="live-btnpositon  Busy-btnpositon"> 
                            <span>Currently Busy 
                               <br>Next Avail : {{date("D",strtotime($next_day_name[$nd->id][0]))}},
                               {{date("h.iA",strtotime($next_start_time[$nd->id][0]))}} </span> 
                        
                       </div>
                       @endif
                       @else
                  
                    <div class="live-btnpositon  Busy-btnpositon"> 
                      <span>Currently Busy<br>Next Avail : {{date("h:i A",$next_time)}}</span> 
                    </div>
                    @endif

                    @else

            @if(count($nextavaildaytime )> 0)
             <div class="live-btnpositon Offliine-btnpositon">  
              <span>Offline  
               <br>Next Avail : {{date("D",strtotime($next_day_name[$nd->id][0]))}},
               {{date("h.iA",strtotime($next_start_time[$nd->id][0]))}} </span> 
              
            </div>
             @else
             <div class="live-btnpositon Offliine-btnpositon expiredProfile-btn">  
               <span>Currently offline.<br> Please Check Later</span>
                 @php
               $Expired = "Yes";
               @endphp
             </div>
               @endif

            @endif
                    @elseif(strtotime($current_time_1) > strtotime($break_start_time[$bt->id][0]) && strtotime($current_time_1) <= strtotime($break_end_time[$bt->id][0]))

               @if($data['login_status'] == 1)
                    <div class="live-btnpositon"> <span>Break Time</span> </div>
                    @else
                     @if(count($nextavaildaytime )> 0)
                       <div class="live-btnpositon Offliine-btnpositon">  
                        <span>Offline 
                         <br>Next Avail : {{date("D",strtotime($next_day_name[$nd->id][0]))}},
                         {{date("h.iA",strtotime($next_start_time[$nd->id][0]))}} </span> 
                        
                      </div>
                       @else
                       <div class="live-btnpositon Offliine-btnpositon expiredProfile-btn">  
                         <span>Currently offline.<br> Please Check Later</span>
                           @php
               $Expired = "Yes";
               @endphp
                       </div>
                         @endif
                @endif

                     @elseif($Expired == "Yes")
              <div class="live-btnpositon Offliine-btnpositon expiredProfile-btn"> 
              <span>Currently offline.<br/> Please Check Later</span> </div>
              
                    @else

                    @if($data['login_status'] == 1 && count($get_today_working_hours)> 0  && strtotime($current_time) > strtotime($today_start_time) && strtotime($current_time) <= strtotime($today_end_time))
                     <div class="live-btnpositon"> <span>Available Now</span> </div>
                     @else
                        @if(count($nextavaildaytime )> 0)

                        @if( strtotime($today_end_time) == ($getNextDayBooking['booking_end_time']-900))
                              
                         <div class="live-btnpositon Offliine-btnpositon"> 
                            <span>Offline
                               <br>Next Avail : {{date("D",strtotime($next_day_name[$fd->id][0]))}},
                               {{date("h.iA",strtotime($next_start_time[$fd->id][0]))}} </span> 
                        
                       </div>
                        @else  

                        @if($getNextDayBooking['booking_start_time'] == $nextstartTime_Timestamp[$nd->id][0] )
                        <div class="live-btnpositon Offliine-btnpositon"> 
                            <span>Offline
                               <br>Next Avail : {{date("D",strtotime($next_day_name[$nd->id][0]))}},
                               {{date("h.iA",$getNextDayBooking['booking_end_time'])}} </span> 
                        
                       </div>
                       @else
                       <div class="live-btnpositon Offliine-btnpositon">  
                        <span>Offline
                         <br>Next Avail : {{date("D",strtotime($next_day_name[$nd->id][0]))}},
                         {{date("h.iA",strtotime($next_start_time[$nd->id][0]))}} </span> 
                        
                      </div>
                      @endif
                      @endif
                      
                       @else
                       <div class="live-btnpositon Offliine-btnpositon expiredProfile-btn">  
                         <span>Currently offline.<br> Please Check Later</span>
                           @php
               $Expired = "Yes";
               @endphp
                       </div>
                       @endif

                         @endif
                     
                    @endif 

                    {{-- end  Status ad  --}}