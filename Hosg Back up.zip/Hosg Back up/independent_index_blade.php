@extends('frontend.layouts.front_layout')



@section('content')
@php

@endphp
<link rel="stylesheet" href="{{ asset('frontend/css/bootstrap-datetimepicker.min.css') }}">
<script type="text/javascript" src="{{asset('frontend/js/bootstrap-datetimepicker.min.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/daterangepicker.css') }}" />
<script type="text/javascript" src="{{asset('frontend/js/moment1.min.js')}}"></script>
<script type="text/javascript" src="{{asset('frontend/js/daterangepicker.min.js')}}"></script>
<div id="Load" class="load" style="display:none;">
    <div class="load__container">
        <div class="load__animation"></div>
        <div class="load__mask"></div>
        <span class="load__title">Loading...</span>
    </div>
</div>
<section class="profile-details-block">
    <div class="container container-Mobile">
        <div id="wizard" class="wizard clearfix">
         
          @include('frontend.ads.independent-female-escort.frontnav')
         {{-- @if(is_agency())
          @php
          $agencyData = getAgencyDataByUserId(Auth::user()->id);
          $planid = $agencyData->plan_id;
          $escorts_limit = $agencyData->escorts_limit;
          @endphp
          @if((int)$escorts_limit == 0 && (int)$planid==0)
          @include('frontend.ads.independent-female-escort.agency_select_escort')
          @endif
         @endif
         @if(is_club())
          @php
          $agencyData = getClubDataByUserId(Auth::user()->id);
          $planid = $agencyData->plan_id;
          $escorts_limit = $agencyData->escorts_limit;
          @endphp
          @if((int)$escorts_limit == 0 && (int)$planid==0)
          @include('frontend.ads.independent-female-escort.club_select_escort')
          @endif
         @endif--}}
         @include('frontend.ads.independent-female-escort.individualad_step_1')
         @include('frontend.ads.independent-female-escort.individualad_step_2')
         @include('frontend.ads.independent-female-escort.individualad_step_3')
         @include('frontend.ads.independent-female-escort.individualad_step_4')
         @include('frontend.ads.independent-female-escort.individualad_step_5')
         @include('frontend.ads.independent-female-escort.individualad_step_6')

       
      
         @include('frontend.ads.independent-female-escort.individualad_step_7')
         @include('frontend.ads.independent-female-escort.individualad_step_8')

         </div>
    </div>
</section>
<!-- Creates the bootstrap modal where the image will appear -->
<div class="modal fade cropImages" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
  <div class="modal-dialog" style=" max-width:700px; margin:0; vertical-align:center;">
    <div class="modal-content">
      <div class="modal-header">
	  <h2>Edit Image</h2>
	  
	    <div class="crop-btn-blocks">
        	<input type="hidden" name="imgeType" id="imgeType" value="">
        <input type="hidden" name="change" id="changeDone" value="">
           <a href="javascript:void(0)" class="crop-editbtns crop_image" onclick="cropImage()">Crop</a>
			 <a href="javascript:void(0)" class="crop-editbtns blur_image" onclick="blurImage()" >Blur</a>
			 <a href="javascript:void(0)" class="crop-editbtns blur_image" onclick="resetChanges()">Reset</a>
		</div>	 
			 
    
        <button type="button" class="close close-modal-btn" data-dismiss="modal" ><span aria-hidden="true">save</span><span class="sr-only">Close</span></button>
      </div>
      <div class="modal-body" style=" height: calc(100vh - 5em);  max-width: 550px">
       
      <img src="" id="imagepreview" class="img-responsive" style="max-width:100%;height: auto;">
      </div>      
    </div>
  </div>
</div>

    <!-- Cropping modal -->
   
    <!-- Cropping modal -->
    <!--div class="modal fade" id="avatar-modal" aria-hidden="true" aria-labelledby="avatar-modal-label" role="dialog" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <form class="avatar-form" action="crop.php" enctype="multipart/form-data" method="post">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title" id="avatar-modal-label">Change Avatar</h4>
            </div>
            <div class="modal-body">
              <div class="avatar-body">

               

                <!-- Crop and preview -->
                <!--div class="row">
                  <div class="col-md-12">
                    <div class="avatar-wrapper"></div>
                  </div>
                  
                  <div class="col-md-3">
                    <div class="preview_img"></div>
                  </div>
                <div class="row avatar-btns">
                  <div class="col-md-12">
                    <div class="btn-group">
                      <button type="button" class="btn btn-primary" onClick="cropImage()">Crop</button>
                      <button type="button" class="btn btn-primary" >Blur</button>
                      <button type="button" class="btn btn-primary">Save</button>
                     
                    </div>
                    
                  </div>
                  
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div><!-- /.modal -->

     <!-- Thank you update details modal pop up start -->
<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="SetDefaltWorkingHour-Popup" tabindex="-1" role="dialog"  aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">        
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
             <p>Would you like the system to automatically set all your following working days with the Same Working Hrs as well?</p> 
            <button type="button" class="yes-btn" data-dismiss="modal" aria-label="Close">
             Yes
            </button>
            <button type="button" class="close-cancel" data-dismiss="modal" aria-label="Close">
              No 
            </button>
          </div>
          <div class="modal-footer">
            
          </div>
        </div>
      </div>
    </div>
<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="update_details_popup" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    <p>Your details has been successfully updated.</p> 
    <a type="button" class="green_gredient_btn gr_pink" href="{{ $listdata['profile_link']}}" target="_blank">View Profile</a>         
      </div>  

<div class="modal-footer">

</div>
    
    </div>
  </div>
</div>
<div class="modal fade services-addTime thankyou-pop" id="update_Working_popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    <p>your working schedule is successfully updated.</p> 
    <a type="button" class="green_gredient_btn gr_pink" href="{{ $listdata['profile_link']}}" target="_blank">View Profile</a>        
      </div>  

<div class="modal-footer">

</div>
    
    </div>
  </div>
</div>
<!-- Thank you update details modal pop up End -->


 <!-- save as draft model popup start-->

<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="save_as_draft_popup" tabindex="-1" role="dialog" aria-hidden="true"  data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    <p>Details are saved in your Dashboard-Draft section, you can resume/edit/complete your ad anytime from there. </p> 
    <button type="button" class="green_gredient_btn gr_pink" onclick="window.location.href='{{ route('showDraft') }}'" >View Dashboard-Draft Section</button>         
      </div>  

<div class="modal-footer">

</div>
    
    </div>
  </div>
</div>
<!-- save as draft model popup start -->
<script type="text/javascript">
  
    
var imagePostURL = "{!! route('ajaximageupload') !!}";
var videoPostURL = "{!! route('ajaxvideoupload') !!}";
var teaservideoPostURL = "{!! route('ajaxteaservideoupload') !!}";
var dedicatedvideoPostURL = "{!! route('ajaxdedicatedvideoupload') !!}";
var fetchcityURL = "{!! route('fetchcitiesbycountry') !!}";
var deleteImageURL = "{!! route('deleteimage') !!}";
var deleteTourURL = "{!! route('deleteTour') !!}";
var setStatusImageURL = "{!! route('setimagestatus') !!}";
var stepUrl = "{!! route('savestep') !!}";
var token_value = "{{csrf_token()}}";

var fetchaddTour = "{!! route('fetchaddTour') !!}";
var fetchinteraddTour = "{!! route('fetchinteraddTour') !!}";

var form_step = '{{Request::session()->get('form_step')}}';
var fetchbookingtime = '{{route('getTimeByDate')}}';
var getbookingdetails = '{{route('getbookingdetails')}}';
var cancelBookingUrl = '{{route('cancelBooking')}}';
var getAllBookingCheckUrl = '{{route('getAllBookingSlotData')}}';


if (window.location.href.indexOf("step") > -1 && window.location.href.indexOf("edit-profile") > -1) {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = urlParams.get('step');
    form_step = myParam;
     var hash = window.location.hash;
   
  }
  if(form_step == '' || form_step == 'undefined' || form_step == null){
    $(".step_1").css('display','block');
  }
  //alert(form_step);

  if(form_step == '2'){
   $(".step_2").fadeIn('slow');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_0").fadeOut('fast');
    $(".step_7").fadeOut('fast');
     $(".verification_video_section").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');
}
if(form_step == '3'){

   $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeIn('slow');
  $(".step_4").fadeOut('fast');
   $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
   $(".verification_video_section").fadeOut('fast');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
}
if(form_step == '1'){
    $(".step_1").fadeIn('slow');
    $(".step_2").fadeOut('fast');
    $(".step_0").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_7").fadeOut('fast');
     $(".verification_video_section").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.first").removeClass('disabled').addClass('current');
}
if(form_step == '4'){
  $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeIn('slow');
      $(".step_0").fadeOut('fast');
      $(".step_7").fadeOut('fast');
       $(".verification_video_section").fadeOut('fast');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.four").removeClass('disabled').addClass('current');
    
}

if(form_step == '5'){
  $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeOut('fast');
      $(".step_0").fadeOut('fast');
      $(".step_7").fadeOut('fast');
       $(".verification_video_section").fadeIn('slow');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.five").removeClass('disabled').addClass('current');
    
}
</script>

<script src="{{ asset('frontend/js/ad_post_script.js') }}?v={{now()}}"></script>
{{--<script type="text/javascript" src="{{ asset('frontend/js/jquery.imgareaselect.pack.js') }}"></script>--}}
{{-- <script src='https://houseofsexygirls.co.nz/frontend/js/mobile_image_area.js'></script> --}}
<script src='https://houseofsexygirls.co.nz/frontend/js/imageareaselect.dev.js'></script>
{{-- <script src='https://houseofsexygirls.co.nz/frontend/js/jquery.selectareas.min.js'></script> --}}
<script src={{asset('frontend/js/croppezee.js?v='.date('his'))}} defer ></script>
<script type="text/javascript">
            $(function () {
                $('#calendar_date').datetimepicker();
            });
        </script>
<script>
  var draft_step1 = "{{(int)$listdata['step_1']}}";
  var draft_step2 = "{{(int)$listdata['step_2']}}";
  var draft_step3 = "{{(int)$listdata['step_3']}}";
  var draft_step4 = "{{(int)$listdata['step_4']}}";
  var draft_step5 = "{{(int)$listdata['step_5']}}";
/*$(document).ready(function(){


  if(parseInt(draft_step1) > 0 || parseInt(draft_step2) > 0 || parseInt(draft_step3) > 0 || parseInt(draft_step4) > 0 || parseInt(draft_step5)>0 ){
    alert("Sss");
    $("#save_as_draft_warning").modal('show');
    var mssg = '';
    if(parseInt(draft_step1) ==1){
      mssg +="step 1, ";
    }
     if(parseInt(draft_step2) ==1){
      mssg +="step 2, ";
    }
     if(parseInt(draft_step3) ==1){
      mssg +="step 3, ";
    }
     if(parseInt(draft_step4) ==1){
      mssg +="step 4, ";
    }
     if(parseInt(draft_step5) ==1){
      mssg +="step 5, ";
    }

    var new_msg = mssg.trim(", ");
    $("#warn_msg").text("there are unsaved data in "+new_msg);


  }
  })

*/
</script>
  <div class="modal fade services-addTime thankyou-pop" id="save_as_draft_warning" tabindex="-1" role="dialog" aria-hidden="true"  data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    <p id="warn_msg"></p> 
    <!-- <button type="button" class="green_gredient_btn gr_pink" onclick="window.location.href='{{ $listdata['profile_link'] }}'" >View Profile</button>   -->       
      </div>  

<div class="modal-footer">

</div>
    
    </div>
  </div>
</div>
@endsection

