var input = document.getElementById("pro-image");
var jcp ="";
var formdata = false;
var imageSalectionValue = '';
var $original_image;
var displayFireCrackers = false;
var date = new Date();
var d = date.getDate();
var m = date.getMonth();
var y = date.getFullYear();
var upgrade = false;
var genTokenValue ="";
var visible_width='';
var visible_height='';
var naturalWidth = '';
var naturalHeight='';
var selectableArea;
var save_step_4= false;
var dayoff="";
var some_date_range = [];
var scid="";
 $("body").on("keypress",".service_outcall_charge", function(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  })
  

  $("body").on("keypress",".service_incall_charge",function(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  })
   $("body").on("keypress",".extraservice_price",function(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  })



$(document).ready(function(){
var working_from ='';
var working_to ='';
var hnd='<img src="https://www.houseofsexygirls.co.nz/frontend/images/handsign2.png" class="hndicon" alt="handsign" style="display:none">';
var x1 = x2 = x3 = x4 = x5 = "";
x1=$("#update_step_1").parent();
x1.prepend(hnd);
x2=$("#update_step_2").parent();
x2.prepend(hnd);
x3=$("#update_step_3").parent();
x3.prepend(hnd);
x4=$("#update_step_4").parent();
x4.prepend(hnd);
x5=$("#update_step_5").parent();
x5.prepend(hnd);
$("form :input").change(function() {
  var hnd='<img src="https://www.houseofsexygirls.co.nz/frontend/images/handsign2.png" alt="handsign">';
  var x="";
      $("#update_step_1").removeClass('blink-btn');
      $("#update_step_1").addClass('blink-btn');
      $('#update_step_1').css('display','inline-block');
      

      $("#update_step_2").removeClass('blink-btn');
      $("#update_step_2").addClass('blink-btn');
      $('#update_step_2').css('display','inline-block');

      $("#update_step_3").removeClass('blink-btn');
      $("#update_step_3").addClass('blink-btn');
      $('#update_step_3').css('display','inline-block');

      $("#update_step_4").removeClass('blink-btn');
      $("#update_step_4").addClass('blink-btn');
      $('#update_step_4').css('display','inline-block');
      
      $("#update_step_5").removeClass('blink-btn');
      $("#update_step_5").addClass('blink-btn');
      $('#update_step_5').css('display','inline-block');
      

      $(".hndicon").css('display','inline-block');

});
 $(".working_from").change(function(){
      $("#update_step_3_duplicate").removeClass('blink-btn');
      $("#update_step_3_duplicate").addClass('blink-btn');
      var workingIDS = $(this).attr('id');
      var splitIDS = workingIDS.split("_");
      working_from = $("#"+splitIDS[0]+"_from").val();
      working_to = $("#"+splitIDS[0]+"_to").val();
      
      if(working_from != "" && working_to != ''){
         var startTime = new Date().setHours(GetHours(working_from), GetMinutes(working_from), 0);
        var endTime = new Date().setHours(GetHours(working_to), GetMinutes(working_to), 0);
        

        if (startTime > endTime) {
            alert('Please Select End time Greater Then Start Time');
            $("#"+splitIDS[0]+"_from").val('');
            $("#"+splitIDS[0]+"_to").val('');
            working_from = '';
            working_to = '';
        }
        if (startTime == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#"+splitIDS[0]+"_from").val('');
            $("#"+splitIDS[0]+"_to").val('');
            working_from = '';
            working_to = '';
        }
        if ((startTime+1) == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#"+splitIDS[0]+"_from").val('');
            $("#"+splitIDS[0]+"_to").val('');
            working_from = '';
            working_to = '';
        }
      }

      if(working_from != "" && working_to != ''){
        var workin_to_length = $('.working_to').length;
        //alert(workin_to_length);
        if(workin_to_length > 1){
          $("#SetDefaltWorkingHour-Popup").modal('show');
        }

      }
      /*alert(working_from);
      alert(working_to)*/
  });

  $(".working_to").change(function(){

      $("#update_step_3_duplicate").removeClass('blink-btn');
      $("#update_step_3_duplicate").addClass('blink-btn');
      var workingIDS = $(this).attr('id');
      var splitIDS = workingIDS.split("_");
      working_from = $("#"+splitIDS[0]+"_from").val();
      working_to = $("#"+splitIDS[0]+"_to").val();
      
      if(working_from != "" && working_to != ''){
         var startTime = new Date().setHours(GetHours(working_from), GetMinutes(working_from), 0);
        var endTime = new Date().setHours(GetHours(working_to), GetMinutes(working_to), 0);
        
        if (startTime > endTime) {
            alert('Please Select End time Greater Then Start Time');
            $("#"+splitIDS[0]+"_from").val('');
            $("#"+splitIDS[0]+"_to").val('');
            working_from = '';
            working_to = '';
        }
        if (startTime == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#"+splitIDS[0]+"_from").val('');
            $("#"+splitIDS[0]+"_to").val('');
            working_from = '';
            working_to = '';
        }
        if ((startTime+1) == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#"+splitIDS[0]+"_from").val('');
            $("#"+splitIDS[0]+"_to").val('');
            working_from = '';
            working_to = '';
        }
      }
      

      if(working_from != "" && working_to != ''){
        var workin_to_length = $('.working_to').length;
        //alert(workin_to_length);
        if(workin_to_length > 1){
          $("#SetDefaltWorkingHour-Popup").modal('show');
        }
        

      }
      /*alert(working_from);
      alert(working_to)*/
  });



  $(".yes-btn").click(function(){
      $('.working_from').val(working_from);
      $('.working_from').parent().removeClass('disabled_start_day_time');
      $('.working_to').parent().removeClass('disabled_end_day_time');

      $('.working_from option[value="'+working_from+'"]').attr('selected','selected');
      $('.working_to option[value="'+working_to+'"]').attr('selected','selected');

      $('.working_from').removeAttr('disabled');
      $('.working_to').removeAttr('disabled');
      $('.working_to').val(working_to);
      $('.dayoffCheckBox').removeAttr('checked');
      $(".working-hours-dayoff-block").removeClass('dayoff_on');
  });
  
  $("#calendar_start_time").change(function(){
      
      calendar_start_time = $("#calendar_start_time").val();
      calendar_end_time = $("#calendar_end_time").val();
      
      if(calendar_start_time != "" && calendar_end_time != ''){
         var startTime = new Date().setHours(GetHours(calendar_start_time), GetMinutes(calendar_start_time), 0);
        var endTime = new Date().setHours(GetHours(calendar_end_time), GetMinutes(calendar_end_time), 0);
        
        if (startTime > endTime) {
            alert('Please Select End time Greater Then Start Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if (startTime == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if ((startTime+1) == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if($("#cal_booking_id").val() == ''){
          var bookingDate = $('#calendar_date').val();
          var ads_id = $('#booking_ad_id').val();
          $.ajax({
            url : getAllBookingCheckUrl,
            method:'POST',
            data : {'ad_id':ads_id,'bookingDate':bookingDate,'starttime':calendar_start_time,'endtime':calendar_end_time,_token:token_value},
            success:function(response){
              if(response == "0"){
                alert('Please Select Diifrent Start Time And End Time because another booking is already booked on between start time and end time. please select different booking time slot.');
                $("#calendar_start_time").val('');
                $("#calendar_end_time").val('');
                calendar_start_time = '';
                calendar_end_time = '';

              }
            },
          });
        }
      }
      

      
      /*alert(working_from);
      alert(working_to)*/
  });
  $("#calendar_end_time").change(function(){
      
      calendar_start_time = $("#calendar_start_time").val();
      calendar_end_time = $("#calendar_end_time").val();
      
      if(calendar_start_time != "" && calendar_end_time != ''){
         var startTime = new Date().setHours(GetHours(calendar_start_time), GetMinutes(calendar_start_time), 0);
        var endTime = new Date().setHours(GetHours(calendar_end_time), GetMinutes(calendar_end_time), 0);
        
        if (startTime > endTime) {
            alert('Please select End time Greater Then Start Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if (startTime == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if ((startTime+1) == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }

        if($("#cal_booking_id").val() == ''){
          var bookingDate = $('#calendar_date').val();
          var ads_id = $('#booking_ad_id').val();
          $.ajax({
            url : getAllBookingCheckUrl,
            method:'POST',
            data : {'ad_id':ads_id,'bookingDate':bookingDate,'starttime':calendar_start_time,'endtime':calendar_end_time,_token:token_value},
            success:function(response){
              if(response == "0"){
                alert('Please Select Diifrent Start Time And End Time because another booking is already booked on between start time and end time. please select different booking time slot.');
                $("#calendar_start_time").val('');
                $("#calendar_end_time").val('');
                calendar_start_time = '';
                calendar_end_time = '';

              }
            },
          });
        }
      }
      

      
      /*alert(working_from);
      alert(working_to)*/
  });
 $(".startdate").prop('readonly', true);
 $(".inter_startdate").prop('readonly', true);
 $(".enddate").prop('readonly', true);
 $(".inter_enddate").prop('readonly', true);

  if (window.location.href.indexOf("step") > -1 && window.location.href.indexOf("edit-profile") > -1) {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = urlParams.get('step');
    form_step = myParam;
     var hash = window.location.hash;
   
  }
  //alert(form_step);

  if(form_step == '2'){
   $(".step_2").fadeIn('slow');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_0").fadeOut('fast');
    $(".step_7").fadeOut('fast');
     $(".verification_video_section").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');
}
if(form_step == '3'){

   $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeIn('slow');
  $(".step_4").fadeOut('fast');
   $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
   $(".verification_video_section").fadeOut('fast');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
}
if(form_step == '1'){
    $(".step_1").fadeIn('slow');
    $(".step_2").fadeOut('fast');
    $(".step_0").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_7").fadeOut('fast');
     $(".verification_video_section").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.first").removeClass('disabled').addClass('current');
}
if(form_step == '4'){
  $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeIn('slow');
      $(".step_0").fadeOut('fast');
      $(".step_7").fadeOut('fast');
       $(".verification_video_section").fadeOut('fast');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.four").removeClass('disabled').addClass('current');
    
}

if(form_step != '3'){
$(".step_3").css('display', 'block');
}
  
  /*$('.datepicker').datetimepicker({
       format: 'DD-MM-YYYY',
     });
   
 
   $('.timepicker').datetimepicker({
       format: 'HH:mm:ss'
   });*/
     

});

$( function() {

  var cal_selected_date="";
    selectableArea =  $( "#calendar-time-range" ).selectable({

  stop: function( event, ui ) {
    //alert('hello');
    var starttime = $(".ui-selected").first().text().trim();
    var endtime = $(".ui-selected").last().text().trim();
     var booking_id = $(".ui-selected").attr('data-booking-id');
     $(".Available-btn").remove();
     if(starttime == endtime){
      endtime = '';
     }
    
      if(booking_id){
      jQuery.ajax({
        type: 'POST',
        url: getbookingdetails,
        data: {'booking_id':booking_id,_token:token_value},
        success: function(data) {
          if(data){
             dayoff = data.dayoff;
             if(dayoff !='yes'){
            $(".breaktime-btn").after('<label for="booked" class="bookslot-btns Available-btn" style="width:160px"><input type="radio" name="slot_type" id="booked" value="Available" onclick="deleteBookingSlot(\''+booking_id+'\');"  class="bookingSlot-commonbtn"><span class="label"></span>Cancel Booking</label>')
            $("#title").val(data.records.booking_length);
            $("#client_name").val(data.records.client_name);
            $("#booking_notes").val(data.records.booking_notes);
            $("#services_popup").val(data.records.booking_services);
            $("#service-type").val(data.records.booking_service_type);
            $("#ex_services").val(data.records.booking_ex_services);
            $("#calendar_date").val(data.records.date);
            $("#calendar_start_time").val(data.records.booking_start_time);
            $("#calendar_end_time").val(data.records.booking_end_time);
            $("#booking_ad_id").val(data.records.ad_id);
            $("#cal_booking_id").val(booking_id);
            $('input[name="slot_type"][value="' + data.records.booking_slot_type + '"]').attr('checked', true);
            $(".bookslot-btns").removeClass('calanderbutton-active');
            $('input[name="slot_type"][value="' + data.records.booking_slot_type + '"]').parent().addClass('calanderbutton-active');
            $('.calanderbutton-active').find('input').trigger('click');
            $('#calendar_start_time').html(data.option_html);
            $('#calendar_end_time').html(data.option_html2);
            $("#services-addTime").modal('show');

           }
             
           }
        },
      });
      
    }
    if(dayoff != 'yes'){

        $("#title").val('');
        $("#client_name").val('');
        $("#booking_notes").val('');
        $("#services_popup").val('');
        $("#service-type").val('');
        $("#ex_services").val('');
        $("#cal_booking_id").val('');
        $(".bookslot-btns").removeClass('calanderbutton-active');
        $('input[name="slot_type"]').attr('checked', false);
        $('input[name="slot_type"][value="Booked"]').trigger('click');
     $("#services-addTime").modal('show');
     cal_selected_date = new Date($(".fc-today").attr('data-date'));
     var months = cal_selected_date .getMonth() + 1;
    var days = cal_selected_date .getDate();
    var years = cal_selected_date .getFullYear();
     //var days = 
     var SelectedDate = days+'-'+months+'-'+years;
     /*jQuery.ajax({
        type: 'POST',
        url: fetchbookingtime,
        data: {'cal_date':SelectedDate, 'ad_id':ad_id,_token:'{{csrf_token()}}'},
        success: function(data) {
         
          // data.option_html
                $('#calendar_start_time').html(data.option_html);
                $('#calendar_end_time').html(data.option_html2);
                return false;
        },
      });*/
    if(booking_id){

    }else{
      //alert('hi');
        $.ajax({
        type: 'POST',
        url: fetchbookingtime,
        data: {'cal_date':SelectedDate, 'ad_id':ad_id,_token:token_value},
        success: function(data) {
         
         
          // data.option_html
                $('#calendar_start_time').html(data.option_html);
                $('#calendar_start_time option').removeAttr('selected');
                $('select[name^="calendar_start_time"] option:selected').attr("selected",null);
                $('select[name^="calendar_start_time"]  option[value="'+starttime+'"]').attr("selected","selected");
                $('#calendar_end_time').html(data.option_html2);
                //$('#calendar_start_time option').removeAttr('selected');
                //return false;
                if(endtime != ''){
                  $('#calendar_end_time option').removeAttr('selected');
                  $('select[name^="calendar_end_time"] option:selected').attr("selected",null);
   $('select[name^="calendar_end_time"]  option[value="'+endtime+'"]').attr("selected","selected");
                 }
        },
      }); 
    }
    console.log(starttime);
     
     
     if(endtime == ''){
      $("#calendar_end_time").val('');
      $("#calendar_end_time option").removeAttr('selected');
     }else{
      $('select[name^="calendar_end_time"] option:selected').attr("selected",null);
   $('select[name^="calendar_end_time"]  option[value="'+endtime+'"]').attr("selected","selected");
    }
  $('select[name^="calendar_start_time"] option:selected').attr("selected",null);
   $('select[name^="calendar_start_time"]  option[value="'+starttime+'"]').attr("selected","selected");
     $("#calendar_date").val(SelectedDate);
    }
   

    
  }
    });

  var ad_id = $("#user_ad_id").val();
  var user_draft_id = $("input[name=user_draft_id]").val();
  if($.isNumeric(user_draft_id)){
    ad_id = user_draft_id
  }

  //alert(user_draft_id);
  /*if($.trim(user_draft_id) != undefined || $.trim(user_draft_id) != '' || $.trim(user_draft_id) != null){
    ad_id = user_draft_id
  }*/
  if($.isNumeric(user_draft_id)){
    ad_id = user_draft_id
  }
  //alert(ad_id);
  


  
        $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:current_date,_token:token,formtype:'backend'},
         success:function(res)
         {
          var result = res;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $("#calendar-time-range").selectable("refresh"); 
             $("#calendar-time-range").selectable("disable"); 
             }else{
             $("#calendar-time-range").selectable("refresh"); 
            $( "#calendar-time-range" ).selectable("enable"); 
             
            }
         }
        });
var weekoffdays=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayrender',
   success:function(res)
   {
      if(res.status==1){
        weekoffdays = res.weekoffdays;
      }
    
   }
});

  var weekoffdaysworking=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayoff',
   success:function(res)
   {
      if(res.status==1){
        weekoffdaysworking = res.weekoffdays;
      }
    
   }
});
     var calendar = $('#touring-calender').fullCalendar({
    header:{
     left:'prev,next today',
     center:'title',
     right:'month'
    },
    events: FetchBookingURL+'?ad_id='+ad_id+'&formtype=backend',
    selectConstraint: {
        start: $.fullCalendar.moment().subtract(1, 'days'),
        end: $.fullCalendar.moment().startOf('month').add(12, 'month')
    },
    
    selectHelper:true,
    dayRender:function(date, cell){
            var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           console.log(maxDate);
           // var maxDate = '2020-02-15';
            if(maxDate !="" && startdatestr > maxDate){
              $(cell).addClass('fc-disabled-day');
              $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css({"color":"rgb(255, 255, 255)","opacity":"0.2"});
            }else{
            var startrdate = $.fullCalendar.formatDate(date, "dddd");
          
            //var start = moment.unix(date).format("YYYY-MM-DD");
            var start = $.fullCalendar.formatDate(date, "Y-MM-DD");
            var tocheckdate = "dayoff_"+startrdate.toLowerCase();
            if(weekoffdays.length > 0){
            if(jQuery.inArray(start, weekoffdays) !== -1){
               $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
            }
           }

             if(weekoffdaysworking.includes(startdatestr) == false){
                 $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#ffff");
              }else{
                $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#2d962a !important");
              }
              
         }
        if(startdatestr == oldDate){
            
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-past');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-state-highlight');
                
           }
           if(startdatestr == current_date){
            
            $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-future');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');
              
           }

      
    },
        eventRender: function(event, element) {
     // element.css('visibility', 'hidden');
                    if(event.slot_type == "Day Off") {
                  var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");

                 $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
                var ss =   $('td').find("[data-date='" + start + "']").find('.fc-day-number');
                  
                }
                if(event.slot_type == "Day Off") {
                element.find(".fc-event").css('background-color','transparent');
              }
                element.find(".fc-event").css('border','none');
                 element.find("span.fc-title").css('visibility', 'hidden');
               /*  if (event.imageurl) {

        element.find("div.fc-content").prepend("<img src='" + event.imageurl +"' width='16' height='16'>");
    }
*/
                 if(event.slot_type == "Touring") {
                  var tourtstart = new Date(event.start);
                    var tourtend = new Date(event.end);
            
                    while(tourtstart <= tourtend){
                     
                     var customsatrtdate = (new Date(tourtstart)).toISOString().slice(0, 10);
                     
                    $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').addClass('touring-plane');
                   
                      tourtstart = new Date(tourtstart.setDate(tourtstart.getDate() + 1));
                       //self popover
                        var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                       var end_ss = "";
                      if(event.end){
                       end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");
                      
                     }
                      $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-title',event.title);
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-content','Start : '+start_ss+ ' End : '+end_ss);

                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-placement','top');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-container','body');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-toggle','popover');

                     //end popover
                     }
                     $('.touring-plane').popover({
                      container: 'body',
                      trigger : 'hover'
                    });
                     
                    
                    var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                var end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");

              /*element.popover({
                    title: event.title,
                    content: 'Start : '+start_ss+ ' End : '+end_ss,
                    trigger: 'hover',
                    placement: 'top',
                    container: 'body'
                  });*/
            }
                //  element.find("span.fc-title").css('visibility', 'hidden');
            
            },
    viewRender: function (view,element) {

            if (moment() >= view.start && moment() <= view.end) {
                $(".fc-prev-button").prop('disabled', true); 
                $(".fc-prev-button").addClass('fc-state-disabled'); 
            }
            else {
                $(".fc-prev-button").removeClass('fc-state-disabled'); 
                $(".fc-prev-button").prop('disabled', false); 
            }
        },
    dayClick: function(date, jsEvent, view) {
       var today = new Date((new Date()).toString().substring(0,15));
      if( date < today) {
       
        $('#calendar').fullCalendar('unselect');
        return false;
    }
    var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           
    //var maxDate = '2020-02-15';
    if(maxDate !="" && startdatestr > maxDate){
      console.log(startdatestr);
      return false;
    }
    //$(".touring-form-section").show();
 
      var startDate = $.fullCalendar.formatDate(date, "Y-MM-DD");
      $("#working_date").val(startDate);
       cal_selected_date = $.fullCalendar.formatDate(date, "DD-MM-Y");
       $("#working_date_label").val(cal_selected_date);
      
      $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
         success:function(res)
         {
          var result = res;
          dayoff=result.dayoff;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $( "#calendar-time-range" ).selectable("refresh"); 
             $( "#calendar-time-range" ).selectable("disable"); 
             }else{
              $( "#calendar-time-range" ).selectable("refresh");
              $( "#calendar-time-range" ).selectable("enable"); 
              
             
            }
         }
        })
      if(dayoff != "yes"){
        //$("#services-addTime").modal('show');
        $('td').find(".fc-state-highlight").removeClass('fc-state-highlight');
        $('td').find(".fc-today").removeClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');

         $('select[name^="calendar_end_time"] option:selected').attr("selected",null);
         $('select[name^="calendar_start_time"] option:selected').attr("selected",null);
         $("#calendar_date").val(cal_selected_date);
      }
    },
   

   });
  
    $("#working_hrs_btn").click(function(){
$("#working_end_time-error").text('');
            $("#working_start_time-error").text('');
      var form = $("#cal_working_hrs");
    var  checked = $('#working_day_off').is(':checked')? true:false;

    if(!checked){
var validobj = form.validate({
    errorPlacement: function errorPlacement(error, element) {
     
      element.after(error);
   
    },
    rules: {

      working_start_time:{ required:true,
       },
      working_end_time :{ required:true,
      },
    },
    messages: {
      "working_end_time": "select finish time",
        "working_start_time": "select start time",
      
    }
});
 if(form.valid()){
  $("#working_day_off").val('');
    $.ajax({
         url:$("#cal_working_hrs").attr('action'),
         type:"POST",
        data:$("#cal_working_hrs").serialize(),
         success:function(res)
         {

          var result = res;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#working_end_time").val('');
            $("#working_start_time").val('');
            $("#working_date").val('');
            
            $('#working_day_off').attr('checked', false);
            $(".touring-form-section").hide();
            
         }
        })
  }
}else{
   $("#working_end_time-error").text('');
    $("#working_start_time-error").text('');
    $("#working_day_off").val('yes');
  $.ajax({
         url:$("#cal_working_hrs").attr('action'),
         type:"POST",
        data:$("#cal_working_hrs").serialize(),
         success:function(res)
         {

          var result = res;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
              $("#working_end_time").val('');
              $("#working_start_time").val('');
              $("#working_date").val('');
              $('#working_day_off').attr('checked', false);
              $(".touring-form-section").hide();
         }
        })
}
 
    
  
  });
    /*var startDatesArray = Array();
    var endDatesArray = Array();
    $('.startdate').click(function(){
      $('.startdate').each(function(){
        startDatesArray.push($('.startdate').val());
      });
      $('.enddate').each(function(){
        endDatesArray.push($('.enddate').val());
      });

      for(var r =0 r<startDatesArray.length; r++){
        if((startDatesArray <= lDate && cDate >= fDate)) {
            alert("true");
            return true;
        }
      }


    });*/

    //$(document).on("click", "#calendar_add_bookings",function(){
     $("#calendar_add_bookings").click(function(){
        
       /* $("input").removeClass("error");
        $("select").removeClass("error");
        var error = [];
        if($("#title").val() == ""){
          error.push('#title');

        }
        if($("#calendar_date").val() == ""){
          error.push('#calendar_date');
        }
       
        if(error.length > 0){
          for(var i=0; i<error.length; i++){
            $(error[i]).addClass('error');
          }
        }
        if(error.length == 0)
       {
     
        $.ajax({
         url:BookingURL,
         type:"POST",
         data:$("#booking_form").serialize()+'&action=insert&_token='+$('input[name="_token"]').val(),
         success:function(res)
         {
          console.log(res);
          var result = res;
          if(result.errors){

             $.each(result.errors, function(key, value) {
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });
              //$('.error_msg').html(result.errors).css('color', 'red');

            }else{

              $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
              calendar.fullCalendar('refetchEvents');
              $("#services-addTime").modal('hide');
               $('#services-addTime form :input').val("");

            }
         }
        });
       }*/
       $(".help1-block").addClass("hidden");
      $(".input-box").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("booking_form"));
      $.ajax({
        type: 'POST',
        dataType: "JSON",
        url: $("#booking_form").attr('action'),
        data: registration_form,
        processData: false,
        contentType: false,
         beforeSend:function(){
      $("#Load").fadeIn('slow');
      $("#calendar_add_bookings").text('Processing...');
      $("#calendar_add_bookings").attr('disabled',true);
    },
     success: function(data) {
        $("#Load").fadeOut('fast');
    $("#calendar_add_bookings").text('Save & View');
    $("#calendar_add_bookings").attr('disabled',false);
          if (data.errors) {
            $.each(data.errors, function(key, value) {
              console.log(key);
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });


           
          } else {
             //$("#services-addTime").modal('hide');
              // $('#services-addTime form :input').val("");
            $('#selected_date').html(data.date);
            $('#selected_day').html(data.day);
            $('#selected_m_y').html(data.month_year);
            $("#calendar-time-range").html(data.html);
              calendar.fullCalendar('refetchEvents');
               $('#title').val("");
               $('#client_name').val("");
               $('#service-type').val("");
               $('#services_popup').val("");
               $('#ex_services').val("");
               $('#ex_services').val("");
               $('#booking_notes').val("no");
               $('input[name="slot_type"]').attr('checked', false);
                $(".bookslot-btns").removeClass('calanderbutton-active');
              $("#services-addTime").modal('hide');



          }
        },
      });
     })

  });
function hideWokForm(){
    $("#working_end_time").val('');
    $("#working_start_time").val('');
    $("#working_date").val('');
    $("#working_end_time-error").text('');
    $("#working_start_time-error").text('');
    $(".touring-form-section").hide();
    $('#working_day_off').attr('checked', false);
  }


  function setValues(data){
    alert('hi');
    $('#title').val(data.title);
    $('#client_name').val(data.client_name);
    $('#service_name').val(data.service_name);
    $('#booking_id').val(data.id);
    $('#slot_type').val(data.slot_type);
    $('#calendar_end_time').val(data.end_time);
    $('#calendar_start_time').val(data.start_time);
  }

function readVideo(){
  var total = $(".preview-video").length;
if(total >= 2){
    alert("You can upload only 2 videos.");
    return false;
   }
  if (window.File  && window.FileReader) {
   
    var files = event.target.files; //FileList object
    var output = $(".preview-profilevideo-zone");
    var imageToBig = false;
    for (let i = 0; i < files.length; i++) {
    var file = files[i];
    if (!file.type.match('video.*')) {
      alert("Only videos are allowed to upload.");
      return false;
    }

     if(file.size > 40000000){
      imageToBig = true;
      
    }
    formdata = new FormData();

     if (formdata) {
              formdata.append("pro-video", file);
          }
     
    }
    } else {
    console.log('Browser not support');
    }
     if(imageToBig){
      alert("Video size limit exceeded. You can upload upto 40mb size video.");
      $('#pro-video').val('')
      return false;
     }

    if (formdata) {
      
      formdata.append("_token", $('input[name="_token"]').val());
      formdata.append("listing_type", 'individual');

      console.log(formdata);
      $.ajax({
        url : videoPostURL,
        type: "POST",
        data : formdata,
        contentType: false,
        cache: false,
        processData:false,
        mimeType:"multipart/form-data",
        xhr: function () {
          var xhr = new window.XMLHttpRequest();
          xhr.upload.addEventListener("progress", function (evt) {
            $('.js-loading-bar').modal('show');
              if (evt.lengthComputable) {
                  var percentComplete = evt.loaded / evt.total;
                  percentComplete = parseInt(percentComplete * 100);
                  $('.myprogress').text(percentComplete + '%');
                  $('.myprogress').css('width', percentComplete + '%');
              }
          }, false);
          return xhr;
      },
    success:function(res1){ //
      res = JSON.parse(res1);
      console.log(res);
      //checkVideoUpload(res.videopath);
      window.setTimeout(function(){

      
      $('.js-loading-bar').modal('hide');
         if(res.file_name != ""){
              var html =  '<div class="preview-image preview-show-' + num + ' preview-video">' +
              '<div class="image-settings-icons" data-no="'+ num +'" >' +
              '<a href="javascript:void(0)" class="image-cancel" data-no="'+ num +'" data-image-id="'+ num +'" onclick=removeImage("'+res.videopath+'",'+num+')>x</a>' +
              '</div>' +
              '<div class="image-zone"><video width="250" height="200" controls><source src="' + res.videopath + '"></video>' +
              '</div>' +
              '<div class="radio radio-info form-check-inlinesquarebox image-zone1">' +
              '<input type="hidden" value="'+res.file_name+'" name="videourl[]" class="videourl">' +
              '</div>'
              '</div>';
          
          output.append(html);
          }else{
             $("#ErrorModel").modal('show');
            $(".js-loading-bar").modal('hide');
          }
        },1000);


        },

        error: function(jqXHR, errorThrown) {
           $("#ErrorModel").modal('show');
          $(".js-loading-bar").modal('hide');

               }


      });
    }
    
    num = num + 1;
    
    $("#pro-image").val('');
    

}

function readDedicatedVideo(){
    var total = $(".preview-dedicated-video").length;
    if(total >= 1){
      alert("Sorry! you have exceed your limit. You can only upload 1 video.");
        return false;
    }
  if (window.File  && window.FileReader) {
   
    var files = event.target.files; //FileList object
    var output = $(".preview-dedicatedvideo-zone");
    var imageToBig = false;
    for (let i = 0; i < files.length; i++) {
    var file = files[i];
       if (!file.type.match('video.*')) {
      alert("Only videos are allowed to upload.");
      return false;
    }
    if(file.size > 40000000){
      imageToBig = true;
      
    }
    formdata = new FormData();
     if (formdata) {
              formdata.append("dedicated-video", file);
          }
      }
    } else {
    console.log('Browser not support');
    }

    if(imageToBig){
    alert("Video size limit exceeded. You can upload upto 40mb size video.");
    return false;
   }

    if (formdata) {
      
      formdata.append("_token", $('input[name="_token"]').val());
      console.log(formdata);
      $.ajax({
        url : dedicatedvideoPostURL,
        type: "POST",
        data : formdata,
        contentType: false,
        cache: false,
        processData:false,
        mimeType:"multipart/form-data",
        xhr: function () {
          var xhr = new window.XMLHttpRequest();
          xhr.upload.addEventListener("progress", function (evt) {
            $('.js-loading-bar').modal('show');
              if (evt.lengthComputable) {
                  var percentComplete = evt.loaded / evt.total;
                  percentComplete = parseInt(percentComplete * 100);
                  $('.myprogress').text(percentComplete + '%');
                  $('.myprogress').css('width', percentComplete + '%');
              }
          }, false);
          return xhr;
      },
    success:function(res1){ //
      res = JSON.parse(res1);
        window.setTimeout(function(){
      $('.js-loading-bar').modal('hide');

        if(res.file_name != ""){

              var html =  '<div class="preview-image preview-show-' + num + ' preview-dedicated-video">' +
            '<div class="image-settings-icons" data-no="'+ num +'" >' +
            '<a href="javascript:void(0)" class="image-cancel" data-no="'+ num +'" data-image-id="'+ num +'" onclick=removeImage("'+res.videopath+'","'+num+'")>x</a>'+
            '</div>' +
            '<div class="image-zone"><video width="250" height="200" controls><source src="' + res.videopath + '"></video>' +
              '</div>'+
            '<div class="radio radio-info form-check-inlinesquarebox image-zone1"><input type="hidden" value="'+res.file_name+'" name="dedicatedvideourl[]" class="dedicatedvideourl"></div>'
          '</div>';
            
          output.append(html);
          }else{
             $("#ErrorModel").modal('show');
            $(".js-loading-bar").modal('hide');
          }
           },10000);

        }
      });
    }
    
    num = num + 1;
   
    
    $("#dedicated-video").val('');
    

}
function readTeaserVideo(){
    var total = $(".preview-teaser-video").length;
    if(total >= 1){
      alert("Sorry! you have exceed your limit. You can only upload 1 video.");
        return false;
    }
  if (window.File  && window.FileReader) {
   
    var files = event.target.files; //FileList object
    var output = $(".preview-teaservideo-zone");
    var imageToBig = false;
    for (let i = 0; i < files.length; i++) {
    var file = files[i];
       if (!file.type.match('video.*')) {
      alert("Only videos are allowed to upload.");
      return false;
    }
    if(file.size > 25000000){
      imageToBig = true;
      
    }
    formdata = new FormData();
     if (formdata) {
              formdata.append("teaser-video", file);
          }
      }
    } else {
    console.log('Browser not support');
    }

    if(imageToBig){
    alert("Video size limit exceeded. You can upload upto 25mb size video.");
    return false;
   }

    if (formdata) {
      
      formdata.append("_token", $('input[name="_token"]').val());
      console.log(formdata);
      $.ajax({
        url : teaservideoPostURL,
        type: "POST",
        data : formdata,
        contentType: false,
        cache: false,
        processData:false,
        mimeType:"multipart/form-data",
        xhr: function () {
          var xhr = new window.XMLHttpRequest();
          xhr.upload.addEventListener("progress", function (evt) {
            $('.js-loading-bar').modal('show');
              if (evt.lengthComputable) {
                  var percentComplete = evt.loaded / evt.total;
                  percentComplete = parseInt(percentComplete * 100);
                  $('.myprogress').text(percentComplete + '%');
                  $('.myprogress').css('width', percentComplete + '%');
              }
          }, false);
          return xhr;
      },
    success:function(res1){ //
      res = JSON.parse(res1);
      window.setTimeout(function(){
      $('.js-loading-bar').modal('hide');
        if(res.file_name != ""){
              var html =  '<div class="preview-image preview-show-' + num + ' preview-teaser-video">' +
            '<div class="image-settings-icons" data-no="'+ num +'" >' +
            '<a href="javascript:void(0)" class="image-cancel" data-no="'+ num +'" data-image-id="'+ num +'" onclick=removeImage("'+res.videopath+'","'+num+'")>x</a>'+
            '</div>' +
            '<div class="image-zone"><video width="250" height="200" controls><source src="' + res.videopath + '"></video></div>'+
            '<div class="radio radio-info form-check-inlinesquarebox image-zone1"><input type="hidden" value="'+res.file_name+'" name="teaservideourl[]" class="teaservideourl"></div>'
          '</div>';
          
          output.append(html);
          }else{
             $("#ErrorModel").modal('show');
            $(".js-loading-bar").modal('hide');
          }
          },10000);

        }
      });
    }
    
    num = num + 1;
   
    
    $("#teaser-video").val('');
    

}
$(function(){
  if(form_step != '3'){
 $(".step_3").css('display', 'none');
}
//$("#wizard").steps();
 var selectedGender = $("input[name='rdo']:checked").val();
if(selectedGender == 'male'){
   $(".personal-section").hide();
   $("#bustype-section").hide();
   $("#waistsize-section").show();
   $("#penissize-section").show();
   $("#peniscircum-section").show();
   $(".wishlist_things_male").show();
   $(".wishlist_things_female").hide();
    $(".favthings_male").show();
   $(".favthings_female").hide();
 }else{
    $(".personal-section").show();
    $("#bustype-section").show();
    $("#waistsize-section").hide();
    $("#penissize-section").hide();
    $("#peniscircum-section").hide();
    $(".wishlist_things_male").hide();
     $(".wishlist_things_female").show();
       $(".favthings_male").hide();
   $(".favthings_female").show();
 }
$('input[type=radio][name=rdo]').change(function() {
  if (this.value == 'male') {
      $(".personal-section").hide();

      $("#bustype-section").hide();
      $("#waistsize-section").show();
      $("#penissize-section").show();
      $("#peniscircum-section").show();
      $(".wishlist_things_male").show();
       $(".wishlist_things_female").hide();
        $(".favthings_male").show();
   $(".favthings_female").hide();
  }else{
    $(".personal-section").show();
    $("#bustype-section").show();
    $("#waistsize-section").hide();
    $("#penissize-section").hide();
    $("#peniscircum-section").hide();
    $(".wishlist_things_male").hide();
    $(".wishlist_things_female").show();
     $(".favthings_male").hide();
   $(".favthings_female").show();
  }

 $.ajax({
         headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
       type:"post",
       url:fetchBackendgenderURL,
       data:{gender:this.value},
      beforeSend: function() {
     // $("#Load").show();  
    },
       success: function(data){
        console.log(data);
         // $("#cities").html(data);
           // $("#Load").hide(); 
            var bustsize = data.master_bust_size;
            var dresssize = data.master_dress_size;
            var bodytype = data.master_body_type;
            var waistsize = data.master_waist_size
   
          if ($('.select_box').data('select2')) {
              $(".select_box").select2("destroy");
              $('.select_box')
              .removeAttr('data-live-search')
              .removeAttr('data-select2-id')
              .removeAttr('aria-hidden')
              .removeAttr('tabindex');
           }

           $("#bodytype").html(bodytype);
           $("#bustsize").html(bustsize);
           $("#dresssize").html(dresssize);
           $("#waistsize").html(waistsize);
           $('.select_box').select2({});
       }
    });

 
});
$("#next_step_0").click(function(){
  $("#number_of_escorts-error").html();
  if($("#number_of_escorts_selected").val() == ""){
    $("#number_of_escorts-error").html('enter number of escorts');
    return false;
  }else if($("#escort_selected_plan").val() == ""){
     alert('Select Plan first');
    return false;
  }else{
    $.ajax({
  type:"POST",
  url: $("#step_select_form").attr('action'),
  data : $("#step_select_form").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
  success: function(result){
    $("#Load").fadeOut('fast');
   $(".step_1").fadeIn('slow');
    $(".step_2").fadeOut('fast');
    $(".step_0").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_7").fadeOut('fast');
     $(".verification_video_section").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.first").removeClass('disabled').addClass('current');

}
});
   
  }


})
$(".popup-proceed-btn").click(function(){
  $("#selected-escortsmodel").modal('hide');
})
$("input[name=agency_plan]").change(function(){
  var price = $(this).attr('data-plan-price');
  var type = $(this).attr('data-plan-type');
  var number_of_escorts = $("#number_of_escorts").val();
  if(type == 'free'){
    var total = 0.00 * number_of_escorts;
  }else{
    var total = price * number_of_escorts;
  }
  
  $('.total_amount_overview').html('Total: ' + Math.round((parseFloat(total)) * 100) / 100);
  //$('.total_amount_overview').html('Total: '+total);
  var plan = $(this).val();
  $("#escort_selected_plan").val(plan);
  $("#number_of_escorts_selected").val(number_of_escorts);


});
$("input[name=club_plan]").change(function(){
  var price = $(this).attr('data-plan-price');
  var number_of_escorts = $("#number_of_escorts").val();
  var type = $(this).attr('data-plan-type');
  var plan_type = $("#number_of_escorts").val();
   if(type == 'free'){
    var total = 0.00 * number_of_escorts;
  }else{
    var total = price * number_of_escorts;
  }
  $('.total_amount_overview').html('Total: ' + Math.round((parseFloat(total)) * 100) / 100);
  //$('.total_amount_overview').html('Total: '+total);
  var plan = $(this).val();
  $("#escort_selected_plan").val(plan);
  $("#number_of_escorts_selected").val(number_of_escorts);
});

//step 0 form data save start
//step 0 end
$("#next_step_1").click(function(){
    $("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');
    
var form = $("#form_step_1");

var validobj = form.validate({
    errorPlacement: function errorPlacement(error, element) {
     
     // return false;
     if(element.is(":radio")){
      $("#personal-error2").before(error);
     
     }
     else if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
     
      element.after(error);
     }
         
    },
    rules: {
      "body-type": {
        required: true,
        //minlength: 1
      },
      personal:{ required:true },
      rdo :{ required:true},
      suburbs:{ required:true },
      ad_name:{required:true},
      ad_email:{required:true},
      ad_contactno:{required:true},
      age:{ required:true,  number:true, min:18},
      country_name:{ required:true },
      city_name:{ required:true },
      eyecolor:{ required:true },
      haircolor:{ required:true },
      bustsize:{ required:true },
      weight:{ required:true, number:true, min:1},
      height:{ required:true, number:true, min:1 },
      //nationality:{ required:true },
      orientation:{ required:true },
      gender:{ required:true },
      dresssize:{ required:true },
      shoessize:{ required:true },
      hairlength:{ required:true },
       language:{ required:true },
     // busttype:{ required:true },
      //waistsize:{ required:true },
      about_description:{ required : true},
      tagline:{  maxlength: 35},
      ethinicity:{required:true, },
     /* "piercing[]":{
        required: true,
        minlength: 1
      },*/
      "disclaimer[]" : {
          required: function(element){
            return $(".disclaimer").length > 0;
        },
        minlength : $(".disclaimer").length,
      },
     

    },
    messages: {
      "body-type[]": "Please choose body type",
      "country_name":"Please select Country",
      "city_name":"Please select City",
      "ad_name":"Please enter your name",
      "ad_email":"Please enter your email-address",
       "ad_contactno":"Please enter your number with the country code.",
      "rdo":"Please select gender",
      "language":"Please enter your language ",
      "suburbs":"Please enter your suburbs",
      "about_description" : "Please describe  yourself.",
      "tagline" : "35 Character Max.",
      "personal": "Please choose atleast one option",
      "age" : "Age should be 18+",
      "eyecolor" :"Please select eye color",
      "haircolor" :"Please select hair color",
      "height" :"Height must be in number only",
      "weight" : "Weight must be in kg ",
      //"nationality" :"Please select nationality",
      //"busttype" :"Please select bust type.",
      "orientation" :"Please select orientation",
      "gender" : "Please select gender",
      "dresssize" : "Please select dress size",
      "shoessize" : "Please select shoes size",
      "hairlength" : "Please select hair length",
      "bustsize" : "Please select bust size",
      //"piercing[]":"Please choose atleast one option.",
      "disclaimer[]" : "Please accept disclaimer",
      "ethinicity":"Please enter ethinicity"

      
    }
});

if(form.valid()){

$.ajax({
  type:"POST",
  //dataType: "JSON",
  url: $("#form_step_1").attr('action'),
  data : $("#form_step_1").serialize(),
  //processData: false,
       // contentType: false,
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
  success: function(result){
    if (result.errors) {
      $("#Load").fadeOut('fast');
      $.each(result.errors, function(key, value) {
        $("." + key + "_error").html(value);
        $("." + key + "_error").removeClass("hidden");
        $("#" + key).parent().addClass("has-error");
      });


      $('html, body').animate({
        scrollTop: parseInt($('.has-error:visible:first').offset().top) - 10
      }, 1000);
    }else {
    $("#Load").fadeOut('fast');
    $("#post_ad_id").val(result.ad_id); 
    $(".ad_user_id").val(result.ad_id); 
    $(".ad_draft_id").val(result.draft_id); 
    $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
    $(".step_2").fadeIn('slow');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
    $(".step_0").fadeOut('fast');
    $(".step_7").fadeOut('fast');
     $(".verification_video_section").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');
}
}
});


}

});

$("#next_step_2").click(function(){
 //var activePlan = $(".price-cards .price-cards-inner.active-plan").length;
 if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
 $("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');
if(upgrade){
if(genTokenValue != ""){

  var redirectpayurl = RedirectURL+'?token='+genTokenValue
}

window.location.href = redirectpayurl;
}else{
upgrade = false;
  $.ajax({
  type:"get",
  url: stepUrl,
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
  success: function(result){
    $("#Load").fadeOut('fast');
     $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeIn('slow');
  $(".step_4").fadeOut('fast');
  $(".step_7").fadeOut('fast');
 $(".verification_video_section").fadeOut('fast');
 window.history.pushState("", "", "?step=3");
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');

}
});




}

});
$("#prev_step_2").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_1").fadeIn('slow');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.first").removeClass('disabled').addClass('current');
})
$("#prev_verification_video_section").click(function(){
  $(".step_2").fadeOut('fast');
  $(".step_4").fadeIn('slow');
  $(".step_3").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  $(".verification_video_section").fadeOut('fast');
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.five").removeClass('disabled').addClass('current');
})
$("#prev_step_3").click(function(){

  $(".step_2").fadeIn('slow');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
   $(".verification_video_section").fadeOut('fast');
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');
})


$("#next_step_3").click(function(){
 if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
 $("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');
var form1 = $("#form_step_3");
var validobj = form1.validate({
    errorPlacement: function errorPlacement(error, element) {
     // console.log(element);
     // return false;
   
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }
         
    },
    rules: {
      "service-avail-for[]" : {
        required:true,
        minlength: 1
      },
      "service-available[]" : {
        required: true,
        minlength: 1
      },
      "service-type[]" : {
        required: true,
        minlength: 1
      },
      describe_service:{ required : true, minlength: 200},
      "service[0][service_time]" : {
        required: true,
      },
     /* "service[0][service_incall_charge]" : {
        required: true,
      },
        "service[0][service_outcall_charge]" : {
        required: true,
      },
      "service[0][service_name]" : {
        required: true,
       
      },*/
      "extra_services[0][price]" : {
        number:true,
        min:0.01
      }
    },
    messages: {
      "service-avail-for[]":"Please choose atleast one option.",
      "service-type[]":"Please choose atleast one option.",
      "service-available[]":"Please choose atleast one option.",
      "describe-service" : "Please describe your service. Minimum length should be 200.",
      "service[0][service_time]":"Plase select service time",
      "service[0][service_incall_charge]":"Please enter valid incall charge",
      "service[0][service_outcall_charge]":"Please enter valid outcall charge",
      "service[0][service_name]":"Please select service name",
      "extra_services[0][price]":"Please enter valid price."
      
    }

  
});

if(form1.valid()){
  $.ajax({
    type:"POST",
    url: $("#form_step_3").attr('action'),
    data : $("#form_step_3").serialize(),
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
      $(".step_2").fadeOut('fast');
      $(".step_1").fadeOut('fast');
      $(".step_3").fadeOut('fast');
      $(".step_4").fadeIn('slow');
      $(".step_0").fadeOut('fast');
      $(".step_7").fadeOut('fast');
       $(".verification_video_section").fadeOut('fast');
      $('.tablist li.current').removeClass('current').addClass("disabled");
      $(".tablist li.four").removeClass('disabled').addClass('current');
    }
  });
}
});
var ad_user_name="";

$("#next_step_4").click(function(){
  if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
 if(save_step_4 === false){
  alet("You haven't save your changes. Please save first.");
  return false;
 }
 $("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');
  var form2 = $("form_step_4");
  /*var validobj = form2.validate({
    errorPlacement: function errorPlacement(error, element) {
  
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }
         
    },
    rules: {
            
            'pro-image':{
              required : true,
              accept: "image/jpg,image/jpeg"
            },
           
    },
    messages: {
      
      "pro-image":{
        required: 'Required!', accept: 'Not an image!'
      },
     photo_disclaimer:"Please accept disclaimer"
    }


});
  
*/
  $.ajax({
    type:"POST",
    url: $("#form_step_4").attr('action'),
    data : $("#form_step_4").serialize(),
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
     ad_user_name = result;
    save_step_4 = true;
    $("#Load").fadeOut('fast');
    $(".step_2").fadeOut('fast');
    $(".step_1").fadeOut('fast');
    $(".step_0").fadeOut('fast');
    $(".step_3").fadeOut('fast');
    $(".step_4").fadeOut('fast');
  if($('.verification_video_section').length > 0)
  {
    $(".verification_video_section").fadeIn('slow');
  }else{

   
     $(".step_7").fadeIn('slow');
     ad_user_name = $("input[name=ad_name]").val();
      $("h2.welcome-msg").html('Hi, '+ad_user_name+'');
  }
      $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
    
   /* let width = window.innerWidth;
  let height = window.innerHeight;
  let particles = [];
  
  // particle canvas
  const canvas = document.createElement( 'canvas' );
  const context = canvas.getContext( '2d' );
  canvas.id = 'firework-canvas';
  canvas.width = width;
  canvas.height = height;
  canvas.style.display = 'block';
  canvas.style.pointerEvents = 'none';
  canvas.style.position = 'fixed';
  canvas.style.zIndex = '1';
  canvas.style.left = '0';
  canvas.style.top = '0';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.opacity = '.85';
  document.getElementById("finished_crackerss").appendChild( canvas );
  
  // on resize 
  window.addEventListener( 'resize', e => {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;
  });
  
  // add particles slowly over time 
  const create = () => {
    if ( particles.length > 2 ) return; 
    particles.push( new FireworkParticle( context, width, height, 100 ) ); 
    setTimeout( create, 600 );  
  }; 
  
  // animation loop 
  const loop = () => {
    requestAnimationFrame( loop );
    context.fillStyle = 'rgba(0,0,0,0.2)';
    context.fillRect( 0, 0, width, height );
    
    for ( let p of particles ) {
      if ( p.complete() ) p.reset();
      p.update( width, height );
      p.draw();
    }
  };
 
  // init 
  create();
  loop();*/
  if($('.verification_video_section').length > 0){
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.five").removeClass('disabled').addClass('current');
  }else{
     $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.last").removeClass('disabled').addClass('current');
  }
  
  }
  
  });

  });
$("#next_verification_video_section").click(function(){
  var total = $(".preview-verification").length;
  if(total == 0){
    alert("Please upload verification video.");
    return false;
  }
  $("#update_step_5").removeClass('blink-btn');
    $(".hndicon").css('display','none');
  $(".step_2").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_3").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeIn('slow');
  $(".verification_video_section").fadeOut('fast');
   ad_user_name = $("input[name=ad_name]").val();
  $("h2.welcome-msg").html('Hi, '+ad_user_name+'');
  
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.last").removeClass('disabled').addClass('current');
})

  $("#prev_step_4").click(function(){
    $(".step_2").fadeOut('fast');
    $(".step_1").fadeOut('fast');
    $(".step_3").fadeIn('slow');
    $(".step_4").fadeOut('fast');
    $(".step_7").fadeOut('fast');
    $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
    $(".step_0").fadeOut('fast');
    $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
  });

$.validator.setDefaults({ignore: ":hidden:not(.select_box)"});
console.log(maxdatepickerDate);
console.log(mindatepickerDate);
/*$('.startdate').datepicker({

  dateFormat:'dd/mm/yy',
    minDate : new Date(mindatepickerDate),
    maxDate : new Date(maxdatepickerDate),
  
  });

  $('.enddate').datepicker({
    dateFormat:'dd/mm/yy',
    minDate : new Date(mindatepickerDate),
    maxDate : new Date(maxdatepickerDate),
   
  })*/
//   $('.inter_startdate').datepicker({

//   dateFormat:'dd/mm/yy',
//    minDate : new Date(mindatepickerDate),
  
//   });

//   $('.inter_enddate').datepicker({
//     dateFormat:'dd/mm/yy',
//  minDate : new Date(mindatepickerDate),
   
//   })
//   $('.startdate').on('click', function(e) {
//    e.preventDefault();
//    $(this).attr("autocomplete", "off");  
// });
// $('.enddate').on('click', function(e) {
//    e.preventDefault();
//    $(this).attr("autocomplete", "off");  
// });

  $('a[href$="#previous"]').addClass('previous');

  //$ias = $('img#imagepreview').imgAreaSelect({instance: true });
  
  $(".select_box").select2();
  $(".service_select_box").select2();
  //$(".select_country_box").select2();
  //$(".select_city_box").select2();
  //$(".services_rates:first .remove-rate").css('display','none');
  //$(".touring_girls:first .remove-tour").css('display','none');
  //$(".inter_touring_girls:first .remove-tour").css('display','none');
  //$(".extraservice_fee:first .remove-service-rate").css('display','none');
  document.getElementById('pro-image').addEventListener('change', readImage, false);
  document.getElementById('pro-video').addEventListener('change', readVideo, false);
  if($("#teaser-video").length >0 ){
     document.getElementById('teaser-video').addEventListener('change', readTeaserVideo, false);
  }
    if($("#dedicated-video").length >0 ){
     document.getElementById('dedicated-video').addEventListener('change', readDedicatedVideo, false);
  }
 
  
  $('#imagemodal').on('hidden.bs.modal', function () {
    //alert('hello');
    var ImgIds = $('#imgeType').val();
    if($("#changeDone").val() != ''){
      $("#newimg"+ImgIds).val($("#changeDone").val());
    }
    $("#ImageNodal").html('');
    //$ias.cancelSelection();
});

  /*$('img#imagepreview').imgAreaSelect({
    onSelectEnd: function (img, selection) {
      imageSalectionValue = selection;
      console.log(selection);
        // imegid = $("#imagepreview");
       visible_width=img.offsetWidth;
       visible_height=img.offsetHeight;
       naturalWidth = img.naturalWidth;
       naturalHeight = img.naturalHeight;
      // console.log(visible_width);
      // console.log(visible_height);
      // console.log(naturalWidth);
      // console.log(naturalHeight);
    } 
    });*/




if (window.FormData) {
formdata = new FormData();
}
    

});

function cropImage(){

  if(imageSalectionValue == ""){
    
    alert("Please select  image first to crop.");
    return false;

  }
  var imghei = imgwid = imgx = imgy = '';

  var url = $("#imagepreview").attr('src');
  var filename = $("#imagepreview").attr('src').substring($("#imagepreview").attr('src').lastIndexOf('/')+1);
    
        $.ajax({
          url : imagePostURL,
          type: "POST",
          data : {'original_width' : naturalWidth, 
          'original_height':naturalHeight,
          'visible_width':visible_width,
          'visible_height':visible_height,
          'width':imageSalectionValue.width,
          'height':imageSalectionValue.height,
          'image_url':$("#imagepreview").attr('src'),
          'image_file_name':filename, 
          'x1': imageSalectionValue.x1, 
          'y1':imageSalectionValue.y1, 
          'y2':imageSalectionValue.y2,
          'x2':imageSalectionValue.x2,
          'action' : 'crop', "_token": $('input[name="_token"]').val()},
          beforeSend: function(){
            $("#Load").fadeIn('slow');
          },
          success: function(res){
             
              imageSalectionValue = {x1 : imgx, y1 : imgy, x2 : imgwid, y2: imghei}
             $(".jcrop-widget").remove();
             //jcp.removeWidget(jcp.active);
             
             var NewImageId = $("imgeType").val();
             
             $("#changeDone").val(res);
           //$('img#imagepreview').imgAreaSelect({hide:true});

            $("img#imagepreview").attr('src', res+"?random="+new Date().getTime());
          console.log(imageSalectionValue);
          const rect = Jcrop.Rect.fromPoints([0,0],[600,600]);      
               jcp.newWidget(rect,{ minSize: [600,600] });
               jcp.focus();

 $("#Load").fadeOut('fast');
          
          }
        }); 

}

function resetChanges(){
  
  var filename = $original_image.substring($original_image.lastIndexOf('/')+1);
  var imghei = imgwid = imgx = imgy = '';
      $.ajax({
        url : imagePostURL,
        type: "POST",
        data : {'image_url':$original_image,'image_file_name':filename,'action' : 'reset', "_token": $('input[name="_token"]').val()},

      }).done(function(res){
         imageSalectionValue = {x1 : imgx, y1 : imgy, x2 : imgwid, y2: imghei}
        var NewImageId = $("imgeType").val();
             $("#changeDone").val('');
             $.ajax({
      url : editImageOpen,
      method: 'GET',
      data : {url:$original_image},
      success:function(response){
          //var imghei = imgwid = imgx = imgy = '';
           imageSalectionValue = {x1 : imgx, y1 : imgy, x2 : imgwid, y2: imghei}
          /*var ow= document.getElementById("imagepreview").offsetWidth;
          var oh=document.getElementById("imagepreview").offsetHeight;
          naturalWidth = document.getElementById("imagepreview").naturalWidth;
       naturalHeight = document.getElementById("imagepreview").naturalHeight;*/
          $('#ImageNodal').html(response);
          $(".jcrop-widget").remove();
          const rect = Jcrop.Rect.fromPoints([0,0],[600,600]);      
               jcp.newWidget(rect,{ minSize: [600,600] });
               jcp.focus();

          visible_width=200;
       visible_height=200;
       


      },
  });
        /*$("#imagepreview").attr('src', $original_image);
        $('img#imagepreview').imgAreaSelect({
    x1 : 1, y1 : 1, x2 : 100, y2: 100
     });
imageSalectionValue ={ x1 : 1, y1 : 1, x2 : 100, y2: 100};*/

    visible_width=200;
       visible_height=200;
       naturalWidth = document.getElementById("imagepreview").naturalWidth;
       naturalHeight = document.getElementById("imagepreview").naturalHeight;

      });  
}

function blurImage(){
  if(imageSalectionValue == ""){
    
    alert("Please select image  first to crop.");
    return false;

  }
   var imghei = imgwid = imgx = imgy = '';
  var url = $("#imagepreview").attr('src');
  var filename = url.substring(url.lastIndexOf('/')+1);
    console.log(imageSalectionValue);
        $.ajax({
          url : imagePostURL,
          type: "POST",
          data : {'original_width' : naturalWidth, 'original_height':naturalHeight,'visible_width':visible_width,'visible_height':visible_height,'image_url':url,'image_file_name':filename, 'x1': imageSalectionValue.x1, 'y1':imageSalectionValue.y1, 'y2':imageSalectionValue.y2,'x2':imageSalectionValue.x2,'action' : 'blur', "_token": $('input[name="_token"]').val()},
           beforeSend: function(){
            $("#Load").fadeIn('slow');
          },
          success: function(res){
            imageSalectionValue = {x1 : imgx, y1 : imgy, x2 : imgwid, y2: imghei};
            $(".jcrop-widget").remove();
            var NewImageId = $("imgeType").val();
             $("#changeDone").val(res);
           //$('img#imagepreview').imgAreaSelect({hide:true});
          $("img#imagepreview").attr('src', res+"?random="+new Date().getTime());
      
            const rect = Jcrop.Rect.fromPoints([0,0],[600,600]);      
               jcp.newWidget(rect,{ minSize: [600,600] });
               jcp.focus();

          $("#Load").fadeOut('fast');
          }

        });    

}
function readMoreFeatures(id){
  $("#hide-more-features"+id+" .hide-more-features").toggle();
 
if($('#read-more-features'+id).text() == 'Read More'){
  $('#read-more-features'+id).text('Read Less');
   
}else{
  $('#read-more-features'+id).text('Read More');
   $('html, body').animate({scrollTop:$('.step_2 .pay-boxz').position().top}, 'slow');
}
  
}


var current_id = 0;
function addRate(){

  if ($('.service_select_box').data('select2')) {
    $(".service_select_box").select2("destroy");
    $('.service_select_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }


var num =  $('.services_rates').length;
var clone = $(".services_rates").first().clone();
clone.insertBefore('#tool-placeholder');
clone.attr('id', 'test'+num);
clone.find('.service_incall_charge').attr('name', "service["+num+"][service_incall_charge]").val('');
clone.find('.service_outcall_charge').attr('name', "service["+num+"][service_outcall_charge]").val('');
clone.find('.service_time').attr('name', "service["+num+"][service_time]");
clone.find('.service_name').attr('id', "service_name"+num).val('');;
clone.find('.service_name_hidden').attr('name', "service["+num+"][service_name]");
clone.find('.service_name_hidden').attr('id', "service_name_hidden"+num).val('');
clone.find("select").attr("id", "services_rates_"+num);
clone.find('h6.labelwhite').remove();
clone.find('.remove-rate').css("display", "inline-block");
$(".service_select_box").select2({}); 
$("select").on("select2:close", function (e) {  
  $(this).valid(); 
});

}

function setId(id){
  scid=id;
  $('.services_include').map(function() {
      
    $(this).prop('checked', false);

});
  $("#service_available").val(id);
  var hiddenInputValues = id.replace('service_name', 'service_name_hidden');
  console.log($('#'+hiddenInputValues).val());
  if($('#'+hiddenInputValues).val() != ""){
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
          $(this).prop('checked', true);
      } else {
          $(this).prop('checked', false);
      }
  });
   
  }
 }
 // =======================================================
  function setValuesToTextbox_popup(){
   // alert(); 
  var selectedValue = '';
  var selectedText = '';
  selectedValue = $('.services_include_popup:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.services_include_popup:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  console.log(selectedValue);
  var inputId = $('#service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('services_popup', 'services_hidden_popup');
  $('#'+hiddenInputValues).val(selectedValue);
 
 }
   function setValuesToExtraTextbox_popup(){
   // alert();
   $('body').addClass('modal-open'); 
  var selectedValue = '';
  var selectedText = '';
  selectedValue = $('.extra_services_include_popup:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.extra_services_include_popup:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  // console.log(selectedValue+'======>>>> >>>selectedValue');
  var inputId = $('#extra_service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('ex_services', 'ex_services_hidden');
  $('#'+hiddenInputValues).val(selectedValue);
  console.log($('#'+hiddenInputValues).val());
 }
 // =======================================================
 function setValuesToTextbox(){
  if ($('.services_include:checked').length>=4) {
  $('body').addClass('modal-open'); 
  var selectedValue = '';
  var selectedText = '';
  
  selectedValue = $('.services_include:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.services_include:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  console.log(selectedValue);
  var inputId = $('#service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('service_name', 'service_name_hidden');
  $('#'+hiddenInputValues).val(selectedValue);
  console.log(hiddenInputValues);
  console.log($('#'+hiddenInputValues).val());
  $('#serviceIncluded-popup').modal('hide')
}
else{
  
  alert('Please select Minimum 4 Services!');
   //$('#serviceIncluded-popup').modal('show')
  return false;
 }
 }



 //for extra services
 function setExtraId(id){
  $('.extra_services_include').map(function() {
      
    $(this).prop('checked', false);
  
});
  $("#extra_service_available").val(id);
  console.log($("#extra_service_available").val());
  var hiddenInputValues = id.replace('extra_service_name', 'extra_service_name_hidden');
  console.log(hiddenInputValues);
  if($('#'+hiddenInputValues).val() != ""){
    
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='extra-service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
        
          $(this).prop('checked', true);
      } else {
        
          $(this).prop('checked', false);
      }
  });
   
  }
 }
 //============================================================
 function setExtraId_popup(id){
  $('.extra_services_include').map(function() {
      
    $(this).prop('checked', false);
  
});
  $("#extra_service_available").val(id);
  console.log($("#extra_service_available").val());
  var hiddenInputValues = id.replace('ex_services', 'ex_services_hidden');
  console.log(hiddenInputValues);
  if($('#'+hiddenInputValues).val() != ""){
    
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='extra-service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
        
          $(this).prop('checked', true);
      } else {
        
          $(this).prop('checked', false);
      }
  });
   
  }
 }

 // ============================================================
 function setValuesToExtraTextbox(){
  // if ($('.extra_services_include:checked').length>=6) {
  $('body').addClass('modal-open');
  var selectedValue = '';
  var selectedText = '';
  selectedValue = $('.extra_services_include:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.extra_services_include:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  console.log(selectedValue);
  var inputId = $('#extra_service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('extra_service_name', 'extra_service_name_hidden');
  $('#'+hiddenInputValues).val(selectedValue);
  console.log(hiddenInputValues);
  console.log($('#'+hiddenInputValues).val());
   //$('#extraserviceIncluded-popup').modal('hide')
 // }else{
  
 //  alert('Please select Minimum 6 Services!');
 //  return false;
 // }
}

function addServiceFee(){
  
  var num =  $('.extraservice_fee').length;
  var clone = $(".extraservice_fee").first().clone();
  clone.insertBefore('#service-placeholder');

  clone.find('.extraservice_price').attr('name', "extra_services["+num+"][price]").val('');
  clone.find('.extra_service_name').attr('id', "extra_service_name"+num).val('');;
  clone.find('.extra_service_name_hidden').attr('name', "extra_services["+num+"][service_name]");
  clone.find('.extra_service_name_hidden').attr('id', "extra_service_name_hidden"+num).val('');
  clone.find('h6.labelwhite').remove();
  clone.find('.remove-service-rate').css("display", "inline-block");
}
function removeServiceFee(){
  $(".extraservice_fee:last .remove-service-rate").closest('.extraservice_fee').remove();
}
$(document).on('click', '.image-cancel', function() {
    let no = $(this).data('no');
    $.ajax({
    type:"POST",
    url: deleteImageURL,
    data : {image_id:$(this).data('image-id'), _token:token_value},
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      $(".preview-image.preview-show-"+no).remove();
    }
  }); 
    
   });

$(document).on("change", "input[name='img_is_default']", function () {
  var checkedLength = $('.preview-image .radio-info input[name="img_is_default:"]:checked').length;
  console.log(checkedLength);
  if(checkedLength == 1){
    return false;
  }
  var current_checkbox = $(this);
  var image_id = $(this).attr('data-id');
  if (this.checked) {
      var value = 1;
    }else{
      var value = 0;
    }
   $.ajax({
    type:"POST",
    url: setStatusImageURL,
    data : {image_id:image_id, default_value:value,_token:token_value },
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      $('.preview-image .radio-info .img_is_add_default').prop('checked', false);
      $('.preview-image .radio-info input[name="img_is_default"]').prop('checked', false);
      $(current_checkbox).prop("checked", true);

    }
  }); 
    
});

$(document).on("change", ".img_is_add_default", function () {
 
  var current_checkbox = $(this);
  var image_id = $(this).attr('data-id');
  $('.preview-image .radio-info .img_is_add_default').prop('checked', false);
  $('.preview-image .radio-info input[name="img_is_default"]').prop('checked', false);
  $(current_checkbox).prop("checked", true);
    
});
$(document).on("change",".inter_startdate", function(){
  $("#touring_updates").val('yes');
})
$(document).on("change",".startdate", function(){
  $("#touring_updates").val('yes');
})

function removeRate(){
$(".services_rates:last .remove-rate").closest('.services_rates').remove();
}

function addFavThings(){

  var favnum =  $('.favthings_addmore').length;
 
  var html = '';
  html += '<div class="row favthings_addmore">';

  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-1 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN remove-favthings" onclick="removeFavThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.favthings_placeholder').append(html);
}

function removeFavThings(){
$(".favthings_addmore").last().remove();
}
function addFavThingsFemale(){

  var favnum =  $('.favthings_addmore').length;
 
  var html = '';
  html += '<div class="row favthings_addmore">';

  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-1 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN remove-favthings" onclick="removeFavThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.favthings_placeholder_female').append(html);
}function addFavThingsMale(){

  var favnum =  $('.favthings_addmore').length;
 
  var html = '';
  html += '<div class="row favthings_addmore">';

  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_fav_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-1 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN remove-favthings" onclick="removeFavThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.favthings_placeholder_male').append(html);
}
function addWishThings(){

  var favnum =  $('.wishthings_addmore').length;
  var html = '';
  html += '<div class="row wishthings_addmore">';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-12 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN" onclick="removeWishThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.wishlist_placeholder').append(html);
}
function removeWishThings(){
  $('.wishthings_addmore').last().remove();
}
function addWishThingsMale(){

  var favnum =  $('.wishthings_addmore').length;
  var html = '';
  html += '<div class="row wishthings_addmore">';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-12 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN" onclick="removeWishThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.wishlist_placeholder_male').append(html);
}
function addWishThingsFemale(){

  var favnum =  $('.wishthings_addmore').length;
  var html = '';
  html += '<div class="row wishthings_addmore">';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][label]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-4 col-sm-12 col-xs-12">';
  html += '<input type="text" name="custom_wish_things['+favnum+'][value]" class="form-control" id="inputText" placeholder="Place your text">';
  html += '</div>';
  html += '<div class="col-md-1 col-sm-12 col-xs-12">';
  html += '<a href="javascript:void(0)" class="remove-BTN" onclick="removeWishThings()"><i class="fa fa-minus"></i></a>';
  html += '</div></div>';
  $('.wishlist_placeholder_female').append(html);
}

function addTour(){
  /*if ($('.touring_girls .select_city_box').data('select2')) {
    $(".touring_girls .select_city_box").select2("destroy");
    $('.touring_girls .select_city_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }*/

 /*if ($('.select_country_box').data('select2')) {
  $(".select_country_box").select2("destroy");
  $('.select_country_box')
  .removeAttr('data-live-search')
  .removeAttr('data-select2-id')
  .removeAttr('aria-hidden')
  .removeAttr('tabindex');
}
 */
/*var num =  $('.touring_girls').length;

var clone = $(".touring_girls").first().clone();
clone.attr('id', 'touring_girls'+num);

clone.find(".select_city_box").attr("id", "tour_city"+num);
clone.find('.select_city_box option[value!=""]').remove();

clone.find('.select_country_box').attr('name', "new_tour["+num+"][country]");
clone.find('.select_city_box').attr('name', "new_tour["+num+"][city]");
clone.find(".select_country_box").attr("id", "tour_country"+num);

clone.find(".select_country_box option[selected]").removeAttr("selected");    
clone.find(':input.enddate').attr("id", "").removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({dateFormat:'dd/mm/yy',minDate : new Date(mindatepickerDate),maxDate : new Date(maxdatepickerDate)});
clone.find(':input.startdate').attr("id", "").removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({dateFormat:'dd/mm/yy',minDate : new Date(mindatepickerDate),maxDate : new Date(maxdatepickerDate)});
clone.find('input.startdate').attr('name', "new_tour["+num+"][startdate]");
clone.find('input.enddate').attr('name', "new_tour["+num+"][enddate]");
clone.insertBefore('#touring-section-placeholder');
var html = '<a href="javascript:void(0)" class="servicefee-btn-remove remove-tour" onclick="removeTour()"><i class="fa fa-minus"></i></a>';
clone.find('.my-feesbtn').html(html);
*///$(".select_city_box").select2();
//$(".select_country_box").select2();
var num =  parseInt($('#tourcount').val());
var html = $(".nationalTouring").html();
var xx="";
var x1="";
var edt="";
//clone.attr('id', 'touring_girls'+num);


$("#touring-section-placeholder").before(html);
$('#tourcount').val(num+1);
$(".Newzealand").find('.touring_girls00').find(".select_city_box").attr("id", "tour_city"+num);
$(".Newzealand").find('.touring_girls00').find('.select_city_box option[value!=""]').remove();
$(".Newzealand").find('.touring_girls00').find('#removeTourBtns').attr('id','removeTourBtns'+num);
$(".Newzealand").find('.touring_girls00').find('.select_country_box').attr('name', "new_tour["+num+"][country]");
$(".Newzealand").find('.touring_girls00').find('.select_city_box').attr('name', "new_tour["+num+"][city]");
$(".Newzealand").find('.touring_girls00').find(".select_country_box").attr("id", "tour_country"+num);
$(".Newzealand").find('.touring_girls00').find(".select_country_box option[selected]").removeAttr("selected");    
//$(".Newzealand").find('.touring_girls00').find(':input.startdate').attr("id", "").removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({dateFormat:'dd/mm/yy',minDate : new Date(mindatepickerDate),maxDate : new Date(maxdatepickerDate)});
//$(".Newzealand").find('.touring_girls00').find('.two-inputs').unbind().daterangepicker({opens: 'left'}, function(start, end, label) {$('#startdate'+num).val(start.format('DD-MM-YYYY'));$('#enddate'+num).val(end.format('DD-MM-YYYY'));});
$(".Newzealand").find('.touring_girls00').find(".two-inputs").attr("id", "two-inputs"+num);
$(".Newzealand").find('.touring_girls00').find(".two-inputs").find(".startdate").attr("id", "startdate"+num);
$(".Newzealand").find('.touring_girls00').find(".two-inputs").find(".enddate").attr("id", "enddate"+num);
$(".Newzealand").find('.touring_girls00').find('input.startdate').attr('name', "new_tour["+num+"][startdate]");
$(".Newzealand").find('.touring_girls00').find('input.enddate').attr('name', "new_tour["+num+"][enddate]");
$(".Newzealand").find('.touring_girls00').closest('.touring_girls00').attr('id', 'touring_girls'+num);
$(".Newzealand").find('.touring_girls00').closest('.touring_girls00').attr('class', 'touring_girls');
    

}


function deleteTour(id,deleteId){
  
   $.ajax({
    type:"POST",
    url: deleteTourURL,
    data : {id:id, _token:token_value},
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      
      removeTour(deleteId);
    }
  }); 

}

function deleteIntTour(id,deleteId){
  
   $.ajax({
    type:"POST",
    url: deleteTourURL,
    data : {id:id, _token:token_value},
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      
      removeInterTour(deleteId);
    }
  }); 

}
function addInterTour(){
  /*if ($('.inter_touring_girls .select_city_box').data('select2')) {
    $(".inter_touring_girls .select_city_box").select2("destroy");
    $('.inter_touring_girls .select_city_box')
    .removeAttr('data-live-search')
    .removeAttr('data-select2-id')
    .removeAttr('aria-hidden')
    .removeAttr('tabindex');
 }*/

 /*if ($('.select_country_box').data('select2')) {
  $(".select_country_box").select2("destroy");
  $('.select_country_box')
  .removeAttr('data-live-search')
  .removeAttr('data-select2-id')
  .removeAttr('aria-hidden')
  .removeAttr('tabindex');
}
 */
var num =  parseInt($('#tourcount').val());
var html = $(".interNationalTouring").html();
$('#tourcount').val(num+1);
$("#inter_touring-section-placeholder").before(html);
$(".intenational").find('.inter_touring_girls00').find('.select_city_box option[value!=""]').remove();

$(".intenational").find('.inter_touring_girls00').find('.select_country_box').attr('name', "new_inter_tour["+num+"][country]");
$(".intenational").find('.inter_touring_girls00').find('.select_city_box').attr('name', "new_inter_tour["+num+"][city]");
$(".intenational").find('.inter_touring_girls00').find('.select_city_box').attr("id", "inter_tour_city"+num);
$(".intenational").find('.inter_touring_girls00').find(".select_country_box").attr("id", "inter_tour_country"+num);

$(".intenational").find('.inter_touring_girls00').find('#removeInterTourBtns').attr('id','removeInterTourBtns'+num);
//$(".intenational").find('.inter_touring_girls00').find(".select_country_box option[selected]").removeAttr("selected");    
$(".intenational").find('.inter_touring_girls00').find(".two-inputs").attr("id", "two-inputs"+num);
$(".intenational").find('.inter_touring_girls00').find(".two-inputs").find(".startdate").attr("id", "startdate"+num);
$(".intenational").find('.inter_touring_girls00').find(".two-inputs").find(".enddate").attr("id", "enddate"+num);

//$(".intenational").find('.inter_touring_girls00').find(':input.inter_enddate').attr("id", "inter_enddate"+num).removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({dateFormat:'dd/mm/yy',minDate : new Date(mindatepickerDate)});
//$(".intenational").find('.inter_touring_girls00').find(':input.inter_startdate').attr("id", "inter_startdate"+num).removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({dateFormat:'dd/mm/yy',minDate : new Date(mindatepickerDate)});

$(".intenational").find('.inter_touring_girls00').find('input.inter_startdate').attr('name', "new_inter_tour["+num+"][startdate]");
$(".intenational").find('.inter_touring_girls00').find('input.inter_enddate').attr('name', "new_inter_tour["+num+"][enddate]");
//clone.insertBefore('#inter_touring-section-placeholder');
//clone.find('.remove-tour').css("display", "inline-block");
$(".intenational").find('.inter_touring_girls00').closest('.inter_touring_girls00').attr('id', 'inter_touring_girls'+num);
$(".intenational").find('.inter_touring_girls00').closest('.inter_touring_girls00').attr('class', 'inter_touring_girls');

/*var clone = $(".inter_touring_girls").first().clone();
clone.attr('id', 'inter_touring_girls'+num);

clone.find(".select_city_box").attr("id", "inter_tour_city"+num);
clone.find('.select_city_box option[value!=""]').remove();

clone.find('.select_country_box').attr('name', "new_inter_tour["+num+"][country]");
clone.find('.select_city_box').attr('name', "new_inter_tour["+num+"][city]");
clone.find(".select_country_box").attr("id", "inter_tour_country"+num);

clone.find(".select_country_box option[selected]").removeAttr("selected");    
clone.find(':input.inter_enddate').attr("id", "inter_enddate"+num).removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({dateFormat:'dd/mm/yy',minDate : new Date(mindatepickerDate)});
clone.find(':input.inter_startdate').attr("id", "inter_startdate"+num).removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({dateFormat:'dd/mm/yy',minDate : new Date(mindatepickerDate)});
clone.find('input.inter_startdate').attr('name', "new_inter_tour["+num+"][startdate]");
clone.find('input.inter_enddate').attr('name', "new_inter_tour["+num+"][enddate]");
clone.insertBefore('#inter_touring-section-placeholder');
clone.find('.remove-tour').css("display", "inline-block");
*///$(".select_city_box").select2();
//$(".select_country_box").select2();


}
function removeTour(deleteID){
  var delId = deleteID.replace("removeTourBtns", "touring_girls");
  //console.log()
          
$("#"+delId).remove();
}
function removeInterTour(deleteID){
  var delId = deleteID.replace("removeInterTourBtns", "inter_touring_girls");
  //console.log()
          
$("#"+delId).remove();
//$(".inter_touring_girls:last .remove-tour").closest('.inter_touring_girls').remove();
}

var num = 4;


function readImage() {
var num = $(".preview-image").length;
var total = $(".preview-profile-image").length;
if(total >= 20){
  alert("Sorry! you have exceed your limit. You can only upload 20 images.");
    return false;
}
  if (window.File && window.FileList && window.FileReader) {
  var files = event.target.files; //FileList object
 
   var allwedfiles= 20;
  var remainingfiles = parseInt(allwedfiles) - parseInt(num);
  if(files.length > remainingfiles){
    alert("You can select only " + remainingfiles + " files.");
    return false;
  }else if(files.length > 10){
    alert("You can select upto 10 images only at one time.");
    return false;
  }
  var output = $(".preview-images-zone");
  var formdata = new FormData();
  var imageToBig = false;
  for (let i = 0; i < files.length; i++) {
  var file = files[i];
  if(file.size > 5000000){
    imageToBig = true;
    
  }
  
  if (!file.type.match('image')) {
      alert("Only images are allowed to upload.");
      return false;
    }
  
        if (formdata) {
            formdata.append("pro-image[]", file);
        }
    
  }
  } else {
  console.log('Browser not support');
  }
 /*if(imageToBig){
  alert("One of your file is too large to process. You can choose only upto 5 mb.");
  return false;
 }*/

    if (formdata) {
   // formdata.append("pro-image", file);
    formdata.append("_token", $('input[name="_token"]').val());
    $("#Load").fadeIn('slow');
    $.ajax({
      url : imagePostURL,
      type: "POST",
      data : formdata,
      contentType: false,
      cache: false,
      processData:false,
      mimeType:"multipart/form-data",
   success: function(res1){
               $("#Load").fadeOut('fast');
      var res = JSON.parse(res1);
      if(res != ""){
        
        var html="";
        for(var j=0; j< res.length; j++){
            html +=  '<div class="preview-image preview-show-' + num + ' preview-profile-image">' +
      '<div class="image-settings-icons" data-no="' + num + '">'+
      '<a href="javascript:void(0)" onclick="showImage('+num+')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>'+
      '<a href="javascript:void(0)" onclick=removeImage("'+res[j]+'",'+num+')><i class="fas fa-trash-alt"></i></a></div>'+
      '<div class="image-zone"><img  id="pro-img-' + num + '" src="' + res[j] + '"></div>' +
      '<div class="radio radio-info form-check-inlinesquarebox image-zone1">'+
      '<input type="hidden" value="'+res[j]+'" name="imageurl['+num+'][image]" class="imageurl">'+
      '<input type="checkbox" name="imageurl['+num+'][img_is_add_default]" data-image-index ="'+num+'" id="pro-img1-' + num + '" class="img_is_add_default css-checkbox"><label for="pro-img1-' + num + '" class="css-label">Set as main image</label></div>'+
      '</div>';
      num++;
        }
        output.append(html);
        
        }
               
       },
      error: function(jqXHR, errorThrown) {
           $("#ErrorModel").modal('show');
          $("#Load").hide();

               }

    })
  }
  
  $("#pro-image").val('');
  
  }

function removeImage(link, num){
   
    $.ajax({
    type:"POST",
    url: deleteImageURL,
    data : {image_url:link, _token:token_value, type:'removeimagefromserver'},
    beforeSend: function(){
      $("#Load").fadeIn('slow');
    },
    success: function(result){
      $("#Load").fadeOut('fast');
      $(".preview-image.preview-show-"+num).remove();
    }
  }); 

}

$(document).ready(function(){
  $('.select_box').on('select2:select', function (e) {
   
    if($(this).val() != ""){
      $(this).next().find('.select2-selection--single').removeClass('error');
    }else{
      $(this).next().find('.select2-selection--single').addClass('error');
    }
    
  });





      /*$('body').on('focus', ".startdate", function() {
        $('.startdate').datepicker({
          dateFormat:'dd/mm/yy',
        minDate : new Date(mindatepickerDate),
        maxDate : new Date(maxdatepickerDate),
            beforeShowDay: function(d) {
        var dmy = (d.getMonth()+1)
        if(d.getMonth()<9) 
            dmy="0"+dmy; 
        dmy+= "-"; 

        if(d.getDate()<10) dmy+="0"; 
            dmy+=d.getDate() + "-" + d.getFullYear(); 

        console.log(dmy+' : '+($.inArray(dmy, availableDates)));

        if ($.inArray(dmy, availableDates) != -1) {
            return [true, "","Available"]; 
        } else{
             return [false,"","unAvailable"]; 
        }
      },console.log('test'));
      });*/
/*
      $('body').on('focus', ".two-inputs", function() {
    
    some_date_range = [];
    x=$(this).attr('id');
    x1=x.split('two-inputs');
    j1=$("#startdate"+x1[1]).val();
    console.log(j1);
    if (j1==="") {
      j1="01/01/2020";
    }
    jx=j1.split("/");
    start1=jx[1]+"/"+jx[0]+"/"+jx[2];
    j2=$("#enddate"+x1[1]).val();
    if (j2==="") {
      j2="01/01/2020";
    }
    jx1=j2.split("/");
    end1=jx1[1]+"/"+jx1[0]+"/"+jx1[2];
    mxd=maxDate.split("-");
    m1=mxd[1]+"/"+mxd[2]+"/"+mxd[0];
    mindt=mindatepickerDate;
    mn=0;
    cs=parseInt(x1[1]);
    rl=parseInt($("#tourcount").val());
    if(rl===0){
      rl=2;
    }
    while(mn<rl){
      if(mn===cs){}else{
        if($("#startdate"+mn).length>0){
      st1=$("#startdate"+mn).val();
      console.log(mn);
      console.log(st1);
      st2=st1.split("/");
      st1=st2[1]+"/"+st2[0]+"/"+st2[2];
      en1=$("#enddate"+mn).val();
      en2=en1.split("/");
      en1=en2[1]+"/"+en2[0]+"/"+en2[2];

      currentDate = new Date(st1);
      en1 = new Date(en1);
      console .log(en1);
      
      while (currentDate <= en1) {
        var today=new Date(currentDate);
        var dd = today.getDate(); 
        var mm = today.getMonth() + 1; 
        var yyyy = today.getFullYear(); 
        if (dd < 10) { 
            dd = '0' + dd; 
        } 
        if (mm < 10) { 
            mm = '0' + mm; 
        } 
        var today = dd + '/' + mm + '/' + yyyy; 
        if(some_date_range.indexOf(today) !== -1){
        } else{
            some_date_range.push(today);
        }
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
    }
    }
    mn=mn+1;
    }
    console.log(some_date_range);

    $(this).daterangepicker({
    "autoApply": true,
    //linkedCalendars: false,
    autoUpdateInput: true,
    startDate:start1,
    endDate:end1,
    isInvalidDate: function(date) {
    for(var ii = 0; ii < some_date_range.length; ii++){
    if (date.format('DD/MM/YYYY') == some_date_range[ii]){
      return true;
        }
      }
    },
    minDate:mindt,
    maxDate:m1,
    
  }, function(start, end, label) {
    f1=0;
    $('.prev.available').css('display','none');
    console.log(start);
    currentDate=new Date(start);
    en1=new Date(end);
    console.log(currentDate);
    while (currentDate <= en1) {
        var today=new Date(currentDate);
        var dd = today.getDate(); 
        var mm = today.getMonth() + 1; 
        var yyyy = today.getFullYear(); 
        if (dd < 10) { 
            dd = '0' + dd; 
        } 
        if (mm < 10) { 
            mm = '0' + mm; 
        } 
        var today = dd + '/' + mm + '/' + yyyy; 
        if(some_date_range.indexOf(today) !== -1){
          f1=1;
          break;
        } 
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
    if(f1===0){
    $('#startdate'+x1[1]).val(start.format('DD/MM/YYYY'));
    $('#enddate'+x1[1]).val(end.format('DD/MM/YYYY'));
    
    cc=parseInt(x1[1])+1;
    console.log(cc);
    if (parseInt($("#tourcount").val())>cc) {
      console.log('testok');
          $("#two-inputs"+cc).daterangepicker({
              minDate:mindt,maxDate:m1
            }, 
            function(start, end, label) {
        $('#startdate'+cc).val(start.format('DD/MM/YYYY'));
        $('#enddate'+cc).val(end.format('DD/MM/YYYY'));
        });
    }
  }
  else{
    alert('Selected Dates have already Tour!');
    $('#startdate'+x1[1]).val();
    $('#enddate'+x1[1]).val();
  }
  
  });
  });

      */
      $('body').on('focus', ".startdate", function() {
    
    some_date_range = [];
    mindt1=mindatepickerDate.split("/");
    mindt=mindt1[1]+"/"+mindt1[0]+"/"+mindt1[2];
    x=$(this).attr('id');
    x1=x.split('startdate');
    j1=$("#startdate"+x1[1]).val();
    console.log(j1);
    if (j1==="") {
      j1=mindt;
    }
    jx=j1.split("/");
    start1=jx[0]+"/"+jx[1]+"/"+jx[2];
    j2=$("#enddate"+x1[1]).val();
    if (j2==="") {
      j2=mindt;
    }
    jx1=j2.split("/");
    end1=jx1[0]+"/"+jx1[1]+"/"+jx1[2];
    mxd=maxDate.split("-");
    m1=mxd[2]+"/"+mxd[1]+"/"+mxd[0];
    
    //mindt=mindatepickerDate;
    //mindt="12/10/2020";
    mn=0;
    cs=parseInt(x1[1]);
    rl=parseInt($("#tourcount").val());
    if(rl===0){
      rl=2;
    }
    while(mn<rl){
      if(mn===cs){}else{
        if($("#startdate"+mn).length>0){
      st1=$("#startdate"+mn).val();
      console.log(mn);
      console.log(st1);
      st2=st1.split("/");
      st1=st2[1]+"/"+st2[0]+"/"+st2[2];
      if($("#enddate"+mn).val()!=="")
      	en1=$("#enddate"+mn).val();
      else
      	en1=$("#startdate"+mn).val();
      en2=en1.split("/");
      en1=en2[1]+"/"+en2[0]+"/"+en2[2];

      currentDate = new Date(st1);
      en1 = new Date(en1);
      console .log(en1);
      
      while (currentDate <= en1) {
        var today=new Date(currentDate);
        var dd = today.getDate(); 
        var mm = today.getMonth() + 1; 
        var yyyy = today.getFullYear(); 
        if (dd < 10) { 
            dd = '0' + dd; 
        } 
        if (mm < 10) { 
            mm = '0' + mm; 
        } 
        var today = dd + '/' + mm + '/' + yyyy; 
        if(some_date_range.indexOf(today) !== -1){
        } else{
            some_date_range.push(today);
        }
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
    }
    }
    mn=mn+1;
    }
    console.log(some_date_range);

    $(this).daterangepicker({   
    
    singleDatePicker: true,
    autoUpdateInput: false,
    locale: {
      format: 'DD/MM/YYYY'
    },
    isInvalidDate: function(date) {
    for(var ii = 0; ii < some_date_range.length; ii++){
    if (date.format('DD/MM/YYYY') == some_date_range[ii]){
      return true;
        }
      }
    },
    minDate:mindt,
    maxDate:m1,
    
  });
$(".startdate").on('apply.daterangepicker', function(ev, picker) {
   
   start=picker.startDate; end=picker.endDate;
    f1=0;
    if ($('#enddate'+x1[1]).val()!==""){ 
    	
    currentDate=new Date(start);
    en1=$('#enddate'+x1[1]).val();
    en2=en1.split("/");
    en1=en2[1]+"/"+en2[0]+"/"+en2[2];
    en1=new Date(en1);
    if(currentDate<=en1){
	    while (currentDate <= en1) {
	        var today=new Date(currentDate);
	        var dd = today.getDate(); 
	        var mm = today.getMonth() + 1; 
	        var yyyy = today.getFullYear(); 
	        if (dd < 10) { 
	            dd = '0' + dd; 
	        } 
	        if (mm < 10) { 
	            mm = '0' + mm; 
	        } 
	        var today = dd + '/' + mm + '/' + yyyy; 
	        if(some_date_range.indexOf(today) !== -1){
	          f1=1;
	          break;
	        } 
	        
	        currentDate.setDate(currentDate.getDate() + 1);
	      }
	    if(f1===0){
	    $('#startdate'+x1[1]).val(start.format('DD/MM/YYYY'));
	    
	    
	    cc=parseInt(x1[1])+1;
	    console.log(cc);
	    if (parseInt($("#tourcount").val())>cc) {
	      console.log('testok');
	          $("#startdate"+cc).daterangepicker({
	              "autoApply": true,
			    linkedCalendars: false,
			    singleDatePicker: true,
			    autoUpdateInput: false,    
			    locale: {
			      format: 'DD/MM/YYYY'
			    },minDate:mindt,maxDate:m1
	            }, 
	            function(start, end, label) {
	        $('#startdate'+cc).val(start.format('DD/MM/YYYY'));
	        $('#enddate'+cc).val(end.format('DD/MM/YYYY'));
	        });
	    }
	  }
	  else{
	    alert('Selected Dates have already Tour!');
	    $('#startdate'+x1[1]).val();
	    $('#enddate'+x1[1]).val();
	  }
  }
  	else{
	    alert('Select Start Tour Date lessthen or Equal to End Tour Date !');
	    $('#startdate'+x1[1]).val();
	    $('#enddate'+x1[1]).val();
	  }
	}else{
		$('#startdate'+x1[1]).val(picker.startDate.format('DD/MM/YYYY'));
		//$('#enddate'+x1[1]).val(start.format('DD/MM/YYYY'));
	}
  });
  });


     $('body').on('focus', ".enddate", function() {
    
    some_date_range = [];
    mindt1=mindatepickerDate.split("/");
    mindt=mindt1[1]+"/"+mindt1[0]+"/"+mindt1[2];
    x=$(this).attr('id');
    x1=x.split('enddate');
    j1=$("#startdate"+x1[1]).val();
    console.log(j1);
    if (j1==="") {
      j1=mindt;
    }
    jx=j1.split("/");
    start1=jx[0]+"/"+jx[1]+"/"+jx[2];
    j2=$("#enddate"+x1[1]).val();
    if (j2==="") {
      j2=mindt;
    }
    jx1=j2.split("/");
    end1=jx1[0]+"/"+jx1[1]+"/"+jx1[2];
    mxd=maxDate.split("-");
    m1=mxd[2]+"/"+mxd[1]+"/"+mxd[0];
    
    //mindt=mindatepickerDate;
    //mindt="12/10/2020";
    mn=0;
    cs=parseInt(x1[1]);
    rl=parseInt($("#tourcount").val());
    if(rl===0){
      rl=2;
    }
    while(mn<rl){
      if(mn===cs){}else{
        if($("#startdate"+mn).length>0 && $("#startdate"+mn).val()!==""){
      st1=$("#startdate"+mn).val();
      console.log(mn);
      console.log(st1);
      st2=st1.split("/");
      st1=st2[1]+"/"+st2[0]+"/"+st2[2];
      if($("#enddate"+mn).val()!=="")
      	en1=$("#enddate"+mn).val();
      else
      	en1=$("#startdate"+mn).val();
      en2=en1.split("/");
      en1=en2[1]+"/"+en2[0]+"/"+en2[2];

      currentDate = new Date(st1);
      en1 = new Date(en1);
      console .log(en1);
      
      while (currentDate <= en1) {
        var today=new Date(currentDate);
        var dd = today.getDate(); 
        var mm = today.getMonth() + 1; 
        var yyyy = today.getFullYear(); 
        if (dd < 10) { 
            dd = '0' + dd; 
        } 
        if (mm < 10) { 
            mm = '0' + mm; 
        } 
        var today = dd + '/' + mm + '/' + yyyy; 
        if(some_date_range.indexOf(today) !== -1){
        } else{
            some_date_range.push(today);
        }
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
    }
    }
    mn=mn+1;
    }
    console.log(some_date_range);

    $(this).daterangepicker({
    //"autoApply": true,
    linkedCalendars: false,
    singleDatePicker: true,
    autoUpdateInput: false,
    
    locale: {
      format: 'DD/MM/YYYY'
    },
    isInvalidDate: function(date) {
    for(var ii = 0; ii < some_date_range.length; ii++){
    if (date.format('DD/MM/YYYY') == some_date_range[ii]){
      return true;
        }
      }
    },
    minDate:mindt,
    maxDate:m1,
    
  });
$(".enddate").on('apply.daterangepicker', function(ev, picker) {
   
   start=picker.startDate; end=picker.endDate;
    f1=0;
    if ($('#startdate'+x1[1]).val()!=="") {
    st1=$('#startdate'+x1[1]).val();
    st2=st1.split("/");
    st1=st2[1]+"/"+st2[0]+"/"+st2[2];
    currentDate=new Date(st1);
    
    en1=new Date(end);
    if(currentDate<=en1){
    while (currentDate <= en1) {
        var today=new Date(currentDate);
        var dd = today.getDate(); 
        var mm = today.getMonth() + 1; 
        var yyyy = today.getFullYear(); 
        if (dd < 10) { 
            dd = '0' + dd; 
        } 
        if (mm < 10) { 
            mm = '0' + mm; 
        } 
        var today = dd + '/' + mm + '/' + yyyy; 
        if(some_date_range.indexOf(today) !== -1){
          f1=1;
          break;
        } 
        
        currentDate.setDate(currentDate.getDate() + 1);
      }

    if(f1===0){
    	if($('#startdate'+x1[1]).val()==="")
    		$('#startdate'+x1[1]).val(start.format('DD/MM/YYYY'));
    $('#enddate'+x1[1]).val(end.format('DD/MM/YYYY'));
    
    cc=parseInt(x1[1])+1;
    console.log(cc);
    if (parseInt($("#tourcount").val())>cc) {
      console.log('testok');
          $("#enddate"+cc).daterangepicker({
              "autoApply": true,
			    linkedCalendars: false,
			    singleDatePicker: true,
			    autoUpdateInput: false,    
			    locale: {
			      format: 'DD/MM/YYYY'
			    },minDate:mindt,maxDate:m1
            }, 
            function(start, end, label) {
        //$('#startdate'+cc).val(start.format('DD/MM/YYYY'));
        $('#enddate'+cc).val(end.format('DD/MM/YYYY'));
        });
    }
  }
  else{
    alert('Selected Dates have already Tour!');
    $('#startdate'+x1[1]).val();
    $('#enddate'+x1[1]).val();
  }
}
else{
	alert('Select bigger date!');
    $('#startdate'+x1[1]).val();
    $('#enddate'+x1[1]).val();
}
  }else{
    alert('Select First Start Date of this Tour!');
    $('#startdate'+x1[1]).val();
    $('#enddate'+x1[1]).val();
  }
  });
  });

});

function showImage(id,type=""){
   var imghei = imgwid = imgx = imgy = '';
  $('#imgeType').val(id);
  var imageOriganalName = $("#pro-img-"+id).attr('src');
if(type == ''){
  var imageOriganalName = $("#pro-img-"+id).attr('src');
  $original_image = imageOriganalName;
}else{
  var imageOriganalNames = $("#pro-img-"+id).attr('src');
  //$original_images = $("#pro-img-"+id).attr('src');
  imageOriganalName = imageOriganalNames.replace('_202*182.jpg','');
  $original_image = imageOriganalName;
 
  
 
  //var imageOriganalName = imageOriganalName;
}

 $.ajax({
      url : editImageOpen,
      method: 'GET',
      data : {url:imageOriganalName},
      success:function(response){
          var imghei = imgwid = imgx = imgy = '';
          /*var ow= document.getElementById("imagepreview").offsetWidth;
          var oh=document.getElementById("imagepreview").offsetHeight;
          naturalWidth = document.getElementById("imagepreview").naturalWidth;
       naturalHeight = document.getElementById("imagepreview").naturalHeight;*/
          $('#ImageNodal').html(response);
          
          visible_width=200;
       visible_height=200;
       


      },
  });

//var finalsImageName = imageOriganalName.replace('https://www.houseofsexygirls.co.nz');
////var getFinalImagePath = 

$("#imagemodal").modal('show'); 
  //$('img#imagepreview').attr('src', imageOriganalName); 
  // here asign the image to the modal when the user click the enlarge link
  console.log(imageOriganalName);
  
  
  imageSalectionValue = {x1 : imgx, y1 : imgy, x2 : imgwid, y2: imghei}

  /*$('img#imagepreview').imgAreaSelect({
    x1 : 1, y1 : 1, x2 : 100, y2: 100, aspectRatio: '0:0', handles: true  ,parent:'imagemodal'
     });
imageSalectionValue ={ x1 : 1, y1 : 1, x2 : 100, y2: 100};*/
console.log(imageSalectionValue);

    
 // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
 
}



function getCity(id){
  if(id !== ""){
    $.ajax({
         headers: {
            'X-CSRF-TOKEN': $('input[name="_token"]').val()
          },
       type:"post",
       url:fetchcityURL,
       data:{country_id:id},
       success: function(data){
          $("#city_name").html(data);
       }
    });
    }
  
}

function getTourCity(id, countryid){
  if(id !== ""){
    $.ajax({
         headers: {
            'X-CSRF-TOKEN': $('input[name="_token"]').val()
          },
       type:"post",
       url:fetchcityURL,
       data:{country_id:id,'type':'touring'},
       success: function(data){
         var cityid = countryid.replace("tour_country", "tour_city");
          $("#"+cityid).html(data);
       }
    });
    }
  
}
function getInterTourCity(id, countryid){

  if(id !== ""){
    
    $.ajax({
         headers: {
            'X-CSRF-TOKEN': $('input[name="_token"]').val()
          },
       type:"post",
       url:fetchcityURL,
       data:{country_id:id,'type':'touring'},
       success: function(data){
        
         var cityid = countryid.replace("inter_tour_country", "inter_tour_city");
         
          $("#"+cityid).html(data);
       }
    });
    }
  
}
/*
class FireworkParticle {
  
  constructor( context, width, height, total ) {
    this.context = context;  
    this.width = width;
    this.height = height;
    this.total = total;
    this.done = 0;
    this.x = 0;
    this.xTo = 0;
    this.y = 0;
    this.yTo = 0;
    this.ease = 20;
    this.size = 300;
    this.hue = 0, 
    this.particles = [];
    this.reset(); 
  }
  
  between( min, max ) {
    return Math.random() * ( max - min + 1 ) + min;
  }
  
  complete() {
    return ( this.done >= this.total );
  }
  
  reset() {
    this.particles = [];
    this.x = this.between( 100, this.width - 100 );
    this.xTo = this.between( this.x + 100, this.x - 100 );
    this.y = this.height + 10;
    this.yTo = this.height / 2 - this.between( 0, 200 );
    this.ease = this.between( 12, 20 );
    this.hue = this.between( 100, 360 );
    this.done = 0;
  }
  
  explode() {
    this.particles = [];
    this.context.clearRect( 0, 0, this.width, this.height ); // flash 
    
    for ( let i = 0; i < this.total; i++ ) {
      this.particles.push( {
        x     : this.x,
        y     : this.y,
        xTo   : this.between( this.x - this.size, this.x + this.size ),
        yTo   : this.between( this.y - this.size, this.y + this.size ),
        size  : this.between( 1, 3 ),
        ease  : this.between( 8, 28 ),
        hue   : this.between( this.hue - 100, this.hue ),
        alpha : 1
      });
    }
  }
  
  update( width, height ) {
    this.width = width || this.width;
    this.height = height || this.height;
    this.x += ( this.xTo - this.x ) / this.ease;
    this.y += ( this.yTo - this.y ) / this.ease;
  }
  
  drawBomb() {
    this.context.beginPath();
    this.context.arc( this.x, this.y, 2, 0, 2 * Math.PI, false );
    this.context.fillStyle = `hsl( ${this.hue}, 100%, 60% )`;
    this.context.fill();
  }
  
  drawParticles() {
    for ( let i = 0; i < this.particles.length; i++ ) {
      const p = this.particles[ i ];

      if ( p.alpha >= 0 ) {
        this.context.beginPath();
        this.context.arc( p.x, p.y, p.size, 0, 2 * Math.PI, false );
        this.context.fillStyle = `hsla( ${p.hue}, 100%, 60%, ${p.alpha} )`;
        this.context.fill();

        p.x += ( p.xTo - p.x ) / p.ease;
        p.y += ( p.yTo - p.y ) / p.ease;
        p.alpha -= 0.014;
        continue;
      }
      this.particles.splice( i, 1 );
      this.done += 1;
    }
  }
  
  draw() {
    if ( this.complete() ) return;
    if ( this.y > this.yTo + 20 ) { this.drawBomb(); } 
    else if ( !this.particles.length ) { this.explode(); } 
    else { this.drawParticles(); } 
  }
}
*/
$("body").on("click", ".plan_remove", function(){
       $('#featured_profile_price').val('');
        $('#featured_profile_day').val('');
        $('#teaser_video_price').val('');
        $('#teaser_video_day').val('');
        $('#super_speed_price').val('');
        $('#super_speed_day').val('');
        $('#teaser_video_two_price').val('');
        $('#teaser_video_two_day').val('');
        $("#user_selected_plan").val('');
        $(".price-section-overview").html('');
         $(".price-section-overview").hide();
         $("li input").prop('checked',false);
})
  $(document).ready(function(){
     
    $(".sub-add-on-features").change(function(){
      if($("#user_selected_plan").val() !=  $(this).attr('data-selected-plan-id')){
        $('#featured_profile_price').val('');
        $('#featured_profile_day').val('');
        $('#teaser_video_price').val('');
        $('#teaser_video_day').val('');
        $('#super_speed_price').val('');
        $('#super_speed_day').val('');
        $('#teaser_video_two_price').val('');
        $('#teaser_video_two_day').val('');
        
        
      }

var featurenameArray = new Array();
      var featurename = $(this).attr('data-feature-name');
      var crrval=$(this).val();
      var unselectFeature = Array();
      //console.log(crrval);
      /*if(crrval == 'on'){
        $('.sub-add-on-features:checked').each(function(i, opt){
          console.log(opt.value);
          if (opt.value==""){
            console.log("."+featurename+"_none");
            opt.checked = false;
          }
            $("."+featurename+"_none").prop('checked',false);
          }else{
                      opt.checked =true;
          }
        });

      }
      if(crrval == ''){
        $("."+featurename+"li input").prop('checked',false);
        $(this).prop('checked',true);
      }*/

      
      
      //console.log(crrval);
      /*if(crrval == ""){
    $('.sub-add-on-features').each(function(i, opt){ 
      console.log($(this).val());
          if ($(this).val()==""){
            $(this).prop('checked',true) ;
          }else{
        $(this).prop('checked',false) ;
        
      }
    });
  }
if(crrval == "on"){
    $('.sub-add-on-features').each(function(i, opt){ 
      console.log($(this).val());
          if ($(this).val()!="on"){
            $(this).prop('checked',false) ;
          }
    });
  }*/

    

      //new multi select option code 
      var selets = new Array();
    var textData = new Array();
    
     var dataIdarray = Array(); 
     

       $('.sub-add-on-features:checked').each(function(i, opt){
        
          var featurenametemp = $(this).attr('data-feature-name');
          var normalValue = $(this).attr('data-day');
          var dataPrice = $(this).attr('data-price');
          var dataId = $(this).attr("id");

        if(dataPrice == 0 ){
          unselectFeature.push(featurenametemp);
        } else{
          //console.log(opt);
        //if(opt.getAttribute("disabled") == false){

          //console.log(normalValue);
          //var splitVal = normalValue.split('-');
          featurenameArray.push(featurenametemp);
          selets.push(eval(dataPrice));
          textData.push(normalValue);
          dataIdarray.push(dataId);

        }
        

          //currencysymbol = splitVal[0];
       // }
       //console.log(splitVal);
        
    });
       //console.log(selets);
 //console.log(textData);
         var days = "";
    textData.forEach(function(value,index,array){
      var textnon = value.split("-");
      
      days = days + textnon[0] + ',';

    });

      //console.log(days);
    
    var strVal = days;
    var lastChar = strVal.slice(-1);
  if (lastChar == ',') {
  strVal = strVal.slice(0, -1);
  }
  selectedtext = strVal;
    //console.log(selectedtext);
     arrsum1 = arrsum2 = arrsum3 = arrsum4 =  0;
    arrday1 = arrday2 = arrday3 = arrday4 = ''; 
    unselectDataIdArray =Array();
    for (i = 0; i < featurenameArray.length; i++) {
      if(featurenameArray[i] == 'featured_profile'){
        var results = unselectFeature.includes(featurenameArray[i]);
        if(results == false){
          arrsum1 += selets[i];
          if(arrday1 == ''){
            arrday1 += textData[i];
          }else{
            arrday1 += ","+textData[i];
          }
        }else{
          unselectDataIdArray.push(dataIdarray[i]);
        }      


      }
      if(featurenameArray[i] == 'teaser_video'){
        var results2 = unselectFeature.includes(featurenameArray[i]);
        if(results2 == false){
          arrsum2 += selets[i];
           if(arrday2 == ''){
            arrday2 += textData[i];
          }else{
            arrday2 += ","+textData[i];
          }
        }else{
          unselectDataIdArray.push(dataIdarray[i]);
        } 
        
      }
      if(featurenameArray[i] == 'teaser_video_two'){
        var results3 = unselectFeature.includes(featurenameArray[i]);
        if(results3 == false){
          arrsum3 += selets[i];

           if(arrday3 == ''){
            arrday3 += textData[i];
          }else{
            arrday3 += ","+textData[i];
          }
        }else{
          unselectDataIdArray.push(dataIdarray[i]);
        } 
      }
      if(featurenameArray[i] == 'super_speed_boost'){
        var results4 = unselectFeature.includes(featurenameArray[i]);
        if(results4 == false){
          arrsum4 += selets[i];
           if(arrday4 == ''){
            arrday4 += textData[i];
          }else{
            arrday4 += ","+textData[i];
          }
        }else{
          unselectDataIdArray.push(dataIdarray[i]);
        } 
        
      }

    }
    const arrSum = parseFloat(Number(selets.reduce((a,b) => a + b, 0)).toFixed(2));
  //console.log(arrSum);
    /*var selectedtext = $(this).children('option:selected').val()
    console.log(selectedtext);*/


    

    /*var newSelectedText =  selectedtext.split(" ").join("");
    var finalnewSelectedText = newSelectedText.replace( /[\r\n]+/gm, "" );
    console.log(finalnewSelectedText);*/

    var html = "";
    var total = 0;
    //end new multiselect code
      if(featurename == 'featured_profile'){
         //upgrade = true;
        $('#featured_profile_price').val(arrsum1);
        $('#featured_profile_day').val(arrday1);
      }
      if(featurename == 'teaser_video'){
         //upgrade = true;
        $('#teaser_video_price').val(arrsum2);
        $('#teaser_video_day').val(arrday2);
      }
       if(featurename == 'teaser_video_two'){
         //upgrade = true;
        $('#teaser_video_two_price').val(arrsum3);
        $('#teaser_video_two_day').val(arrday3);
      }
       if(featurename == 'super_speed_boost'){
         //upgrade = true;
        $('#super_speed_price').val(arrsum4);
        $('#super_speed_day').val(arrday4);
      }
     

     
         var plan_id = $(this).attr('data-selected-plan-id');
          $("#user_selected_plan").val(plan_id);
           activePlan = plan_id;
                 $.ajax({
            type:"POST",
            url: $("#form_step_2").attr('action'),
            data : $("#form_step_2").serialize(),
            beforeSend: function(){
              $("#Load").fadeIn('slow');
            },
            success: function(result){
            res = result;
            if(res.error){
              alert(res.error);
               $("#Load").fadeOut('fast');
              return false;
            }
            if(res.no_of_days_exceeded){
              alert("You can't buy more than 90 days plan.");
              $("#Load").fadeOut('fast');
              return false;
            }
            for (j = 0; j < unselectDataIdArray.length; j++) {
              $("#"+unselectDataIdArray[j]).trigger("click");
            }
            genTokenValue = res.order_id;
            $(".price-cards-inner").removeClass('active-plan');
            $(this).parent().parent().addClass('active-plan');

             var redirectpayurl = RedirectURL+'?token='+genTokenValue;

              $("#Load").fadeOut('fast');
              $(".papx-section").html(res.formdata);
              $("#actual-price").text(res.actual_plan_price);
              $(".price-section-overview").show();
              

              html +='<div class="text-right whiteColor"><a href="javascript:void(0)" class="plan_remove"><i class="fa fa-close"></i></a></div>';

               html += '<div id="actual-price"><span class="plan-label">Plan Price:</span><span class="plan-price-label">'+res.actual_plan_price+'</span></div>';
              if(res.featured_profile_price){
              $("#featured-profile-price-shw").text(res.featured_profile_price);
               html += '<div id="featured-profile-price-shw"><span class="plan-label">Featured Profile:</span> <span class="plan-price-label">'+res.featured_profile_price+'</span></div>';
              }
              if(res.plan_teaser_price){
            
              html += '<div id="teaser-video-price-shw"><span class="plan-label">Sexy Teaser Video:</span> <span class="plan-price-label">'+res.plan_teaser_price+'</span></div>';
              }
              if(res.plan_teaser_two_price){
            
              html += '<div id="teaser-video-price-shw"><span class="plan-label">Dedicated Teaser Video:</span> <span class="plan-price-label">'+res.plan_teaser_two_price+'</span></div>';
              }
               if(res.plan_super_speed){
            
              html += '<div id="teaser-video-price-shw"><span class="plan-label">Super Boost(every 10mins):</span> <span class="plan-price-label">'+res.plan_super_speed+'</span></div>';
              }
              html += ' <div id="total-amount"><span class="plan-label">Total amount to be paid:</span> <span class="plan-price-label">'+res.total_amount_price+'</span></div>';

              html += ' <div id="vat-amount"><span class="plan-label"><small>GST included.</small></div>';

              html += ' <div id="next-button-mobile"><a href="'+redirectpayurl+'"  class="proceedPlan-btn" name="mobile_pay" id="mobile_pay">Proceed</a></div>';
              
             $(".price-section-overview").html(html);
          }

          })
          
    })

    $(".price-cards .select-plan").click(function(){
      upgrade = true;
      var plan_id = $(this).attr('data-selected-plan-id')
      var featured_profile_day = $(this).find('.sub-add-on-features');
      //find(':input[name=featured_profile]:checked').attr('data-day');
      //var teaser_video_day = $(this).find(':input[name=teaser_video]:checked').attr('data-day');
     var featured_profile_days = $('.featured_profile_day input[name=featured_profile]:checked').attr('data-day');
     activePlan = plan_id;
      $("#user_selected_plan").val(plan_id);

        $.ajax({
            type:"POST",
            url: $("#form_step_2").attr('action'),
            data : $("#form_step_2").serialize(),
            beforeSend: function(){
              $("#Load").fadeIn('slow');
            },
            success: function(result){
            res = result;
            if(res.error){
              alert(res.error);
               $("#Load").fadeOut('fast');
              return false;
            }else if(res.no_of_days_exceeded){
              alert("You can't buy more than 90 days plan.");
              $("#Load").fadeOut('fast');
              return false;
            }else{
            genTokenValue = res.order_id;
                  $(".price-cards-inner").removeClass('active-plan');
       $(this).parent().parent().addClass('active-plan');

             var redirectpayurl = RedirectURL+'?token='+genTokenValue;

              $("#Load").fadeOut('fast');
              $(".papx-section").html(res.formdata);
              $("#actual-price").text(res.actual_plan_price);
              $(".price-section-overview").show();
              var html ="";
               html +='<div class="text-right whiteColor"><a href="javascript:void(0)" class="plan_remove"><i class="fa fa-close"></i></a></div>';

               html += '<div id="actual-price"><span class="plan-label">Plan Price:</span><span class="plan-price-label">'+res.actual_plan_price+'</span></div>';
              if(res.featured_profile_price){
              $("#featured-profile-price-shw").text(res.featured_profile_price);
               html += '<div id="featured-profile-price-shw"><span class="plan-label">Featured Profile:</span> <span class="plan-price-label">'+res.featured_profile_price+'</span></div>';
              }
              if(res.plan_teaser_price){
            
              html += '<div id="teaser-video-price-shw"><span class="plan-label">Sexy Teaser Video:</span> <span class="plan-price-label">'+res.plan_teaser_price+'</span></div>';
              }
              if(res.plan_teaser_two_price){
            
              html += '<div id="teaser-video-price-shw"><span class="plan-label">Dedicated Teaser Video:</span> <span class="plan-price-label">'+res.plan_teaser_two_price+'</span></div>';
              }
               if(res.plan_super_speed){
            
              html += '<div id="teaser-video-price-shw"><span class="plan-label">Super Boost(every 10mins):</span> <span class="plan-price-label">'+res.plan_super_speed+'</span></div>';
              }
              html += ' <div id="total-amount"><span class="plan-label">Total amount to be paid:</span> <span class="plan-price-label">'+res.total_amount_price+'</span></div>';

              html += ' <div id="vat-amount"><span class="plan-label"><small>GST included.</small></div>';

              html += ' <div id="next-button-mobile"><a href="'+redirectpayurl+'"  class="proceedPlan-btn" name="mobile_pay" id="mobile_pay">Proceed</a></div>';
              
             $(".price-section-overview").html(html);
          }
        }

          })
          
    })
  })

 function openPriceModal(){
   $("#selected-escortsmodel").modal('show');
    $(".selected-escorts-count").html('Number of Selected Escorts -'+'&nbsp;<span>' +$('#number_of_escorts').val()+'</span>');
  }
$(document).ready(function(){
  $(input[name='agency_plan']).change(function(){
    if($(this).checked){
      checked_price = $(this).attr('data-plan-price');
      $(".total_amount_overview").html("Total Amount : " + checked_price);

    }
  })
  $(input[name='club_plan']).change(function(){
    if($(this).checked){
      checked_price = $(this).attr('data-plan-price');
      $(".total_amount_overview").html("Total Amount : " + checked_price);

    }
  })
  $( ".preview-images-zone" ).sortable();

})
$(".bookslot-btns").on('click', function(){
    $(".bookslot-btns").removeClass('calanderbutton-active');
    $(this).addClass('calanderbutton-active');
});

//booking calender slot save data 
/*function add_booking_slot(calender) {
      $(".help1-block").addClass("hidden");
      $(".input-box").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("booking_form"));
      $.ajax({
        type: 'POST',
        dataType: "JSON",
        url: $("#booking_form").attr('action'),
        data: registration_form,
        processData: false,
        contentType: false,
     success: function(data) {
          if (data.errors) {
            $.each(data.errors, function(key, value) {
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });


           
          } else {
             //$("#services-addTime").modal('hide');
              // $('#services-addTime form :input').val("");
            $('#selected_date').html(data.date);
            $('#selected_day').html(data.day);
            $('#selected_m_y').html(data.month_year);
            $("#calendar-time-range").html(data.html);
              calendar.fullCalendar('refetchEvents');
              $("#services-addTime").modal('hide');
               $('#services-addTime form :input').val("");


          }
        },
      });
    }
*/
function getBackendAttributesByGender(id){
  //id = $("#cities").val();

  if(id != ""){
    $.ajax({
         headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
       type:"post",
       url:fetchgenderURL,
       data:{gender:id, type:'filter'},
      beforeSend: function() {
     // $("#Load").show();  
    },
       success: function(data){
        console.log(data);
         // $("#cities").html(data);
           // $("#Load").hide(); 
            var bustsize = data.master_bust_size;
            var dresssize = data.master_dress_size;
            var bodytype = data.master_body_type;
            var waistsize = data.master_waist_size;
            if(id == 'male'){
              var label = 'Chest Size';
              $("#bustype-section").hide();
            }else{
              var label = 'Bust Size';
              $("#bustype-section").show();
            }
           $("#bustsize").empty();
                        $('#bustsize').multiselect('destroy');
                          $("#bustsize").append(bustsize);
                          //$("#bustsize option:first").remove()
            $('#bustsize').multiselect({
                      numberDisplayed: 1,
                      nonSelectedText: label ,
                      enableCaseInsensitiveFiltering: true,
                      includeFilterClearBtn: false
                  });

            $("#dressize").empty();
                        $('#dressize').multiselect('destroy');
                          $("#dressize").append(dresssize);
                         // $("#dressize option:first").remove()
            $('#dressize').multiselect({
                      numberDisplayed: 1,
                      nonSelectedText: 'Dress Size',
                      enableCaseInsensitiveFiltering: true,
                      includeFilterClearBtn: false
                  });
             $("#bodytype").empty();
                        $('#bodytype').multiselect('destroy');
                          $("#bodytype").append(bodytype);
                        //  $("#bodytype option:first").remove()
            $('#bodytype').multiselect({
                      numberDisplayed: 1,
                      nonSelectedText: 'Body Type',
                      enableCaseInsensitiveFiltering: true,
                      includeFilterClearBtn: false
                  });

             $("#waistsize").empty();
                        $('#waistsize').multiselect('destroy');
                          $("#waistsize").append(waistsize);
                          //$("#waistsize option:first").remove()
            $('#waistsize').multiselect({
                      numberDisplayed: 1,
                      nonSelectedText: 'Waist Size',
                      enableCaseInsensitiveFiltering: true,
                      includeFilterClearBtn: false
                  });
                  
       }
    });
    }
  
}

// Update data in case of edit profile

$("#update_step_1").click(function(){
  var form = $("#form_step_1");
var validobj = form.validate({
  ignore: ":hidden",
    errorPlacement: function errorPlacement(error, element) {
     
     // return false;
     if(element.is(":radio")){
      $("#personal-error2").before(error);
     
     }
     else if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
     
      element.after(error);
     }
         
    },
    rules: {
      "body-type": {
        required: true,
        //minlength: 1
      },
      personal:{ required:true },
      rdo :{ required:true},
      suburbs:{ required:true },
      ad_name:{required:true},
      ad_email:{required:true},
      ad_contactno:{required:true},
      age:{ required:true,  number:true, min:18},
      country_name:{ required:true },
      city_name:{ required:true },
      eyecolor:{ required:true },
      haircolor:{ required:true },
      bustsize:{ required:true },
      weight:{ required:true, number:true, min:1},
      height:{ required:true, number:true, min:1 },
      //nationality:{ required:true },
      orientation:{ required:true },
      gender:{ required:true },
       language:{ required:true },
      dresssize:{ required:true },
      shoessize:{ required:true },
      hairlength:{ required:true },
     busttype:{ required:true },
     waistsize:{ required:true },
      penissize:{ required:true },
        peniscircumference:{ required:true },
      about_description:{ required : true },
      tagline:{  maxlength: 35},
      ethinicity:{required:true, },
     /* "piercing[]":{
        required: true,
        minlength: 1
      },*/
      "disclaimer[]" : {
          required: function(element){
            return $(".disclaimer").length > 0;
        },
        minlength : $(".disclaimer").length,
      },
     

    },
    messages: {
      "body-type[]": "Please choose body type",
      "country_name":"Please select Country",
      "city_name":"Please select City",
      "ad_name":"Please enter your name",
      "ad_email":"Please enter your email-address",
       "ad_contactno":"Please enter your number with the country code.",
      "rdo":"Please select gender",     
 "language":"Please enter your language ",
      "suburbs":"Please enter your suburbs",
      "about_description" : "Please describe  yourself.",
      "tagline" : "35 Character Max.",
      "personal": "Please choose atleast one option",
      "age" : "Age should be 18+",
      "eyecolor" :"Please select eye color",
      "haircolor" :"Please select hair color",
      "height" :"Height must be in number only",
      "weight" : "Weight must be in kg ",
      //"nationality" :"Please select nationality",
      "busttype" :"Please select bust type.",
      "orientation" :"Please select orientation",
      "gender" : "Please select gender",
      "dresssize" : "Please select dress size",
      "shoessize" : "Please select shoes size",
      "hairlength" : "Please select hair length",
      "bustsize" : "Please select bust size",
        "peniscircumference": "Please enter your penis circumference",
       "penissize": "Please enter your penis size. ",
        "waistsize" : "Please select bust size",
      //"piercing[]":"Please choose atleast one option.",
      "disclaimer[]" : "Please accept disclaimer",
      "ethinicity":"Please enter ethinicity"

      
    }
});

if(form.valid()){
$.ajax({
  type:"POST",
  url: $("#form_step_1").attr('action'),
  data : $("#form_step_1").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
       $("#Load").fadeOut('fast');        
        $("#update_details_popup").modal("show");
   },
});

}else{
     $('html, body').animate({
        scrollTop: parseInt($('.error:visible:first').offset().top) - 10
      }, 1000);
  }

});



$("#update_step_3").click(function(){
   if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
var form1 = $("#form_step_3");
var validobj = form1.validate({
    errorPlacement: function errorPlacement(error, element) {
     // console.log(element);
     // return false;
   
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }
         
    },
    rules: {
      "service-avail-for[]" : {
        required:true,
        minlength: 1
      },
      "service-available[]" : {
        required: true,
        minlength: 1
      },
      "service-type[]" : {
        required: true,
        minlength: 1
      },
      describe_service:{ required : true, minlength: 200},
      "service[0][service_time]" : {
        required: true,
      },

       /*"service[0][service_incall_charge]" : {
        required: true,
      },
        "service[0][service_outcall_charge]" : {
        required: true,
      },*/
      "service[0][service_name]" : {
        required: true,
       
      },
      "extra_services[0][price]" : {
        number:true,
        min:0.01
      }
    },
    messages: {
      "service-avail-for[]":"Please choose atleast one option.",
      "service-type[]":"Please choose atleast one option.",
      "service-available[]":"Please choose atleast one option.",
      "describe-service" : "Please describe your service. Minimum length should be 200.",
      "service[0][service_time]":"Plase select service time",
      "service[0][service_incall_charge]":"Please enter valid incall charge",
      "service[0][service_outcall_charge]":"Please enter valid outcall charge",
      "service[0][service_name]":"Please select service name",
      "extra_services[0][price]":"Please enter valid price."
      
    }

  
});
var value ='';
  var value1 = '';
  $('.working_to').each(function () {
        if(this.value == ''){
          if($('.working_to').is(':disabled') == true){
            value = '';
          }else{
            value = 'abc';
          } 
          
        }
    });

    

    $('.working_from').each(function () {
        if(this.value == ''){
          if($('.working_from').is(':disabled') == true){
            value1 = '';
          }else{
            value1 = 'abc';
          } 
          
        }
    });

    
    if(value != '' || value1 != ''){
      alert('Please fill out all Working Hour.');
          return false;
    }

if(form1.valid()){
$.ajax({
  type:"POST",
  url: $("#form_step_3").attr('action'),
  data : $("#form_step_3").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
    $("#touring-calender").fullCalendar('destroy');
       window.setTimeout(function(){
       

  var ad_id = $("#user_ad_id").val();
  var user_draft_id = $("input[name=user_draft_id]").val();
  if($.isNumeric(user_draft_id)){
    ad_id = user_draft_id
  }
  

  
        
var weekoffdays=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayrender',
   success:function(res)
   {
      if(res.status==1){
        weekoffdays = res.weekoffdays;
      }
    
   }
});

  var weekoffdaysworking=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayoff',
   success:function(res)
   {
      if(res.status==1){
        weekoffdaysworking = res.weekoffdays;
      }
    
   }
});  
       var calendar = $('#touring-calender').fullCalendar({
    header:{
     left:'prev,next today',
     center:'title',
     right:'month'
    },
    events: FetchBookingURL+'?ad_id='+ad_id+'&formtype=backend',
    selectConstraint: {
        start: $.fullCalendar.moment().subtract(1, 'days'),
        end: $.fullCalendar.moment().startOf('month').add(12, 'month')
    },
    
    selectHelper:true,
    dayRender:function(date, cell){
            var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           console.log(maxDate);
           // var maxDate = '2020-02-15';
            if(maxDate !="" && startdatestr > maxDate){
              $(cell).addClass('fc-disabled-day');
              $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css({"color":"rgb(255, 255, 255)","opacity":"0.2"});
            }else{
            var startrdate = $.fullCalendar.formatDate(date, "dddd");
          
            //var start = moment.unix(date).format("YYYY-MM-DD");
            var start = $.fullCalendar.formatDate(date, "Y-MM-DD");
            var tocheckdate = "dayoff_"+startrdate.toLowerCase();
            if(weekoffdays.length > 0){
            if(jQuery.inArray(start, weekoffdays) !== -1){
               $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
            }
           }

             if(weekoffdaysworking.includes(startdatestr) == false){
                 $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#ffff");
              }else{
                $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#2d962a !important");
              }
              
         }
        if(startdatestr == oldDate){
            
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-past');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-state-highlight');
                
           }
           if(startdatestr == current_date){
            
            $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-future');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');
              
           }

      
    },
        eventRender: function(event, element) {
          console.log(event.start);
          console.log(event.end);
     // element.css('visibility', 'hidden');
                    if(event.slot_type == "Day Off") {
                  var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");

                 $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
                var ss =   $('td').find("[data-date='" + start + "']").find('.fc-day-number');
                  
                }
                if(event.slot_type == "Day Off") {
                element.find(".fc-event").css('background-color','transparent');
              }
                element.find(".fc-event").css('border','none');
                 element.find("span.fc-title").css('visibility', 'hidden');
               /*  if (event.imageurl) {

        element.find("div.fc-content").prepend("<img src='" + event.imageurl +"' width='16' height='16'>");
    }
*/
                 if(event.slot_type == "Touring") {
                  var tourtstart = new Date(event.start);
                    var tourtend = new Date(event.end);
            
                    while(tourtstart <= tourtend){
                     
                     var customsatrtdate = (new Date(tourtstart)).toISOString().slice(0, 10);
                     
                    $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').addClass('touring-plane');
                   
                      tourtstart = new Date(tourtstart.setDate(tourtstart.getDate() + 1)); //self popover
                        var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                       var end_ss = "";
                      if(event.end){
                       end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");
                      
                     }
                      $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-title',event.title);
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-content','Start : '+start_ss+ ' End : '+end_ss);

                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-placement','top');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-container','body');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-toggle','popover');

                     //end popover
                     }
                     $('.touring-plane').popover({
    container: 'body',
    trigger : 'hover'
  });
                    var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                var end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");

              /*element.popover({
                    title: event.title,
                    content: 'Start : '+start_ss+ ' End : '+end_ss,
                    trigger: 'hover',
                    placement: 'top',
                    container: 'body'
                  });*/
            }
                //  element.find("span.fc-title").css('visibility', 'hidden');
            
            },
    viewRender: function (view,element) {

            if (moment() >= view.start && moment() <= view.end) {
                $(".fc-prev-button").prop('disabled', true); 
                $(".fc-prev-button").addClass('fc-state-disabled'); 
            }
            else {
                $(".fc-prev-button").removeClass('fc-state-disabled'); 
                $(".fc-prev-button").prop('disabled', false); 
            }
        },
    dayClick: function(date, jsEvent, view) {
       var today = new Date((new Date()).toString().substring(0,15));
      if( date < today) {
       
        $('#calendar').fullCalendar('unselect');
        return false;
    }
    var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           
    //var maxDate = '2020-02-15';
    if(maxDate !="" && startdatestr > maxDate){
      console.log(startdatestr);
      return false;
    }
    //$(".touring-form-section").show();
 
      var startDate = $.fullCalendar.formatDate(date, "Y-MM-DD");
      $("#working_date").val(startDate);
       cal_selected_date = $.fullCalendar.formatDate(date, "DD-MM-Y");
       $("#working_date_label").val(cal_selected_date);
      
      $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
         success:function(res)
         {
          var result = res;
          dayoff=result.dayoff;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $( "#calendar-time-range" ).selectable("refresh"); 
             $( "#calendar-time-range" ).selectable("disable"); 
             }else{
              $( "#calendar-time-range" ).selectable("refresh");
              $( "#calendar-time-range" ).selectable("enable"); 
              
             
            }
         }
        })
      if(dayoff != "yes"){
        //$("#services-addTime").modal('show');
        $('td').find(".fc-state-highlight").removeClass('fc-state-highlight');
        $('td').find(".fc-today").removeClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');

         $('select[name^="calendar_end_time"] option:selected').attr("selected",null);
         $('select[name^="calendar_start_time"] option:selected').attr("selected",null);
         $("#calendar_date").val(cal_selected_date);
      }
    },
   

   });
    startDate = $('.fc-today').data('date');
  $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
         success:function(res)
         {
          var result = res;
          dayoff=result.dayoff;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $( "#calendar-time-range" ).selectable("refresh"); 
             $( "#calendar-time-range" ).selectable("disable"); 
             }else{
              $( "#calendar-time-range" ).selectable("refresh");
              $( "#calendar-time-range" ).selectable("enable"); 
              
             
            }
         }
        })
      

    $.ajax({
        async:false,
       url:fetchaddTour+'?ad_id='+ad_id,
       success:function(res)
       {
          if(res!=''){
            $('.Newzealand').html('');
            $('.Newzealand').html(res);
          }
        
       }
    });
    $.ajax({
        async:false,
       url:fetchinteraddTour+'?ad_id='+ad_id,
       success:function(res)
       {
          if(res!=''){
            $('.intenational').html('');
            $('.intenational').html(res);
          }
        
       }
    });
   /* $('.startdate').datepicker({

        dateFormat:'dd/mm/yy',
          minDate : new Date(mindatepickerDate),
          maxDate : new Date(maxdatepickerDate),
        
        });

        $('.enddate').datepicker({
          dateFormat:'dd/mm/yy',
          minDate : new Date(mindatepickerDate),
          maxDate : new Date(maxdatepickerDate),
         
        })
        $('.inter_startdate').datepicker({

        dateFormat:'dd/mm/yy',
         minDate : new Date(mindatepickerDate),
        
        });

        $('.inter_enddate').datepicker({
          dateFormat:'dd/mm/yy',
       minDate : new Date(mindatepickerDate),
         
        })
        $('.startdate').on('click', function(e) {
         e.preventDefault();
         $(this).attr("autocomplete", "off");  
      });
      $('.enddate').on('click', function(e) {
         e.preventDefault();
         $(this).attr("autocomplete", "off");  
      });*/
    $("#Load").fadeOut('fast');
    $("#update_step_3_duplicate").removeClass('blink-btn');
        $("#update_details_popup").modal("show");

        
},2000);
        
    

   },
});

}
});

$("#update_step_3_duplicate").click(function(){
   if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
var form1 = $("#form_step_3");
var validobj = form1.validate({
    errorPlacement: function errorPlacement(error, element) {
     // console.log(element);
     // return false;
   
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }

    

     
         
    },
    rules: {
      "service-avail-for[]" : {
        required:true,
        minlength: 1
      },
      "service-available[]" : {
        required: true,
        minlength: 1
      },
      "service-type[]" : {
        required: true,
        minlength: 1
      },
      describe_service:{ required : true, minlength: 200},
      "service[0][service_time]" : {
        required: true,
      },

       /*"service[0][service_incall_charge]" : {
        required: true,
      },
        "service[0][service_outcall_charge]" : {
        required: true,
      },*/
      "service[0][service_name]" : {
        required: true,
       
      },
      "extra_services[0][price]" : {
        number:true,
        min:0.01
      }
    },
    messages: {
      "service-avail-for[]":"Please choose atleast one option.",
      "service-type[]":"Please choose atleast one option.",
      "service-available[]":"Please choose atleast one option.",
      "describe-service" : "Please describe your service. Minimum length should be 200.",
      "service[0][service_time]":"Plase select service time",
      "service[0][service_incall_charge]":"Please enter valid incall charge",
      "service[0][service_outcall_charge]":"Please enter valid outcall charge",
      "service[0][service_name]":"Please select service name",
      "extra_services[0][price]":"Please enter valid price."
      
    }

  
});
  var value ='';
  var value1 = '';
  $('.working_to').each(function () {
        if(this.value == ''){
          if($('.working_to').is(':disabled') == true){
            value = '';
          }else{
            value = 'abc';
          } 
          
        }
    });

    

    $('.working_from').each(function () {
        if(this.value == ''){
          if($('.working_from').is(':disabled') == true){
            value1 = '';
          }else{
            value1 = 'abc';
          } 
          
        }
    });

    
    if(value != '' || value1 != ''){
      alert('Please fill out all Working Hour.');
          return false;
    }

    
    

if(form1.valid()){
$.ajax({
  type:"POST",
  url: $("#form_step_3").attr('action'),
  data : $("#form_step_3").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
        
       $("#touring-calender").fullCalendar('destroy');
       window.setTimeout(function(){
       

  var ad_id = $("#user_ad_id").val();
  var user_draft_id = $("input[name=user_draft_id]").val();
  if($.isNumeric(user_draft_id)){
    ad_id = user_draft_id
  }
      


  
        
var weekoffdays=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayrender',
   success:function(res)
   {
      if(res.status==1){
        weekoffdays = res.weekoffdays;
      }
    
   }
});

  var weekoffdaysworking=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayoff',
   success:function(res)
   {
      if(res.status==1){
        weekoffdaysworking = res.weekoffdays;
      }
    
   }
});  
       var calendar = $('#touring-calender').fullCalendar({
    header:{
     left:'prev,next today',
     center:'title',
     right:'month'
    },
    events: FetchBookingURL+'?ad_id='+ad_id+'&formtype=backend',
    selectConstraint: {
        start: $.fullCalendar.moment().subtract(1, 'days'),
        end: $.fullCalendar.moment().startOf('month').add(12, 'month')
    },
    
    selectHelper:true,
    dayRender:function(date, cell){
            var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           console.log(maxDate);
           // var maxDate = '2020-02-15';
            if(maxDate !="" && startdatestr > maxDate){
              $(cell).addClass('fc-disabled-day');
              $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css({"color":"rgb(255, 255, 255)","opacity":"0.2"});
            }else{
            var startrdate = $.fullCalendar.formatDate(date, "dddd");
          
            //var start = moment.unix(date).format("YYYY-MM-DD");
            var start = $.fullCalendar.formatDate(date, "Y-MM-DD");
            var tocheckdate = "dayoff_"+startrdate.toLowerCase();
            if(weekoffdays.length > 0){
            if(jQuery.inArray(start, weekoffdays) !== -1){
               $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
            }
           }

             if(weekoffdaysworking.includes(startdatestr) == false){
                 $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#ffff");
              }else{
                $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#2d962a !important");
              }
              
         }
        if(startdatestr == oldDate){
            
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-past');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-state-highlight');
                
           }
           if(startdatestr == current_date){
            
            $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-future');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');
              
           }

      
    },
        eventRender: function(event, element) {
     // element.css('visibility', 'hidden');
                    if(event.slot_type == "Day Off") {
                  var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");

                 $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
                var ss =   $('td').find("[data-date='" + start + "']").find('.fc-day-number');
                  
                }
                if(event.slot_type == "Day Off") {
                element.find(".fc-event").css('background-color','transparent');
              }
                element.find(".fc-event").css('border','none');
                 element.find("span.fc-title").css('visibility', 'hidden');
               /*  if (event.imageurl) {

        element.find("div.fc-content").prepend("<img src='" + event.imageurl +"' width='16' height='16'>");
    }
*/
                 if(event.slot_type == "Touring") {
                  var tourtstart = new Date(event.start);
                    var tourtend = new Date(event.end);
                    console.log(tourtstart);
                    console.log(tourtend);
            
                    while(tourtstart <= tourtend){
                     
                     var customsatrtdate = (new Date(tourtstart)).toISOString().slice(0, 10);
                     
                    $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').addClass('touring-plane');
                   
                      tourtstart = new Date(tourtstart.setDate(tourtstart.getDate() + 1));
                      //self popover
                        var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                       var end_ss = "";
                      if(event.end){
                       end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");
                      
                     }
                      $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-title',event.title);
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-content','Start : '+start_ss+ ' End : '+end_ss);

                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-placement','top');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-container','body');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-toggle','popover');

                     //end popover
                     }
                     $('.touring-plane').popover({
    container: 'body',
    trigger : 'hover'
  });
                    var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                var end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");

              /*element.popover({
                    title: event.title,
                    content: 'Start : '+start_ss+ ' End : '+end_ss,
                    trigger: 'hover',
                    placement: 'top',
                    container: 'body'
                  });*/
            }
                //  element.find("span.fc-title").css('visibility', 'hidden');
            
            },
    viewRender: function (view,element) {

            if (moment() >= view.start && moment() <= view.end) {
                $(".fc-prev-button").prop('disabled', true); 
                $(".fc-prev-button").addClass('fc-state-disabled'); 
            }
            else {
                $(".fc-prev-button").removeClass('fc-state-disabled'); 
                $(".fc-prev-button").prop('disabled', false); 
            }
        },
    dayClick: function(date, jsEvent, view) {
       var today = new Date((new Date()).toString().substring(0,15));
      if( date < today) {
       
        $('#calendar').fullCalendar('unselect');
        return false;
    }
    var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           
    //var maxDate = '2020-02-15';
    if(maxDate !="" && startdatestr > maxDate){
      console.log(startdatestr);
      return false;
    }
    //$(".touring-form-section").show();
 
      var startDate = $.fullCalendar.formatDate(date, "Y-MM-DD");
      $("#working_date").val(startDate);
       cal_selected_date = $.fullCalendar.formatDate(date, "DD-MM-Y");
       $("#working_date_label").val(cal_selected_date);
      
      $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
         success:function(res)
         {
          var result = res;
          dayoff=result.dayoff;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $( "#calendar-time-range" ).selectable("refresh"); 
             $( "#calendar-time-range" ).selectable("disable"); 
             }else{
              $( "#calendar-time-range" ).selectable("refresh");
              $( "#calendar-time-range" ).selectable("enable"); 
              
             
            }
         }
        })
      if(dayoff != "yes"){
        //$("#services-addTime").modal('show');
        $('td').find(".fc-state-highlight").removeClass('fc-state-highlight');
        $('td').find(".fc-today").removeClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');

         $('select[name^="calendar_end_time"] option:selected').attr("selected",null);
         $('select[name^="calendar_start_time"] option:selected').attr("selected",null);
         $("#calendar_date").val(cal_selected_date);
      }
    },
   

   });
  startDate = $('.fc-today').data('date');
  $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
         success:function(res)
         {
          var result = res;
          dayoff=result.dayoff;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $( "#calendar-time-range" ).selectable("refresh"); 
             $( "#calendar-time-range" ).selectable("disable"); 
             }else{
              $( "#calendar-time-range" ).selectable("refresh");
              $( "#calendar-time-range" ).selectable("enable"); 
              
             
            }
         }
        })
      
    
    $.ajax({
        async:false,
       url:fetchaddTour+'?ad_id='+ad_id,
       success:function(res)
       {
          if(res!=''){
            $('.Newzealand').html('');
            $('.Newzealand').html(res);
          }
        
       }
    });
    $.ajax({
        async:false,
       url:fetchinteraddTour+'?ad_id='+ad_id,
       success:function(res)
       {
          if(res!=''){
            $('.intenational').html('');
            $('.intenational').html(res);
          }
        
       }
    });

    /*$('.startdate').datepicker({

        dateFormat:'dd/mm/yy',
          minDate : new Date(mindatepickerDate),
          maxDate : new Date(maxdatepickerDate),
        
        });

        $('.enddate').datepicker({
          dateFormat:'dd/mm/yy',
          minDate : new Date(mindatepickerDate),
          maxDate : new Date(maxdatepickerDate),
         
        })
        $('.inter_startdate').datepicker({

        dateFormat:'dd/mm/yy',
         minDate : new Date(mindatepickerDate),
        
        });

        $('.inter_enddate').datepicker({
          dateFormat:'dd/mm/yy',
       minDate : new Date(mindatepickerDate),
         
        })
        $('.startdate').on('click', function(e) {
         e.preventDefault();
         $(this).attr("autocomplete", "off");  
      });
      $('.enddate').on('click', function(e) {
         e.preventDefault();
         $(this).attr("autocomplete", "off");  
      });*/
    $("#Load").fadeOut('fast');
    $("#update_step_3_duplicate").removeClass('blink-btn');
    $("#update_Working_popup").modal("show");
        
},2000);

   },
});

}
});



$("#update_step_4").click(function(){
if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }

 var total = $(".preview-profile-image").length;
  if(total == 0){
    alert("Please upload atleast one profile image.");
    return false;
  }

   var totalVideo = $(".preview-video").length;
  if(totalVideo == 0){
    alert("Please upload a profile video.");
    return false;
  }

$.ajax({
  type:"POST",
  url: $("#form_step_4").attr('action'),
  data : $("#form_step_4").serialize()+'&update=yes',
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
       $("#Load").fadeOut('fast'); 
        $(".imageurl").val('');
      $(".videourl").val('');
      $(".teaservideourl").val(''); 
      $(".dedicatedvideourl").val('');        
        $("#update_details_popup").modal("show");

       var refreshImages = JSON.parse(data);
        if(refreshImages.length > 0){

        	var html ="";

       for ( var i =0; i< refreshImages.length; i++) {
           var checked = refreshImages[i].mediaDefault == 1 ? 'checked' : '';
                 html +=  '<div class="preview-image preview-show-'+ refreshImages[i].id+' preview-profile-image">';
                 html +=    '<div class="image-settings-icons" data-no="' +  refreshImages[i].id + '">';
                 html +=   '<a href="javascript:void(0)" onclick="showImage('+ refreshImages[i].id+',\'Edit\')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';
                 html +=   '<a href="javascript:void(0)" class="image-cancel" data-image-id="'+ refreshImages[i].id+'" data-no="'+ refreshImages[i].id+'"><i class="fas fa-trash-alt"></i></a></div>';
                 html +=   '<div class="image-zone"><img id="pro-img-'+ refreshImages[i].id+'" src="'+ refreshImages[i].media_filename+'"></div>'; 
                 html +=  ' <div class="radio radio-info form-check-inlinesquarebox image-zone1">';
                 html +=  ' <input type="hidden" value="'+ refreshImages[i].media_filename+'" name="old_imageurl[]">';
                 html +=  '  <input type="hidden" value="'+ refreshImages[i].media_filename+'" name="new_imageurl[]" id="newimg' +  refreshImages[i].id + '">';
                 html +=  '  <input type="hidden" name="NewImage_value[]" value="' +  refreshImages[i].id + '" id="NewImage_value">';
                 html +=  ' <input type="checkbox" data-id="' +  refreshImages[i].id + '" value="1" name="img_is_default" id="pro-img1-' +  refreshImages[i].id + '" class="css-checkbox" ' + checked + '>';
                 html +=  '<label for="pro-img1-' +  refreshImages[i].id + '" class="css-label">Set as main image</label></div>';
                html +=  '</div>';
           
        }

        $('.preview-profile-image').remove();
        $(".preview-images-zone").append(html);
        
      }
        
   },
});


});

// end update data in case of edit profile 


//save as draft  form data  start

$("#save_as_draft_step_1").click(function(){
  var form = $("#form_step_1");
var validobj = form.validate({
  ignore: ":hidden",
    errorPlacement: function errorPlacement(error, element) {
     
     // return false;
     if(element.is(":radio")){
      $("#personal-error2").before(error);
     
     }
     else if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
     
      element.after(error);
     }
         
    },
    rules: {
      "body-type": {
        required: true,
        //minlength: 1
      },
      personal:{ required:true },
      rdo :{ required:true},
      suburbs:{ required:true },
      ad_name:{required:true},
      ad_email:{required:true},
      ad_contactno:{required:true},
      age:{ required:true,  number:true, min:18},
      country_name:{ required:true },
      city_name:{ required:true },
      eyecolor:{ required:true },
      haircolor:{ required:true },
      bustsize:{ required:true },
      weight:{ required:true, number:true, min:1},
      height:{ required:true, number:true, min:1 },
      //nationality:{ required:true },
      orientation:{ required:true },
      gender:{ required:true },
      dresssize:{ required:true },
      shoessize:{ required:true },
      hairlength:{ required:true },
       language:{ required:true },
      busttype:{ required:true },
      waistsize:{ required:true },
       penissize:{ required:true },
        peniscircumference:{ required:true },
      about_description:{ required : true },
      tagline:{  maxlength: 35},
      ethinicity:{required:true, },
     /* "piercing[]":{
        required: true,
        minlength: 1
      },*/
      "disclaimer[]" : {
          required: function(element){
            return $(".disclaimer").length > 0;
        },
        minlength : $(".disclaimer").length,
      },
     

    },
    messages: {
      "body-type[]": "Please choose body type",
      "country_name":"Please select Country",
      "city_name":"Please select City",
      "ad_name":"Please enter your name",
      "ad_email":"Please enter your email-address",
       "ad_contactno":"Please enter your number with the country code.",
      "rdo":"Please select gender",
      "suburbs":"Please enter your suburbs",
      "about_description" : "Please describe  yourself.",
      "tagline" : "35 Character Max.",
      "personal": "Please choose atleast one option",
      "age" : "Age should be 18+",

 "language":"Please enter your language ",
      "eyecolor" :"Please select eye color",
      "haircolor" :"Please select hair color",
      "height" :"Height must be in number only",
      "weight" : "Weight must be in kg ",
      //"nationality" :"Please select nationality",
      "busttype" :"Please select bust type.",
      "orientation" :"Please select orientation",
      "gender" : "Please select gender",
      "dresssize" : "Please select dress size",
        "peniscircumference": "Please enter your penis circumference",
       "penissize": "Please enter your penis size. ",
        "waistsize" : "Please select bust size",
      "shoessize" : "Please select shoes size",
      "hairlength" : "Please select hair length",
      "bustsize" : "Please select bust size",

      //"piercing[]":"Please choose atleast one option.",
      "disclaimer[]" : "Please accept disclaimer",
      "ethinicity":"Please enter ethinicity"

      
    }
});

if(form.valid()){
$.ajax({
  type:"POST",
  url: $("#form_step_1").attr('action'),
  data : $("#form_step_1").serialize()+'&is_draft=1',
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(result) {
       $("#Load").fadeOut('fast');
        $("#post_ad_id").val(result.ad_id); 
        $(".ad_user_id").val(result.ad_id); 
        $(".ad_draft_id").val(result.draft_id);     
        $("#save_as_draft_popup").modal("show");
   },
});

}else{
     $('html, body').animate({
        scrollTop: parseInt($('.error:visible:first').offset().top) - 10
      }, 1000);
  }
});



$("#save_as_draft_step_3").click(function(){
   if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
 var value ='';
  var value1 = '';
  $('.working_to').each(function () {
        if(this.value == ''){
          if($('.working_to').is(':disabled') == true){
            value = '';
          }else{
            value = 'abc';
          } 
          
        }
    });

    

    $('.working_from').each(function () {
        if(this.value == ''){
          if($('.working_from').is(':disabled') == true){
            value1 = '';
          }else{
            value1 = 'abc';
          } 
          
        }
    });

    
    if(value != '' || value1 != ''){
      alert('Please fill out all Working Hour.');
          return false;
    }
var form1 = $("#form_step_3");
var validobj = form1.validate({
    errorPlacement: function errorPlacement(error, element) {
     // console.log(element);
     // return false;
   
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }
         
    },
    rules: {
      "service-avail-for[]" : {
        required:true,
        minlength: 1
      },
      "service-available[]" : {
        required: true,
        minlength: 1
      },
      "service-type[]" : {
        required: true,
        minlength: 1
      },
      describe_service:{ required : true, minlength: 200},
      "service[0][service_time]" : {
        required: true,
      },
       /*"service[0][service_incall_charge]" : {
        required: true,
      },
        "service[0][service_outcall_charge]" : {
        required: true,
      },*/
      "service[0][service_name]" : {
        required: true,
       
      },
      "extra_services[0][price]" : {
        number:true,
        min:0.01
      }
    },
    messages: {
      "service-avail-for[]":"Please choose atleast one option.",
      "service-type[]":"Please choose atleast one option.",
      "service-available[]":"Please choose atleast one option.",
      "describe-service" : "Please describe your service. Minimum length should be 200.",
      "service[0][service_time]":"Plase select service time",
      "service[0][service_incall_charge]":"Please enter valid incall charge",
      "service[0][service_outcall_charge]":"Please enter valid outcall charge",
      "service[0][service_name]":"Please select service name",
      "extra_services[0][price]":"Please enter valid price."
      
    }

  
});

if(form1.valid()){
$.ajax({
  type:"POST",
  url: $("#form_step_3").attr('action'),
  data : $("#form_step_3").serialize()+'&is_draft=1',
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
       $("#Load").fadeOut('fast');        
        $("#save_as_draft_popup").modal("show");
   },
});

}
});



$("#save_as_draft_step_4").click(function(){
if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }

var total = $(".preview-profile-image").length;
  if(total == 0){
    alert("Please upload atleast one profile image.");
    return false;
  }

   var totalVideo = $(".preview-video").length;
  if(totalVideo == 0){
    alert("Please upload a profile video.");
    return false;
  }

$.ajax({
  type:"POST",
  url: $("#form_step_4").attr('action'),
  data : $("#form_step_4").serialize()+'&update=yes&is_draft=1',
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
    save_step_4 = true;
       $("#Load").fadeOut('fast');
        $(".imageurl").val('');
      $(".videourl").val('');
      $(".teaservideourl").val(''); 
      $(".dedicatedvideourl").val('');                   
        $("#save_as_draft_popup").modal("show");
   },
});


});
//end save as draft data 

//================for pop up form=======================
 function setId_popup(id){
  $('.services_include').map(function() {
      
    $(this).prop('checked', false);

});
  $("#service_available").val(id);
  var hiddenInputValues = id.replace('services_popup', 'services_hidden_popup');
  console.log($('#'+hiddenInputValues).val());
  if($('#'+hiddenInputValues).val() != ""){
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
          $(this).prop('checked', true);
      } else {
          $(this).prop('checked', false);
      }
  });
   
  }
 }
 //==================================================================


// =================GET Time By DAte===================================================
 
    $("body").on('change','#calendar_date', function(){
 
        var cal_date = $('#calendar_date').val();
        var ad_id = $('#user_ad_id').val();
        var user_draft_id = $("input[name=user_draft_id]").val();
        if($.isNumeric(user_draft_id)){
          ad_id = user_draft_id
        }
       
      // ---------------
       jQuery.ajax({
        type: 'POST',
        url: fetchbookingtime,
        data: {'cal_date':cal_date, 'ad_id':ad_id,_token:'{{csrf_token()}}'},
        success: function(data) {
         
          // data.option_html
                $('#calendar_start_time').html(data.option_html);
                $('#calendar_end_time').html(data.option_html2);
                return false;
        },
      });
    // -----------
    });

     $("body").on('click','.booked-slot', function(){
      //alert("ddd");
      var booking_id = $(this).attr('data-booking-id');
      jQuery.ajax({
        type: 'POST',
        url: getbookingdetails,
        data: {'booking_id':booking_id,_token:'{{csrf_token()}}'},
        success: function(data) {
            console.log(data);
        },
      });
     });


 
// ===============================================================


//=================================================================
//if edit profile on click next button go next step

 $("#save_next_step_1").click(function(){
$("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');
  var form = $("#form_step_1");

var validobj = form.validate({
  ignore: ":hidden",
    errorPlacement: function errorPlacement(error, element) {
     
     // return false;
     if(element.is(":radio")){
      $("#personal-error2").before(error);
     
     }
     else if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
     
      element.after(error);
     }
         
    },
    rules: {
      "body-type": {
        required: true,
        //minlength: 1
      },

      personal:{ required:true },
      rdo :{ required:true},
      suburbs:{ required:true },
      ad_name:{required:true},
      ad_email:{required:true},
      ad_contactno:{required:true},
      age:{ required:true,  number:true, min:18},
      country_name:{ required:true },
      city_name:{ required:true },
      eyecolor:{ required:true },
      haircolor:{ required:true },
      bustsize:{ required:true },
      weight:{ required:true, number:true, min:1},
      height:{ required:true, number:true, min:1 },
      //nationality:{ required:true },
      orientation:{ required:true },
      gender:{ required:true },
      dresssize:{ required:true },
      shoessize:{ required:true },
      hairlength:{ required:true },
       language:{ required:true },
      busttype:{ required:true },
      waistsize:{ required:true },
       penissize:{ required:true },
        peniscircumference:{ required:true },
      about_description:{ required : true},
      tagline:{  maxlength: 35},
      ethinicity:{required:true, },
     /* "piercing[]":{
        required: true,
        minlength: 1
      },*/
      "booking_method[]":{
        required: true,
        minlength: 1
      },
      "disclaimer[]" : {
          required: function(element){
            return $(".disclaimer").length > 0;
        },
        minlength : $(".disclaimer").length,
      },
     

    },
    messages: {
      "body-type[]": "Please choose body type",
      "country_name":"Please select Country",
      "city_name":"Please select City",
      "ad_name":"Please enter your name",
      "ad_email":"Please enter your email-address",
       "ad_contactno":"Please enter your number with the country code.",
      "rdo":"Please select gender",
 "language":"Please enter your language ",
      "suburbs":"Please enter your suburbs",
      "about_description" : "Please describe  yourself.",
      "tagline" : "35 Character Max.",
      "personal": "Please choose atleast one option",
      "age" : "Age should be 18+",
      "eyecolor" :"Please select eye color",
      "haircolor" :"Please select hair color",
      "height" :"Height must be in number only",
      "weight" : "Weight must be in kg ",
      //"nationality" :"Please select nationality",
      "busttype" :"Please select bust type.",
      "orientation" :"Please select orientation",
      "peniscircumference": "Please enter your penis circumference",
       "penissize": "Please enter your penis size. ",
      "gender" : "Please select gender",
      "dresssize" : "Please select dress size",
      "shoessize" : "Please select shoes size",
      "hairlength" : "Please select hair length",
      "waistsize" : "Please select your waist size ",
      "bustsize" : "Please select bust size",
      //"piercing[]":"Please choose atleast one option.",
      "disclaimer[]" : "Please accept disclaimer",
      "ethinicity":"Please enter ethinicity",
      "booking_method[]": "Please choose one booking methode"

      
    }
});

if(form.valid()){

$.ajax({
  type:"POST",
  url: $("#form_step_1").attr('action'),
  data : $("#form_step_1").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
       $("#Load").fadeOut('fast');
         $(".step_2").fadeIn('slow');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  window.history.pushState("", "", "?step=2");
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.second").removeClass('disabled').addClass('current');        
       
   },
});
  }else{
     $('html, body').animate({
        scrollTop: parseInt($('.error:visible:first').offset().top) - 10
      }, 1000);
  }
})

  $("#save_next_step_2").click(function(){
     if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
 $("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');

  $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeIn('slow');
  $(".step_4").fadeOut('fast');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  window.history.pushState("", "", "?step=3");
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.three").removeClass('disabled').addClass('current');
})

  $("#save_next_step_3").click(function(){
    if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
 $("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');
    
 var value ='';
  var value1 = '';
  $('.working_to').each(function () {
        if(this.value == ''){
          if($('.working_to').is(':disabled') == true){
            value = '';
          }else{
            value = 'abc';
          } 
          
        }
    });

    

    $('.working_from').each(function () {
        if(this.value == ''){
          if($('.working_from').is(':disabled') == true){
            value1 = '';
          }else{
            value1 = 'abc';
          } 
          
        }
    });

    
    if(value != '' || value1 != ''){
      alert('Please fill out all Working Hour.');
          return false;
    }
var form1 = $("#form_step_3");
var validobj = form1.validate({
    errorPlacement: function errorPlacement(error, element) {
     // console.log(element);
     // return false;
   
      if(element.is(":checkbox")){
      var chkname = element.attr("name");
      var chkid = chkname.split('[]')[0];
      $("#"+chkid+'-error2').before(error);
     
     }else if(element.is("select")){
     
       element.next().find('.select2-selection--single').addClass('error');
     }else{
      element.after(error);
     }
         
    },
    rules: {
      "service-avail-for[]" : {
        required:true,
        minlength: 1
      },
      "service-available[]" : {
        required: true,
        minlength: 1
      },
      "service-type[]" : {
        required: true,
        minlength: 1
      },
      describe_service:{ required : true, minlength: 200},
      "service[0][service_time]" : {
        required: true,
      },
      /* "service[0][service_incall_charge]" : {
        required: true,
      },
        "service[0][service_outcall_charge]" : {
        required: true,
      },*/
      "service[0][service_name]" : {
        required: true,
       
      },
      "extra_services[0][price]" : {
        number:true,
        min:0.01
      }
    },
    messages: {
      "service-avail-for[]":"Please choose atleast one option.",
      "service-type[]":"Please choose atleast one option.",
      "service-available[]":"Please choose atleast one option.",
      "describe-service" : "Please describe your service. Minimum length should be 200.",
      "service[0][service_time]":"Plase select service time",
      "service[0][service_incall_charge]":"Please enter valid incall charge",
      "service[0][service_outcall_charge]":"Please enter valid outcall charge",
      "service[0][service_name]":"Please select service name",
      "extra_services[0][price]":"Please enter valid price."
      
    }

  
});

if(form1.valid()){

  $.ajax({
  type:"POST",
  url: $("#form_step_3").attr('action'),
  data : $("#form_step_3").serialize(),
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
    $("#touring-calender").fullCalendar('destroy');
       window.setTimeout(function(){
       

  var ad_id = $("#user_ad_id").val();
  var user_draft_id = $("input[name=user_draft_id]").val();
  if($.isNumeric(user_draft_id)){
    ad_id = user_draft_id
  }
  


  
        
var weekoffdays=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayrender',
   success:function(res)
   {
      if(res.status==1){
        weekoffdays = res.weekoffdays;
      }
    
   }
});

  var weekoffdaysworking=[];
  $.ajax({
    async:false,
   url:FetchBookingURL+'?ad_id='+ad_id+'&action=dayoff',
   success:function(res)
   {
      if(res.status==1){
        weekoffdaysworking = res.weekoffdays;
      }
    
   }
});  
       var calendar = $('#touring-calender').fullCalendar({
    header:{
     left:'prev,next today',
     center:'title',
     right:'month'
    },
    events: FetchBookingURL+'?ad_id='+ad_id+'&formtype=backend',
    selectConstraint: {
        start: $.fullCalendar.moment().subtract(1, 'days'),
        end: $.fullCalendar.moment().startOf('month').add(12, 'month')
    },
    
    selectHelper:true,
    dayRender:function(date, cell){
            var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           console.log(maxDate);
           // var maxDate = '2020-02-15';
            if(maxDate !="" && startdatestr > maxDate){
              $(cell).addClass('fc-disabled-day');
              $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css({"color":"rgb(255, 255, 255)","opacity":"0.2"});
            }else{
            var startrdate = $.fullCalendar.formatDate(date, "dddd");
          
            //var start = moment.unix(date).format("YYYY-MM-DD");
            var start = $.fullCalendar.formatDate(date, "Y-MM-DD");
            var tocheckdate = "dayoff_"+startrdate.toLowerCase();
            if(weekoffdays.length > 0){
            if(jQuery.inArray(start, weekoffdays) !== -1){
               $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
            }
           }

             if(weekoffdaysworking.includes(startdatestr) == false){
                 $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#ffff");
              }else{
                $('td').find("[data-date='" + startdatestr + "']").find('.fc-day-number').css("color", "#2d962a !important");
              }
              
         }
        if(startdatestr == oldDate){
            
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-past');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-state-highlight');
                
           }
           if(startdatestr == current_date){
            
            $('td').find("[data-date='" + startdatestr + "']").removeClass('fc-future');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
                $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');
              
           }

      
    },
        eventRender: function(event, element) {
     // element.css('visibility', 'hidden');
                    if(event.slot_type == "Day Off") {
                  var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");

                 $('td').find("[data-date='" + start + "']").find('.fc-day-number').css("color", "#ffff");
                var ss =   $('td').find("[data-date='" + start + "']").find('.fc-day-number');
                  
                }
                if(event.slot_type == "Day Off") {
                element.find(".fc-event").css('background-color','transparent');
              }
                element.find(".fc-event").css('border','none');
                 element.find("span.fc-title").css('visibility', 'hidden');
               /*  if (event.imageurl) {

        element.find("div.fc-content").prepend("<img src='" + event.imageurl +"' width='16' height='16'>");
    }
*/
                 if(event.slot_type == "Touring") {
                  var tourtstart = new Date(event.start);
                    var tourtend = new Date(event.end);
            
                    while(tourtstart <= tourtend){
                     
                     var customsatrtdate = (new Date(tourtstart)).toISOString().slice(0, 10);
                     
                    $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').addClass('touring-plane');
                   
                      tourtstart = new Date(tourtstart.setDate(tourtstart.getDate() + 1)); //self popover
                        var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                       var end_ss = "";
                      if(event.end){
                       end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");
                      
                     }
                      $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-title',event.title);
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-content','Start : '+start_ss+ ' End : '+end_ss);

                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-placement','top');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-container','body');
                     $('.fc-day-top[data-date="' + customsatrtdate+ '"] span').attr('data-toggle','popover');

                     //end popover
                     }
                     $('.touring-plane').popover({
    container: 'body',
    trigger : 'hover'
  });
                    var start_ss = $.fullCalendar.formatDate(event.start, "DD MMM Y");
                var end_ss = $.fullCalendar.formatDate(event.end, "DD MMM Y");

              /*element.popover({
                    title: event.title,
                    content: 'Start : '+start_ss+ ' End : '+end_ss,
                    trigger: 'hover',
                    placement: 'top',
                    container: 'body'
                  });*/
            }
                //  element.find("span.fc-title").css('visibility', 'hidden');
            
            },
    viewRender: function (view,element) {

            if (moment() >= view.start && moment() <= view.end) {
                $(".fc-prev-button").prop('disabled', true); 
                $(".fc-prev-button").addClass('fc-state-disabled'); 
            }
            else {
                $(".fc-prev-button").removeClass('fc-state-disabled'); 
                $(".fc-prev-button").prop('disabled', false); 
            }
        },
    dayClick: function(date, jsEvent, view) {
       var today = new Date((new Date()).toString().substring(0,15));
      if( date < today) {
       
        $('#calendar').fullCalendar('unselect');
        return false;
    }
    var startdatestr = $.fullCalendar.formatDate(date, "Y-MM-DD");
           
    //var maxDate = '2020-02-15';
    if(maxDate !="" && startdatestr > maxDate){
      console.log(startdatestr);
      return false;
    }
    //$(".touring-form-section").show();
 
      var startDate = $.fullCalendar.formatDate(date, "Y-MM-DD");
      $("#working_date").val(startDate);
       cal_selected_date = $.fullCalendar.formatDate(date, "DD-MM-Y");
       $("#working_date_label").val(cal_selected_date);
      
      $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
         success:function(res)
         {
          var result = res;
          dayoff=result.dayoff;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $( "#calendar-time-range" ).selectable("refresh"); 
             $( "#calendar-time-range" ).selectable("disable"); 
             }else{
              $( "#calendar-time-range" ).selectable("refresh");
              $( "#calendar-time-range" ).selectable("enable"); 
              
             
            }
         }
        })
      if(dayoff != "yes"){
        //$("#services-addTime").modal('show');
        $('td').find(".fc-state-highlight").removeClass('fc-state-highlight');
        $('td').find(".fc-today").removeClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-today');
        $('td').find("[data-date='" + startdatestr + "']").addClass('fc-state-highlight');

         $('select[name^="calendar_end_time"] option:selected').attr("selected",null);
         $('select[name^="calendar_start_time"] option:selected').attr("selected",null);
         $("#calendar_date").val(cal_selected_date);
      }
    },
   

   });
  startDate = $('.fc-today').data('date');
  $.ajax({
         url:FetchCalBookingURL,
         type:"POST",
        data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
         success:function(res)
         {
          var result = res;
          dayoff=result.dayoff;
            $('#selected_date').html(result.date);
            $('#selected_day').html(result.day);
            $('#selected_m_y').html(result.month_year);
            $("#calendar-time-range").html(result.html);
            $("#calendar_start_time").html(result.option_html);
             $("#calendar_end_time").html(result.option_html2);
             if(result.dayoff == 'yes'){
              $( "#calendar-time-range" ).selectable("refresh"); 
             $( "#calendar-time-range" ).selectable("disable"); 
             }else{
              $( "#calendar-time-range" ).selectable("refresh");
              $( "#calendar-time-range" ).selectable("enable"); 
              
             
            }
         }
        })
    $.ajax({
        async:false,
       url:fetchaddTour+'?ad_id='+ad_id,
       success:function(res)
       {
          if(res!=''){
            $('.Newzealand').html('');
            $('.Newzealand').html(res);
          }
        
       }
    });
    $.ajax({
        async:false,
       url:fetchinteraddTour+'?ad_id='+ad_id,
       success:function(res)
       {
          if(res!=''){
            $('.intenational').html('');
            $('.intenational').html(res);
          }
        
       }
    });
    $("#Load").fadeOut('fast');
    $("#update_step_3_duplicate").removeClass('blink-btn');
    $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeIn('slow');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  window.history.pushState("", "", "?step=4");
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.four").removeClass('disabled').addClass('current');
        //$("#update_details_popup").modal("show");

        
},2000);
        
    

   },
});
  
  }else{
     $('html, body').animate({
        scrollTop: parseInt($('.error:visible:first').offset().top) - 10
      }, 1000);
  }
})



  $("#save_next_step_4").click(function(){
     if(!activePlan){
  alert('Please choose one of payment option.');
  return false;
 }
$("#update_step_1").removeClass('blink-btn');
    $(".hndicon").css('display','none');
    $("#update_step_2").removeClass('blink-btn');
    $("#update_step_3").removeClass('blink-btn');
    $("#update_step_4").removeClass('blink-btn');
    $("#update_step_5").removeClass('blink-btn');
 var total = $(".preview-profile-image").length;
  if(total == 0){
    alert("Please upload atleast one profile image.");
    return false;
  }

  var totalVideo = $(".preview-video").length;
  if(totalVideo == 0){
    alert("Please upload a profile video.");
    return false;
  }

  $.ajax({
  type:"POST",
  url: $("#form_step_4").attr('action'),
  data : $("#form_step_4").serialize()+'&update=yes',
  beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
   success:function(data) {
       $("#Load").fadeOut('fast'); 
        $(".step_2").fadeOut('fast');
  $(".step_1").fadeOut('fast');
  $(".step_3").fadeOut('fast');
  $(".step_4").fadeOut('fast');
  $(".verification_video_section").fadeIn('slow');
  $(".step_0").fadeOut('fast');
  $(".step_7").fadeOut('fast');
  window.history.pushState("", "", "?step=5");
  $('html, body').animate({scrollTop:$('.content_block').position().top}, 'slow');
  $('.tablist li.current').removeClass('current').addClass("disabled");
    $(".tablist li.five").removeClass('disabled').addClass('current');
        $(".imageurl").val('');
      $(".videourl").val('');
      $(".teaservideourl").val(''); 
      $(".dedicatedvideourl").val('');        
        //$("#update_details_popup").modal("show");

   },
});

  

 
})


// end edit profile on click next button go next step

function autosave1(){
  if($("#user_ad_name").val() != "" && $("#user_ad_email").val() != "" && $("#user_ad_contact").val() != ""
    && $("#city_name").val() != "" && $("#country_name").val() != "" && $("#suburbs").val() != ""){

        $.ajax({
      type:"POST",
      url: $("#form_step_1").attr('action'),
      data : $("#form_step_1").serialize()+'&is_draft=1&savetype=autosave',
  
       success:function(result) {
          $("#post_ad_id").val(result.ad_id); 
          $(".ad_user_id").val(result.ad_id); 
          $(".ad_draft_id").val(result.draft_id); 
       },
    });
  }
}

function autosave3(){
    $.ajax({
  type:"POST",
  url: $("#form_step_3").attr('action'),
  data : $("#form_step_3").serialize()+'&is_draft=1&savetype=autosave',

   success:function(data) {
   },
});
  
}

function autosave4(){
    $.ajax({
      type:"POST",
      url: $("#form_step_4").attr('action'),
      data : $("#form_step_4").serialize()+'&update=yes&is_draft=1',
      success:function(data){
       },
    });
  
}

/*function checkVideoUpload(res2){
  alert(res2);
  $.ajax({
        url : CheckVideoUploaded,
        data :{'id' : res2} ,
        type: "GET",
        success:function(res2){
          if(res2 == 0){
            checkVideoUpload(res);
          }else{
            alert('true');
          }
        }

      });
}*/

function oooooo(){
  
    $.ajax({
      type:"POST",
      url: $("#form_step_4").attr('action'),
      data : $("#form_step_4").serialize()+'&update=yes&is_draft=1',
      success:function(data){
       },
    });
  
}
function GetHours(d) {
    if(d == '12:00 AM'){
      d = "00:00 AM";
    }
    if(d == '12:15 AM'){
        d = "00:15 AM";
    }
    if(d == '12:30 AM'){
        d = "00:30 AM";
    }
    if(d == '12:45 AM'){
        d = "00:45 AM";
    }
    if(d == '12:00 PM'){
      d = "00:00 PM";
    }
    if(d == '12:15 PM'){
        d = "00:15 PM";
    }
    if(d == '12:30 PM'){
        d = "00:30 PM";
    }
    if(d == '12:45 PM'){
        d = "00:45 PM";
    }

    //console.log("hello "+ d)
    
    var h = parseInt(d.split(':')[0]);

    if (d.split(':')[1].split(' ')[1] == "PM") {
        h = h + 12;
    }
    //console.log("Hi"+h);
    return h;
}
function GetMinutes(d) {
  
    return parseInt(d.split(':')[1].split(' ')[0]);
}
function deleteBookingSlot(data){
  var result = confirm("Are you sure that you want to cancel this booking?");
  if (result) {
    $("#Load").fadeIn('slow');
  var booking_id = data;
  $.ajax({
      url : cancelBookingUrl+"?booking_id="+booking_id,
      type : "GET",     
      success:function(result){
        if(result == "true"){
          startDate = $('.fc-today').data('date');
          ad_id =  $(".ad_user_id").val();
          $(".Available-btn").remove();
          $("#services-addTime").modal('hide');
          $.ajax({
                 url:FetchCalBookingURL,
                 type:"POST",
                data:{ad_id:ad_id, start_date:startDate,_token:token,formtype:"backend"},
                 success:function(res)
                 {
                  var result = res;
                  dayoff=result.dayoff;
                    $('#selected_date').html(result.date);
                    $('#selected_day').html(result.day);
                    $('#selected_m_y').html(result.month_year);
                    $("#calendar-time-range").html(result.html);
                    $("#calendar_start_time").html(result.option_html);
                     $("#calendar_end_time").html(result.option_html2);
                     if(result.dayoff == 'yes'){
                      $( "#calendar-time-range" ).selectable("refresh"); 
                     $( "#calendar-time-range" ).selectable("disable"); 
                     }else{
                      $( "#calendar-time-range" ).selectable("refresh");
                      $( "#calendar-time-range" ).selectable("enable"); 
                      
                     
                    }
                 }
                })
          $("#Load").fadeOut('fast');
      
        }
      }
  });
  }
  console.log(data);
    
}

function blankProVideo(){
  $('#pro-video').val('');
  $('#pro-video').click();
}
function blankTeaserVideo(){
  $('#teaser-video').val('');
  $('#teaser-video').click();
  //$('#teaser-video').click()
}
function blankDedicatedTeaserVideo(){
  $('#dedicated-video').val('');
  $('#dedicated-video').click();
  //$('#dedicated-video').click()
}

function blankVerificationVideo(){
  $('#verification-video').val('');
  $('#verification-video').click();
}