@extends('frontend.layouts.front_layout')
@section('content')
@php
$default_locale = app()->getLocale();

@endphp
@php
$now = time();

if($data['plan_expired'] > $now){
$expiry_date = $data['plan_expired']; 
$current_date = $now;
$diff_hours = round(($expiry_date - $current_date)/3600);
// echo $diff_hours = 23;
$days = $diff_hours/24;

}

$servicesavailable =  $availableService['service-available'];

@endphp
  
<style>
  .slot_type_error{
    color: #f44336;
    font-size: 12px;
    font-weight: 400;
  }
  .hidden{
    display:none;
  }
</style>

<div id="Load" class="load" style="display:none;">
    <div class="load__container">
        <div class="load__animation"></div>
        <div class="load__mask"></div>
        <!-- <span class="load__title">Loading...</span> -->
    </div>
</div>
<section class="profile-details-block">    
     <div class="container container-Mobile">
          <div class="row">
               @include('frontend.layouts.partials.navfordashboard')
               <div class="col-md-9 col-sm-12 col-xs-12">
               	<div>
                    		@if($errors->has("featured_sexy_girls"))
                         	<span class="help-block">{{ $errors->first("featured_sexy_girls") }}</span>
		                    @endif 
		                     @if($errors->has("sexy_girl_teaser"))
		                         <span class="help-block">{{ $errors->first("sexy_girl_teaser") }}</span>
		                    @endif 
		                    @if($errors->has("order_id"))
		                         <span class="help-block">{{ $errors->first("order_id") }}</span>
		                    @endif 
		                    @if(session()->has('message'))   
		                    <span class="help-block"> {{ session()->get('message') }}</span>
		                     @endif
                    	</div>
                       @php
                      $countAdsDatas =0;
                      @endphp
                @forelse($adsData as $data)
                 @php
                      $countAdsDatas++;
                      @endphp
                    <div class="row side_box">
                         <div class="col-md-3">
                              <div class="card-boxes gr_pink">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-view-icon.png')}}"></div>
                                   <div class="text">Views<br /><span>{{ $data['stat_views'] }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_orange">
                                   <div class="dashboard_icon"><img
                                             src="{{ asset('frontend/images/dashboard-shortlisted-icon.png')}}"></div>
                                   <div class="text">Shortlisted<br /><span>{{$data['shortlist']}}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_purple">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-likes-icon.png')}}"></div>
                                   <div class="text">Likes<br /><span>{{ $data['stat_likes'] }}</span></div>
                              </div>
                         </div>
                         <div class="col-md-3">
                              <div class="card-boxes gr_green">
                                   <div class="dashboard_icon"><img
                                             src="{{asset('frontend/images/dashboard-clicks-icon.png')}}"></div>
                                   <div class="text">Clicks<br /><span>{{ $data['stat_clicks'] }}</span></div>
                              </div>
                         </div>
                    </div>
                   
                   
                    <div class="mt-4">
                    	
                         <div class="col-md-12 ad-status-box">
                              <div class="img_slider">
                                   <div id="demo" class="carousel slide" data-ride="carousel">
                                        <!-- Indicators -->
                                        @if(count($data['images']) > 1)
                                        @php
                                        $i = 0;
                                        @endphp
                                        <ul class="carousel-indicators">
                                             @foreach($data['images'] as $img)
                                             <li data-target="#demo" data-slide-to="{{$i}}" class="active"></li>
                                             @php $i++; @endphp
                                             @endforeach
                                        </ul>
                                        @endif
                                        <!-- The slideshow -->

                                        <div class="carousel-inner">
                                             @if(count($data['images']) > 0)
                                             @php
                                             $i=0;
                                             @endphp
                                             @foreach($data['images'] as $img)
                                             @php
                                             $verified = mediaStatusCheckbyId($img->id);
                                              if($verified){
                                               $imageurl = $img->media_filename;
                                               $text = 'Photos Verified';
                                               $iconimg = asset('frontend/images/photosverified-icon.png');
                                             }else{
                                               $imageurl = "unverified_".$img->media_filename;
                                               $text = 'Profile Under Screening';
                                               $iconimg = asset('frontend/images/underscreening.png');
                                             }
                                                                                @endphp
                                             <div class="carousel-item {{$i == 0 ?'active': ''}}">
                                                  <img class="img-fluid" src="{{getS3ImageURL($imageurl,'377*625', md5(Auth::user()->id))}}" alt="">
                                                  <div class="photosVerified_aboveimg">
                                                  <img src="{{$iconimg}}"
                                                            alt="photosverified-icon">
                                                       <h6>{{$text}}</h6>
                                                  </div>
                                             </div>
                                             @php $i++; @endphp
                                             @endforeach
                                             @else
                                             <div class="carousel-item active">
                                                  <img class="img-fluid" src="{{url('public/images/default.png')}}"
                                                       alt="">

                                             </div>
                                             @endif
                                        </div>
                                        <!-- Left and right controls -->
                                        @if(count($data['images']) > 1)
                                        <a class="carousel-control-prev" href="#demo" data-slide="prev">
                                             <span class="carousel-control-prev-icon"></span>
                                        </a>
                                        <a class="carousel-control-next" href="#demo" data-slide="next">
                                             <span class="carousel-control-next-icon"></span>
                                        </a>
                                        @endif
                                   </div>
                              </div>
                              <div>
                              <div>

                         </div>
                              <div class="cnt_section cnt_section_left">
                                   <div class="cnt">
                                    @if(!empty($data['adId']))
                                        <div class="ad_id">#{{$data['adId']}}
                                        <div class="clearfix"></div>

                                      <div class="testimonial-status dashboard-onoff-btn">

                                   <button type="button" class="btn btn-lg btn-toggle {{(int)$data['login_status']==1?'active':''}}" data-toggle="button" data-ad-id= "{{$data['adId']}}" aria-pressed="true" autocomplete="off"  onclick="updateStatus(this)">
                                           <div class="handle"></div>
                                         </button>
                                       </div> 
                                        
                                        </div>
                                        @endif

                                        <h2>{{$data['adName']}}&nbsp;
                                           @if(!empty($data['age']))
                                           
                                             <span class="whiteColor"> 
                                              {{ count($data['age'])>0 ? $data['age']->meta_value:''}}
                                            </span>
                                               @endif
                                            </h2>
                                          <div class="private_tag">
                                            {{getListingType($data['listing_type_id'], true)}}
                                          </div>
                                        <div class="listing">

                                             @if(count($data['nationality']) > 0)
                                             <div class="list">
                                              <span class="label">Ethnicity : </span>
                                             <span class="label-text"> {{ count($data['nationality']) > 0 ? getMaterData($data['nationality']->meta_value):''}}</span>
                                             </div>
                                             @endif

                                        </div>

                                        @if(!empty($data['minRate']))
                                        <div class="rate">{!! price_format($data['minRate']) !!}/Hour</div>
                                        @endif

                                         @if(!empty($data['adContact']))
                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="{{asset('frontend/images/hover-phone-icon.png')}}"></div>
                                             <div class="phone-number"><span>Phone</span><br><a href="tel:{{$data['adContact']}}">{{$data['adContact']}}</a>
                                             </div>
                                        </div>
                                        @endif

                                          @if(!empty($data['textNumber']))
                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="{{asset('frontend/images/textmessage-icon.png')}}"></div>
                                             <div class="phone-number"><span>Text</span><br>
                                                  <a href="sms:{{$data['textNumber'] && count($data['textNumber']) > 0 ? $data['textNumber']->meta_value : ''}}">
                                                    {{$data['textNumber'] && count($data['textNumber']) > 0 ? $data['textNumber']->meta_value : ''}}
                                                  </a>
                                             </div>
                                        </div>
                                        @endif

                                          @if(!empty($data['whatsappNumber']))
                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="{{asset('frontend/images/profile-whatsapp.png')}}"></div>
                                             <div class="phone-number"><span>Whatsapp</span><br>
                                                 <a href="https://wa.me/{{$data['whatsappNumber'] && count($data['whatsappNumber']) > 0 ? $data['whatsappNumber']->meta_value : ''}}">
                                                  {{$data['whatsappNumber'] && count($data['whatsappNumber']) > 0 ? $data['whatsappNumber']->meta_value : ''}}
                                                 </a>
                                             </div>
                                        </div>
                                        @endif

                                        @if(!empty($data['adEmail']))
                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="{{asset('frontend/images/email-dashboardicon.png')}}"></div>
                                             <div class="phone-number"><span>Email</span><br>
                                              <a href="mailto:{{$data['adEmail']}}">{{$data['adEmail']}}</a>
                                             </div>
                                        </div>
                                        @endif
                                        
                                         @if(!empty($data['website_url']))
                                        <div class="contact_detail mt-3 phonedetails-div">
                                             <div class="icon"><img src="{{asset('frontend/images/dashobar-web-icon.png')}}"></div>
                                             <div class="phone-number"><span>Website</span><br>
                                                  <a href="{{$data['website_url'] && count($data['website_url']) > 0 ? $data['website_url']->meta_value : ''}}">{{$data['website_url'] && count($data['website_url']) > 0 ? $data['website_url']->meta_value : ''}}</a>
                                             </div>
                                        </div>
                                        @endif
                                      
                                       
                                        <ul class="followus mt-2 float-left">
                                             @if(count($data['social_links']) > 0)
                                           <span>Social Media</span>
                                          <br>
                                          @endif
                                             @foreach($data['social_links'] as $sl)
                                             @php
                                             $key = explode("_", $sl['meta_key']);
                                             $icon = getMaterIcon(end($key));
                                             $socialtitle = getMasterValue(end($key));
                                             @endphp

                                             <li><a  data-toggle="tooltip" data-placement="top" 
                                                  title="{{$socialtitle}}" target="_blank" href="{{$sl['meta_value']}}"><img
                                                            src="{{url('upload/'.$icon)}}"></a></li>
                                             @endforeach
                                        </ul>
                                       
                                   </div>
                              </div>
                              <div class="cnt_section cnt_section_right">
                                   
                                   
                                   <div class="cnt">
                                  @php
                                    $getAllOrderData = getAllOrderData(Auth::user()->id,$data['adId']);
                                    @endphp
                                   @php
                                   $plans = array();
                                   $newPlanDetail = array();
                                   @endphp
                                   @if(!empty($data['plan_id']))
                                   <h2>Ad Status
                                   @php
                                   $today = strtotime(date("Y-m-d h:i a"));
                                   $planex = strtotime(date("Y-m-d h:i a", $data['order']->plan_expired));
                                   
                                   @endphp
                                  @if(count($getAllOrderData) > 0)
                                    <span class="ad-status active button button-pulse">Active</span>
                                   @else
                                   <span class="ad-status expired">Expired</span>
                                   @endif
                                   </h2>
                                      
                       @php

                        $getAllOrderData = getAllOrderData(Auth::user()->id,$data['adId']);

                                   if(!empty($data['order']->plan_id)){

                                   $plans = getPlanDetail($data['order']->plan_id);
                                    $plan_purchased = $data['plan_purchased'];
                                    $plan_expired = $data['plan_expired'];
                                   $activePlanId = $data['plan_id'];

                                    
                                    $old_order_Detail = getOrderData($data['old_order_id']);
                                   $orderDetail = getOrderData($data['old_order_id']);
                                    $upcomingOrderDetail = getOrderData($data['order']->id);

                                 
                                   //if((int)$data['old_order_id'] > 0){
                                   
                                    $todayDate = strtotime(date("Y-m-d"));
                                    // if($todayDate >= $old_plan_exp){

                                       $oldPlanDetail = getPlanDetail($old_order_Detail->plan_id);
                                        $old_plan_purchased_date = $old_order_Detail->plan_purchased;
                                        $old_plan_expiry_date = $old_order_Detail->plan_expired;

                                      $current_plan = getPlanDetail($getAllOrderData[0]->plan_id);
                                      $current_plan_purchased =  $getAllOrderData[0]->plan_purchased;  
                                      $current_plan_expired =  $getAllOrderData[0]->plan_expired;

                                        $upcomingPlanDetail = getPlanDetail($upcomingOrderDetail->plan_id);
                                        $upcomig_start_date = $upcomingOrderDetail->plan_purchased;
                                        $upcomig_plan_expiry_date = $upcomingOrderDetail->plan_expired;

                                        //$plans = getPlanDetail($orderDetail->plan_id);
                                        //$plan_purchased = $orderDetail->plan_purchased;
                                        
                                        //$plan_expired = $orderDetail->plan_expired;
                                        //$activePlanId = $orderDetail->plan_id;
                                        
                                     //}                                    
                               //}
                           }



                                   @endphp

                                       @php

                                       $featured_sexy_girls = getAdOnsStatus('featured_profiles',$data['adId']);
                                       $teaser_sexy_video = getAdOnsStatus('teaser_video',$data['adId']);
                                       $featured_banner = getAdOnsStatus('featured_banner',$data['adId']);
                                       $super_speed_boost = getAdOnsStatus('super_speed_boost',$data['adId']);
                                       $second_teaser_video = getAdOnsStatus('teaser_video_two',$data['adId']);
                                       @endphp
<style>
 
.current_plan_cards .current_plan{
  color:#fff;
  padding: 10px;
  margin-bottom:10px;
  border-radius:8px;
  background:#171717;
  display:inline-block;
  width:100%;
}

</style>
                                        @if(count($getAllOrderData) == 0)
                                       <div class="list">
                                                 <div class="current_plan_cards">
                                                      <div class="current_plan  purple-border">
                                                        <h5 style="color: #ff0026;">Current Plan Details</h5>
                                                        <span class="label"><h6>No Plan Found!</h6></span> 
                                                       <span class="label"><h6><a class="btn renew-btn" href="{{$data['editLink']}}?step=2">Renew</a></h6></span> 
                                                          
                                                     
                                                   
                                              </div>
                                       </div>
                                     </div>
                                      @endif

                                        @if(count($current_plan) > 0)
                                        
                                        <div class="listing">

                                  @if($data['listing_category']->cat_type == 'job')

                                             
                                             @else
                                              @if($current_plan_expired >= strtotime(date("Y-m-d h:i a")))
                                             <div class="list">
                                               <div class="current_plan_cards">
                                                      <div class="current_plan  purple-border">
                                                       
                                                        <span class="label"><h6>Today's working Hours :</h6></span>
                                                                  @if(!empty($data['ad_duration_off']))
                                                                    <span class="label-text">{{strtoupper(date("D",strtotime(date("Y-m-d"))))}}, &nbsp; {{strtolower($data['ad_duration_off'])}}</span>
                                                                  @elseif(!empty($data['ad_duration_from']) && !empty($data['ad_duration_to']))
                                                                 <span class="label-text"> {{strtoupper(date('D',strtotime(date("Y-m-d"))))}},&nbsp;{{$data['ad_duration_from'] .'-'. $data['ad_duration_to'] }}</span>
                                                                  @else
                                                                  <span class="label-text">{{strtoupper(date("D",strtotime(date("Y-m-d"))))}},&nbsp; not updated</span>
                                                          <a class="btn renew-btn" href="{{$data['editLink']}}?step=3#WorkingHours" target="_blank">Update Now</a>
                                                                  @endif
                                               
                                                  </div>
                                                  
                                              </div>
                                             </div>
                                             @endif
                                             @endif

                                                <!-- Current Plan Details Start  -->

                                <!-- extra new code for plans -->
 @php

$r= 0;
@endphp                     
                                @if(count($getAllOrderData)>0)
                            @foreach($getAllOrderData as $all_order_data)
                             @php
                            $allplanDetails=getPlanDetail($all_order_data->plan_id);
                            @endphp
                            @if($r== 0)
                            @if($all_order_data->plan_expired >= strtotime(date("Y-m-d h:i a")))
                            @php
                            $plans = getPlanDetail($all_order_data->plan_id);
                            
                            @endphp
                           

                              
                                             <div class="list">
                                               <div class="current_plan_cards">
                                                      <div class="current_plan  purple-border">
                                                        <h5 style="color: #ff0026;">Current Plan Details</h5>

                                                       @if($allplanDetails->plan_is_recommended  == '1')
                                                      <span class="label"><h6>Ad duration :</h6></span> 
                                                      @if($allplanDetails->plan_duration == '1')  
                                                       <span class="label-text"> {{$allplanDetails->plan_duration}} day</span>
                                                      @else
                                                    <span class="label-text"> {{$allplanDetails->plan_duration}} days</span>
                                                   @endif
                                                      
                                                       @else
                                                       <span class="label"><h6>Ad duration :</h6></span> 
                                                     @if($allplanDetails->plan_duration == '1')  
                                                       <span class="label-text"> {{$allplanDetails->plan_duration}} day</span>
                                                      @else
                                                    <span class="label-text"> {{$allplanDetails->plan_duration}} days</span>
                                                   @endif
                                                      @endif

                                                      @php
                                                        $CurrentorderIds = $all_order_data->id;
                                                        $cureentExpiry = $all_order_data->plan_expired;
                                                        @endphp
                                                       <br>
                                                      @if($allplanDetails->plan_type == 'Free')
                                                      <span class="label"><h6>Ad Type :</h6></span>
                                                     <span class="label-text"> Free Trial</span>
                                                      @elseif($allplanDetails->plan_is_recommended == '1')
                                                      <span class="label"><h6>Ad Type :</h6></span>
                                                     <span class="label-text">Premium Ad-Money Lovers</span>

                                                      @else
                                                      <span class="label"><h6>Ad Type :</h6></span>
                                                     <span class="label-text">Premium(Paid)</span>
                                                      @endif
                                                         <br>
              @if(count($all_order_data) > 0  && !empty($all_order_data->super_speed_boost_price) && !empty($all_order_data->super_speed_boost_days))
                                                     @php
                                                        $allSpeedDays = $all_order_data->super_speed_boost_days;
                                                        $countSpeedDays =count( explode(",",$allSpeedDays));

                                                      @endphp 
                                                     @if($countSpeedDays == '1')
                                                      <span class="label"><h6>Smart AD Boosting :</h6></span> {{$countSpeedDays}} day
                                                      @else
                                                       <span class="label"><h6>Smart AD Boosting :</h6></span> {{$countSpeedDays}} days
                                                      @endif
                                                
                                                  <small>(Every 10 Minutes during your working hrs)</small>
                                                  <br>                                                  @else
                                                  <span class="label"><h6>Smart AD Boosting :</h6></span> 
                                                  <span class="label-text">{{$allplanDetails->plan_duration}} {{$allplanDetails->plan_duration_unit}}</span>
                                              
                                                  <small>(Every 30 Minutes until ad expires)</small>
                                                  <br>
                                                  @endif

                                                  <span class="label"><h6>Ad Start Date :</h6></span> 
                                                <span class="label-text">{{date("d M Y h:i A",$all_order_data->plan_purchased) }}</span>
                                                <br>
                                                <span class="label"><h6>Ad Expiry Date :</h6></span> 
                                                  <span class="label-text">{{date("d M Y h:i A", $all_order_data->plan_expired)}}</span>

                                                  </div>
                                              </div>
                                             </div>
                                            
                                             @php
                                             $r++;
                                             @endphp
                            @endif
                            @else
                                               <div class="list">
                                                 <div class="current_plan_cards">
                                                      <div class="current_plan  purple-border">
                                                        <h5 style="color: #ff0026;">Upcoming Plan Details</h5>
                                                        <span class="label"><h6>Ad duration :</h6></span> 
                                                          @if($allplanDetails->plan_duration == '1')  
                                                             <span class="label-text"> {{$allplanDetails->plan_duration}} day</span>
                                                            @else
                                                          <span class="label-text"> {{$allplanDetails->plan_duration}} days</span>
                                                         @endif
                                                       <br>
                                                      
                                                     
                                                       <span class="label"><h6>Ad Start Date :</h6></span>
                                                       <span class="label-text"> {{date("d M Y h:i A", $all_order_data->plan_purchased)}}</span>
                                                       
                                              <br>
                                                       <span class="label"><h6>Ad Expiry Date :</h6></span>
                                                       <span class="label-text"> {{date("d M Y h:i A",  $all_order_data->plan_expired)}} </span>
                                                     
                                                  </div>
                                              </div>

                                       
                                       </div>
                            @endif
                            @endforeach
                             @else

                                   <div class="list">
                                                 <div class="current_plan_cards">
                                                      <div class="current_plan  purple-border">
                                                        <h5 style="color: #ff0026;">Current Plan Details</h5>
                                                        <span class="label"><h6>No Plan Found!</h6></span> 
                                                 <span class="label"><h6><a class="btn renew-btn check_ad_status1"  data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{$data['editLink']}}?step=2">Renew</a></h6></span> 
                                                          
                                                     
                                                   
                                              </div>
                                       </div>
                                     </div>
                                       @endif

                            <!-- end extrarr -->
                                <!-- end here new code-->

                          @php
                            $getUserGender =$data['gender']->meta_value;
                            if($getUserGender =='male'){
                                  $genderName = 'Men';
                            }elseif($getUserGender =='trans'){
                                   $genderName = 'Trans';
                            }else{
                               $genderName = 'Girl';

                            }
                            @endphp
                                      @if(count($featured_sexy_girls) > 0 || count($teaser_sexy_video) > 0 || count($featured_banner) > 0 || count($super_speed_boost) > 0 | count($second_teaser_video) > 0)
                                      @php
                                      $now = strtotime(date("Y-m-d h:i A"));
                                      $newExpiryDateTime= strtotime(date('Y-m-d').' '.date('h:i A',$cureentExpiry));
                                      if($now > $newExpiryDateTime){
                                        $newCurrDAte = date('Y-m-d');
                                        $newDashboarddate3 = date('Y-m-d', strtotime($newCurrDAte. '+1 day' ));
                                        $spanTxt = '<span class="label-text">'.date("d M, Y", time() + 86400).' '.date('h:i A',$cureentExpiry).'</span>';
                                      }else{
                                      $spanTxt = '<span class="label-text">'.date("d M, Y").' '.date('h:i A',$cureentExpiry).'</span>';
                                        $newDashboarddate3 = date('Y-m-d');
                                    }
                                      
                                        $newDashboardTIme3 = date("h:i A",$cureentExpiry);
                                        $newDashboardDateTime3 = $newDashboarddate3.' '.$newDashboardTIme3;
                                        $expiry_date = strtotime($newDashboardDateTime3); 
                                        
                                      @endphp
                                      
                                      <div class="list">
                                        <h2>Add-ons Status</h2>
                                      </div>
                    
                                      @endif
                                       @if(count($featured_sexy_girls) > 0 && $data['listing_category']->cat_type !='job')
                                       @if($plans->plan_type != "Free")
                       <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Featured Sexy {{$genderName}}</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <?php echo $spanTxt; ?>
                                      </div>
                                      @php
                                      if($expiry_date > $now){
                                         
                                        $current_date = $now;
                                        $diff_hours1 = abs(($expiry_date - $current_date)/3600);
                                        
                                        $addondays1 = $diff_hours/24;

                                        }
                                        @endphp
                                        @if($diff_hours1 > 0 && $diff_hours1 <= 24 &&  $today <  $expiry_date)
                                      {{--  <div class="list adexpires"><span class="label">Your Add-on expiring soon </span>
                                              <div id="clockdiv1" class="clockdiv">
                                              </div>    
                                              @if($plans->plan_duration != '1')    
                                              <div class="add-extend">     
                                                  <div><span class="blink" onclick="slideToAddon()">extend now</span></div>
                                              </div>
                                              @endif
                                        </div> --}}
                                        @endif
</div>

                                      @else
                                      <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Featured Sexy {{$genderName}}</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <span class="label-text">{{date("d M, Y",$cureentExpiry)}} </span>
                                      </div>
                                    </div>
                                      @endif
                                      @endif
                                      @if(count($teaser_sexy_video) > 0 && $data['listing_category']->cat_type !='job')
                                      @if($plans->plan_type != "Free")
                      <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Sexy Girl Teaser</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <?php echo $spanTxt; ?>
                                      </div>
                                       @php

                                      if($expiry_date > $now){
                                         
                                        $current_date = $now;

                                      $diff_hours2 = abs(($expiry_date - $current_date)/3600);
                                     
                                        $addondays1 = $diff_hours/24;

                                        }
                                        @endphp
                                        @if($diff_hours2 > 0 && $diff_hours2 <= 24 &&  $today <  $expiry_date)
                                       {{-- <div class="list adexpires"><span class="label">Your Add-on expiring soon </span>
                                              <div id="clockdiv2" class="clockdiv">
                                              </div>    
                                              @if($plans->plan_duration != '1')    
                                              <div class="add-extend">     
                                                  <div><span class="blink" onclick="slideToAddon()">extend now</span></div>
                                              </div>
                                              @endif
                                        </div> --}}
                                        @endif
                    
                    </div>
                                      @else
                                      <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Sexy {{$genderName}} Teaser</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <span class="label-text">{{date("d M, Y",$cureentExpiry)}} </span>
                                      </div>
                                    </div>
                                      @endif
                    
                                      @endif
                                        @if(count($second_teaser_video) > 0 && $data['listing_category']->cat_type !='job')
                                        @if($plans->plan_type != "Free")
                      <div class="adons-seperate">
                                        <div class="list addons-main-title">
                                        <span class="label addon-title">Dedicated Page Teaser Video</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <?php echo $spanTxt; ?>
                                      </div>
                                      @php
                                      if($expiry_date > $now){
                                         
                                        $current_date = $now;
                                        $diff_hours3 = abs(($expiry_date - $current_date)/3600);
                                        $addondays1 = $diff_hours/24;

                                        }
                                        @endphp
                                        @if($diff_hours3 > 0 && $diff_hours3 <= 24 &&  $today <  $expiry_date)
                                     {{--   <div class="list adexpires"><span class="label">Your Add-on expiring soon </span>
                                              <div id="clockdiv3" class="clockdiv">
                                              </div>    
                                              @if($plans->plan_duration != '1')    
                                              <div class="add-extend">     
                                                  <div><span class="blink" onclick="slideToAddon()">extend now</span></div>
                                              </div>
                                              @endif
                                        </div> --}}
                                        @endif
                    </div>
                                      @else
                                      <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Dedicated Page Teaser Video</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <span class="label-text">{{date("d M, Y",$cureentExpiry)}} </span>
                                      </div>
                                    </div>
                                      @endif
                                      @endif
                                      @if(count($super_speed_boost) > 0 && $data['listing_category']->cat_type !='job')
                                      @if($plans->plan_type != "Free")
                      <div class="adons-seperate">
                                      <div class="list addons-main-title">
                                        <span class="label addon-title">Super Speed Boost</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <?php echo $spanTxt; ?>
                                      </div>
                                      @php
                                      if($expiry_date > $now){
                                         
                                        $current_date = $now;
                                        $diff_hours4 = abs(($expiry_date - $current_date)/3600);
                                        $addondays1 = $diff_hours/24;

                                        }
                                        @endphp
                                        @if($diff_hours4 > 0 && $diff_hours4 <= 24 &&  $today <  $expiry_date)
                                      {{--  <div class="list adexpires"><span class="label">Your Add-on expiring soon </span>
                                              <div id="clockdiv4" class="clockdiv">
                                              </div>    
                                              @if($plans->plan_duration != '1')    
                                              <div class="add-extend">     
                                                  <div><span class="blink" onclick="slideToAddon()">extend now</span></div>
                                              </div>
                                              @endif
                                        </div> --}}
                                        @endif
                    </div>
                                      @else
                                      <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Super Speed Boost</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <span class="label-text">{{date("d M, Y",$cureentExpiry)}} </span>
                                      </div>
                                    </div>
                                      @endif
                                      @endif  
                                      @if(count($featured_banner) > 0)
                                      @if($plans->plan_type != "Free")
                      <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Featured Banner</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <?php echo $spanTxt; ?>
                                      </div>
                                       @php
                                      if($expiry_date > $now){
                                        
                                        $current_date = $now;
                                        $diff_hours5 = abs(($expiry_date - $current_date)/3600);
                                        $addondays1 = $diff_hours/24;

                                        }
                                        @endphp
                                        @if($diff_hours5 > 0 && $diff_hours5 <= 24 &&  $today <  $expiry_date)
                                      {{--  <div class="list adexpires"><span class="label">Your Add-on expiring soon </span>
                                              <div id="clockdiv5" class="clockdiv">
                                              </div>    
                                              @if($plans->plan_duration != '1')    
                                              <div class="add-extend">     
                                                  <div><span class="blink" onclick="slideToAddon()">extend now</span></div>
                                              </div>
                                              @endif
                                        </div> --}}
                                        @endif
                    </div>
                                      @else
                                      <div class="adons-seperate">
                                       <div class="list addons-main-title">
                                        <span class="label addon-title">Featured Banner</span>
                                      </div>
                                      <div class="list addons-expires">
                                        <span class="label">Expiry Date :</span>
                                        <span class="label-text">{{date("d M, Y",$cureentExpiry)}} </span>
                                      </div>
                                    </div>
                                      @endif
                                      @endif
                                     
                                        </div>
                                        
     
@endif
                                        </div>
                                        
                                        @endif
                                        @if(count($plans) > 0)
                                         @if($data['listing_category']->cat_type == 'individual' || $data['listing_category']->cat_type == 'male')
                                        <div class="view_shorlist_section">
                                         
                                         <!--     <div class="block">
                                      <div class="icon">
                        <a class="check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}"  data-profile-link="{{$data['editLink']}}?step=3#touring_section" ><img src="{{asset('frontend/images/aeroplane-icon.png')}}">
                                         <div class="name">Edit Touring</div>
                                                  </a>
                                                     
                                     </div>
                                             </div> -->

                                             
                                             <div class="block">
                                                   <div class="icon">
                                              <a class="check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" data-profile-link="{{$data['editLink']}}?step=3#WorkingHours" ><img src="{{asset('frontend/images/calendor-icon.png')}}">
                                                     <div class="name">Edit Working Schedule</div>
                                                  </a>
                                                   
                                                  </div>
                                                  

                                             </div>
                                              <div class="block">
                                                  <div class="icon">
                                                    <a class="check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}"  data-profile-link="{{$data['editLink']}}?step=3#calendar_section" >
                                                      <img src="{{asset('frontend/images/calendor-icon.png')}}">
                                                     <div class="name">View Booked Slot/Cancel Booking</div>
                                                  </a>
                                                   
                                                  </div>
                                                  

                                             </div>

                                              <div class="block">
                                                  <div class="icon">
                                                    <a class="check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}"  data-profile-link="{{$data['editLink']}}?step=4" >
                                                      <img src="{{asset('frontend/images/calendor-icon.png')}}">
                                                     <div class="name">Edit Video/Photos</div>
                                                  </a>
                                                   
                                                  </div>
                                                  

                                             </div>
                                            
                                                 <div class="block updatebookingnotes">
                                                  <div class="icon"><a data-redirect-link="{{$data['editLink']}}?step=3#calendar_section" data-toggle="modal" onclick="check_working_hours({{$data['adId']}})" data-ad-id="{{$data['adId']}}" class="update-booking-slot"><img src="{{asset('frontend/images/calendor-icon.png')}}">
                                                     <div class="name">Update Booking Notes And Time Slot</div>
                                                  </a>
                                                  
                                                   
                                                  </div>

                                             </div>

                                            
                                              @if($data['listing_category']->cat_type !='job')
                                            @php
                                             $mediaverifity = CheckMediaStatusVerificationTable($data['adId']);
                                             @endphp

                                             <div class="block verifPending">
                                                  <div class="icon">
                          <a>
                          <img src="{{$mediaverifity == 0 ? asset('frontend/images/verification-ok-icon.png'): asset('frontend/images/underscreening-dashboard.png')}}">
                          <div class="name">{{$mediaverifity > 0 ? 'Verification Pending':'Verified'}}</div>
                          </a>
                                                  </div>
                                                  

                                             </div>
                                             @endif

                                        </div>
                                        @endif
                                        @endif

                     <div class="button_section">
                        <div class="dropdown dropdown-user">
    
                        <button class="btn Edit-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Edit Ad <i class="fa fa-angle-down"></i>
                        </button>
              
              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  
             <a class="dropdown-item check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{$data['editLink']}}?step=1">Details</a>
           <a class="dropdown-item check_ad_status1"  data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{$data['editLink']}}?step=2">Upgrade</a>
            @if($data['listing_category']->cat_type == 'individual' || $listing_category->cat_type == 'male')
            <a class="dropdown-item  check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{$data['editLink']}}?step=3">Services</a>
            <a class="dropdown-item check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{$data['editLink']}}?step=4">Photos</a>
            @endif
            @if($data['listing_category']->cat_type == 'job')
            <a class="dropdown-item check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{$data['editLink']}}?step=3">Featured Banner</a>
            @endif
              </div>
                </div>        
                  @if(!empty($plans))
                    <div class="btns">
                      <a class="btn view-btn check_ad_status" data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{url('profile/'. $data['slug'])}}">View Ad</a>
                        </div>
                     <div class="btns"><a class="btn renew-btn check_ad_status1"  data-id="{{$data['adId']}}" data-user-id="{{Auth::user()->id}}" href="javascript:void(0)" data-profile-link="{{$data['editLink']}}?step=2">Advance Top Up/Renew</a>
                 </div>
                   @endif
                  </div>

                                   <div class="clearfix"></div>
 @if($plans->plan_type != "Free")
              @if(!empty($activePlanId) && !empty($plans->addon_features) )
              <div class="extend_time">
                  @php
                  
                                             $ad_on_featuress = json_decode($plans->addon_features, true);
                                           $ad_on_features  =array();
                                           $new_add_on = array();
                                                    foreach($ad_on_featuress as $ss){
                                                       if(!empty($ss['price']) && !empty($ss['day'])){
                                                      $ad_on_features[$ss['title']][] = array(
                                                      "key_value" => $ss['key_value'],
                                                      "price" => $ss['price'],
                                                      "day" =>$ss['day'],
                                                     
                                                      );
                                                      
                                                 }
                                                      
                                                  }
                                                $orderDetail = getOrderData($CurrentorderIds);
                                             @endphp
                                            
                  @if(count($ad_on_features) > 0 )
                   
                    @php
                     if(count($orderDetail) > 0 && ($todayDate <= $orderDetail->plan_expired)){
                    $ts2 =$orderDetail->plan_expired; 
                    }else{
                    $ts2 =$orderDetail->plan_expired;
                    }
                    $ts1 = strtotime(date("Y-m-d h:i A"));
                        
                    $seconds_diff = $ts2 - $ts1;                            
                    $RemainingDays = round((($seconds_diff/24)/60)/60) ;

                    $featured_sexy_girlsdata =getAdOnsMultipleDates('featured_profiles', $query[0]->id);
                   $teaser_sexy_videodata = getAdOnsMultipleDates('teaser_video',$query[0]->id);
                   $featured_bannerdata = getAdOnsMultipleDates('featured_banner',$query[0]->id);
                   $super_speed_boostdata = getAdOnsMultipleDates('super_speed_boost',$query[0]->id);
                   $second_teaser_videodata = getAdOnsMultipleDates('teaser_video_two',$query[0]->id);

                    
                    $nn = 1;
                    @endphp
                    @if($current_plan_expired >= strtotime(date("d M Y h:i a")))
                     <h6 style="color: #fff;">SPECIAL PREMIUM ADD-ONS</h6>
                     <p>The Premium Add-ons features are specially designed to maximise your Ad Visibility at other places in the site as well.&nbsp;The more you're seen means more business you'll get. </p>
                   @if($errors->has("featured_sexy_girls"))
                         <span class="help-block">{{ $errors->first("featured_sexy_girls") }}</span>
                    @endif 
                     @if($errors->has("sexy_girl_teaser"))
                         <span class="help-block">{{ $errors->first("sexy_girl_teaser") }}</span>
                    @endif 
                    @if($errors->has("order_id"))
                         <span class="help-block">{{ $errors->first("order_id") }}</span>
                    @endif 
                    @if(session()->has('message'))   <span class="help-block">       {{ session()->get('message') }}    </span>  @endif
                    
                {{-- <form id="form_step_2" action="{{route('buyAddOns')}}" method="post">    --}} 
                                      
        @foreach( $ad_on_features as $pkey=>$af)
                    
                     @php
                      if($getUserGender =='male'){
                        $labelTitle = str_replace(array('Girls', 'Girl'),'Men',$pkey); 
                      }elseif($getUserGender =='trans'){
                         $labelTitle = str_replace(array('Girls', 'Girl'),'Trans',$pkey);
                      }else{
                         $labelTitle = $pkey;
                      }
                    @endphp         
                      
                        
                    <label>{{$labelTitle}}</label>
                    <div class="clearfix"></div>
                       
                       
                          @php
                          $ranme =  strtolower(str_replace(array('Super Boost(every 10mins)', " "),array('super_boost','_'),trim($pkey)));
                          $newslots = array();
                          $remainingday=0;
                          $skey =0;

                          $newdata = array();

                          $todayDateField = strtotime(date("Y-m-d"));
                          @endphp
                          
                               <select class="form-control add_on_features_upgrade" multiple id="addons{{$nn}}_{{$countAdsDatas}}" name="addons[]">
                                   {{--<option value="0" data-feature-name="{{$ranme}}">Select</option>--}}

                          @foreach($af as $aff)
                          @php
                          

                          $dateWiseTime = strtotime('+'.($aff['day'] -1).' days', $orderDetail->plan_purchased);

                          $dateWiseDateTime = '';
                           $addons_status[$aff['key_value']] = getAdOnsMultipleDates($aff['key_value'],$query[0]->id);
                            
                          
                                       


                          $nm = mt_rand(1,100);
                          $order_plan_id = count($orderDetail) > 0 && ($todayDate <= $orderDetail->plan_expired)? $plans->id : $plans->id;
                                        // new code 
                         
                    $featureDay = count($orderDetail) > 0 && ($todayDate <= $orderDetail->plan_expired)? $orderDetail->featured_profile_days : $order->featured_profile_days;
                      $featureDayArray = explode(',',$featureDay);

                      if(in_array($aff['day'],$featureDayArray)){
                          $checked = 'disabled=true';
                        }else{
                           $checked = '';
                        }

                    $teaserDay = count($orderDetail) > 0 && ($todayDate <= $orderDetail->plan_expired)? $orderDetail->teaser_video_days : $order->teaser_video_days;
                      $teaserDayArray = explode(',',$teaserDay);

                      if(in_array($aff['day'],$teaserDayArray)){
                         $checked = 'disabled=true';
                        }else{
                           $checked = '';
                        }

                    $teaserVideoTwoDay = count($orderDetail) > 0 && ($todayDate <= $orderDetail->plan_expired)? $orderDetail->teaser_video_two_days : $order->teaser_video_two_days;
                      $teaserVideoTwoDayArray = explode(',',$teaserVideoTwoDay);

                      if(in_array($aff['day'],$teaserVideoTwoDayArray)){
                         $checked = 'disabled=true';
                        }else{
                           $checked = '';
                        }


                    $superspeedDay = count($orderDetail) > 0 && ($todayDate <= $orderDetail->plan_expired)? $orderDetail->super_speed_boost_days : $order->super_speed_boost_days;
                      $superspeedDayArray = explode(',',$superspeedDay);

                       if(in_array($aff['day'],$superspeedDayArray)){
                         $checked = 'disabled=true';
                        }else{
                           $checked = '';
                        }

                    $featureBannerDay = count($orderDetail) > 0 && ($todayDate <= $orderDetail->plan_expired)? $orderDetail->featured_banner_days : $order->featured_banner_days;
                      $bannerDayArray = explode(',',$featureBannerDay);

                      if(in_array($aff['day'],$bannerDayArray)){
                         $checked = 'disabled=true';
                        }else{
                           $checked = '';
                        }


              //end new code
                         

                          $adremainingdays = $plans->plan_duration-$RemainingDays;
                          
                          $dateWiseDateTime = date('Y-m-d',strtotime('+'.($aff['day']-1).' days', $orderDetail->plan_purchased));
                          
                          if($aff['key_value'] =='featured_profile'){

                            if(in_array($dateWiseDateTime,$featured_sexy_girlsdata))
                            {
                            $disab = " disabled=true";
                            $purchasedTxt = 'Purchased';
                            }else{
                            $disab = "";
                            $purchasedTxt = '';
                          }
                              

                        }
                        if($aff['key_value'] =='teaser_video'){

                            if(in_array($dateWiseDateTime,$teaser_sexy_videodata))
                            {
                            $disab = "disabled=true";
                            $purchasedTxt = 'Purchased';
                            }else{
                            $disab = "";
                            $purchasedTxt = '';
                          }
                              

                        }
                        if($aff['key_value'] =='featured_banner'){

                            if(in_array($dateWiseDateTime,$featured_bannerdata))
                            {
                            $disab = "disabled=true";
                            $purchasedTxt = 'Purchased';
                            }else{
                            $disab = "";
                            $purchasedTxt = '';
                          }
                              

                        }
                        if($aff['key_value'] =='super_speed_boost'){

                            if(in_array($dateWiseDateTime,$super_speed_boostdata))
                            {
                            $disab = "disabled=true";
                            $purchasedTxt = 'Purchased';
                            }else{
                            $disab = "";
                            $purchasedTxt = '';
                          }
                              

                        }
                        if($aff['key_value'] =='teaser_video_two'){

                            if(in_array($dateWiseDateTime,$second_teaser_videodata))
                            {
                            $disab = "disabled=true";
                            $purchasedTxt = 'Purchased';
                            }else{
                            $disab = "";
                            $purchasedTxt = '';
                          }
                              

                        }
                          
                          
                       
                          @endphp
                          @if((int)$adremainingdays == 0 || (int)$adremainingdays < (int)$aff['day'] )
                        
                            echo "hello";
                            <option value="{{$aff['day'].'-'.$aff['price']}}" data-feature-name="{{$aff['key_value']}}" {{$checked}} {{$disab}} data-order-id="{{$CurrentorderIds}}"> 
                             {{--  {{$aff['day']}} Day  - {!! price_format( $af[$skey]['price']) !!} {{ $purchasedTxt }}</option> --}}
                               {{date('D, d M',$dateWiseTime)}}  - {!! price_format( $af[$skey]['price']) !!} {{ $purchasedTxt }} </option>
                               @php
                       $skey++;
                       @endphp
                          @else
                          @php
                          $skey = 0;
                          @endphp
                              echo "hi";
                              <option value="{{$aff['day'].'-'.$aff['price']}}" data-feature-name="{{$aff['key_value']}}" {{$checked}} disabled> 
                              {{-- {{$aff['day']}} Day  - {!! price_format( $aff['price']) !!} {{ $purchasedTxt }}</option> --}}

                               {{date('D, d M',$dateWiseTime)}}  - {!! price_format( $aff['price']) !!} {{$purchasedTxt}} </option>
                         @endif
                         
                            @endforeach
                           
                 </select>
                  
              @php
               $nn++;
              @endphp

              
                @endforeach
                @endif  
                            {{--   <!-- <button type="submit" class="purchaseadd-btn" id="ad_one_purchase">Buy Add-Ons</button> --> --}} 
          <div class="clearfix"></div>
       
         
        {{--  <!-- </form> --> --}}
             
           
         
               @endif
                  
                                        </div>
                                        @endif
                                        @endif
 
                                   </div>
                              </div>
                         </div>
                      

                         <div class="clearfix"></div> 

                  
                   
                    <!-- Verification data show start -->
                 <div class="profile_photos dashboard_uploadPhotos club-dashboard">
                        
                             
                     @if(count($data['verification_videos']) > 0)
                     <p class="whiteColor"><span>Video Verification</span></p>                     
                      <div class="preview-video-zone">
                             @foreach($data['verification_videos'] as $s)
                               <div class="dashboard-exitinguser-upload-img">
                               <div class="preview-image preview-show-{{$s->id}}">
                                   <!-- <div class="image-cancel" data-no="{{$s->id}}" data-image-id="{{$s->id}}">x</div> -->
                                    <div class="image-zone">
                                        <video video width="250" height="200" controls 
                                        id="verification-video-{{$s->id}}">
                                        <source src='{{asset("uploads/verification_video/".$s->identity_details)}}'>     
                                        </source>
                                        </video>
                                            
                                             </div>
                                           </div>
                                    </div>
                              @endforeach
                              </div>
                
                
                <p class="uploadphotos-verif-text"><u>Disclaimer</u>- Your video verification video will only be visible to you and our verification team. Read <a href="{{url('info/privacy-policy')}}" style="color:red;">privacy policy</a> </p>
                    @endif
                             
                         
                     </div> 
                     <!-- End verification data  -->

                    </div>

                    <!-- All ad modals  starts here  -->

                    <div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="Update_working_hours{{$data['adId']}}" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <strong>Whoops!</strong>
          <p> Looks like you haven't updated your working hours.</p> 
           <a type="button" class="green_gredient_btn gr_pink" href="{{$data['editLink']}}?step=3#WorkingHours" target="_blank">Update Now</a> 
            
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>
          
<div class="modal fade services-addTime thankyou-pop" id="Day_Off_Modal{{$data['adId']}}" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    
         <p>Today is Dayoff.</p>
        <p><strong>Decided to work ?</strong></p>
        <p><a type="button" class="green_gredient_btn gr_pink" href="{{$data['editLink']}}?step=3#WorkingHours" target="_blank">Update Now</a> </p>
            
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>

<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="expired_ad_status{{$data['adId']}}" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <h3>Hi {{Auth::user()->name}}</h3>
          <p>Looks like your plan is expired.</p> 
         
          <p><a type="button" class="green_gredient_btn gr_pink" href="{{$data['editLink']}}?step=2" target="_blank">Renew Now</a> </p>
                 
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>
<!-- end Day off and working hours update modal --> 

<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="no_verification_video{{$data['adId']}}" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h1>Hi </h1>
          <h3>{{Auth::user()->name}}</h3>
           <p>You have not uploaded your verification video.</p> 
         
          <p><a type="button" class="green_gredient_btn gr_pink" href="{{$data['editLink']}}?step=5" target="_blank">Upload Now</a> </p>
            
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div> 

<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="ad_hidden_modal{{$data['adId']}}" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <h1>Hi </h1>
          <h3>{{Auth::user()->name}}</h3>
           <p>Unhide your ad first to enable the editing sections.</p>
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div> 
<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="ad_visible_modal" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
           <span>Your ad is now visible on the site. <h1>Please refresh page.</h1></span>
           <p><a href="javascript:void(0);" type="button" class="green_gredient_btn gr_pink" data-dismiss="modal">Ok</a></p>

      </div>  

<div class="modal-footer">
    
</div>
       
    </div>
  </div>
</div>

<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="ad_hidden_modal1" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
           Your ad is now hidden from the site. <h1>Please refresh the page.</h1>
          <a href="javascript:void(0);" type="button" class="green_gredient_btn gr_pink" data-dismiss="modal">Ok</a>
      </div>  

<div class="modal-footer">
    
</div>
       
    </div>
  </div>
</div>
                    <!-- End all ad modal here  -->


                    @empty
                    
                         @php
                                   $countMyAds = getMyAdsActiveAndExpired();
                                   
                                   @endphp
                      @if($countMyAds['active'] > 0 )

                      <div class="col-md-12 ad-status-box">
                        <h2>No Expired  Ad Found!</h2>
                             
                          </div>

                          @elseif($countMyAds['expired'] > 0)

                           <div class="col-md-12 ad-status-box">
                         <h2>No Active  Ad Found!</h2>
                            
                          </div>

                          @else
                     
                         <div class="col-md-12 ad-status-box">
                        <h2>No Ad Found. Please post your Ad.</h2>
                              <a href='{{route("post-ad.","/")}}' class="post-add-btn">Post Ad</a>
                          </div>
                        @endif
                    
               @endif
               </div>
               
          </div>
		  </div>
</section>

<!-- =====================Add services pop up for booking update pop up form======= -->
<div class="modal fade services-steps-form" id="service_include_popup" tabindex="-1" role="dialog"  aria-hidden="true" style="z-index: 2000;">

  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">   
<h2>Please select services</h2>  

        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToTextbox_popup()">
          <span aria-hidden="true">save</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">
              
        <div class="extra_service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
          @foreach($servicesavailable as $sa)    
       <!--    @php 
            $nssm = rand(1000,666); 
          @endphp -->
                  <li role="presentation">
                        <div class="radio radio-info form-check-inlinesquarebox">
                          <input type="checkbox" value="{{$sa['id']}}" name="extra-service-available" id="service_available{{$sa['id']}}" class="css-checkbox services_include_popup">
                         <label for="service_available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                        </div>
                  </li>
                        @endforeach
        </ul>
            <input type="hidden" value="" id="service_available">    
            </div>        
        </div>
      </div>  
    </div>
  </div>
</div>
<!-- =====================Add Extra services pop up for booking update pop up form======= -->
<div class="modal fade services-steps-form" id="extra_service_include_popup" tabindex="-1" role="dialog"  aria-hidden="true" style="z-index: 2000;">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">   
<h2>Please select services</h2>     
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToExtraTextbox_popup()">
          <span aria-hidden="true">save</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">
              
        <div class="extra_service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
          @foreach($servicesavailable as $sa)    
         
                  <li role="presentation">
                        <div class="radio radio-info form-check-inlinesquarebox">
                          <input type="checkbox" value="{{$sa['id']}}" name="extra-service-available" id="extra_service_available{{$sa['id']}}" class="css-checkbox extra_services_include_popup">
                         <label for="extra_service_available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                        </div>
                  </li>
                        @endforeach
        </ul>
            <input type="hidden" value="" id="extra_service_available">    
            </div>        
        </div>
      </div>  
    </div>
  </div>
</div>

<!-- BookingCalender  modal pop up start -->
<div class="modal fade services-addTime" id="BookingCalender" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
         <h5 class="modal-title">Booking Slot / Calendar Updates</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="error_msg"></div>
       
        
        <form id="booking_form" onsubmit="return false" method="post" action="{{route('savebookings')}}">
          {{csrf_field()}}
                    @if ($errors->any())
                <div class="alert alert-warning">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif

       
     <div class="sevicesaddtime-top bookingSlot-block">
            {{-- <h4>Booking Slot / Calendar Updates</h4> --}}           
               <label for="booked" class="bookslot-btns booked-btn calanderbutton-active">
                  <input type="radio" name='slot_type' id="booked" checked value="Booked" class="bookingSlot-commonbtn">
                <span class="label"></span>Booked Slot
                </label>
                  {{-- <label for="booked" class="bookslot-btns breaktime-btn">
                  <input type="radio" name='slot_type' id="booked" value="Break Time" class="bookingSlot-commonbtn">
                <span class="label"></span>Break Time
                </label> --}}
                  <br>
                <span class="label"><strong>Tips:</strong><small> Always try to add 15-30mins extra time in your current booking so you can have a enough time to prepare yourself to meet your Next Client.</small></span> 
                <span class="help1-block hidden slot_type_error"></span>
         </div>
          
          <div class="clearfix"></div>
          <div class="sevicesaddtime-top" id="sevicesaddtime-top">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Regular Client</label>
            <select name="title" class="form-control" id="title">
              <option value="Regular Client">Regular Client</option>
              <option value="New Client">New Client</option>
            </select>
          </div>
               <div class="form-group">
       
                <span class="help1-block hidden title_error"></span>

             <input type="hidden" name="user_ad_id" id="user_ad_id" value="">
             <input type="hidden" name="booking_id" id="booking_id" value="">
               <input type="hidden" name="redirect_link" id="redirect_link" value="">
          </div>
              <div class="form-group">
            <label for="recipient-name" class="col-form-label">Client Name</label>
            <input type="text" placeholder="Enter Client Name" class="form-control" name="client_name" id="client_name">
          </div>
           
          
       <div class="form-group">
            <label for="message-text" class="col-form-label">Services Included</label>
            <input type="text" data-toggle="modal" data-target="#service_include_popup" placeholder="" class="form-control" name="services" id="services_popup" onclick="setId_popup(this.id)">
            <input type="hidden" id="services_hidden_popup" name="services_hidden_popup">
      </div>

          <div class="form-group">
            <label for="message-text" class="col-form-label">Add Extra Services</label>
            <input type="text" data-toggle="modal" data-target="#extra_service_include_popup" placeholder="" class="form-control" name="ex_services" id="ex_services" onclick="setExtraId_popup(this.id)">
            <input type="hidden" id="ex_services_hidden" name="ex_services_hidden">
           </div>

          <div class="form-group">
            <label for="message-text" class="col-form-label">Service Type</label>
            <select name="service_type" id="service-type" class="form-control">
            <option value="">Select</option>
            @foreach($servicetype as $ms)
            <option value="{{$ms->id}}">{{$ms->meta_value}}</option>
            @endforeach
          </select>
          </div>
           <div class="form-group">
            <label for="message-text" class="col-form-label">Set Reminder Notification</label>
      
            <select name="reminder" id="reminder-cal" class="form-control">
              <option value="no">No</option>
             
              <option value="15 minutes">15 minutes before</option>
               <option value="1 hour">1 hour before</option>
              <option value="1 day">1 day before</option>
            </select>
          </div>
            <div class="form-group">
              <label for="message-text" class="col-form-label">Booking Notes</label>
              <textarea class="form-control" name="booking_notes" id="booking_notes"></textarea>
            </div>
        </div>
      
 <div class="row">  
      <div class="form-group col-md-12"> 
        
              <label for="message-text" class="col-form-label">From</label>
              <input type="text" class="form-control datepicker" name="calendar_date" value="{{date('d-m-Y')}}" id="calendar_date" placeholder="Select Date"/>
               <span class="help1-block hidden calendar_date_error"></span>
              
            </div>
        <div class="col-md-6 form-group"> 
        @php
        $times = get_calendar_times(date('H:i A', strtotime(date())));
        @endphp
            
        <label for="message-text" class="col-form-label">Start Time</label>
             <select class="form-control" name="calendar_start_time" id="calendar_start_time">
              @foreach($times as $ti)
              <option value="{{$ti}}">{{$ti}}</option>
               @endforeach
             
              </select>
                <span class="help1-block hidden calendar_start_time_error"></span>
        
        </div>
        
        <div class="col-md-6 form-group endtime-block">
         
               <label for="message-text" class="col-form-label">End Time</label>        
              <select class="form-control" name="calendar_end_time" id="calendar_end_time">
                @foreach($times as $ti)
              <option value="{{$ti}}">{{$ti}}</option>
               @endforeach
              
              </select>
              
              <span class="help1-block hidden calendar_end_time_error"></span> 
        
        </div>

             
         
 
       </div>
       
        </form>
        
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="submit" class="servicespopupSave-btn" id="calendar_add_bookings" >Save & View</button>
      </div>
    </div>
  </div>
</div>

<!-- BookingCalender pop up end  -->


<!-- Thanks BookingCalender pop up start -->
<div class="modal fade services-addTime thankyou-pop" id="thankyou_booking" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <p>Your Booking slot has been successfully updated!</p>            
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>
<!-- Thanks BookingCalender pop up end  -->

<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="check_ad_status_modal" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <h3>Hi {{Auth::user()->name}}</h3>
          <p>It's look like your ad is under verification. It can take up to 10-20mins to process depending on the current volume. And If any correction needed in your profile then we'll let you know by a phone call /txt or via email. Thanks</p> 
            
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>

<div class="modal fade services-addTime thankyou-pop brdrrmv-popup" id="expired_ad_status" tabindex="-1" role="dialog"  aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title">Subscribe My Profile</h5>-->
        <button type="button" class="close " data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" title="Close">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <h3>Hi {{Auth::user()->name}}</h3>
          <p>Looks like your plan is expired, please renew.</p> 
            
      </div>  

<div class="modal-footer">

</div>
       
    </div>
  </div>
</div>

 <div class="modal fade" id="wrong_data_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
       <!--  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> -->
      </div>
      <div class="modal-body">
         <div class="alert alert-danger">
            <strong>Whoops!</strong> Something Went Wrong Please Try Later.
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Buy Add ons  price section overview pop up start-->
<div class="price-section-overview" style="display:none;">
                  
                </div>
                  <form id="form_step_2" action="{{route('buyAddOns')}}" method="post">     
                                {{csrf_field()}}                     

                     <input type="hidden" name="order_id" value="" id="order_id">
                      <input type="hidden" name="featured_sexy_girls" id="featured_sexy_girls" value="">
                     <input type="hidden" name="original_featured_sexy_girls" id="original_featured_sexy_girls" value="">
                     <input type="hidden" name="sexy_girl_teaser_video" id="sexy_girl_teaser_video" value="">
                     <input type="hidden" name="original_sexy_girl_teaser_video" id="original_sexy_girl_teaser_video" value="">
                     <input type="hidden" name="dedicated_teaser_video" id="dedicated_teaser_video" value="">
                     <input type="hidden" name="original_dedicated_teaser_video" id="original_dedicated_teaser_video" value="">
                     <input type="hidden" name="featured_banner" id="featured_banner" value="">
                     <input type="hidden" name="original_featured_banner" id="original_featured_banner" value="">
                     <input type="hidden" name="super_boost" id="super_boost" value="">
                     <input type="hidden" name="original_super_boost"id="original_super_boost" value="">
                     <input type="hidden" name="selected_currency" id="selected_currency" value="{{currencysymbol($generalsettings['selected_currency'])}}">
                  
                </form>
<!-- End Buy Add ons  price section overview pop up  -->

<script type="text/javascript">
var verifyVideoUrl = "{!! route('VerifyIdentity') !!}";
var dashboard_url = "{!! route('dashboard') !!}";
var current_date = '{{date("Y-m-d")}}';
</script>
{{--
<script src="{{asset('frontend/js/verify-identity.js')}}"></script> 
--}}
<script>
function Timer(duration, display) 
{
  
    var timer = duration, hours, minutes, seconds;
    setInterval(function () {
        hours = parseInt((timer /3600)%24, 10)
        minutes = parseInt((timer / 60)%60, 10)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
    var $html ='<div>';
    $html +='<span class="hours">'+hours+'</span>';
    $html +='<div class="smalltext1">HRS</div>';
  $html +='</div>';
  $html +='<div>';
    $html +='<span class="minutes">'+minutes+'</span>';
    $html +='<div class="smalltext2">MIN</div>';
  $html +='</div>';
  $html +='<div>';
    $html +='<span class="seconds">'+seconds+'</span>';
    $html +='<div class="smalltext3">SEC</div>';
  $html +='</div>';
        display.html($html);

        --timer;
    }, 1000);
}

function timeDiffrence1(){
   var diff_hours = '{{ !empty($diff_hours1) ?  $diff_hours1 : ''}}';
    var twentyFourHours = diff_hours * 60 * 60;
    var display = $('#clockdiv1');
    Timer(twentyFourHours, display);
}
function timeDiffrence2(){
    var diff_hours = '{{ !empty($diff_hours2) ?  $diff_hours2 : ''}}';
    var twentyFourHours = diff_hours * 60 * 60;
    var display = $('#clockdiv2');
    Timer(twentyFourHours, display);
}
function timeDiffrence3(){
    var diff_hours = '{{ !empty($diff_hours3) ?  $diff_hours3 : ''}}';
    var twentyFourHours = diff_hours * 60 * 60;
    var display = $('#clockdiv3');
    Timer(twentyFourHours, display);
}
function timeDiffrence4(){
    var diff_hours = '{{ !empty($diff_hours4) ?  $diff_hours4 : ''}}';
    var twentyFourHours = diff_hours * 60 * 60;
    var display = $('#clockdiv4');
    Timer(twentyFourHours, display);
}
function timeDiffrence5(){
    var diff_hours = '{{ !empty($diff_hours5) ?  $diff_hours5 : ''}}';
    var twentyFourHours = diff_hours * 60 * 60;
    var display = $('#clockdiv5');
    Timer(twentyFourHours, display);
}
jQuery(function ($) 
{

  timeDiffrence1();
  timeDiffrence2();
  timeDiffrence3();
  timeDiffrence4();
  timeDiffrence5();
});

var timer;
$(function($) {
    timer = setTimeout(blnk, 0);
});


function blnk() {
    $(".blink").css({opacity: 0}).
        animate({opacity: 1}, 300, "linear").
        animate({opacity: 0}, 300, "linear", 
        function() {
            timer = setTimeout(blnk, 0);
        });
}
 var testimonial_setting_url =  "{{ route('updateadstatus') }}";
function updateStatus(ss){
var ad_id = $(ss).attr('data-ad-id');
var token = '{{csrf_token()}}';

   if($(ss).hasClass('active')){
      var status = 0;
   }else{
    var status = 1;
   }

   $.ajax({
      url: testimonial_setting_url,
      data:{status:status , ad_id:ad_id, _token:token},
      type:"POST",
      success: function(result) {
        if(result == 1){
          $("#ad_visible_modal").modal('show');
          
            
        }else{
          $("#ad_hidden_modal1").modal('show');
          
        }
    }
  });
 }

</script>

<script>
  $(document).ready(function(){
    $("#calendar_start_time").change(function(){
      
      calendar_start_time = $("#calendar_start_time").val();
      calendar_end_time = $("#calendar_end_time").val();
      
      if(calendar_start_time != "" && calendar_end_time != ''){
         var startTime = new Date().setHours(GetHours(calendar_start_time), GetMinutes(calendar_start_time), 0);
        var endTime = new Date().setHours(GetHours(calendar_end_time), GetMinutes(calendar_end_time), 0);
        
        if (startTime > endTime) {
            alert('Please Select End time Greater Then Start Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if (startTime == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if ((startTime+1) == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
      }
      

      
      /*alert(working_from);
      alert(working_to)*/
  });
  $("#calendar_end_time").change(function(){
      
      calendar_start_time = $("#calendar_start_time").val();
      calendar_end_time = $("#calendar_end_time").val();
      
      if(calendar_start_time != "" && calendar_end_time != ''){
         var startTime = new Date().setHours(GetHours(calendar_start_time), GetMinutes(calendar_start_time), 0);
        var endTime = new Date().setHours(GetHours(calendar_end_time), GetMinutes(calendar_end_time), 0);
        
        if (startTime > endTime) {
            alert('Please Select End time Greater Then Start Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if (startTime == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
        if ((startTime+1) == endTime) {
            alert('Please Select Diifrent Start Time And End Time');
            $("#calendar_start_time").val('');
            $("#calendar_end_time").val('');
            calendar_start_time = '';
            calendar_end_time = '';
        }
      }
      

      
      /*alert(working_from);
      alert(working_to)*/
  });
    $(".bookslot-btns").on('click', function(){
    $(".bookslot-btns").removeClass('calanderbutton-active');
    $(this).addClass('calanderbutton-active');
    });

     $('#calendar_date').datepicker({
    dateFormat:'dd/mm/yy',
  
  })
  $(".bookingSlot-commonbtn").click(function(){
       $ss =  $(this).val();
       if($ss == 'Available' || $ss=="Break Time"){
        $("#sevicesaddtime-top").hide();
       }else{
        $("#sevicesaddtime-top").show();
       }
      })

 
    $(".add_on_features_upgrade").change(function(){
  
    var addon_value = $(this).children('option:selected').val();
    
    var order_id = $(this).children('option:selected').attr('data-order-id');

    var old_order_id = $("#order_id").val();
       
    $("#order_id").val(order_id);
     
    var featurename = $(this).children('option:selected').attr('data-feature-name');
    console.log(featurename);
    var selets = new Array();
    var textData = new Array();
    var selectedIndexCounts = new Array();

    $(".add_on_features_upgrade").children('option:selected').each(function(i, opts){
      selectedIndexCounts.push(opts.getAttribute('data-feature-name'));
    });

    $(this).children('option:selected').each(function(i, opt){
         console.log(opt);
        if(opt.getAttribute("disabled") != "true"){
          

          console.log('hi');
          var normalValue = opt.value;
          var splitVal = normalValue.split('-');
          selets.push(eval(splitVal[1]));
          textData.push(normalValue);
          currencysymbol = splitVal[0];
        }
        
    });
    var days = "";
    textData.forEach(function(value,index,array){
      var textnon = value.split("-");
      //var daysplit = 
      days = days + textnon[0] + ',';

      
      //var splitVal = normalValue.split('-');
      //var newtext = splitVal[0];
      

    });
    var strVal = days;
    var lastChar = strVal.slice(-1);
  if (lastChar == ',') {
  strVal = strVal.slice(0, -1);
  }
  selectedtext = strVal;
    //console.log(text);
    const arrSum = parseFloat(Number(selets.reduce((a,b) => a + b, 0)).toFixed(2));
    /*var selectedtext = $(this).children('option:selected').val()
    console.log(selectedtext);*/

    

    /*var newSelectedText =  selectedtext.split(" ").join("");
    var finalnewSelectedText = newSelectedText.replace( /[\r\n]+/gm, "" );
    console.log(finalnewSelectedText);*/

    var html = "";
    var total = 0;
    console.log('hello');

      var old_featured_profile = $("#featured_sexy_girls").val();
      var old_teaser_video = $("#sexy_girl_teaser_video").val();
      var old_dedicated_video = $("#dedicated_teaser_video").val();
      var old_super_boosts = $("#super_boost").val();
      var old_selected_currency = $("#selected_currency").val();
      var old_featured_banner = $("#featured_banner").val();
      var old_order_id = $("#order_id").val();
       if(old_order_id!="" && old_order_id !=  order_id){
        $("#featured_sexy_girls").val('');
    $("#sexy_girl_teaser_video").val('');
    $("#dedicated_teaser_video").val('');
    $("#super_boost").val('');
     $("#original_featured_banner").val('');
     $("#original_featured_sexy_girls").val('');
     $("#original_sexy_girl_teaser_video").val('');
      $("#original_dedicated_teaser_video").val('');
     $("#original_super_boost").val('');
        $("#order_id").val();
        $(this).children('option:selected').each(function(i, opt){
          $(this).removeAttr('selected');
        });
        
        $(".price-section-overview").html('');
        $(".price-section-overview").hide();

       }
       $("#order_id").val(order_id);
        if(selectedIndexCounts.length <= 0 ){
             $("#featured_sexy_girls").val();
          $("#sexy_girl_teaser_video").val('');
          $("#dedicated_teaser_video").val('');
          $("#super_boost").val('');
           $("#original_featured_banner").val('');
           $("#original_featured_sexy_girls").val('');
           $("#original_sexy_girl_teaser_video").val('');
            $("#original_dedicated_teaser_video").val('');
           $("#original_super_boost").val('');
            $(".price-section-overview").html('');
            $(".price-section-overview").hide();

          }else{
      $(".price-section-overview").show();
        }
    
     if(featurename == 'featured_profile' || featurename=='featured_sexy_girls'){
      
        $('#featured_sexy_girls').val(arrSum);
        $('#original_featured_sexy_girls').val(selectedtext);
       
      }
      if(featurename == 'teaser_video' || featurename=='sexy_girl_teaser_video'){
      
        $('#sexy_girl_teaser_video').val(arrSum);
       $('#original_sexy_girl_teaser_video').val(selectedtext);
      }
       if(featurename == 'teaser_video_two' || featurename=='dedicated_teaser_video' ){
        
         $('#dedicated_teaser_video').val(arrSum);
        $('#original_dedicated_teaser_video').val(selectedtext);
      }
       if(featurename == 'super_speed_boost' || featurename=='super_boost'){
        
       $('#super_boost').val(arrSum);
        $('#original_super_boost').val(selectedtext);
      }
      if(featurename == 'featured_banner'){
        
       $('#featured_banner').val(arrSum);
        $('#original_featured_banner').val(selectedtext);
      }

      if( selectedIndexCounts.includes('featured_profile') == false){
        $("#featured_sexy_girls").val('');
        $("#original_featured_sexy_girls").val('');
      }
      if( selectedIndexCounts.includes('teaser_video') == false){
        $("#sexy_girl_teaser_video").val('');
        $("#original_sexy_girl_teaser_video").val('');
      }
      if( selectedIndexCounts.includes('teaser_video_two') == false){
        $("#dedicated_teaser_video").val('');
        $("#original_dedicated_teaser_video").val('');
      }
      if( selectedIndexCounts.includes('super_speed_boost') == false){
        $("#super_boost").val('');
        $("#original_super_boost").val('');
      }
      if( selectedIndexCounts.includes('featured_banner') == false){
        $("#featured_banner").val('');
        $("#original_featured_banner").val('');
      }

      var featured_profile = $("#featured_sexy_girls").val();
      var teaser_video = $("#sexy_girl_teaser_video").val();
      var dedicated_video = $("#dedicated_teaser_video").val();
      var super_boosts = $("#super_boost").val();
      var selected_currency = $("#selected_currency").val();
      var featured_banner = $("#featured_banner").val();
      var original_featured_banner = $("#original_featured_banner").val();
      var original_featured_profile = $("#original_featured_sexy_girls").val();
      var original_teaser_video = $("#original_sexy_girl_teaser_video").val();
      var original_dedicated_video = $("#original_dedicated_teaser_video").val();
      var original_super_boosts= $("#original_super_boost").val();
      console.log(featured_profile);
      html +='<div class="text-right whiteColor"><a href="javascript:void(0)" class="plan_remove"><i class="fa fa-close"></i></a></div>';
      if(featured_profile !="" && featured_profile != 0 ){
          var addon_value_array = featured_profile;
          var selecteddate = original_featured_profile.split("-");
          total = parseFloat(total) + parseFloat(addon_value_array);
          html += '<div id="featured-profile-price-shw"><span class="plan-label">Featured Profile('+selecteddate[0]+'):</span> <span class="plan-price-label">'+selected_currency+addon_value_array+'</span></div>';
        } 
         
        if(featured_profile===0){
          var addon_value_array = old_featured_profile;
          total = parseFloat(total) - parseFloat(addon_value_array);
          html += '';
        }
         
       if(teaser_video !="" && teaser_video != 0){
        var addon_value_array = teaser_video;
         var selecteddate = original_teaser_video.split("-");
        total = parseFloat(total) + parseFloat(addon_value_array);
       html += '<div id="featured-profile-price-shw"><span class="plan-label">Sexy Teaser Video('+selecteddate[0]+'):</span> <span class="plan-price-label">'+selected_currency+addon_value_array+'</span></div>';
      }
            if(teaser_video===0){
        
          var addon_value_array = old_teaser_video;
          total = parseFloat(total) - parseFloat(addon_value_array);
          html += '';
        }

        
       if(dedicated_video !="" && dedicated_video != 0){
       var selecteddate = original_dedicated_video.split("-");;
        var addon_value_array = dedicated_video.split("-");
        total = parseFloat(total) + parseFloat(addon_value_array);
       html += '<div id="featured-profile-price-shw"><span class="plan-label">Dedicated Teaser Video('+selecteddate[0]+'):</span> <span class="plan-price-label">'+selected_currency+addon_value_array+'</span></div>';
      }
      if(dedicated_video === 0){
        var addon_value_array = old_dedicated_video;
          total = parseFloat(total) - parseFloat(addon_value_array);
          html += '';
      }
       if(super_boosts !=""  && super_boosts != 0){
        var selecteddate = original_super_boosts.split("-");;
         var addon_value_array = super_boosts.split("-");
         total = parseFloat(total) + parseFloat(addon_value_array);
        html += '<div id="featured-profile-price-shw"><span class="plan-label">Super Boost Profile('+selecteddate[0]+'):</span> <span class="plan-price-label">'+selected_currency+addon_value_array+'</span></div>';
      }
     if(super_boosts  === 0){

           var addon_value_array = old_super_boosts;
          total = parseFloat(total) - parseFloat(addon_value_array);
          html += '';
      }
      console.log(total);
      if(featured_banner !="" && featured_banner != 0){
       
        var selecteddate = original_featured_banner.split("-");
        var addon_value_array = featured_banner;
        total + parseFloat(total) + parseFloat(addon_value_array);
        html += '<div id="featured-profile-price-shw"><span class="plan-label">Featured Banner('+selecteddate[0]+'):</span> <span class="plan-price-label">'+selected_currency+addon_value_array+'</span></div>';
      }
      if(featured_banner  === 0){

           var addon_value_array = old_featured_banner;
          total = parseFloat(total) - parseFloat(addon_value_array);
          html += '';
      }

     
         if(total > 0){
        html += ' <div id="total-amount"><span class="plan-label">Total amount to be paid:</span> <span class="plan-price-label">'+selected_currency+total.toFixed(2)+'</span></div>';
        }
     
      if(total > 0){
         html += ' <div id="next-button-mobile"><a href="javascript:void(0)"  class="proceedPlan-btn" name="mobile_pay" id="mobile_pay">Proceed</a></div>';
         console.log(selets.length);
         
            $(".price-section-overview").html(html);
          
      }else{
       $(".price-section-overview").hide();
      }
  })
    })
  $("body").on("click", ".plan_remove", function(){
    $("#featured_sexy_girls").val();
    $("#sexy_girl_teaser_video").val('');
    $("#dedicated_teaser_video").val('');
    $("#super_boost").val('');
     $("#original_featured_banner").val('');
     $("#original_featured_sexy_girls").val('');
     $("#original_sexy_girl_teaser_video").val('');
      $("#original_dedicated_teaser_video").val('');
     $("#original_super_boost").val('');
     $('.add_on_features_upgrade ').multiselect("deselectAll", false);
    $('.multiselect-container').find('li').find('a').find('label').find('input').prop( "checked", false );
    $('.add_on_features_upgrade').multiselect('refresh');
    $(".price-section-overview").html('');
    $(".price-section-overview").hide();
})
  $(document).on("click", "#mobile_pay", function(){
    if($("#featured_sexy_girls").val() == "" && $("#sexy_girl_teaser_video").val() == "" && $("#dedicated_teaser_video").val() == "" &&  $("#dedicated_teaser_video").val() && $("#super_boost").val() !=""){
      alert("Please select atleast one  addons");
      return false;
    }
    $("#form_step_2").submit();
  });
$('.dropdown-select').on( 'click', '.dropdown-menu li a', function() { 
     var target = $(this).html();

     //Adds active class to selected item
     $(this).parents('.dropdown-menu').find('li').removeClass('active');
     $(this).parent('li').addClass('active');

     //Displays selected text on dropdown-toggle button
     $(this).parents('.dropdown-select').find('.dropdown-toggle').html(target + ' <span class="caret"></span>');
  });

function slideToAddon(){

 $('html, body').animate({
        scrollTop: $(".extend_time").offset().top
    }, 2000);
}

// ====================================================================
$(document).ready(function(){
 
   jQuery.ajax({
        type: 'POST',
        url: "{!!route('getTimeByDate')!!}",
        data: {'cal_date':current_date, 'ad_id':$('#user_ad_id').val(),_token:'{{csrf_token()}}'},
        success: function(data) {
    
          // data.option_html
                $('#calendar_start_time').html(data.option_html);
                $('#calendar_end_time').html(data.option_html2);
                return false;
        },
      });

    $(document).on('change','#calendar_date', function(){
        var cal_date = $('#calendar_date').val();
        var ad_id = $('#user_ad_id').val();
      // ---------------
       jQuery.ajax({
        type: 'POST',
        url: "{!!route('getTimeByDate')!!}",
        data: {'cal_date':cal_date, 'ad_id':ad_id,_token:'{{csrf_token()}}'},
        success: function(data) {
         
         
          // data.option_html
                $('#calendar_start_time').html(data.option_html);
                $('#calendar_end_time').html(data.option_html2);
                return false;
        },
      });
        // -----------
    });
});
// ===============================================================
$(".update-booking-slot").click(function(){
  var ad_id = $(this).attr('data-ad-id');
  $("#user_ad_id").val(ad_id);

   var redirect_link = $(this).attr('data-redirect-link');  
 $("#redirect_link").val(redirect_link);

})
  $("#calendar_add_bookings").click(function(){
        
       $(".help1-block").addClass("hidden");
      $(".form-group").removeClass("has-error");
      var registration_form = new FormData(document.getElementById("booking_form"));
      $.ajax({
        type: 'POST',
        dataType: "JSON",
        url: $("#booking_form").attr('action'),
        data: registration_form,
        processData: false,
        contentType: false,
           beforeSend:function(){
      $("#Load").fadeIn('slow');
      $("#calendar_add_bookings").text('Processing...');
      $("#calendar_add_bookings").attr('disabled',true);
    },
     success: function(data) {
       $("#Load").fadeOut('fast');
    $("#calendar_add_bookings").text('Save & View');
    $("#calendar_add_bookings").attr('disabled',false);
          if (data.errors) {
            $.each(data.errors, function(key, value) {
              $("." + key + "_error").html(value);
              $("." + key + "_error").removeClass("hidden");
              $("#" + key).parent().addClass("has-error");
            });


           
          } else {
                  $('#title').val("");
               $('#client_name').val("");
               $('#services').val("");
               $('#service_type').val("");
               $('#reminder').val("no");
               $('#ex_services').val("");
               $('#booking_notes').val("");
               $('input[name="slot_type"]').attr('checked', false);
                $(".bookslot-btns").removeClass('calanderbutton-active');
           var redirect_link = $('#redirect_link').val();
             $("#BookingCalender").modal('hide');
             window.location.href=redirect_link;
          }
        },
      });
     })

  // =========================================================
   $("#extra_service_include_popup, #service_include_popup").on('hidden.bs.modal', function (e) {
              $("body").addClass("modal-open");

            })


//=======================================================
  function setValuesToTextbox_popup(){
   // alert(); 
  var selectedValue = '';
  var selectedText = '';
  selectedValue = $('.services_include_popup:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.services_include_popup:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  console.log(selectedValue);
  var inputId = $('#service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('services_popup', 'services_hidden_popup');
  $('#'+hiddenInputValues).val(selectedValue);
  console.log(hiddenInputValues+'>>>>>>');
  console.log($('#'+hiddenInputValues).val());
 }
//--------------------------------------------------
   function setValuesToExtraTextbox_popup(){
   // alert();
   $('body').addClass('modal-open'); 
  var selectedValue = '';
  var selectedText = '';
  selectedValue = $('.extra_services_include_popup:checked').map(function() {return this.value;}).get().join(',')
  selectedText = $('.extra_services_include_popup:checked').map(function() {return $(this).next('label').text();}).get().join(',')
  // console.log(selectedValue+'======>>>> >>>selectedValue');
  var inputId = $('#extra_service_available').val();
  $('#'+inputId).val(selectedText);
  var hiddenInputValues = inputId.replace('ex_services', 'ex_services_hidden');
  $('#'+hiddenInputValues).val(selectedValue);
  console.log(hiddenInputValues+'>>>>>>hiddenInputValues');
  console.log($('#'+hiddenInputValues).val());
 }
//=======================================================
//================for pop up form=======================
function setId_popup(id){
  $('.services_include').map(function() {
      
    $(this).prop('checked', false);

});
  $("#service_available").val(id);
  var hiddenInputValues = id.replace('services_popup', 'services_hidden_popup');
  console.log($('#'+hiddenInputValues).val());
  if($('#'+hiddenInputValues).val() != ""){
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
          $(this).prop('checked', true);
      } else {
          $(this).prop('checked', false);
      }
  });
   }
 }
//=====================================================

 function setExtraId_popup(id){
  $('.extra_services_include').map(function() {
      
    $(this).prop('checked', false);
  
});
  $("#extra_service_available").val(id);
  console.log($("#extra_service_available").val());
  var hiddenInputValues = id.replace('ex_services', 'ex_services_hidden');
  console.log(hiddenInputValues);
  if($('#'+hiddenInputValues).val() != ""){
    
    var service_name_array = $('#'+hiddenInputValues).val().split(',');
    console.log(service_name_array);
    $("input[name='extra-service-available']").each(function () {
      var value = $(this).val();
      if ($.inArray(value, service_name_array) !== -1) {
        
          $(this).prop('checked', true);
      } else {
        
          $(this).prop('checked', false);
      }
  });
   
  }
 }
  // =========================================================

</script>
<script>
 //check if not check_working_hours

function check_working_hours(booking_ad_id){  
  var current_working_date = '{{date('Y-m-d')}}';
  $.ajax({
   type: 'POST',
   url: "{!!route('checkworkinghours')!!}",
  data: {'ad_id':booking_ad_id,working_date:current_working_date,_token:'{{csrf_token()}}'},
    success: function(data){

      if(data.errors ) {
        $("#Update_working_hours" + booking_ad_id ).modal('show');
      }else if(data.dayoff){
         $("#Day_Off_Modal" + booking_ad_id).modal('show');
      }else if(data.expired){
        $("#expired_ad_status" + booking_ad_id).modal('show');
      }else if(data.ad_hidden){
        $("#ad_hidden_modal" + booking_ad_id).modal('show');
      }else{
        
        $("#BookingCalender").modal('show');
        var cal_date = '{{date("d-m-Y")}}';
        jQuery.ajax({
        type: 'POST',
        url: "{!!route('getTimeByDate')!!}",
        data: {'cal_date':cal_date, 'ad_id':booking_ad_id,_token:'{{csrf_token()}}'},
        success: function(data) {
         
         
          // data.option_html
                $('#calendar_start_time').html(data.option_html);
                $('#calendar_end_time').html(data.option_html2);
                return false;
        },
        });


      }
    }

  });
}
//end check_working_hours

 //  check Ad Verification Status

$(".check_ad_status").click(function(){  
  var user_id = $(this).data('user-id');
  var ad_id = $(this).data('id');
  var href = $(this).data('profile-link');
  $.ajax({
   type: 'POST',
   url: "{!!route('checkAdVerificationStatus')!!}",
  data: {user_id:user_id,ad_id:ad_id,_token:'{{csrf_token()}}'},
    beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
    success: function(data){
  $("#Load").fadeOut('fast');
      if(data.not_verify ) {
        $("#check_ad_status_modal").modal('show');
      } else if(data.under_screening ) {
        $("#check_ad_status_modal").modal('show');
      } else if(data.ad_expired ) {
        $("#expired_ad_status"+ ad_id ).modal('show');
      }else if(data.ad_expired_video ) {
        $("#expired_ad_status"+ ad_id).modal('show');
      }else if(data.no_verification_video ) {
        $("#no_verification_video"+ ad_id).modal('show');
      }else if(data.not_found ) {
        $("#wrong_data_modal").modal('show');
      } else if(data.ad_hidden ) {
        $("#ad_hidden_modal"+ ad_id).modal('show');
      }else{
        window.location.href = href;
      }
    }

  });
});
//end check Ad Verification Status

$(".check_ad_status1").click(function(){  
  var user_id = $(this).data('user-id');
  var ad_id = $(this).data('id');
  var href = $(this).data('profile-link');
  $.ajax({
   type: 'POST',
   url: "{!!route('checkAdVerificationStatus')!!}",
  data: {user_id:user_id,ad_id:ad_id,_token:'{{csrf_token()}}'},
    beforeSend: function(){
    $("#Load").fadeIn('slow');
  },
    success: function(data){
  $("#Load").fadeOut('fast');
    if(data.ad_hidden ) {
        $("#ad_hidden_modal"+ ad_id).modal('show');
      }else{
        window.location.href = href;
      }
    }

  });
});

function GetHours(d) {
    if(d == '12:00 AM'){
      d = "00:00 AM";
    }
    if(d == '12:15 AM'){
        d = "00:15 AM";
    }
    if(d == '12:30 AM'){
        d = "00:30 AM";
    }
    if(d == '12:45 AM'){
        d = "00:45 AM";
    }
    if(d == '12:00 PM'){
      d = "00:00 PM";
    }
    if(d == '12:15 PM'){
        d = "00:15 PM";
    }
    if(d == '12:30 PM'){
        d = "00:30 PM";
    }
    if(d == '12:45 PM'){
        d = "00:45 PM";
    }

    //console.log("hello "+ d)
    
    var h = parseInt(d.split(':')[0]);

    if (d.split(':')[1].split(' ')[1] == "PM") {
        h = h + 12;
    }
    //console.log("Hi"+h);
    return h;
}
function GetMinutes(d) {
  
    return parseInt(d.split(':')[1].split(' ')[0]);
}
</script>

<script type="text/javascript">
                     
                           
$(document).ready(function() {
  <?php
  if(count($adsData)>0){
    $countAddData = 1;
    foreach($adsData as $data){
  ?>
    $('#addons1_<?php echo $countAddData;?>').multiselect({
        numberDisplayed: 1,
        nonSelectedText: 'Select',
        includeFilterClearBtn: false
    });
    $('#addons2_<?php echo $countAddData;?>').multiselect({
        numberDisplayed: 1,
        nonSelectedText: 'Select',
        includeFilterClearBtn: false
    });
    $('#addons3_<?php echo $countAddData;?>').multiselect({
        numberDisplayed: 1,
        nonSelectedText: 'Select',
        includeFilterClearBtn: false
    });
    $('#addons4_<?php echo $countAddData;?>').multiselect({
        numberDisplayed: 1,
        nonSelectedText: 'Select',
        includeFilterClearBtn: false
    });
  <?php
      $countAddData++;
    }
  } 
  ?>
    
});
</script>
@endsection