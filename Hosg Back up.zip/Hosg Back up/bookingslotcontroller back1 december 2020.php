<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Response;
use Input;
use Hash;
use Auth;
use Session;
use DB;


use App\Models\AdsTouring;
use App\Models\BookingSlots;
use App\Models\AdWorkingHours;
use App\Models\UserAdvertisement;
use App\Models\BookingNotes;
use App\Models\UserAdMeta;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use Imageupload;
use Carbon\Carbon;

class BookingSlotsController extends Controller
{
   public function __construct( ) {
       $this->generalSettings = generalSettings();
      
    }


    public function saveBookings(Request $request){
            $ad_id = $request->input('user_ad_id');
            // if(empty($ad_id)){
            //     return Response::json( array( 'errors' => 'Something wrong please try after some time.' ) );
            // }
            $name_regex = "/^[\pL\s]+$/u";
            if($request->input('slot_type') == 'Booked'){
              $validator = Validator::make( $request->all(),[
            'calendar_date' => 'required',
            'calendar_end_time' => 'required',
            'calendar_start_time' => 'required',
            'slot_type' => 'required',
            'client_name' => 'required'
                    ], [
                        'calendar_date.required' => 'Please select date.',
                        'calendar_end_time.required' => 'Please select end time.',
                        'slot_type.required' => 'Please choose Update type.',
                        'calendar_start_time.required' => 'Please select start time.',
                        'client_name.required' => 'Please enter client name.'
                    ]);
            }else{
            $validator = Validator::make( $request->all(),[
            'calendar_date' => 'required',
            'calendar_end_time' => 'required',
            'calendar_start_time' => 'required',
            'slot_type' => 'required'
            
                    ], [
                        'calendar_date.required' => 'Please select date.',
                        'calendar_end_time.required' => 'Please select end time.',
                        'slot_type.required' => 'Please choose Update type.',
                        'calendar_start_time.required' => 'Please select start time.'
                        
                    ]);
          }
            if ($validator->fails()) {
                return json_encode(array('errors' => $validator->getMessageBag()->toArray() ) );
            }
        
            $cal_date = date('Y-m-d', strtotime(str_replace("/","-",$request->input('calendar_date'))));
            $end_time =  strtotime($cal_date." ".$request->input('calendar_end_time'));
             $start_time =  strtotime($cal_date." ".$request->input('calendar_start_time'));
            $remainder = $request->input("reminder");
            $working_hours = AdWorkingHours::where('ad_id', $ad_id)->where('working_date', $cal_date)->first();
            if(count($working_hours) > 0){
               $starttime = strtotime(date("h:i A",strtotime($request->input('calendar_start_time'))));
                 $endtime = strtotime(date("h:i A",strtotime($request->input('calendar_end_time'))));
                $comp_start_time =  strtotime(date('h:i A', $working_hours->working_start_time));
                $display_start_time =  date('h:i A', $working_hours->working_start_time);
               
              $comp_end_time = strtotime(date('h:i A', $working_hours->working_end_time));
               $display_end_time =  date('h:i A', $working_hours->working_end_time);

              if($starttime < $comp_start_time){
                return json_encode(array('errors'=>array("calendar_start_time" => array("Please select start time and end time between your working hours(". $display_start_time." - ".$display_end_time.")"))
              ));
              }
                 if($endtime > $comp_end_time){
                return json_encode(array('errors'=>array("calendar_end_time" => array("Please select start time and end time between your working hours(". $display_start_time." - ".$display_end_time.")"))
              ));
              }

            }
            $query = "SELECT * FROM `tbl_booking_slots` WHERE `booking_date` = '".$cal_date."' and ".$start_time." between `booking_start_time`  AND `booking_end_time` and ad_id='".$ad_id."'";
    
            $res = DB::select($query);
            $res=array();

            if((int)$request->input('booking_id') > 0){
            
                $bookingObj = BookingSlots::findOrFail($request->input('booking_id'));
                $bookingObj->ad_id = $ad_id;
                $bookingObj->booking_title = $request->input('title');
                $bookingObj->booking_client_name = $request->input('client_name');
                $bookingObj->booking_service_type = $request->input('service_type');
                $bookingObj->booking_services = $request->input('services');
                $bookingObj->booking_slot_type = $request->input('slot_type');
                $bookingObj->booking_date = $cal_date;
                $bookingObj->booking_start_time = $start_time;
                $bookingObj->booking_end_time = $end_time;
                $bookingObj->reminder_set = $remainder;
                $bookingObj->booking_ex_services = $request->input('ex_services');
                $bookingObj->booking_notes = $request->input('booking_notes');
                $bookingObj->save();
                
              
              
            }else{

            $bookingObj = new BookingSlots();
            $bookingObj->ad_id = $ad_id;
            $bookingObj->booking_title = $request->input('title');
            $bookingObj->booking_client_name = $request->input('client_name');
            $bookingObj->booking_service_type = $request->input('service_type');
            $bookingObj->booking_services = $request->input('services');
            $bookingObj->booking_slot_type = $request->input('slot_type');
            $bookingObj->booking_ex_services = $request->input('ex_services');
            $bookingObj->booking_notes = $request->input('booking_notes');
            $bookingObj->booking_date = $cal_date;
            $bookingObj->booking_start_time = $start_time;
            $bookingObj->booking_end_time = $end_time;
            $bookingObj->reminder_set = $remainder;
            $bookingObj->save();
          }
            
             $interval1 = 900;
           if((int)$ad_id > 0){
          $ress= BookingSlots::where('ad_id', $ad_id)->where('booking_date', $cal_date)->get();
        }

        

        $color = array();
        $start_times = array();
        $booking_ids = array(); 
        $booking_titles = array(); 
        $booking_slot = array();

    // ==============================================================
        foreach($ress as $result){
        $booking_start_time = $result->booking_start_time;
        $booking_end_time = $result->booking_end_time;

          for ($i = $booking_start_time; $i <= $booking_end_time; $i += $interval1){
               $start_times[] = date('h:i A', $i);
               

              if($result->booking_slot_type == 'Available'){
                $color[date('h:i A', $i)] = 'color: green !important;width: 60px;float: left;height: 20px; font-size:14px;';
                $booking_ids[date('h:i A', $i)] = $result->id;
                 
                  $booking_slot[date('h:i A', $i)] = $result->booking_slot_type;
              }
              if($result->booking_slot_type == 'Booked'){
                $color[date('h:i A', $i)] = 'background: red;width: 60px;height: 20px;float: left;color:#f0ffff;font-size:14px;';
                 $booking_ids[date('h:i A', $i)] = $result->id;
                 $hyphenSymbol = $result->booking_services !='' ? '-':'';

               //$title = $result->booking_client_name.$hyphenSymbol.$result->booking_services;
                 $title = $result->booking_client_name;
                 $booking_titles[date('h:i A', $i)] =strlen($title) > 32?substr($title, 0,32).'...':$title;
                  $booking_slot[date('h:i A', $i)] = $result->booking_slot_type;
               }
              if($result->booking_slot_type == 'Break Time'){
                $color[date('h:i A', $i)] = 'background: #9c70ff;width: 60px;height: 20px;float: left; color:#f0ffff;font-size:14px;'; 
                $booking_ids[date('h:i A', $i)] = $result->id;
                // $booking_titles[date('h:i A', $i)] =date('h:i A', $result->booking_start_time) ." to ".  date('h:i A', $result->booking_end_time);
                $booking_titles[date('h:i A', $i)] =$result->booking_slot_type;

                  //$booking_slot[date('h:i A', $i)] = $result->booking_slot_type;          
              }
             if($result->booking_slot_type == 'Day Off'){
                $color[date('h:i A', $i)] = 'width: 60px;height: 20px;float: left;color:#f0ffff;font-size:14px;'; 
                $booking_ids[date('h:i A', $i)] = $result->id;             
              }
            }
          
        }

              $times = get_calendar_times();

         $html="";
         $option_html = "";
         $option_html2="";
         $newbookingids = array();
          foreach($times  as $time){
             
              if(count($working_hours) > 0){
              if(empty($working_hours->dayoff)){

              $caltime = strtotime(date("h:i A",strtotime($time)));
                
                $working_start_time =  strtotime(date('h:i A', $working_hours->working_start_time));


               
              $working_end_time = strtotime(date('h:i A', $working_hours->working_end_time));
               
                if($caltime >= $working_start_time && $caltime <= $working_end_time){
                 $booking_id = $booking_ids[$time];
                  if(in_array($time, $start_times)){
                      $class=  $color[$time];
                      
                       $disabled = "disabled";
                       
                         $booking_title = $booking_titles[$time];
                       
                    
                       $booking_slot = $booking_slot[$time];
                       // if(!empty($booking_title) && $booking_slot == 'Break Time'){
                       //  $booking_title = $booking_slot;
                       // }

                       if(!empty($booking_title)){
                      
                         
                          if(!in_array($booking_id, $newbookingids)){
                           
                                $html .= '<li data-booking-id="'.$booking_id.'" class="booked-slot"><span class="booking-date-time-strip" style="'.$class.';border-top: 1px solid #fff;" >'.$time.'</span> <div class="slot-title">View -&nbsp;'.$booking_title.'</div><button data-id="'.$booking_id.'" class="cancel-booking-btn" onclick="deleteBookingSlot(\''.$booking_id.'\')" title ="Cancel Booking">X</button></li>';
                          
                          }else{

                            $html .= '<li data-booking-id="'.$booking_id.'" class="booked-slot"><span class="booking-date-time-strip" style="'.$class.'">'.$time.'</span></li>';
                          }


                         $newbookingids[] = $booking_id;
                        
                       }else{
                         $html .= '<li data-booking-id="'.$booking_id.'"><span class="booking-date-time-strip" style="'.$class.'">'.$time.'</span> </li>';
                       }
                      
                   }else{
                     $disabled = "";
                    $class = "color: green !important;width: 60px;height: 20px;float: left; font-size:14px;";
                     $booking_id ="";
                      $html .= '<li data-booking-id="'.$booking_id.'"><span class="booking-date-time-strip" style="'.$class.'">'.$time.'</span> </li>';
                  }
                 // $html .= '<li data-booking-id="'.$booking_id.'">'.$time.' <span style="'.$class.'"> </span></li>';
                  $option_html .= "<option value=\"{$time}\" ".$disabled.">".$time."</option>";
                   if(date('h:i A', $working_hours->working_end_time) == $time){
                    $selected = 'selected';
                  }else{
                     $selected = '';
                  }
                  $option_html2 .= "<option value=\"{$time}\" ".$selected." ".$disabled.">".$time."</option>";
                  }
                    // echo date('h:i A', $working_hours->working_time);
                    // echo date('h:i A', $working_hours->working_end_time); die;
                }else{
                  //-------day off----------------

                  //echo 'dayoff'; die;
                  $class = "width: 60px;height: 20px;float: left;color:#f0ffff;font-size:14px;";
                     $booking_id ="";
                     $html .= '<li data-booking-id="'.$booking_id.'" disabled><span class="booking-date-time-strip" style="'.$class.'">'.$time.'</span> </li>';
                     $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                     $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
                }
              
                
              }else{
                  //-------------no working hours-------------------  
                    $class = "width: 60px;height: 20px;float: left;font-size:14px;";
                     $booking_id ="";
                    $html .= '<li data-booking-id="'.$booking_id.'"><span class="booking-date-time-strip" style="'.$class.'" >'.$time.'</span> </li>';
                  
                  $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                 $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
              }
              
          }

           
           $date = date("d",strtotime($cal_date));
           $day = date("D",strtotime($cal_date));
           $mnth_year = date("M, Y",strtotime($cal_date));
           return Response::json(array('date' => $date, "day" => $day, "month_year" => $mnth_year, "html"=> $html,"option_html"=>$option_html,"option_html2"  => $option_html2,"dayoff" =>$working_hours->dayoff ));
    }

    function fetchBooking(Request $request){
     
        $ad_id = $request->query('ad_id');
        if(!empty($request->query('action')) && $request->query('action') == 'dayoff'){
          $offday = 'dayoff_'.$day;
          $metakey =  array();
          $qq = AdWorkingHours::where('ad_id', $ad_id)->where('dayoff',null)->get();
          if(count($qq) > 0){
            foreach($qq as $s){
               date("w", strtotime($s->working_date));
              $day = getDay(date("w", strtotime($s->working_date)));
              $metakey[] = date("Y-m-d", strtotime($s->working_date));
           
            }
            return Response::json(array('status'=>1, 'weekoffdays' => $metakey));
          }else{
             return  Response::json(array('status' => 0));
          }

      }
        if(!empty($request->query('action')) && $request->query('action') == 'delete'){
              $res = BookingSlots::findOrFail($ad_id);
              $res->delete();
              return;
        }
        $userAD = UserAdvertisement::where("id", $ad_id)->first();

        if(!empty($request->query('action')) &&  $request->query('action') == 'dayrender'){
         // $day = strtolower(date('l', $request->query('day')));
           $offday = 'dayoff_'.$day;
          $metakey =  array();
          $qq = AdWorkingHours::where('ad_id', $ad_id)->where('dayoff','yes')->get();
          if(count($qq) > 0){
            foreach($qq as $s){
               date("w", strtotime($s->working_date));
              $day = getDay(date("w", strtotime($s->working_date)));
              $metakey[] = date("Y-m-d", strtotime($s->working_date));
             // $metaday[date("Y-m-d")] = date("Y-m-d");

            }
            return Response::json(array('status'=>1, 'weekoffdays' => $metakey));
          }else{
             return  Response::json(array('status' => 0));
          }
        }
       $todaydate =  date("Y-m-d");
       // $res = BookingSlots::where('ad_id', $ad_id)->get();
         $query1 = "select * from tbl_booking_slots where ad_id='".$ad_id."' and  booking_date >='".$todaydate."'";
        $res = DB::select($query1);
//========================================================
        //  if((int)$ad_id > 0){
        //   $booking_res= BookingSlots::where('ad_id', $ad_id)->where('booking_date', $start_date)->get();
        // } 
        //   $booked_time = array();
        //   //print_r($res); die;
        //   $interval1 = 1800;
//==============================================================  
    if((int)$userAD->agency_id == 0 && (int)$userAD->club_id == 0){ 
        $todaysss = strtotime(date("Y-m-d"));
        $query = "select * from tbl_ads_touring where ad_id='".$ad_id."' and (".$todaysss." between from_date and to_date or from_date >= '".$todaysss."')";


        $touring = DB::select($query);
      }
        $data = array();
        if(count($res) > 0){
            foreach($res as $r){
              $booking_start = strtotime($r->booking_date.' '.$r->booking_start_time);
              $booking_end = strtotime($r->booking_date.' '.$r->booking_end_time);
              $day = strtolower(date("l", $r->booking_date));

              
             
                $data[] = array(
                    'id' => $r->id,
                    'title' => $r->booking_title,
                    'start' =>$r->booking_date,
                    'end'=>$r->booking_date,
                    'slot_type' => $r->booking_slot_type,
                    'service_type' => $r->service_type,
                    'client_name' => $r->client_name,
                    'imageurl'=>''
                );
            }
        }
         $data1  =array();
        if(count($touring)){
          foreach($touring as $tt){
             $data1[] = array(
                    'id' => $tt->id,
                    'title' => strtoupper(getCity($tt->city_id)),
                    'start' =>  date('Y-m-d', $tt->from_date),
                    'end'=> date('Y-m-d', $tt->to_date),
                    'slot_type' =>'Touring',
                    'service_type' =>'',
                    'client_name' => '',
                    'imageurl'=>asset('frontend/images/aeroplane-icon.png')

                );
          }
        }

    

       $newdata =  array_merge($data, $data1);
      return json_encode($newdata);
    }




    function fetchBookingData(Request $request){
    
        $data = $request->all();
        $ad_id = $data['ad_id'];
        $booking_id = $data['booking_id'];
        $start_date =  $data['start_date'];
        $formtype = $data['formtype'];
        $interval1 = 900;
        if((int)$ad_id > 0){
          $res= BookingSlots::where('ad_id', $ad_id)->where('booking_date', $start_date)->get();
        }

        $day = strtolower(date('l', strtotime($data['start_date'])));
        $offday = 'dayoff_'.$day;

      

        $color = array();
        $start_time = array();
                $booking_ids = array(); 
        $booking_titles = array(); 
        $booking_slot = array();
        $frontend_title = array();
        $booking_slot_type = array();
    // ==============================================================
        foreach($res as $result){
        $booking_start_time = $result->booking_start_time;
        $booking_end_time = $result->booking_end_time;

          for ($i = $booking_start_time; $i <= $booking_end_time; $i += $interval1){
               $start_time[] = date('h:i A', $i);
               

              if($result->booking_slot_type == 'Available'){
                $color[date('h:i A', $i)] = 'width: 60px;float: left;height: 20px; color: green !important;font-size: 14px;';

                $booking_ids[date('h:i A', $i)] = $result->id;
                 $frontend_title[date('h:i A', $i)] ="Start Time: ".date("h:i A",$result->booking_start_time)." End Time: ".date("h:i A",$result->booking_end_time);
                  $booking_slot[date('h:i A', $i)] = $result->booking_slot_type;
                  $booking_slot_type[date('h:i A', $i)] = $result->booking_slot_type;
              }
              if($result->booking_slot_type == 'Booked'){
                $color[date('h:i A', $i)] = 'background: red;width: 60px;height: 20px;float: left; color: #f0ffff; font-size:14px';

                 $booking_ids[date('h:i A', $i)] = $result->id;
                  $frontend_title[date('h:i A', $i)] ="Start Time: ".date("h:i A",$result->booking_start_time)." End Time: ".date("h:i A",$result->booking_end_time);
                $title = $result->booking_client_name.' - '.$result->booking_services;
                 $booking_title[date('h:i A', $i)] =strlen($title) > 32?substr($title, 0,32).'...':$title;
                  $booking_slot[date('h:i A', $i)] = $result->booking_slot_type;
                  $booking_slot_type[date('h:i A', $i)] = $result->booking_slot_type;
               }
              if($result->booking_slot_type == 'Break Time'){
                $color[date('h:i A', $i)] = 'background: #9c70ff;width: 60px;height: 20px;float: left;color: #f0ffff; font-size:14px;';
                //'background: #9c70ff;width: 30px;height: 20px;float: left;'; 


                $booking_ids[date('h:i A', $i)] = $result->id;
                //  $booking_titles[date('h:i A', $i)] =date('h:i A', $result->booking_start_time) ." to ".  date('h:i A', $result->booking_end_time);
                  $booking_slot[date('h:i A', $i)] = $result->booking_slot_type;    
                   $frontend_title[date('h:i A', $i)] = "Start Time: ".date("h:i A",$result->booking_start_time)." End Time: ".date("h:i A",$result->booking_end_time);
                   $booking_slot_type[date('h:i A', $i)] = $result->booking_slot_type;
              }
             if($result->booking_slot_type == 'Day Off'){
                $color[date('h:i A', $i)] = 'background: #ffff;width: 60px;height: 20px;float: left;color: #f0ffff; font-size:14px;'; 
                $booking_ids[date('h:i A', $i)] = $result->id;             
              }
            }
          
        }

// ==============================================================
        $working_hours = AdWorkingHours::where('ad_id', $ad_id)->where('working_date', $start_date)->first();
        

          $times = get_calendar_times();
        
          

         $html="";
         $option_html = "";
         $option_html2="";
         $newbookingids = array();
         $lastBookingId ="";
         $bookingTitleCount = 1;
         
          foreach($times  as $time){
             
              if(count($working_hours) > 0){
              if(empty($working_hours->dayoff)){

              $caltime = strtotime(date("h:i A",strtotime($time)));
                
                $working_start_time =  strtotime(date('h:i A', $working_hours->working_start_time));


               
              $working_end_time = strtotime(date('h:i A', $working_hours->working_end_time));
               
                if($caltime >= $working_start_time && $caltime <= $working_end_time){
                 $booking_id = $booking_ids[$time];
                 
                  if(in_array($time, $start_time)){
                      $class=  $color[$time];
                      
                       $disabled = "disabled";
                       
                         $booking_title = $booking_titles[$time];
                       
                 
                       $booking_slot = $booking_slot[$time];

                       if(!empty($booking_title)){
                        if($formtype == "backend"){
                         
                          if(!in_array($booking_id, $newbookingids)){
                            if($booking_title != 'Break Time' && $booking_slot != 'Break Time'){
                                $html .= '<li data-booking-id="'.$booking_id.'" class="booked-slot"><span class="booking-date-time-strip" style="'.$class.';border-top: 1px solid #fff;">'.$time.'</span> <div class="slot-title"> View -&nbsp;'.$booking_title.'</div><button data-id="'.$booking_id.'" class="cancel-booking-btn" onclick="deleteBookingSlot(\''.$booking_id.'\')" title ="Cancel Booking">X</button></li>';
                            }else{
                              $html .= '<li data-booking-id="'.$booking_id.'" class="booked-slot"><span class="booking-date-time-strip" style="'.$class.'">'.$time.'</span> <div class="slot-title">'.$booking_title.'</div></li>';
                            }
                          }else{

                            $html .= '<li data-booking-id="'.$booking_id.'" class="booked-slot"><span class="booking-date-time-strip" style="'.$class.'" >'.$time.'</span> </li>';
                          }
                         $newbookingids[] = $booking_id;
                         
                        }else{
                        	
                        	$ftitle = $frontend_title[$time];
                        	$fhead = $booking_slot_type[$time];
                           $html .= '<li data-booking-id="'.$booking_id.'" ><span class="booking-date-time-strip" id="color-strip" style="'.$class.'">'.$time.'</span> </li>';
                        }
                        
                        
                       }else{
                        $CancelBookingBuuton ="";
                        $borderTop = '';
                       	if($formtype == "backend"){
                          if($lastBookingId != $booking_id){
                            if($bookingTitleCount == 1){
                              $fetch_booking_title = DB::table('booking_slots')->where('id',$booking_id)->first();
                                if(!empty($fetch_booking_title->booking_client_name) && $fetch_booking_title->booking_slot_type == "Booked" ){
                                  $ViewText = 'View - &nbsp;';
                                $booking_title = $fetch_booking_title->booking_client_name;
                                $CancelBookingBuuton ='<button data-id="'.$booking_id.'" class="cancel-booking-btn" onclick="deleteBookingSlot(\''.$booking_id.'\')" title ="Cancel Booking">X</button>';
                                $borderTop = ';border-top:1px solid #fff;';
                               }else{
                                 $ViewText = 'View - &nbsp;';
                                $booking_title = $fetch_booking_title->booking_slot_type;
                                $CancelBookingBuuton ='<button data-id="'.$booking_id.'" class="cancel-booking-btn" onclick="deleteBookingSlot(\''.$booking_id.'\')" title ="Cancel Booking">X</button>';
                                $borderTop = ';border-top:1px solid #fff;';
                               }
                              $bookingTitleCount++;

                              $lastBookingId = $booking_id;
                            }else{
                              $booking_title ="";
                               $ViewText = '';
                              $CancelBookingBuuton ="";
                              $borderTop = '';
                              $bookingTitleCount = 1;
                            }
                          }else{
                             $ViewText = '';
                            $booking_title ="";
                            $CancelBookingBuuton ="";
                            $borderTop = '';
                            $bookingTitleCount = 1;
                          }
                          
                          

                       	  $html .= '<li data-booking-id="'.$booking_id.'"><span class="booking-date-time-strip" style="'.$class.$borderTop.
                          '">'.$time.'</span><div class="slot-title">'.$ViewText.''.$booking_title.'</div> '.$CancelBookingBuuton.'</li>';
                       	}else{
                       		
                       	$ftitle = $frontend_title[$time];
                         $fhead = $booking_slot_type[$time];
                        $html .= '<li data-booking-id="'.$booking_id.'" ><span class="booking-date-time-strip" style="'.$class.'" id="color-strip">'.$time.'</span> 
                        </li>';
                       	}
                      

                         
                       }
                      
                  }else{
                     $disabled = "";
                    $class = "width: 60px;height: 20px;float: left; color: green !important; font-size:14px;";
                     $booking_id ="";
                      $html .= '<li data-booking-id="'.$booking_id.'"><span class="booking-date-time-strip" style="'.$class.'">'.$time.'</span> </li>';
                  }
                 // $html .= '<li data-booking-id="'.$booking_id.'">'.$time.' <span style="'.$class.'"> </span></li>';
                  $option_html .= "<option value=\"{$time}\" ".$disabled.">".$time."</option>";
                   if(date('h:i A', $working_hours->working_end_time) == $time){
                    $selected = 'selected';
                  }else{
                     $selected = '';
                  }
                  $option_html2 .= "<option value=\"{$time}\" ".$selected." ".$disabled.">".$time."</option>";
                  }
                    // echo date('h:i A', $working_hours->working_time);
                    // echo date('h:i A', $working_hours->working_end_time); die;
                }else{
                  //-------day off----------------

                  //echo 'dayoff'; die;
                  $class = "width: 60px;height: 20px;float: left;font-size:14px;";
                     $booking_id ="";
                     $html .= '<li data-booking-id="'.$booking_id.'" disabled><span class="booking-date-time-strip" style="'.$class.'" >'.$time.'</span> </li>';
                     $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                     $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
                }
              
                
              }else{
                  //-------------no working hours-------------------  
                    $class = "width: 60px;height: 20px;float: left; font-size:14px;";
                     $booking_id ="";
                    $html .= '<li data-booking-id="'.$booking_id.'"><span class="booking-date-time-strip" style="'.$class.'">'.$time.'</span> </li>';
                  
                  $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                 $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
              }
              
          }

           
           $date =  $sle_date = date("d",strtotime($start_date));
           $day = date("D",strtotime($start_date));
           $mnth_year = date("M, Y",strtotime($start_date));
           return Response::json(array('date' => $date, "day" => $day, "month_year" => $mnth_year, "html"=> $html,"option_html"=>$option_html,"option_html2"  => $option_html2,"dayoff" =>$working_hours->dayoff ));

    }

    function saveWorkingHours(Request $request){
      $data = $request->all();
      $working_date = $data['working_date'];
      $working_start_time = strtotime($data['working_start_time']);
      $working_end_time = strtotime($data['working_end_time']);
     
            
      $ad_id = $data['user_ad_id'];
      $dayoff = $data['day_off'];
      $working_hours = AdWorkingHours::where('ad_id', $ad_id)->where('working_date', $working_date)->first();

      if(count($working_hours) > 0){

        $working = AdWorkingHours::findOrFail($working_hours->id);
        if($dayoff == 'yes'){
          $working->working_start_time = NULL;
          $working->working_end_time = NULL;
          $working->dayoff = 'yes';
          $working->save();
        }else{
          $working->working_start_time = $working_start_time;
          $working->working_end_time = $working_end_time;
          $working->save();
        }
       
      }else{
        $working =new AdWorkingHours();
        if($dayoff == 'yes'){
          $working->ad_id = $ad_id;
          $working->working_date = $working_date;
          $working->working_start_time = NULL;
          $working->working_end_time = NULL;
          $working->dayoff = 'yes';
          $working->save();
        }else{
        $working->ad_id = $ad_id;
        $working->working_date = $working_date;
        $working->working_start_time = $working_start_time;
        $working->working_end_time = $working_end_time;
        $working->save();
        }
      }
        $times = get_calendar_times();

         $html="";

          foreach($times  as $time){
              if($dayoff == 'yes'){
                 $class = "background: #fff;width: 30px;height: 20px;float: right;";
                $html .= '<li data-booking-id="'.$booking_id.'">'.$time.' <span style="'.$class.'"> </span></li>';
                 $option_html .= "<option value=\"{$time}\">".$time."</option>";
              }else{
                $caltime = strtotime($time);
                if($caltime >= $working_start_time && $caltime <= $working_end_time){
                  $option_html .= "<option value=\"{$time}\">".$time."</option>";
                 $class = "background: green !important;width: 30px;height: 20px;float: left;font-size: 14px;";
                  $html .= '<li data-booking-id="'.$booking_id.'">'.$time.' <span style="'.$class.'"> </span></li>';
                }
              }
            }
           $date =  $sle_date = date("d",strtotime($working_date));
           $day = date("D",strtotime($working_date));
           $mnth_year = date("M, Y",strtotime($working_date));
           return Response::json(array('date' => $date, "day" => $day, "month_year" => $mnth_year, "html"=> $html));
    }

   function saveBookingNotes(Request $request){
            $ad_id = $request->input('user_ad_id');
          
            $name_regex = "/^[\pL\s]+$/u";
            $validator = Validator::make( $request->all(), [
            'title' => [ 'required', 'min:3' , 'max:255', 'regex:'.$name_regex],
                    ], [
                        'title.required' => 'Please enter title.',
                        'title.regex' => 'Enter only characters',
                    ]);
            if ($validator->fails()) {
                return json_encode( array( 'errors' => $validator->getMessageBag()->toArray() ) );
            }
        
            $bookingObj = new BookingNotes();
            $bookingObj->ad_id = $ad_id;
            $bookingObj->booking_title = $request->input('title');
            $bookingObj->booking_client_name = $request->input('client_name');
            $bookingObj->booking_service_type = $request->input('service_type');
            $bookingObj->services = $request->input('services');
            $bookingObj->booking_notes =  $request->input('booking_notes');
            $bookingObj->save();
   }
   function saveBookingSlots(Request $request){
     $ad_id = $request->input('user_ad_id');
            // if(empty($ad_id)){
            //     return Response::json( array( 'errors' => 'Something wrong please try after some time.' ) );
            // }
            $validator = Validator::make( $request->all(), [
            'calendar_date' => 'required',
            'calendar_end_time' => 'required',
            'calendar_start_time' => 'required',
            'slot_type' => 'required',
            'client_name' => 'required'
                    ], [
                        'calendar_date.required' => 'Please select date.',
                        'calendar_end_time.required' => 'Please select end time.',
                        'slot_type.required' => 'Please choose booking type.',
                        'calendar_start_time.required' => 'Please select start time.',
                        'client_name.required' => 'Please enter client Name.'
                    ]);
            if ($validator->fails()) {
                return json_encode( array( 'errors' => $validator->getMessageBag()->toArray() ) );
            }
        
            $cal_date =   date('Y-m-d', strtotime($request->input('calendar_date')));
            $end_time =   strtotime($request->input('calendar_end_time'));
            $start_time = strtotime($request->input('calendar_start_time'));
            $remainder =  json_encode($request->input("reminder"));//implode(',', $request->get('reminder'));


            $query = "SELECT * FROM `tbl_booking_slots` WHERE `booking_date` = '".$cal_date."' and ".$start_time." between `booking_start_time`  AND `booking_end_time` and ad_id='".$ad_id."'";
    
            $res = DB::select($query);


            if(count($res) > 0){
              if($res->booking_start_time == $start_time && $res->booking_end_time == $end_time ){
                $bookingObj = BookingSlots::findOrFail((int)$res->id);
                $bookingObj->ad_id = $ad_id;
                $bookingObj->booking_service_type = $request->input('service_type');
                $bookingObj->booking_slot_type = $request->input('slot_type');
                $bookingObj->booking_date = $cal_date;
                $bookingObj->booking_start_time = $start_time;
                $bookingObj->booking_end_time = $end_time;
                $bookingObj->reminder_set = $remainder;
                $bookingObj->save();
                return Response::json( array( 'errors' => 'Updated Successfully!!' ) );
              }
              $time_range = "Please select time range between ".date('H:i A', $res->booking_start_time).' and '.date('H:i A', $res->booking_end_time).' to update.';
              return Response::json( array( 'errors' => array('calendar_start_time'=> ['This slot is already booked.']) ) );
                //return Response::json( array( 'errors' => 'You can\'t book this slot. Its already booked.' ) );
            }

            $bookingObj = new BookingSlots();
            $bookingObj->ad_id = $ad_id;
            $bookingObj->booking_title = $request->input('title');
            $bookingObj->booking_client_name = $request->input('client_name');
            $bookingObj->booking_service_type = $request->input('service_type');
            $bookingObj->booking_slot_type = $request->input('slot_type');
            $bookingObj->booking_date = $cal_date;
            $bookingObj->booking_start_time = $start_time;
            $bookingObj->booking_end_time = $end_time;
            $bookingObj->reminder_set = $remainder;
            $bookingObj->save();
          
   }


//==========================================
  public function getTimeByDate(){
    $strt_date = trim($_POST['cal_date']);
    $ad_id = $_POST['ad_id'];
    $is_disabled = '';
     //str_replace("/","-",$start_date);
     $start_date = date("Y-m-d", strtotime(str_replace("/","-",$strt_date)));


   
    $working_hours = \App\Models\AdWorkingHours::where('ad_id', $ad_id)->where('working_date', $start_date)->first();
    
          $times = get_calendar_times();

         if((int)$ad_id > 0){
          $res= BookingSlots::where('ad_id', $ad_id)->where('booking_date', $start_date)->get();
        } 
          $booked_time = array();
          //print_r($times); die;
          $interval1 = 900;
          // ==========================
          //$booked_time = array();
    foreach($res as $result){
        $booking_start_time = $result->booking_start_time;
        $booking_end_time = $result->booking_end_time;
         
          for($i = $booking_start_time; $i <= $booking_end_time; $i += $interval1){
            //echo $i;
            // date('h:i A', $i);
           $booked_time[] = date('Y-m-d h:i A', $i);
              }
          }
        //echo '<pre>';  print_r($booked_time); die;
          // ==========================

         $html="";
         $option_html = "";
          $option_html2 ="<option value=''>Select End Time</option>";
          foreach($times  as $time){
              if(count($working_hours) > 0){
              if(empty($working_hours->dayoff)){
                $newDateTIme = $start_date." ".$time;
                 $caltime = strtotime(date("Y-m-d h:i A",strtotime($newDateTIme)));
                //  echo $caltime = strtotime(date("h:i A",1582750800));
                // echo ">>>".$caltime; 
                // echo ">> <<".$time; 
                $working_start_time =  strtotime(date('Y-m-d h:i A', $working_hours->working_start_time));
               
              $working_end_time = strtotime(date('Y-m-d h:i A', $working_hours->working_end_time));
              //DB::connection()->enableQueryLog();
                $booking_slots = BookingSlots::where('ad_id', $ad_id)->where('booking_date',  $start_date)->where("booking_start_time", $caltime)->get();

                if($caltime >= $working_start_time && $caltime <= $working_end_time){
                  //---------------------------------

                  if(count($booked_time)>0){
                    $ctime = date("Y-m-d h:i A",strtotime($time));
                    //echo '<pre>'; print_r($booked_time);

                        if(in_array($ctime,$booked_time)){
                              $is_disabled = 'disabled';
                        }else{
                          $is_disabled = '';
                        }

                  }
                 // echo '<pre>'; print_r($booked_time);
                 //--------------------------------- 
                  if(in_array($time, $start_time)){
                      $class =  $color[$time];
                      $booking_id = $booking_ids[$time];
                 
                  }else{
                    $class = "background: green !important;width: 30px;height: 20px;float: left;font-size: 14px;";
                     $booking_id ="";
                 
                  }
                  
                 // echo $working_hours->working_end_time."@@".$caltime;
                  if(date('Y-m-d h:i A', $working_hours->working_end_time) == $time){
                    $selected = 'selected';
                  }else{
                     $selected = '';
                  }
                  

                 // $html .= '<li data-booking-id="'.$booking_id.'">'.$time.' <span style="'.$class.'"> </span></li>';
                  $option_html .= "<option value=\"{$time}\" ".$is_disabled.">".$time."</option>";
                   $option_html2 .= "<option  value=\"{$time}\" ".$selected." ".$is_disabled.">".$time."</option>";
                  }

                }else{
                  $class = "background: white;width: 30px;height: 20px;float: left;";
                     $booking_id ="";
                
                     $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                     $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
                   //echo "DEay off"; die;
                }
              
                
              }else{
                  $class = "background: white;width: 30px;height: 20px;float: left;";
                     $booking_id ="";
                
                     $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                     $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
                   // echo "Nor  wrking hrs Day off"; die;
              }
            }

           
           $date =  $sle_date = date("d",strtotime($start_date));
           $day = date("D",strtotime($start_date));
           $mnth_year = date("M, Y",strtotime($start_date));
           return Response::json(array('date' => $date, "day" => $day, "month_year" => $mnth_year,"option_html"=>$option_html, "option_html2"=>$option_html2));
//---------------------------------------
  }
//==========================================  
 function fetchBookingDetails(Request $request){
    $data =  $request->all();
    $booking_id = $data['booking_id'];
     $bookingRecords = array();
     $interval1 = 900;

    if(!empty($booking_id)){
             $bookingData = BookingSlots::where('id', $booking_id)->get();

             if(count($bookingData) > 0){
              foreach($bookingData as $bd){
                $bookingRecords['booking_length'] = $bd->booking_title; 
                $bookingRecords['client_name'] = $bd->booking_client_name; 
                $bookingRecords['ad_id'] = $bd->ad_id; 
                $bookingRecords['booking_slot_type'] = $bd->booking_slot_type;
                $bookingRecords['booking_service_type'] = $bd->booking_service_type;
                $bookingRecords['booking_services'] = $bd->booking_services;
                $bookingRecords['booking_ex_services'] = $bd->booking_ex_services;
                $bookingRecords['booking_notes'] = $bd->booking_notes;
                $bookingRecords['date'] = date("d/m/Y",strtotime($bd->booking_date));
                $bookingRecords['booking_start_time'] = date("h:i A",$bd->booking_start_time);
                $bookingRecords['booking_end_time'] = date("h:i A",$bd->booking_end_time);
                $bookingRecords['reminder_set'] = $db->reminder_set;
              }
             }

           

             $ad_id = $bookingData[0]->ad_id;
             $booking_date = $bookingData[0]->booking_date;
             DB::enableQueryLog();

             $res = BookingSlots::where('ad_id', $ad_id)->where('id', '!=', $booking_id)->where('booking_date', $booking_date)->get();
              $ss = DB::getQueryLog();
             
            
       $is_disabled = array();
       $start_time = array();
       //================================================================
       //================================================================
        foreach($res as $result){
        $booking_start_time = $result->booking_start_time;
        $booking_end_time = $result->booking_end_time;
    
  
          for($i = $booking_start_time; $i <= $booking_end_time; $i += $interval1){
               $start_time[] = date('h:i A', $i);
               
              if($result->booking_slot_type == 'Booked'){
               
                $is_disabled[date('h:i A', $i)] = 'yes';
                
               }

              if($result->booking_slot_type == 'Break Time'){
                 $is_disabled[date('h:i A', $i)] ='yes';
              }
             
            }
        }


// ==============================================================
        $working_hours = AdWorkingHours::where('ad_id', $ad_id)->where('working_date', $booking_date)->first();
        $disble  = array();
        
    $times = get_calendar_times();
        
         $html="";
         $option_html = "";
         $option_html2= "";

          foreach($times  as $time){
              if(count($working_hours) > 0){
              if(empty($working_hours->dayoff)){

                //$disble[] = 0;
                $caltime = strtotime(date("h:i A",strtotime($time)));
                $working_start_time =  strtotime(date('h:i A', $working_hours->working_start_time));

                $working_end_time = strtotime(date('h:i A', $working_hours->working_end_time));
                if($caltime >= $working_start_time && $caltime <= $working_end_time){

               // echo '<pre>';  print_r( $start_time); die;
                 
                if(in_array($time, $start_time)){
                    $class=  $color[$time];
                    $booking_id = $booking_ids[$time];
                    $is_dis = $is_disabled[$time];
                    
                  }else{
                    $class=  $color[$time];
                    $booking_id = $booking_ids[$time];
                    $is_dis = 'no';

                  }
                  

                if($is_dis == 'yes'){
                    $disabled = 'disabled';
                    $disble[] = $time;
                  }else{
                    $disabled = '';
                    $disble[] = 'enabled';
                  }
                 

                // echo $working_hours->working_end_time."@@".$caltime;
                  if($time == date("h:i A",$bookingData[0]->booking_start_time)){
                    $selected = 'selected';
                  }else{
                     $selected = '';
                  }
            
                  $option_html .= "<option value=\"{$time}\" ".$selected." ".$disabled.">".$time."</option>";
                   if($time == date("h:i A",$bookingData[0]->booking_end_time)){
                    $selected = 'selected';
                  }else{
                     $selected = '';
                  }
                  $option_html2 .= "<option value=\"{$time}\" ".$selected." ".$disabled.">".$time."</option>";
                  }
                }else{
                  //-------day off----------------

                     $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                     $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
                }
              
                
              }else{
                  //-------------no working hours-------------------  
                 // echo "-no working hours-"; die;
                  
                  $option_html .= "<option value=\"{$time}\" disabled>".$time."</option>";
                 $option_html2 .= "<option value=\"{$time}\" disabled>".$time."</option>";
              }
          }
      //=======================================================================
      //=========================================================================
          }



          // $bk_start_time =  date("h:i A",$bookingData[0]->booking_start_time);
          // $bk_end_time = date("h:i A",$bookingData[0]->booking_end_time);
        // echo '<pre>'; print_r($disble); die;
          return Response::json(array('records' =>  $bookingRecords,'option_html'=>$option_html,'option_html2'=>$option_html2, 'start_time'=>$bk_start_time, 'end_time' => $bk_end_time,"dayoff" =>$working_hours->dayoff));
    }

    function checkworkinghours(Request $request){ 
     $ad_id = $request->post('ad_id');
     $current_working_date =$request->post('working_date');
     $date = strtotime(date("Y-m-d h:i a"));
    
     $working_details= DB::table('ad_working_hours')->where('ad_id',$ad_id)->where('working_date',$current_working_date)->first();

     $ad_expiry_date = DB::table('user_advertisement')->where('id', $ad_id)->whereNotNull('plan_purchased')->whereNotNull('plan_expired')->first();
 //print_r($ad_expiry_date);
     if($ad_expiry_date->ad_status == 0 ) {
    return Response::json( array( 'ad_hidden' => 'Ad is hidden.' ) );
  }else{
     if($working_details->dayoff == 'yes' && $ad_expiry_date->plan_expired >= $date){
      return Response::json( array( 'dayoff' =>'Today is day off'));

      }else if($working_details->dayoff == 'yes' && $ad_expiry_date->plan_expired < $date){
      return Response::json( array( 'expired' =>'Your ad is expired now.'));

      }else if($ad_expiry_date->plan_expired < $date){
      return Response::json( array( 'expired' =>'Your ad is expired now.'));

      }else if(count($working_details) > 0 && $working_details->dayoff !== 'yes' && $ad_expiry_date->plan_expired >= $date ){
     
        return Response::json( array( 'success' =>'working hours exist'));  
      }else{
      return Response::json( array( 'errors' =>'Working hour not exists'));  

    }
  }
}

public function cancelBooking(Request $request){
  $booking_id = $request->booking_id;

  $bookingObj = BookingSlots::findOrFail((int)$booking_id)->delete();
  
  return "true";


}

public function getAllBookingSlotData(Request $request){
  $ad_id = $request->ad_id;
  $bookingDate = date('Y-m-d',strtotime($request->bookingDate));
  $starttime = strtotime( $bookingDate." ".$request->starttime);
   $endtime = strtotime( $bookingDate." ".$request->endtime);
   
   
   $booking_data = BookingSlots::where('ad_id',$ad_id)->where('booking_date',$bookingDate)->where('booking_start_time','>=',$starttime)->where('booking_end_time','<=',$endtime)->get();

   if(count($booking_data)>0){
    return "0";
   }else{
    return "1";
   }




}
    
}
