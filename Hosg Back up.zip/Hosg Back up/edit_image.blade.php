   <img id="imagepreview" src="{{$url}}" style="width: 100%">
<script type="text/javascript">

  //var ulsr = "{{$url}}";
  jQuery(function($) {
    //var jcp;
      //Jcrop.load('target').then(img => {
        jcp = Jcrop.attach('imagepreview');
        jcp.listen('crop.update',function(widget,e){
          const pos = widget.pos;
          //console.log(pos);
          imageSalectionValue.x1 = pos.x;
          imageSalectionValue.y1 = pos.y;
          imageSalectionValue.x2 = pos.w + pos.x;
          imageSalectionValue.y2 = pos.h + pos.y;
          imageSalectionValue.width = pos.w;
          imageSalectionValue.height = pos.h;
          var ow= document.getElementById("imagepreview").offsetWidth;
          var oh=document.getElementById("imagepreview").offsetHeight;
          visible_width=ow ;
          //console.log(imageSalectionValue);
       visible_height=oh;
       naturalWidth = document.getElementById("imagepreview").naturalWidth;
       naturalHeight = document.getElementById("imagepreview").naturalHeight;
          //console.log(pos.x,pos.y,pos.w,pos.h);
        });

       
        const rect = Jcrop.Rect.fromPoints([0,0],[600,600]);
        //Jcrop.Rect.fromPoints([100,100],[200,200]);
        jcp.newWidget(rect,{ minSize: [600,600] });

        // jcp.setOptions({ minSize: [ 200, 200 ] });
        jcp.focus();
         /*jcp.active.setOptions({ minSize: [200,200] });
          jcp.focus();*/
        

     // });

    /*$('#target').Jcrop({
            onSelect: showCoords,
            onChange: showCoords
        });*/


    
      //imageSalectionValue = {x1 : imgx, y1 : imgy, x2 : imgwid, y2: imghei}
  });
   function showCoords(c)
  {
      console.log(c);
  };
</script>



