<div class="container container-Mobile">
<div class="content_block services-step-section step_3" style="display:none;">
     <form method="post" action="{{route('individualad.saveservices')}}" id="form_step_3" onsubmit="return false;">
          {{ csrf_field() }}
          @if($is_draft)
                      <input type="hidden" name="user_ad_id" value="{{!empty($listdata['adId'])? $listdata['adId'] : ''}}">
                      <input type="hidden" name="user_draft_id" value="{{!empty($listdata['parent_id'])?$listdata['parent_id'] : ''}}">
                    @else
                      <input type="hidden" name="user_ad_id" class="ad_user_id" value="{{!empty($user_ad_id)? $user_ad_id : ''}}">
                       <input type="hidden" name="user_draft_id" class="ad_draft_id" value="">
                    @endif          
          <h2 class="text-danger">Services</h2>
          <div class="contact-box personal-radiobutton-box pink-label available-block">
               <h4>Available for<sup>*</sup></h4>
               @php
                        if(!empty($listdata['metaData']['service-avail-for'])){
                                if(!is_array($listdata['metaData']['service-avail-for'])){
                                    $service_avail_array = (array)$listdata['metaData']['service-avail-for'];
                                }else{
                                    $service_avail_array = $listdata['metaData']['service-avail-for'];
                                }
                        }
                        @endphp
               @foreach($serviceavailablefor as $saf)
               
               <div class="radio radio-info form-check-inlinesquarebox">
                    <input type="checkbox" onchange="autosave3()" value="{{$saf['id']}}" 
                    {{!empty($service_avail_array) && in_array($saf['id'], $service_avail_array) ? 'checked':''}}
                    name="service-avail-for[]" id="service-avail-for{{$saf['id']}}"
                         class="css-checkbox" />
                    <label for="service-avail-for{{$saf['id']}}" class="css-label">{{$saf['value']}}</label>
                     <span class="help-block hidden service-avail-for_error"></span>
               </div>
               @endforeach

               <div class="clearfix"></div>
               <div id="service-avail-for-error2"></div>

          </div>
          <div class="contact-box personal-radiobutton-box pink-label">
               <h4>Place of service<sup>*</sup></h4>
               @php
                        if(!empty($listdata['metaData']['service-type'])){
                                if(!is_array($listdata['metaData']['service-type'])){
                                    $service_type_array = (array)$listdata['metaData']['service-type'];
                                }else{
                                    $service_type_array = $listdata['metaData']['service-type'];
                                }
                        }
                        @endphp
               @foreach($servicetype as $st)

               <div class="radio radio-info form-check-inlinesquarebox">
              
                    <input type="checkbox" onchange="autosave3()" value="{{$st['id']}}"  name="service-type[]"
                    {{!empty($service_type_array) && in_array($st['id'], $service_type_array) ? 'checked':''}}
                     id="service-type{{$st['id']}}" class="css-checkbox" />
                    <label for="service-type{{$st['id']}}" class="css-label">{{$st['value']}}</label>
               </div>

               @endforeach

               <span class="help-block hidden service-type_error"></span>
               <div class="clearfix"></div>
               <div id="service-type-error2"></div>



          </div>
          <div class="services_select_box contact-box personal-radiobutton-box pink-label working_hours_box myfees-field">
     <h4>My Fee & Services</h4>
    
        @if(count($listdata['rate']) > 0)
        @php $listcount = 0; @endphp
        @foreach($listdata['rate'] as $r)
 <div class="add-userroles services_rates" id="test{{$r->id}}">
          <div class="rates_section">
               <div class="drop_box services_select_box">
                @if($listcount == 0)
               <h6 class="labelwhite">Time<sup>*</sup></h6>
               @endif
                    <select id="services_rates_{{$listcount}}" class="service_select_box service_time"
                         name="service[{{$listcount}}][service_time]">
                         @php
                         $rates_time = get_rate_time();
                         @endphp
                         @foreach($rates_time as $key=>$t)
                         <option value="{{$key}}" {{$key == $r->ad_time ? 'selected' : ''}}>{{ $t }}</option>
                         @endforeach
                    </select>

                     <span class="help-block hidden service_time_error"></span>
               </div>
               <div class="charges_box">
                 @if($listcount == 0)
               <h6 class="labelwhite">In Call </h6>
               @endif
                    <input type="number" name="service[{{$listcount}}][service_incall_charge]"
                         class="form-control service_incall_charge" placeholder="Charges" value="{{$r->incall_charge}}" min="1">

                         <span class="help-block hidden service_incall_charge_error"></span>
               </div>
               <div class="charges_box">
                 @if($listcount == 0)
               <h6 class="labelwhite">Out Call </h6>
               @endif
                    <input type="number" name="service[{{$listcount}}][service_outcall_charge]"
                         class="form-control service_outcall_charge" placeholder="Charges"  value="{{$r->outcall_charge}}"  min="1">
                         <span class="help-block hidden service_outcall_charge_error"></span>
               </div>
               <div class="service_box" data-toggle="modal" data-target="#serviceIncluded-popup" data-backdrop="static">
                 @if($listcount == 0)
                    <h6 class="labelwhite">Service Included <sup>*</sup></h6>
                    @endif
          @if(!empty($r->ad_services))
          @php 
          $services="";
          $servicesarraylist = explode(",", $r->ad_services);
          @endphp
          @foreach($servicesarraylist as $adsr)
          @php
          $services .= ",".getServiceName($adsr);
          @endphp
        
          @endforeach
          @endif
          <input type="text" id="service_name{{$listcount}}"
                         class="form-control service_name_hidden service_name" placeholder="Choose Services" onclick="setId(this.id)" 
                         value="{{!empty($services) ?trim($services, ','):'' }}">

          <input type="hidden" name="service[{{$listcount}}][service_name]"
                         class="form-control service_name_hidden" id="service_name_hidden{{$listcount}}"  value="{{!empty($r->ad_services) ? $r->ad_services :'' }}">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
               </div>
       
        <!-- ============================================= -->
               <div class="button_box my-feesbtn"> 
                    <a href="javascript:void(0)" class="servicefee-btn-add add-rate"
                         onclick="addRate()"><i class="fa fa-plus"></i></a>
                              @php
                              if($listcount > 0){
                              $style = 'display:inline-block';
                              }else{
                              $style = 'display:none';
                              }
                              @endphp
                                   <a  style="{{$style}}" href="javascript:void(0)" class="servicefee-btn-remove remove-rate"  onclick="removeRate()"><i
                              class="fa fa-minus"></i></a>
                     
         </div>
       </div>
     </div>
        @php $listcount++; @endphp

        @endforeach
      @else
     <div class="add-userroles services_rates" id="test">
          <div class="rates_section">
               <div class="drop_box services_select_box">
               <h6 class="labelwhite">Time<sup>*</sup></h6>
                    <select id="services_rates_0" class="service_select_box service_time"
                         name="service[0][service_time]">
                         @php
                         $rates_time = get_rate_time();
                         @endphp
                         @foreach($rates_time as $key=>$t)
                         @if($t == '1 Hour')
                         <option value="{{$key}}" selected="selected">{{ $t }}</option>
                         @else
                          <option value="{{$key}}" >{{ $t }}</option>
                         @endif


                         @endforeach
                    </select>
               </div>
               <div class="charges_box">
               <h6 class="labelwhite">In Call</h6>
                    <input type="number" name="service[0][service_incall_charge]"
                         class="form-control service_incall_charge" placeholder="Charges"  min="1">
               </div>
               <div class="charges_box">
               <h6 class="labelwhite">Out Call</h6>
                    <input type="number" name="service[0][service_outcall_charge]"
                          class="form-control service_outcall_charge" placeholder="Charges"  min="1">
               </div>
               <div class="service_box" data-toggle="modal" data-target="#serviceIncluded-popup" data-backdrop="static">
                    <h6 class="labelwhite">Service Included <sup>*</sup></h6>
          
          <input type="text" id="service_name0"
                         class="form-control service_name_hidden service_name" placeholder="Choose Services" onclick="setId(this.id)">

          <input type="hidden" name="service[0][service_name]"
                         class="form-control service_name_hidden" id="service_name_hidden0" >
                         <span class="help-block hidden service_name_error"></span>
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            </div>

               <div class="button_box my-feesbtn"> 
                    <a href="javascript:void(0)" class="servicefee-btn-add add-rate"
                         onclick="addRate()"><i class="fa fa-plus"></i></a>

                   {{--  <a href="javascript:void(0)" class="servicefee-btn-remove remove-rate" onclick="removeRate()"><i
                              class="fa fa-minus"></i></a></div> --}}
          </div>
     </div>
     @endif
     <div id="tool-placeholder"></div>
</div>
    
      
      <div class="contact-box personal-radiobutton-box pink-label">
                  <h4>Extra Service Fee</h4>
                  @if(count($listdata['extraService']) > 0)
                    @php $excount = 0; @endphp
                  @foreach($listdata['extraService'] as $lex)
                     <div class="add-userroles extraservice_fee">
                    <div class="rates_section">
                      <div class="drop_box">                        
                       <input type="number" class="form-control extraservice_price" name="extra_services[{{$excount}}][price]" placeholder="Price"  value="{{$lex->ad_fee}}"  min="1">
                      </div>
                      @if(!empty($lex->ad_services))
                      @php 
                      $exservices="";
                      $exservicesarraylist = explode(",", $lex->ad_services);
                      @endphp
                      @foreach($exservicesarraylist as $adsr)
                      @php
                      $exservices .= ",".getServiceName($adsr);
                      @endphp

                      @endforeach
                      @endif
                      <div class="service_box" data-toggle="modal" data-target="#extraserviceIncluded-popup" data-backdrop="static">
                         <!--<h6 class="labelwhite">Service Included <sup>*</sup></h6>-->
          
          <input type="text" id="extra_service_name{{$excount}}"
                         class="form-control extra_service_name" value="{{!empty($exservices) ?trim($exservices, ','):'' }}" placeholder="Choose Services" onclick="setExtraId(this.id)">

          <input type="hidden" name="extra_services[{{$excount}}][service_name]"
                         class="form-control extra_service_name_hidden" id="extra_service_name_hidden{{$excount}}" value="{{!empty($lex->ad_services) ? $lex->ad_services :'' }}">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
            
                      
                    </div>
                    
                      <div class="button_box my-feesbtn">
                         <a href="javascript:void(0)" class="servicefee-btn-add" onclick="addServiceFee()"><i class="fa fa-plus"></i></a>
                       
                      <a href="javascript:void(0)" style="{{$excount > 0? 'display:inline-block':'display:none'}}" class="servicefee-btn-remove remove-service-rate" onclick="removeServiceFee()"><i class="fa fa-minus"></i></a>
                      
                      </div>
                    </div>
                   
                  </div>
                    @php $excount++; @endphp
                  @endforeach
                  @else
                  <div class="add-userroles extraservice_fee">
                    <div class="rates_section">
                      <div class="drop_box">                        
                       <input type="number" class="form-control extraservice_price" name="extra_services[0][price]" placeholder="Price"  min="1">
                      </div>
                          
                      <div class="service_box" data-toggle="modal" data-target="#extraserviceIncluded-popup" data-backdrop="static">
                         <!--<h6 class="labelwhite">Service Included <sup>*</sup></h6>-->
          
                  <input type="text" id="extra_service_name0"
                         class="form-control extra_service_name" placeholder="Choose Services" onclick="setExtraId(this.id)">

                 <input type="hidden" name="extra_services[0][service_name]"
                         class="form-control extra_service_name_hidden" id="extra_service_name_hidden0">
                      <!-- <input type="text" class="form-control" placeholder="Services"> -->
                  </div>
                    
                      <div class="button_box my-feesbtn">
                         <a href="javascript:void(0)" class="servicefee-btn-add" onclick="addServiceFee()"><i class="fa fa-plus"></i></a>
                      
                      <a href="javascript:void(0)" class="servicefee-btn-remove remove-service-rate" onclick="removeServiceFee()"><i class="fa fa-minus"></i></a></div>
                    </div>
                   
                  </div>
                  @endif
                  <div id="service-placeholder"></div>
          
          <div class="clearfix"></div>
          
           <div class="personal-radiobutton-box pink-label extraservice_fee_textarea">
                    <div class="form-group">
                      <textarea class="form-control custom-textarea bg-theme-dark-form extraServiceTextarea" id="extraServiceTextarea" name="services_additional_information"  id="exampleFormControlTextarea1" rows="3" placeholder="Addtional Information">{{$listdata['metaData']['services_additional_information']}}</textarea>
                    </div>
                    
                    
                  </div>
                
                 
                </div>
               
      <div class="clearfix"></div>
{{--<!--  <div class="contact-box personal-radiobutton-box pink-label working_hours_box" id="WorkingHours">
               <h4>Working Hours</h4>
               <div class="working_hours">
                   
                   

                        @php
                        $count=1;
                       
                        @endphp
                         @for ( $i = $planstartday; $i <= $planendday; $i = $i + 86400 ) 
                          @if(date('M j Y', $i) >=  date("M j Y"))
                         <div class="dropcol_box">
                          @php
                          $ia = date('w', $i );
                          $colName = date('ymd',$i);
                          $working_hours = get_working_hours($user_ad_id, date('Y-m-d', $i ));
                          $working_start_time =!empty($working_hours->working_start_time) ? date("h:i A", $working_hours->working_start_time):'';
                           
                           $working_end_time = !empty($working_hours->working_end_time) ? date("h:i A", $working_hours->working_end_time):'';
                           $working_day_off = $working_hours->dayoff; 
                           $dateOfPlan = date("Y-m-d",$i);
                                             $currentDates = date("Y-m-d");

                                             $day_fields = getDay($ia);

                                             if($working_day_off == 'yes'){
                                             $class_start_day_time = 'disabled_start_day_time';
                                             $class_end_day_time = 'disabled_end_day_time';
                                             $disabled_class ='';
                                             $dayoffchecked = 'checked';
                                             //$plan_name = 'Current Plan';
                                           }elseif($count > $orderplan_duration){
                                            $class_start_day_time = 'disabled_start_day_time';
                                             $class_end_day_time = 'disabled_end_day_time';
                                             //$upcoming_plan_dayoff = 'upcoming_day_off';
                                            $disabled_class='';
                                            $dayoffchecked = 'checked';
                                            //$plan_name = 'Upcoming Plan';
                                       }else{
                                           $class_start_day_time = '';
                                             $class_end_day_time = '';
                                              //$upcoming_plan_dayoff = '';
                                              $disabled_class='';
                                            $dayoffchecked = '';
                                            //$plan_name = 'Current Plan';
                                         }

                                       
                          @endphp
                         
                              <div class="label-col">
                                <label>{{ getDay($ia) }}</label>
                              
                                <label class="workinghoures-datemonth">{{ date('M j Y', $i ) }}</label>
                                
                                
                              </div>
                               
                                                         
                              <div class="dropbox-col">
                                  <input type="hidden" name="working_hours[{{$count}}][working_date]" value="{{ date('Y-m-d', $i )}}">


                                   <div class="dropdown-col {{$class_start_day_time}} " id="starting_day_time{{$count}}" title="{{$plan_name}}">
                                
                                   
                                   
                                        <select id="{{ $colName }}_from" class="form-control "
                                             name="working_hours[{{$count}}][working_start_time]" {{$disabled_class}}>
                                             <option value="">From</option>
                                             @php
                                             
   
                                             if(strtotime($dateOfPlan) == strtotime($currentDates)){
                                             echo get_times2($working_start_time);
                                           }else{
                                             echo get_times($working_start_time); 
                                         }
                                          @endphp  
                                             
                                        </select>
        
                                   </div>

                                  
                                  
                                   <div class="dropdown-col {{$class_end_day_time}}" id="end_day_time{{$count}}" title="{{$plan_name}}">
                                        <select id="{{ $colName }}_to" class="form-control"
                                             name="working_hours[{{$count}}][working_end_time]" {{$disabled_class}} >
                                             <option value="">To</option>
                                              @php
                                             
   
                                             if(strtotime($dateOfPlan) == strtotime($currentDates)){
                                             echo get_times2($working_end_time);
                                           }else{
                                             echo get_times($working_end_time); 
                                         }
                                          @endphp
                                        </select>
                                   </div>
                                  
                   
                    <div class="working-hours-dayoff-block {{$upcoming_plan_dayoff}}" id="working-hours-dayoff-block{{$count}}" title="{{$plan_name}}">
                    <div class="radio radio-info form-check-inlinesquarebox">
                      
            <div class="dateclickform">
                     <input type="checkbox" name="working_hours[{{$count}}][working_dayoff]" id="dayoff{{$count}}" class="css-checkbox" {{$dayoffchecked}}  onchange="selectDayOff('{{$colName}}',{{$count}})" >
                          <label for="dayoff{{$count}}"  class="css-label" >Day OFF</label>
              </div>
                        </div> 
            </div>
            
                              </div>
                               
                    </div>
                   
                    @endif 
               @php
               $count++;
               @endphp
               @endfor
<style>
 
.disabled_start_day_time select{
       
        pointer-events: none;
     
}

.disabled_end_day_time select{
      
        pointer-events: none;
      
}
.upcoming_day_off input[type="checkbox"]{
      
        pointer-events: none;
      
}

.disabled_start_day_time{
        cursor: not-allowed;
        opacity:0.5;
}

.disabled_end_day_time{
        cursor: not-allowed;
        opacity:0.5;
        
}
.upcoming_day_off{
        cursor: not-allowed;
        opacity:0.5;     
}
</style>
<script type="text/javascript">
 

function selectDayOff(id, ids){
    
     if ($("#dayoff"+ids).prop("checked") == true) {
      //console.log($("#"+id+"_to").val());
      if($("#"+id+"_to").val() == '' && $("#"+id+"_from").val() == ''){
        $("#working-hours-dayoff-block"+ids).show();

        $('#starting_day_time'+ids).addClass("disabled_start_day_time");
          $('#end_day_time'+ids).addClass("disabled_end_day_time"); 

         $("#"+id+"_to").attr("disabled",true);
         $("#"+id+"_from").attr("disabled",true);


      }else{
        window.setTimeout(function(){
          $("#dayoff"+ids).trigger("click");
          $("#working-hours-dayoff-block"+ids).addClass('dayoff_on');
          alert("Please unselect start and end time.");
          console.log("#dayoff"+ids);
        },500);
        
      }
      
    }else if($("#dayoff"+ ids).prop("checked") == false){
     $("#working-hours-dayoff-block"+ids).show();
      $("#"+id+"_to").attr("disabled",false);
     $("#"+id+"_from").attr("disabled",false);
      $('#starting_day_time'+ids).removeClass("disabled_start_day_time");
      $('#end_day_time'+ids).removeClass("disabled_end_day_time"); 
        $("#working-hours-dayoff-block"+ids).removeClass('dayoff_on');
    } 
  
}

</script>         
         <div class="form-group mt-4">
                      <textarea class="form-control custom-textarea bg-theme-dark-form" id="exampleFormControlTextarea1" rows="3" name="working_additional_information" placeholder="Additional Information">{{$listdata['metaData']['working_additional_information']}}
                      </textarea>
                    </div>
          </div>

</div> --> --}}

<!-- new working code -->
      <!-- Working hours block start -->
 <div class="contact-box personal-radiobutton-box pink-label working_hours_box" id="WorkingHours">
              <h4>Working Hours<sup class="text-danger">*</sup></h4>
               <div class="workingupdate-btn">
                <img src="{{asset('frontend/images/handsign2.png')}}" alt="handsign" />
               <input type="submit" name="update_step_3" value="Update your working schedule" id="update_step_3_duplicate" class="NextBTN "></div>
               <div class="working_hours">
                @php
                if($is_draft){
              $getAllOrderData = getAllOrderData(Auth::user()->id,$listdata['parent_id']);
              $ad_id =$listdata['parent_id'];
                    }else{
              $getAllOrderData = getAllOrderData(Auth::user()->id,$user_ad_id);
              $ad_id =$user_ad_id;
 
                }
               
                

                $count=1;
                $countoreder = count($getAllOrderData);
                $newcountorrder = 0;
                
                
                @endphp
                @foreach($getAllOrderData as $allOrderData)
                @php
                if($newcountorrder == 0){
                  $current_plan_purchased_date = $allOrderData->plan_purchased;
                }else{
                  $current_plan_purchased_date = $allOrderData->plan_purchased+86400;
                }
                $ordate=strtotime($allOrderData->created_at);  
                $podate = date('d-m-Y', $ordate);
                $rounded_seconds = round($current_plan_purchased_date / (15 * 60)) * (15 * 60);
                $current_plan_expiry_date = $allOrderData->plan_expired;
                $newcountorrder++;
                @endphp
                @for ( $i = $current_plan_purchased_date; $i <= $current_plan_expiry_date; $i = $i + 86400 ) 
                          @if(date("Y-m-d",$i) >=  date("Y-m-d"))
                         <div class="dropcol_box">
                          @php
                          $ia = date('w', $i );
                          $colName = date('ymd',$i);
                          $working_hours = get_working_hours($ad_id, date('Y-m-d', $i ));
                          $working_start_time =!empty($working_hours->working_start_time) ? date("h:i A", $working_hours->working_start_time):'';
                           
                           $working_end_time = !empty($working_hours->working_end_time) ? date("h:i A", $working_hours->working_end_time):'';
                           $working_day_off = $working_hours->dayoff; 
                           
                           $dateOfPlan = date("Y-m-d",$i);
                                             $currentDates = date("Y-m-d");

                                             $day_fields = getDay($ia);

                                            if($upcoming_Order_Detail > 0){
                                            $class_start_day_time = 'disabled_start_day_time';
                                             $class_end_day_time = 'disabled_end_day_time';
                                             //$upcoming_plan_dayoff = 'upcoming_day_off';
                                            $disabled_class='disabled="disabled"';
                                            $dayoffchecked = '';
                                            $plan_name = 'Current Plan';
                                       }else{
                                           $class_start_day_time = '';
                                             $class_end_day_time = '';
                                              //$upcoming_plan_dayoff = '';
                                              $disabled_class='';
                                            $dayoffchecked = '';
                                            $plan_name = 'Current Plan';
                                         }
                                         if($working_day_off == 'yes'){
                                             $class_start_day_time = 'disabled_start_day_time';
                                             $class_end_day_time = 'disabled_end_day_time';
                                             $disabled_class ='disabled="disabled"';
                                             $dayoffchecked = 'checked';
                                             
                                           }else{
                                           $class_start_day_time = '';
                                             $class_end_day_time = '';
                                              //$upcoming_plan_dayoff = '';
                                              $disabled_class='';
                                            $dayoffchecked = '';
                                           
                                         }

                                         if($newcountorrder == 1){
                                         $plan_name = 'Current Plan';

                                     }else{
                                     $plan_name = 'Upcoming Plan';
                                 }
                                     


                                       
                          @endphp
                         
                              <div class="label-col">
                                <label>{{ getDay($ia) }}</label>
                              
                                <label class="workinghoures-datemonth">{{ date('M j Y, h:i A', $i) }}</label>
                                
                                
                              </div>
                               
                                                         
                              <div class="dropbox-col">
                                  <input type="hidden" name="working_hours[{{$count}}][working_date]" value="{{ date('Y-m-d', $i )}}">


                                   <div class="dropdown-col {{$class_start_day_time}} " id="starting_day_time{{$count}}" title="{{$plan_name}}">
                                
                                   
                                   
                                        <select id="{{ $colName }}_from" class="form-control working_from"
                                             name="working_hours[{{$count}}][working_start_time]" {{$disabled_class}}>
                                             <option value="">From</option>
                                             @php
                                             if($newcountorrder == $countoreder){
                                            if($current_plan_expiry_date == $i){
                                                echo get_times3($working_start_time,$i);
                                             }else{
                                               if($podate == date('d-m-Y',$i)){
                                                  echo get_times5($working_start_time,$rounded_seconds);
                                                }else{
                                                  echo get_times($working_start_time);   
                                                }
                                              }
                                             }

                                          
                                          else{
                                            if($podate == date('d-m-Y',$i)){
                                                  echo get_times5($working_start_time,$rounded_seconds);
                                                }else{
                                                  echo get_times($working_start_time);   
                                                }
                                          }
   
                                             
                                            @endphp  
                                             
                                        </select>
        
                                   </div>

                                  
                                  
                                   <div class="dropdown-col {{$class_end_day_time}}" id="end_day_time{{$count}}" title="{{$plan_name}}">
                                        <select id="{{ $colName }}_to" class="form-control working_to"
                                             name="working_hours[{{$count}}][working_end_time]" {{$disabled_class}} >
                                             <option value="">To</option>
                                              @php
                                              if($newcountorrder == $countoreder){
                                              if($current_plan_expiry_date == $i){
                                                echo get_times3($working_end_time,$i);
                                             }else{
                                                 if($podate == date('d-m-Y',$i)){
                                                      echo get_times5($working_end_time,$rounded_seconds);
                                                    }else{
                                                      echo get_times($working_end_time);   
                                                    }
                                                
                                             }

                                          }else{
                                            if($podate == date('d-m-Y',$i)){
                                                      echo get_times5($working_end_time,$rounded_seconds);
                                            }else{
                                               echo get_times($working_end_time);   
                                            }
                                          }
                                          @endphp
                                        </select>
                                   </div>
                                  
                   
                    <div class="working-hours-dayoff-block {{$upcoming_plan_dayoff}}" id="working-hours-dayoff-block{{$count}}" title="{{$plan_name}}">
                    <div class="radio radio-info form-check-inlinesquarebox">
             
                      
            <div class="dateclickform">
                     <input type="checkbox" name="working_hours[{{$count}}][working_dayoff]" id="dayoff{{$count}}" class="css-checkbox dayoffCheckBox" {{$dayoffchecked}}  onchange="selectDayOff('{{$colName}}',{{$count}})" >
                          <label for="dayoff{{$count}}"  class="css-label" >Day OFF</label>
              </div>
                        </div> 
            </div>
            
                              </div>
                               
                    </div>
                   
                    @endif 
               @php
               $count++;
               @endphp
               @endfor
               @endforeach
                   
                   

                        
               
              

<style>
 
.disabled_start_day_time select{
       
        pointer-events: none;
     
}

.disabled_end_day_time select{
      
        pointer-events: none;
      
}
.upcoming_day_off input[type="checkbox"]{
      
        pointer-events: none;
      
}

.disabled_start_day_time{
        cursor: not-allowed;
        opacity:0.5;
}

.disabled_end_day_time{
        cursor: not-allowed;
        opacity:0.5;
        
}
.upcoming_day_off{
        cursor: not-allowed;
        opacity:0.5;     
}
</style>
<script type="text/javascript">
 

function selectDayOff(id, ids){
    
     if ($("#dayoff"+ids).prop("checked") == true) {
      //console.log($("#"+id+"_to").val());
      if($("#"+id+"_to").val() == '' && $("#"+id+"_from").val() == ''){
        $("#working-hours-dayoff-block"+ids).show();

        $('#starting_day_time'+ids).addClass("disabled_start_day_time");
          $('#end_day_time'+ids).addClass("disabled_end_day_time"); 

         $("#"+id+"_to").attr("disabled",true);
         $("#"+id+"_from").attr("disabled",true);


      }else{
        window.setTimeout(function(){
          $("#working-hours-dayoff-block"+ids).show();

        $('#starting_day_time'+ids).addClass("disabled_start_day_time");
          $('#end_day_time'+ids).addClass("disabled_end_day_time"); 

         $("#"+id+"_to").attr("disabled",true);
         $("#"+id+"_from").attr("disabled",true);
          $("#"+id+"_to").val('');
          $("#"+id+"_from").val('');
          
          
        },100);
        
      }
      
    }else if($("#dayoff"+ ids).prop("checked") == false){
     $("#working-hours-dayoff-block"+ids).show();
      $("#"+id+"_to").attr("disabled",false);
     $("#"+id+"_from").attr("disabled",false);
      $('#starting_day_time'+ids).removeClass("disabled_start_day_time");
      $('#end_day_time'+ids).removeClass("disabled_end_day_time"); 
        $("#working-hours-dayoff-block"+ids).removeClass('dayoff_on');
    } 
  
}

</script>         
         <div class="form-group mt-4">
                      <textarea class="form-control custom-textarea bg-theme-dark-form WorkingHoursTextarea" id="WorkingHoursTextarea" rows="3" name="working_additional_information" placeholder="Additional info, if any ">{{$listdata['metaData']['working_additional_information']}}</textarea>
                    </div>
          </div>
</div>
<!-- Working hours  block end -->
<!-- end new code -->


<div class="clearfix"></div>
      <section class="mybookingCalendar-block services-calendar padding-50">
            <!--<h2>
              <img src="{{asset('frontend/images/bookingCalendar-img.png')}}" alt="bookingCalendar-img" class="img-fluid">
              <button type="button" data-toggle="modal" data-target="#services-addTime" class="add-newBlog-btn calander-addnew-btn"><i class="fa fa-plus"></i> Add New Entry</button>

            </h2>-->
             <div class="clearfix"></div>
         
               
               
               <div class="calendar-main padding-80" id="calendar_section">
         <div class="calendarform-height">
     <div class="calendar-title"> 
<h6 class="realtimebookslot">real time booking slot</h6>     
                  <div class="calendar-left-panel">
                     <div class="calendar-bookingTime-Slot">
                       <div class="bookingSlot-day">
                      <h3 id="selected_date"></h3>
                       <span><h6 id="selected_day"></h6> <span id="selected_m_y"></span></span>
                        
                        
                       </div>
                       <div class="clearfix"></div>
                       
                       <div class="slotTime-block">
                          <div class="slotTime-left"  >
                            <!--<h4>Today’s Booking Time Slot</h4>-->
                            <div class="TimeSlot-start">
                            <h5>start time</h5>
                           <ul id="calendar-time-range" style="position:relative;">
                                  
                                   
                         </ul>                               
                               <h5>finish time</h5>
                               </div>
                               
                           </div>
                           <div class="slotTime-right"></div>                      
                       </div>              
                  </div>
         
           <ul class="calendar-Indicators calandardot-mobilemode">
           <li><span class="red-calenderIndicator green-calenderIndicator"></span> available</li>
                   <li><span class="red-calenderIndicator"></span> booked</li>                    
                   {{--  <li><span class="red-calenderIndicator violet-calenderIndicator"></span> break time</li>  --}}                   
                  </ul>
                  </div>
          </div>
                  
                  
                  <div class="calendarright-mainpanel">
          <h6 class="bookingimg-desktop-view">my booking calendar</h6>
                   <p>Click on to the <span>GREEN DATES</span> to View The Available Booking Slots.</p>
                   <div class="calendar-right-panel">
                     <div id="touring-calender"></div>                  
                  </div>                   
          </div>
          </div>
          
                  
                  <div class="clearfix"></div>
                  
                  <ul class="calendar-Indicators">
                   <!--<li class="displaynone-mobile"><span class="red-calenderIndicator"></span> booked</li>                    
                    <li class="displaynone-mobile"><span class="red-calenderIndicator violet-calenderIndicator"></span> break time</li>
                    <li><span class="touring-calenderIndicator"></span> <img src="{{asset('frontend/images/aeroplane-icon.png')}}">touring</li>
          <li class="displaynone-desktop"><span class="red-calenderIndicator green-calenderIndicator"></span>working</li>
          -->
          <li><span class="red-calenderIndicator green-calenderIndicator"></span> available</li>
                    <li><span class="red-calenderIndicator dayoff-calenderIndicator"></span> day off</li>
                    @if(!is_agency() && !is_club())         
          <li><span class="touring-calenderIndicator"></span> <img src="{{asset('frontend/images/aeroplane-icon.png')}}">touring</li>
          @endif
                  </ul>
          
           <div class="calander-textarea-block">
            @php
            $placeholdertext = !is_agency() && !is_club() ? "Please don't forget to subscribe my profile so you can get an advance notifications like when I'm touring to your location, running Special, working, day off, new photos & videos etc." : "Please don't forget to subscribe my profile so you can get an advance notifications like I am running special, working, day off, new photos & videos etc."
            @endphp
                     <textarea class="calandar-textarea bookingAdditionalTextarea" id="bookingAdditionalTextarea" name="booking_additional_information"  rows="3" placeholder="{{$placeholdertext}}">{{$listdata['metaData']['working_additional_information']}}</textarea>                  
                  </div>  
                  
                             
               </div>         
     </section>
      
<div class="clearfix"></div>
@if(!is_agency() && !is_club())
<div class="contact-box personal-radiobutton-box pink-label working_hours_box touring_girls_box Newzealand" id="touring_section">
	@if(count($listdata['touring'])>0 && count($listdata['inter_tour'])>0 )
     	@php
		$tourcnt=count($listdata['touring'])+count($listdata['inter_tour']);
		@endphp
	@elseif(count($listdata['touring'])==0 && count($listdata['inter_tour'])==0 )
     @php
		$tourcnt=2;
		@endphp
	@elseif(count($listdata['touring'])>0)
     @php
		$tourcnt=count($listdata['touring'])+1;
		@endphp
	@elseif(count($listdata['inter_tour'])>0)
     @php
		$tourcnt=count($listdata['inter_tour'])+1;
		@endphp
	@endif
  <input type="hidden" value="{{ $tourcnt }}" id="tourcount">
     <h4 style="display: inline-block;">Touring in New Zealand (Optional)</h4> <!-- <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addTour()"><i class="fa fa-plus"></i></a> -->
     @if(count($listdata['touring']) > 0)
     @php
     $tcount = 0;
     @endphp
     @foreach($listdata['touring'] as $tour)
      <div class="touring_girls" id="touring_girls{{$tcount}}">
          <div class="rates_section">
               <span class="two-inputs" id="two-inputs{{$tcount}}">
                  <div class="drop_box">
                        <input class="form-control startdate" id="startdate{{$tcount}}" name="old_tour[{{$tcount}}][startdate]" placeholder="From Date" value="{{getDateddFormat($tour->from_date)}}"/>
              <span class="calender-icon">
                <i class="fa fa-calendar-o" aria-hidden="true"></i>
              </span>
               <span class="help-block hidden startdate_error"></span>

                   </div>
                   <div class="charges_box">
                        <input class="form-control enddate" id="enddate{{$tcount}}" name="old_tour[{{$tcount}}][enddate]" placeholder="To Date" value="{{getDateddFormat($tour->to_date)}}"/>
              <span class="calender-icon">
                <i class="fa fa-calendar-o" aria-hidden="true"></i>
              </span>
               <span class="help-block hidden enddate_error"></span>
                   </div>
               </span>

               <div class="service_box">
                    <select class="select_country_box form-control" name="old_tour[{{$tcount}}][country]" id="tour_country{{$tcount}}" onchange="getTourCity(this.value, this.id)" >
                         <option value=''>Select Country</option>
                         @foreach($tourcountries as $cn)
                            <option value='{{ $cn["id"] }}' {{$cn['id'] == $tour->country_id ?'selected':''}}>{{ $cn['country_name'] }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="service_box touring-serviebox">
                @php
                $cities = getcities($tour->country_id, true);
                @endphp
                    <select class="select_city_box form-control" name="old_tour[{{$tcount}}][city]" id="tour_city{{$tcount}}">
                         <option value=''>Select City</option>
                        @if(count($cities) > 0)
                        @foreach($cities as $ct)
                        <option value="{{$ct->id}}" {{$ct->id == $tour->city_id ? 'selected':''}}>{{$ct->name}}</option>
                        @endforeach
                        @endif
                    </select>
               </div>
              <div class="button_box my-feesbtn">
                         
                      <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addTour()"><i class="fa fa-plus"></i></a>
                      <a href="javascript:void(0)" id="removeTourBtns{{$tcount}}" class="servicefee-btn-remove remove-tour" onclick="deleteTour('{{$tour->id}}',this.id)"><i class="fa fa-minus"></i></a></div>
            
          </div>
         
     </div>
      @php
     $tcount++;
     @endphp
     @endforeach
     @else
      <div class="touring_girls" id="touring_girls">
          <div class="rates_section">
            <span class="two-inputs" id="two-inputs0">
                  <div class="drop_box">
                        <input class="form-control startdate" id="startdate0" name="new_tour[0][startdate]" placeholder="From Date" value=""/>
              <span class="calender-icon">
                <i class="fa fa-calendar-o" aria-hidden="true"></i>
              </span>
               <span class="help-block hidden startdate_error"></span>

                   </div>
                   <div class="charges_box">
                        <input class="form-control enddate" id="enddate0" name="new_tour[0][enddate]" placeholder="To Date" value=""/>
              <span class="calender-icon">
                <i class="fa fa-calendar-o" aria-hidden="true"></i>
              </span>
               <span class="help-block hidden enddate_error"></span>
                   </div>
            </span>

               <div class="service_box">
                    <select class="select_country_box form-control" name="new_tour[0][country]" id="tour_country0" onchange="getTourCity(this.value, this.id)" >
                         <option value=''>Select Country</option>
                         @foreach($tourcountries as $cn)
                            <option value='{{ $cn["id"] }}' {{ $cn['id'] == getDefaultCountry() ? 'selected' : '' }}>{{ $cn['country_name'] }}</option>
                         @endforeach
                    </select>
               </div>
               @php
                $cities = getcities($tourcountries[0]->id, true);
                @endphp
                    
               <div class="service_box">
                    <select class="select_city_box form-control" name="new_tour[0][city]" id="tour_city0">
                         <option value=''>Select City</option>
                      @foreach($cities as $ct)
                        <option value="{{$ct->id}}">{{$ct->name}}</option>
                        @endforeach
                    </select>
               </div>

              <div class="button_box my-feesbtn">
                         
                      <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addTour()"><i class="fa fa-plus"></i></a>
                      <!-- <a href="javascript:void(0)" id="removeTourBtns" class="servicefee-btn-remove remove-tour" onclick="removeTour(this.id)"><i class="fa fa-minus"></i></a>--></div>
            
          </div>
         
     </div>
     @endif
    
     <div id="touring-section-placeholder"></div>
</div>
<div class="clearfix"></div>
<div class="contact-box personal-radiobutton-box pink-label working_hours_box touring_girls_box intenational" id="touring_section">
     <h4 style="display: inline-block;">International Touring (Optional)</h4>
     <!-- <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addInterTour()"><i class="fa fa-plus"></i></a> -->

     @if(count($listdata['inter_tour']) > 0)
     
     	@if(count($listdata['touring']) > 0)
        	@php
		    	$tcount=count($listdata['touring']);
		    @endphp
		@else
			@php
		    	$tcount=1;
		    @endphp
        @endif
     @foreach($listdata['inter_tour'] as $tour)
      <div class="inter_touring_girls" id="inter_touring_girls{{$tcount}}">
          <div class="rates_section">
            <span class="two-inputs" id="two-inputs{{$tcount}}">
               <div class="drop_box">
                    <input class="form-control startdate" id="startdate{{$tcount}}" name="old_inter_tour[{{$tcount}}][startdate]" placeholder="From Date" value="{{getDateddFormat($tour->from_date)}}"/>
          <span class="calender-icon">
            <i class="fa fa-calendar-o" aria-hidden="true"></i>
          </span>
           <span class="help-block hidden startdate_error"></span>

               </div>
               <div class="charges_box">
                    <input class="form-control enddate" id="enddate{{$tcount}}" name="old_inter_tour[{{$tcount}}][enddate]" placeholder="To Date" value="{{getDateddFormat($tour->to_date)}}"/>
          <span class="calender-icon">
            <i class="fa fa-calendar-o" aria-hidden="true"></i>
          </span>
           <span class="help-block hidden enddate_error"></span>
               </div>
            </span>
               <div class="service_box">
                    <select class="select_country_box form-control" name="old_inter_tour[{{$tcount}}][country]" id="inter_tour_country{{$tcount}}" onchange="getInterTourCity(this.value, this.id)" >
                         <option value=''>Select Country</option>
                         @foreach($intertourcountries as $cn)
                            <option value='{{ $cn["id"] }}' {{$cn['id'] == $tour->country_id ?'selected':''}}>{{ $cn['country_name'] }}</option>
                         @endforeach
                    </select>
               </div>
               <div class="service_box touring-serviebox">
                @php
                $cities = getcities($tour->country_id, true);
                @endphp
                    <select class="select_city_box form-control" name="old_inter_tour[{{$tcount}}][city]" id="inter_tour_city{{$tcount}}">
                         <option value=''>Select City</option>
                        @if(count($cities) > 0)
                        @foreach($cities as $ct)
                        <option value="{{$ct->id}}" {{$ct->id == $tour->city_id ? 'selected':''}}>{{$ct->name}}</option>
                        @endforeach
                        @endif
                    </select>
               </div>
              <div class="button_box my-feesbtn">
                         
                      <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addInterTour()"><i class="fa fa-plus"></i></a>
                      <a href="javascript:void(0)" id="removeInterTourBtns{{$tcount}}" class="servicefee-btn-remove remove-tour" onclick="deleteIntTour('{{$tour->id}}',this.id)"><i class="fa fa-minus"></i></a></div>
            
          </div>
         
     </div>
      @php
     $tcount++;
     @endphp
     @endforeach
     @else
        @if(count($listdata['touring']) > 0)
        	@php
		    	$tcount=count($listdata['touring']);
		    @endphp
		@else
			@php
		    	$tcount=1;
		    @endphp
        @endif
      <div class="inter_touring_girls" id="inter_touring_girls">
          <div class="rates_section">
            <span class="two-inputs" id="two-inputs{{$tcount}}">
               <div class="drop_box">
                    <input class="form-control startdate" id="startdate{{$tcount}}" name="new_inter_tour[0][startdate]" placeholder="From Date" />
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>

               </div>
               <div class="charges_box">
                    <input class="form-control enddate" id="enddate{{$tcount}}" name="new_inter_tour[0][enddate]" placeholder="To Date" />
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>
               </div>
             </span>
               <div class="service_box">
                    <select class="select_country_box form-control" name="new_inter_tour[0][country]" id="inter_tour_country0" onchange="getInterTourCity(this.value, this.id)" >
                         <option value=''>Select Country</option>
                         @foreach($intertourcountries as $cn)
                            <option value='{{ $cn["id"] }}'>{{ $cn['country_name'] }}</option>
                         @endforeach
                    </select>
               </div>

               <div class="service_box">
                    <select class="select_city_box form-control" name="new_inter_tour[0][city]" id="inter_tour_city0">
                         <option value=''>Select City</option>
                  
                    </select>
               </div>
              <div class="button_box my-feesbtn">
                         
                      <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addInterTour()"><i class="fa fa-plus"></i></a>
                      <!-- <a href="javascript:void(0)" id="removeInterTourBtns" class="servicefee-btn-remove remove-tour" onclick="removeInterTour(this.id)"><i class="fa fa-minus"></i></a>--></div>
            
          </div>
         
     </div>
     @endif
     <input type="hidden" name="touring_updates" id="touring_updates" value="">
     <div id="inter_touring-section-placeholder"></div>
</div>
@endif
<div class="clearfix"></div>

 <div class="contact-box personal-radiobutton-box pink-label run-specialboxmain">
                      <h4>Run Special Offer (Optional)</h4>
                      <div class="add-userroles">
                        <div class="rates_section">
                          <div class="runspecial-box">       
                          <span>today's special:</span>             
                           <input type="text" onchange="autosave3()" class="form-control runSpecialTextarea" id="runSpecialTextarea" name="run_specials" placeholder="15mins $100 Quickies, Full Service Mutual Kissing" value="{{$listdata['metaData']['run_specials']}}">
              
                          </div>                                                       
                        </div>
                      </div>
                      
                    </div>  


 <div class="social-float-parent">
         <div id="social-float2">
<div class="actions clearfix">
     <ul role="menu" aria-label="Pagination">
          <li class="" aria-disabled="false">
               <input type="button" name="prev_step_3" class="previous PreviousBTN" value="Previous" id="prev_step_3">
          </li>


          <li aria-hidden="false" aria-disabled="false">
             <input type="button" name="save_next_step_3" class="NextBTN" value="Next" id="save_next_step_3">
          </li>

            @if(Request::segment(1) =='edit-profile')

          <li>            
           <input type="submit" name="update_step_3" value="Update" id="update_step_3" class="NextBTN">
          </li>
          @else
          <li>            
           <input type="submit" name="update_step_3" value="Save" id="update_step_3" class="NextBTN">
          </li>
         
          @endif

           <li >   
              <input type="submit" name="save_as_draft_step_3" value="Save As Draft" id="save_as_draft_step_3" class="NextBTN">
                   
          </li>


     </ul>
</div>
</div>
</div>

<div id="secondFooter2"> </div>

</form>


</div>
</div>





<!-- service Included modal pop up start -->
<div class="modal fade services-steps-form" id="serviceIncluded-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
         <h2>Please select services</h2>    
        <button type="button" class="close" /*data-dismiss="modal"*/ aria-label="Close" onclick="setValuesToTextbox()">
          <span aria-hidden="true">save</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">              
        <div class="service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
             
                            
          @foreach($servicesavailable as $sa)  
         
                        <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" value="{{$sa['id']}}" name="service-available"  id="service-available{{$sa['id']}}" class="css-checkbox services_include" >
                               
                                <label for="service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                              </div>
                        </li>
                        @endforeach
                   <span class="help-block hidden service-available_error"></span>
                    </ul>
                          <input type="hidden" value="" id="service_available">    
      </div>        
          </div>
      </div>  
    </div>
  </div>
</div>
<!-- service Included modal pop up End -->
<!-- extra service Included modal pop up start -->
<div class="modal fade services-steps-form" id="extraserviceIncluded-popup" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">   
<h2>Please select services</h2>     
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToExtraTextbox()">
          <span aria-hidden="true">save</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">
              
        <div class="extra_service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
      
                            
          @foreach($servicesavailable as $sa)    
                        <li role="presentation">
                              <div class="radio radio-info form-check-inlinesquarebox">
                                <input type="checkbox" value="{{$sa['id']}}" name="extra-service-available"  id="extra-service-available{{$sa['id']}}" class="css-checkbox extra_services_include" >
                               
                                <label for="extra-service-available{{$sa['id']}}" class="css-label">{{$sa['value']}}</label>
                              </div>
                        </li>
                        @endforeach
                           
                
                    </ul>
                          <input type="hidden" value="" id="extra_service_available">    
      </div>        
          </div>
      </div>  
    </div>
  </div>
</div>
<!-- =====================Add services pop up for booking update pop up form======= -->
<div class="modal fade services-steps-form" id="service_include_popup" tabindex="-1" role="dialog"  aria-hidden="true" style="z-index: 2000;">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">   
<h2>Please select services</h2>     
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToTextbox_popup()">
          <span aria-hidden="true">save</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">
              
        <div class="extra_service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
          @foreach($servicesavailable as $sa)    
          @php 
            $nssm = rand(1000,666); 
          @endphp
                  <li role="presentation">
                        <div class="radio radio-info form-check-inlinesquarebox">
                          <input type="checkbox" value="{{$sa['id']}}" name="extra-service-available" id="extra-service-available{{$nssm}}" class="css-checkbox services_include_popup">
                         <label for="extra-service-available{{$nssm}}" class="css-label">{{$sa['value']}}</label>
                        </div>
                  </li>
                        @endforeach
        </ul>
            <input type="hidden" value="" id="extra_service_available">    
            </div>        
        </div>
      </div>  
    </div>
  </div>
</div>
<!-- =====================Add Extra services pop up for booking update pop up form======= -->
<div class="modal fade services-steps-form" id="extra_service_include_popup" tabindex="-1" role="dialog"  aria-hidden="true" style="z-index: 2000;">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">   
<h2>Please select services</h2>     
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="setValuesToExtraTextbox_popup()">
          <span aria-hidden="true">save</span>
        </button>
      </div>
      <div class="modal-body" id="style-2">
              
        <div class="extra_service_included">
        
          <div class="subscribe-Notify services_includeChkbox">   
        <ul>
          @foreach($servicesavailable as $sa)    
            @php  $nssm = rand(3000,1866);  @endphp
                  <li role="presentation">
                        <div class="radio radio-info form-check-inlinesquarebox">
                          <input type="checkbox" value="{{$sa['id']}}" name="extra-service-available" id="extra-service-available{{$nssm}}" class="css-checkbox extra_services_include_popup">
                         <label for="extra-service-available{{$nssm}}" class="css-label">{{$sa['value']}}</label>
                        </div>
                  </li>
                        @endforeach
        </ul>
            <input type="hidden" value="" id="extra_service_available">    
            </div>        
        </div>
      </div>  
    </div>
  </div>
</div>
<!-- =============================================================================== -->
<!-- =============================================================================== -->
<!-- =============================================================================== -->
<!-- services time modal pop up start -->
<div class="modal fade services-addTime" id="services-addTime" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"> Booking Slot / Calendar Updates</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="error_msg"></div>
       
        
        <form id="booking_form" onsubmit="return false" method="post" action="{{route('savebookings')}}">
          {{csrf_field()}}
                    @if ($errors->any())
                <div class="alert alert-warning">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif
           
        <div class="sevicesaddtime-top bookingSlot-block">
           {{--  <h4>Booking Slot Updates</h4> --}}           
               <label for="booked" class="bookslot-btns booked-btn">
                  <input type="radio" name='slot_type' id="booked" value="Booked" class="bookingSlot-commonbtn">
                <span class="label"></span>Booked Slot
                </label>
                 {{--  <label for="booked" class="bookslot-btns breaktime-btn">
                  <input type="radio" name='slot_type' id="booked" value="Break Time" class="bookingSlot-commonbtn">
                <span class="label"></span>Break Time
                </label> --}}
                 <br>
                <span class="label"><strong>Tips:</strong><small> Always try to add 15-30mins extra time in your current booking so you can have a enough time to prepare yourself to meet your Next Client.</small></span>
                  
                <span class="help1-block hidden slot_type_error"></span>
      </div>

          
          <div class="clearfix"></div>
            <div class="sevicesaddtime-top" id="sevicesaddtime-top">
            <div class="form-group">
            <label for="recipient-name" class="col-form-label">Regular Client</label>
            <select name="title" class="form-control" id="title">
              <option value="Regular Client">Regular Client</option>
              <option value="New Client">New Client</option>
            </select>
          <!--   <input type="radio" value="Regular Client"  name="title" id="title">
       
            <label for="recipient-name" class="col-form-label">New Client</label>
            <input type="radio" value="New Client"  name="title" id="title"> -->
            <span class="help1-block hidden title_error"></span>

             <input type="hidden" name="user_ad_id" id="booking_ad_id" value="{{!empty($user_ad_id)? $user_ad_id : ''}}">
             <input type="hidden" name="booking_id" id="cal_booking_id" value="">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Client Name</label>
            <input type="text" placeholder="Enter Client Name" class="form-control" name="client_name" id="client_name">
            <span class="help1-block hidden client_name_error " style="color: #ff0026"></span>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Services Included</label>
            <input type="text" data-toggle="modal" data-target="#service_include_popup" placeholder="" class="form-control" name="services" id="services_popup" onclick="setId_popup(this.id)">
            
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Add Extra Services</label>
            <input type="text" data-toggle="modal" data-target="#extra_service_include_popup" placeholder="" class="form-control" name="ex_services" id="ex_services" onclick="setExtraId_popup(this.id)">
       </div>

          <div class="form-group">
            <label for="message-text" class="col-form-label">Service Type</label>
            <select name="service_type" id="service-type" class="form-control">
            <option value="">Select</option>
            @foreach($servicetype as $ms)
            <option value="{{$ms['id']}}">{{$ms['value']}}</option>
            @endforeach
          </select>
          </div>

           <div class="form-group">
            <label for="message-text" class="col-form-label">Set Reminder Notification</label>
      
            <select name="reminder" id="reminder-cal" class="form-control">
              <option value="no">No</option>
               <option value="15 minutes">15 minutes before</option>
               <option value="1 hour">1 hour before</option>
              <option value="1 day">1 day before</option>
            </select>
          </div>
              <div class="form-group">
              <label for="message-text" class="col-form-label">Booking Notes</label>
              <textarea class="form-control" name="booking_notes" id="booking_notes"></textarea>
            </div>
        </div>
   

         
          
 <div class="row">  
      <div class="form-group col-md-12"> 
        
              <label for="message-text" class="col-form-label">From</label>
              <input type="text" class="form-control datepicker" name="calendar_date" value="{{date('m-d-Y')}}" id="calendar_date" placeholder="Select Date"/>
               <span class="help1-block hidden calendar_date_error"></span>
              
            </div>
        <div class="col-md-6 form-group"> 
        @php
        $times = get_calendar_times(date('H:i A', strtotime(date())));
        @endphp
            
        <label for="message-text" class="col-form-label">Start Time</label>
             <select class="form-control" name="calendar_start_time" id="calendar_start_time">
              <option value="">Select Start Time</option>
              @foreach($times as $ti)
              <option value="{{$ti}}">{{$ti}}</option>
               @endforeach
               
              </select>
              <span class="help1-block hidden calendar_start_time_error" style="color: #ff0026"></span>
        
        </div>
        
        <div class="col-md-6 form-group endtime-block">
         
               <label for="message-text" class="col-form-label">End Time</label>        
              <select class="form-control" name="calendar_end_time" id="calendar_end_time">
                <option value="">Select End Time</option>
                @foreach($times as $ti)
              <option value="{{$ti}}">{{$ti}}</option>
               @endforeach
                
              </select>
              <span class="help1-block hidden calendar_end_time_error" style="color: #ff0026"></span>
              
             
        
        </div>

             
         
 
       </div>
       
        </form>
        
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="submit" class="servicespopupSave-btn" id="calendar_add_bookings" >Save & View</button>
      </div>
    </div>
  </div>
</div>
<div class="nationalTouring" style="display: none">
    <div class="touring_girls00" id="touring_girls" style="margin-top: 30px;">
      <div class="rates_section">
        <span class="two-inputs" id="two-inputs0">
                  <div class="drop_box">
                        <input class="form-control startdate" id="startdate0" name="new_tour[0][startdate]" placeholder="From Date" value=""/>
              <span class="calender-icon">
                <i class="fa fa-calendar-o" aria-hidden="true"></i>
              </span>
               <span class="help-block hidden startdate_error"></span>

                   </div>
                   <div class="charges_box">
                        <input class="form-control enddate" id="enddate0" name="new_tour[0][enddate]" placeholder="To Date" value=""/>
              <span class="calender-icon">
                <i class="fa fa-calendar-o" aria-hidden="true"></i>
              </span>
               <span class="help-block hidden enddate_error"></span>
                   </div>
            </span>
           <div class="service_box">
                <select class="select_country_box form-control" name="new_tour[0][country]" id="tour_country0" onchange="getTourCity(this.value, this.id)" >
                     <option value=''>Select Country</option>
                     @foreach($tourcountries as $cn)
                        <option value='{{ $cn["id"] }}' {{ $cn['id'] == getDefaultCountry() ? 'selected' : '' }}>{{ $cn['country_name'] }}</option>
                     @endforeach
                </select>
           </div>
           @php
            $cities = getcities($tourcountries[0]->id, true);
            @endphp
                
           <div class="service_box">
                <select class="select_city_box form-control" name="new_tour[0][city]" id="tour_city0">
                     <option value=''>Select City</option>
                  @foreach($cities as $ct)
                    <option value="{{$ct->id}}">{{$ct->name}}</option>
                    @endforeach
                </select>
           </div>

          <div class="button_box my-feesbtn">
                       <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addTour()"><i class="fa fa-plus"></i></a>
                  
                  <a href="javascript:void(0)" id="removeTourBtns" class="servicefee-btn-remove remove-tour" onclick="removeTour(this.id)"><i class="fa fa-minus"></i></a></div>
        
      </div>
     
 </div>
 </div>
 <div class="interNationalTouring" style="display: none">
   <div class="inter_touring_girls00" id="inter_touring_girls">
          <div class="rates_section">
          	<span class="two-inputs" id="two-inputs0">
               <div class="drop_box">
                    <input class="form-control startdate" id="startdate0" name="new_inter_tour[0][startdate]" placeholder="From Date" />
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>

               </div>
               <div class="charges_box">
                    <input class="form-control enddate" id="enddate0" name="new_inter_tour[0][enddate]" placeholder="To Date" />
          <span class="calender-icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></span>
               </div>
           </span>
               <div class="service_box">
                    <select class="select_country_box form-control" name="new_inter_tour[0][country]" id="inter_tour_country0" onchange="getInterTourCity(this.value, this.id)" >
                         <option value=''>Select Country</option>
                         @foreach($intertourcountries as $cn)
                            <option value='{{ $cn["id"] }}'>{{ $cn['country_name'] }}</option>
                         @endforeach
                    </select>
               </div>

               <div class="service_box">
                    <select class="select_city_box form-control" name="new_inter_tour[0][city]" id="inter_tour_city0">
                         <option value=''>Select City</option>
                  
                    </select>
               </div>
              <div class="button_box my-feesbtn">
                       <a href="javascript:void(0)" class="servicefee-btn-add add-tour" onclick="addInterTour()"><i class="fa fa-plus"></i></a>  
                      
                      <a href="javascript:void(0)" id="removeInterTourBtns" class="servicefee-btn-remove remove-tour" onclick="removeInterTour(this.id)"><i class="fa fa-minus"></i></a></div>
            
          </div>
         
     </div>
 </div>
<!-- services time modal pop up end -->


<style>
  .fc-event {
  position: relative; /* for resize handle and other inner positioning */
  display: block; /* make the <a> tag block */
  font-size: .85em;
  line-height: 1.3;
  border-radius: 3px;
  border: none; /* default BORDER color */
  font-weight: normal; /* undo jqui's ui-widget-header bold */
}
.fc-today{
  background-color: transparent !important;
}

.fc-event,
.fc-event-dot {
  background-color: transparent; /* default BACKGROUND color */
}
input.error{
 border : 1px solid #f00 !important;
}
  </style>

  <script>
      var current_date = "{{date('Y-m-d')}}";
      $(".bookingSlot-commonbtn").click(function(){
       $ss =  $(this).val();
       if($ss == 'Available' || $ss=="Break Time"){
        $("#sevicesaddtime-top").hide();
       }else{
        $("#sevicesaddtime-top").show();
       }
      })


    
    $("#extra_service_include_popup, #service_include_popup").on('hidden.bs.modal', function (e) {
          $("body").addClass("modal-open");
      }) 
 

</script>
<script type="text/javascript" src="{{asset('frontend/js/moment1.min.js')}}"></script>
<script type="text/javascript" src="{{asset('frontend/js/daterangepicker.min.js')}}"></script>
