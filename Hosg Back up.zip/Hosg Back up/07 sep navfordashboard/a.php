 <script>
$(document).ready(function() {
  var $menu = $('#menu'),
    $menulink = $('.menu-link');
  
$menulink.click(function() {
  $menulink.toggleClass('active');
  $menu.toggleClass('active');
  return false;
});});
</script>
 
 <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="nav-side-menu">
                         <div class="profile-image text-center">
                              @if(count($images) == 0)
                    
                             <img src="{{asset('frontend/images/user-profile-icon.png')}}" class="figure-img img-fluid" alt="dummyaccountseeting-">
                             @else
                             @php
                             if(is_agency() ){
                              $imageurl = getAgencyLogo($query[0]->id, md5(Auth::user()->id));
                              }elseif(is_club()){
                              $imageurl = getClubLogo($query[0]->id, md5(Auth::user()->id));
                            }elseif(count($images) > 0){
                              foreach($images as $immg){
                                if($immg->media_is_default == 1){
                                  $imageurl = getS3ImageURL($immg->media_filename,'202*182', md5(Auth::user()->id));
                                  break;
                                }
                              }
                            }
                              
                             @endphp
                              <a href="{{url('profile/'.$query[0]->slug)}}"> <img src="{{ $imageurl }}" class="figure-img img-fluid" alt="dummyaccountseeting-" width="30%"> </a>
                              @endif
                         </div>
                         <div class="brand">
                             @if(!empty($query[0]->ad_name))
                            <a href="{{url('profile/'.$query[0]->slug)}}"> {{ $query[0]->ad_name}}  </a>
						 @if(count($age) > 0) 
							 
								 , <span class="whiteColor">{{$age->meta_value}}</span>
							 
							 @endif
                              @else
                               {{ Auth::user()->name  }}
                              @endif
                         </div>
                         <div class="private-badge text-center">
                          @if(is_agency() || is_club())
                          <span>{{getListingType(Auth::user()->listing_type, true)}}</span> 
                          @else
                          <span>{{getListingType(Auth::user()->listing_type)}}</span>
                          @endif
                        </div>
                          @if(count($query) > 0)
						             <div class="location text-center">
                         
                          @if(is_agency() || is_club())
                          @if(!empty($query[0]->suburbs) && !empty($query[0]->city))
                           <h6>{{ $query[0]->suburbs.", ".getCity($query[0]->city) }}</h6>
                           @endif
                          @else
                            @if(!empty($query[0]->ad_suburbs) && !empty($query[0]->ad_location))
                          <h6>{{ $query[0]->ad_suburbs.", ".getCity($query[0]->ad_location) }}</h6>
                          @endif
                          @endif
                          </div>
                          @endif
                         <!--<i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>-->
							<a href="#menu" class="menu-link">Menu <i class="fa fa-caret-down" aria-hidden="true"></i></a>
                         <div class="menu-list" id="menu" role="navigation">
                             <ul id="menu-content" class="menu-content"><!-- class="collapse out"-->
                                   <li class="dashboard {{ Request::path() === 'dashboard' ? 'active' : null }}">
                                        <a href="{{route('dashboard')}}">Dashboard</a>
                                   </li>
                                    

                                   @if(is_agency(\Request::session('agency_id')))
                                   @php
                                   $counterMyAds = getMyAdsActiveAndExpired();
                                   
                                   @endphp
                                   <li class="my-ads {{ Request::segment(2) === 'my-ads' ? 'active' : null }}">
                                        <a href="{{ route('myAds')}}">My Ads
                                        @if($counterMyAds['active'] > 0)
                                          <span class="badge badge-success" title="{{$counterMyAds['active']}} Active Ads">
                                            "{{$counterMyAds['active']}}"
                                          </span>
                                          @endif
                                          
                                   @if($counterMyAds['expired'] > 0)
                                          <span class="badge badge-danger" title="{{$counterMyAds['expired']}} Expired Ads">
                                            "{{$counterMyAds['expired']}}"
                                          </span>
                                          @endif
                                         

                                        </a>
                                   </li>
                                  
                                   @endif

                                    @if(is_club(\Request::session('club_id')))
                                    @php
                                   $counterMyAds = getMyAdsActiveAndExpired();
                                   
                                   @endphp
                                   <li class="my-ads {{ Request::segment(2) === 'my-ads' ? 'active' : null }}">
                                        <a href="{{ route('myAds')}}">My Ads
                                            @if($counterMyAds['active'] > 0)
                                          <span class="badge badge-success" title="{{$counterMyAds['active']}} Active Ads">
                                            "{{$counterMyAds['active']}}"
                                          </span>
                                          @endif
                                          
                                   @if($counterMyAds['expired'] > 0)
                                          <span class="badge badge-danger" title="{{$counterMyAds['expired']}} Expired Ads">
                                            "{{$counterMyAds['expired']}}"
                                          </span>
                                          @endif
                                        </a>

                                   </li>
                                   @endif
{{-- Testimonial section start --}}
                                    <li class="viewtestimonials {{ Request::segment(2) === 'view-testimonial' ? 'active' : null }}">
                                        <a href="javascript:void();">   
                                         
                                       Testimonials
                                        @if(check_all_unread_testimonial() > 0)
                                          <span class="badge badge-danger" title="{{check_all_unread_testimonial()}} new testimonial">
                                            "{{check_all_unread_testimonial()}}"
                                          </span>
                                          @endif
                                        </a>
                                 @php
                                $all_testimonal = DB::table('testimonials')
                                    ->where('test_user_id', Auth::user()->id)
                                     ->groupBy('test_ad_id')
                                    ->get();
                                 @endphp       
                                 <ul id="menu-content" class="menu-content">
                                  @foreach($all_testimonal as $testimonial)
                                  @php
                                    $unreadTestimonial = DB::table('testimonials')
                                    ->where('test_ad_id', $testimonial->test_ad_id)
                                     ->where('status', 0)
                                    ->count();
                                  @endphp
                                   <li class="dashboard {{ Request::path() === 'dashboard' ? 'active' : null }}">
                                <a href="{{url('/dashboard/view-testimonial/'.$testimonial->test_ad_id)}}">{{getTestimonialAdName($testimonial->test_ad_id)}}

                                @if($unreadTestimonial > 0)
                                          <span class="badge badge-danger" title="{{$unreadTestimonial}} new testimonial">
                                            "{{$unreadTestimonial}}"
                                          </span>
                                          @endif
                                        </a>
                                   </li>
                                   @endforeach

                                 </ul>
                                   </li>
{{-- Testimonial section end --}}

                                   {{--<li class="addOnfeatures ">
                                        <a href="#">Ad-On Features</a>
                                   </li>--}}

                                   <li class="updatelivestatus {{ Request::segment(2) === 'update-staus' ? 'active' : null }}">
                                        <a href="{{ route('updateLiveStatus')}}" >Update Live Status</a>
                                   </li>


                                      

                                   <li class="readmyescorstsStory {{ Request::segment(2) === 'blogs' ? 'active' : null }}">
                                        <a href="{{route('blogIndex')}}">  
                                      @if(is_agency() || is_club())
                                          Post Escorts Story
                                          @else
                                          Read my Escorts Story
                                          @endif
                                              @if(check_all_unread_comments() > 0)
                                          <span class="badge badge-danger" title="{{check_all_unread_comments()}} new comment">
                                            "{{check_all_unread_comments()}}"
                                          </span>
                                          @endif
                                      
                                        </a>
                                   </li>
                                   
                                   <li class="drafts {{ Request::segment(2) === 'draft' ? 'active' : null }}">
                                      @php
                                      if(is_agency()  || is_club()){
                                       $links = route('showDraft');
                                    }else if($query[0]->draft == 1 && $query[0]->step < 6){
                                       $link = createEditLink($query[0]->ad_listing_type_id,$query[0]->slug);
                                       $links = $link."?step=".$query[0]->step;
                                      }else{
                                      $links = route('showDraft');
                                    }
                                      @endphp
                                        <a href="{{ $links }}">Drafts</a>
                                   </li>
                                   
								   
                                   <li class="change-password {{ Request::segment(1) === 'cpassword' ? 'active' : null }}">
                                        <a href="{{route('changePassword')}}">Change Password</a>
                                   </li>
                                   <li class="edit-account  {{ Request::segment(2) === 'account-setting' ? 'active' : null }}">
                                        <a href="{{route('accountSetting')}}">Account Setting</a>
                                      </li>


                                   <!-- <li class="edit-account">
                                        <a data-toggle="modal" data-target="#reportThisadd" >
                                              Delete Account
                                        </a>
                                   </li> -->
 
                                   <li class="signout">
                                        <a href="{{route('logout')}}">Signout</a>
                                   </li>
                              </ul>
                         </div>
                    </div>
               </div>
			   			   
			 		   
			   
