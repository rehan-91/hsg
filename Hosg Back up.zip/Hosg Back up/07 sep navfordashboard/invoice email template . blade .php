<div style="max-width:1000px;margin:auto;padding:30px;font-size:16px;line-height:24px;font-family:'Montserrat', sans-serif;color:#fff; background:#000;">
  <table  cellpadding="0" cellspacing="0"  style=" width: 100%;line-height: inherit;text-align: left;">
  
  <tr>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  </tr>
    <tr>
      <td style="background:#000;"><img src="https://www.houseofsexygirls.co.nz/frontend/images/emailer-logo.jpg" style="width:100%; max-width: 120px;
        margin-left:0;"/></td>
        
          <td colspan="2" style="padding: 5px;vertical-align: top;text-align: right;padding-bottom: 20px; font-size: 14px; font-size: 14px;
        font-weight: 500; vertical-align: middle; color:#ff0026;margin-top: 50px; background:#000;""> INVOICE NO.<br>
      <span style="color: #fff;
        font-size: 18px;">
      :invoice_no:
      </span><br>
        </td>
    </tr>
    
    <tr>
      <td colspan="3" style="height:60px; background:#000;"></td>
    </tr>
  
    <tr>       
    <td style="padding: 5px;vertical-align: top;padding-bottom: 40px; font-size: 14px; font-size: 14px;
        font-weight: 500; background:#000;"><b style="color:#ff0026; ">From</b><br>
      :site_name:.<br>
      :site_address:
        </td>
        
    <td colspan="2" style="padding: 5px;vertical-align: top;text-align: right;padding-bottom: 40px; font-size: 14px; font-size: 14px;
        font-weight: 500; background:#000;" ><b style="color:#ff0026;">To</b><br>
      :user_name:<br>
      :user_email: <br>
      :user_phone: </td>
   </tr>
   
   
    <tr  style="text-align:right; font-size: 14px;font-weight: 500; padding-bottom:20px;background:#000; width:100%;">
      <td colspan="3">Purchased Date:  :invoice_date:</td>
    </tr>
    
    <tr>
      <td colspan="3" style="height:30px; background:#000;"></td>
    </tr>
    
    <tr>
      <th style="font-size: 14px; text-align:left; background: #ff0026; padding: 20px;">ITEM</th>
      <th style="font-size: 14px;  text-align:center; background: #ff0026; padding: 20px;">UNIT PRICE</th>
      <th style="font-size: 14px; text-align:right; background: #ff0026; padding: 20px;">TOTAL PRICE</th>
    </tr>

    <tr>
      <td style="color:#007bff; padding: 20px; background:#000;"><strong>:plan_name:</strong></td>
      <td style="text-align:center; padding: 20px; background:#000;">:plan_unit_price:</td>
      <td style="text-align:right; padding: 20px; background:#000;">:plan_unit_price:</td>
    </tr>

    <tr style="background:#262626;">
      <td style="color:#007bff; padding: 20px;"><strong>:featured_sexy_profile:</strong></td>
      <td style="text-align:center; padding: 20px;">:featured_sexy_price:</td>
      <td style="text-align:right; padding: 20px;">:featured_sexy_price:</td>
    </tr>

    <tr style="background:#000;">
      <td style="color:#007bff; padding: 20px;"><strong>:featured_sexy_teaser_video:</strong></td>
      <td style="text-align:center; padding: 20px;">:featured_sexy_teaser_price:</td>
      <td style="text-align:right; padding: 20px;">:featured_sexy_teaser_price:</td>
    </tr>

    <tr style="background:#262626;">
      <td style="color:#007bff; padding: 20px;"><strong>:dedicated_sexy_teaser_video:</strong></td>
      <td style="text-align:center; padding: 20px;">:dedicated_sexy_teaser_price:</td>
      <td style="text-align:right; padding: 20px;">:dedicated_sexy_teaser_price:</td>
    </tr>
    <tr style="background:#000;">
      <td style="color:#007bff; padding: 20px;"><strong>:super_boost:</strong></td>
      <td style="text-align:center; padding: 20px;">:super_boost_price:</td>
      <td style="text-align:right; padding: 20px;">:super_boost_price:</td>
    </tr>
    <tr style="background:#262626;">
      <td style="color:#007bff; padding: 20px;"><strong>:featured_banner:</strong></td>
      <td style="text-align:center; padding: 20px;">:featured_banner_price:</td>
      <td style="text-align:right ; padding: 20px;">:featured_banner_price:</td>
    </tr>
    <tr>
      <td colspan="3" style="height:30px; background:#000;"></td>
    </tr>
    <tr style="background:#000;">
      <td  colspan="2" style="text-align:right; border-top:0; color:#ff0026; padding: 0 0 28px 0;"><strong>Sub Total :</strong></td>
      <td style="border-top:0; text-align:right; color:#ff0026; padding: 0 0 28px 0;">:total_price:</td>
    </tr>
    <tr style="background:#000;">
      <td colspan="2" style="text-align:right;border-top:0; color:#ff0026; padding: 0 0 28px 0;"><strong>TOTAL :</strong></td>
      <td style="text-align:right; color:#ff0026;padding: 0 0 28px 0;">:total_price:</td>
    </tr>
    <tr  style="height:1px; background:#191919;">
      <td colspan="3" style="padding: 0;"></td>
    </tr>
    <tr style="background:#000;">
      <td colspan="4" style="padding: 8px 8px; text-align:right; font-size: 14px;"><a style="color: #b1b1b1;  padding-right: 17px;  font-size: 14px;" href=":download_pdf:" class=""><i class="fa-file-pdf-o "></i> Download  as PDF</a></td>
    </tr>
    <tr style="height:1px; background:#191919;">
      <td colspan="3" style="padding: 0;"></td>
    </tr>
    <tr>
      <td colspan="3" style="height:30px; background:#000;"></td>
    </tr>
    <tr style=" background:#000;">
      <td colspan="3" style="font-size:10px; text-align:center;">Thank you for your business. Please make sure all amounts are  payable to <strong>:site_name:</strong></td>
    </tr>
  </table>
</div>