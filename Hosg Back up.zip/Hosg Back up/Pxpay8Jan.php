<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use App\Library\PxPayMessage;
use App\Library\PxPay_Curl;
use App\Library\PxPayRequest;
use App\Library\PxPayResponse;
use App\Library\MifMessage;
use App\Models\UserAdvertisement;
use App\Models\Payment;
use App\Models\Order;
use App\Models\AdBoostLog;
use App\Models\EmailMessage;
use App\Models\User;
use App\Models\AdsAddOnFeatures;
use App\Models\addOnsUpgrade;
use App\Models\Plans;
use App\Models\AddOnDetails;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use App\Models\Invoices;
use Response;
use Input;
use Hash;
use Auth;
use Session;
use DB;
class Pxpay extends Controller
{	

	public function __construct( ) {
		   $this->generalSettings = generalSettings();
		   /*$this->PxPay_Userid = "HouseofSexyGirls_PxP";
		   $this->PxPay_Key    = "e1b10415df6bc729173884b11b1631548fc15b8506b137f2a174330e9ba64d6e";
  		$this->PxPay_Url = "https://sec.windcave.com/pxaccess/pxpay.aspx";*/
  		//card cred
		$this->PxPay_Userid = "HouseofSexyGirls_Dev";
  		$this->PxPay_Key    = "5f5d5cdb1c1ee1b11dfd87001f6c14795a373d9bbf73b063073f04398c76cfa4";
  		$this->PxPay_Url = "https://sec.windcave.com/pxaccess/pxpay.aspx";
  		$this->pxpay = new PxPay_Curl( $this->PxPay_Url, $this->PxPay_Userid, $this->PxPay_Key );
	}
	function paypaxSuccess(Request $request){

		$data = $request->all();


		$enc_hex = $data["result"];
		
		$rsp = $this->pxpay->getResponse($enc_hex);

		$TxnData3          = $rsp->getTxnData3();
		$Success           = $rsp->getSuccess();
		//print_r($rsp);
		//die("ddd");
		if(!empty($TxnData3)){
			if($Success == "1"){
			return redirect()->route('pay-addons-success');
			}

			return redirect('dashboard');

		}else{
				
				if($Success == "1"){
				return redirect()->route('pay-success');
						
				}
				$user_ad_id =  $request->session()->get('user_ad_id');
				$adData = UserAdvertisement::where('id', $user_ad_id)->first();
				$slug = $adData->slug;
				$listing_slug = DB::table('listing_type')->where("id", $adData->ad_listing_type_id)->first()->slug;
				$data = array();
				$profile_edit_link = url('edit-profile/'.$listing_slug.'/'.$slug);
				return redirect($profile_edit_link);
			}
		
	}
	function Addonssuccess(Request $request){
		// $datas = $request->session()->all();
		// print_r($datas);
		// exit;
		$request->session()->forget('update_addons');
		$data['type'] = 'addOns';
		$user_ad_id =  $request->session()->get('user_ad_id');
		
		$adData = UserAdvertisement::where('id', $user_ad_id)->first();
		$data['generalsettings'] = $this->generalSettings;
		return view('frontend.payment_success',compact('adData'), $data);
	}
	function success(Request $request){
	
		$user_ad_id =  $request->session()->get('user_ad_id');
		$adData = UserAdvertisement::where('id', $user_ad_id)->first();
		$slug = $adData->slug;

		$countOrderData = Order::where('ad_id',$user_ad_id)->where('order_status','=','Success')->count();
		$request->session()->put('form_step', '3');
		$listing_slug = DB::table('listing_type')->where("id", $adData->ad_listing_type_id)->first()->slug;
		$data = array();
		$data['profile_edit_link'] = url('edit-profile/'.$listing_slug.'/'.$slug.'?step=3#WorkingHours');
		$data['generalsettings'] = $this->generalSettings;
		
		return view('frontend.payment_success',compact('countOrderData'), $data)->with('adData',$adData);
	}

	function paypaxIpn(Request $request){
		//$myfile = fopen(public_path('uploads/test.txt'),  "w") or die("Unable to open file!");
	
		$data = $request->all();
		$enc_hex = $data["result"];
	
		$rsp = $this->pxpay->getResponse($enc_hex);
		// $dump_data = json_encode($rsp);
		// $insert_DUmpDAta =  DB::table('dump_data')->insert(['dump_data' => $dump_data]);
		
		# the following are the fields available in the PxPayResponse object
		
		$Success           = $rsp->getSuccess();   # =1 when request succeeds
		$AmountSettlement  = $rsp->getAmountSettlement();
		$AuthCode          = $rsp->getAuthCode();  # from bank
		$CardName          = $rsp->getCardName();  # e.g. "Visa"
		$CardNumber        = $rsp->getCardNumber(); # Truncated card number
		$DateExpiry        = $rsp->getDateExpiry(); # in mmyy format
		$DpsBillingId      = $rsp->getDpsBillingId();
		$BillingId    	 = $rsp->getBillingId();
		$CardHolderName    = $rsp->getCardHolderName();
		$DpsTxnRef	     = $rsp->getDpsTxnRef();
		$TxnType           = $rsp->getTxnType();
		$orderId          = $rsp->getTxnData1();
		$userId          = $rsp->getTxnData2();
		$TxnData3          = $rsp->getTxnData3();
		$CurrencySettlement= $rsp->getCurrencySettlement();
		$ClientInfo        = $rsp->getClientInfo(); # The IP address of the user who submitted the transaction
		$TxnId             = $rsp->getTxnId();
		$CurrencyInput     = $rsp->getCurrencyInput();
		$EmailAddress      = $rsp->getEmailAddress();
		$MerchantReference = $rsp->getMerchantReference();
		$ResponseText		 = $rsp->getResponseText();
		$TxnMac            = $rsp->getTxnMac(); # An indication as to the uniqueness of a card used in relation to others

		if ($rsp->getSuccess() == "1")
		{
			$today = strtotime(date("Y-m-d H:i"));
			$today_exp = strtotime(date("Y-m-d H:i"));
			$order = Order::findOrFail($orderId);
			$user =  User::where('id', $userId)->first();
			$checkIfOrderExist = Order::where('user_id', $userId)->where('ad_id', $order->ad_id)->where('order_status', "Success")->where('plan_expired', '>', $today_exp)->orderBy('id','desc')->get();
			$old_plan_expired = '';

			if($order->plan_expired == null ){
				if(count($checkIfOrderExist) > 0){
					$old_plan_id = $checkIfOrderExist[0]->plan_id;
					$old_plan_expired = $checkIfOrderExist[0]->plan_expired;
					$old_order_id = $checkIfOrderExist[0]->id;
				}

				$planDetails = Plans::findOrFail($order->plan_id);
				$plansDuration = $planDetails->plan_duration;
				$plansDurationUnit = $planDetails->plan_duration_unit;
				if($plansDurationUnit == 1){
					$expiryDate = strtotime(date("Y-m-d H:i"));
				}else{
					$expiryDate = strtotime('+ '.($plansDuration-1).' '.$duration_unit, strtotime(date("Y-m-d H:i")));
				}
				
				$userAdData = UserAdvertisement::findOrFail($order->ad_id);
				$userAdData->plan_id = $order->plan_id;
				$userAdData->plan_purchased = $today;

				if($old_plan_expired == ''){
					$todaytime = $today;

				}else{
					$todaytime = (int)$old_plan_expired > 0  && $old_plan_expired > $today? $old_plan_expired : $today;
				}
				$todaytimes = date('Y-m-d',$todaytime+86400);
				//$todaytime = (int)$userAdData->plan_expired > 0  && $userAdData->plan_expired > $today? $userAdData->plan_expired : $today;
				
				$userPlanExpire =  strtotime('+ '.$plansDuration.' '.$plansDurationUnit, $todaytime );
				
				
				$userAdData->plan_expired = $userPlanExpire;
				
				
				if(!empty($old_plan_id)){
					$userAdData->old_plan_id = $old_plan_id;
				}
				if(!empty($old_plan_expired)){
					$userAdData->old_plan_expiry = $old_plan_expired;
				}
				if(!empty($old_order_id)){
					$userAdData->old_order_id  = $old_order_id;
				}

				$userAdData->next_boost_time = strtotime('+ 20 minutes', $today);
				$userAdData->step = 3;
				$userAdData->day_before_mail_sent = 0;
				$userAdData->hours_before_mail_sent= 0;
				$userAdData->expired_mail_sent = 0;
				$userAdData->save();
				$ad_id = $order->ad_id;
				$boost_interval = "10 minutes";

					
				if(!empty($order->featured_profile_price)){
					$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_profiles')->first();
					if(count($getOrderfeature)>0){
						if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
						{
								$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
						}else{
							$addOnExpiryDateMultiple = '';	
						}	
					}else{
						$addOnExpiryDateMultiple = '';
					}
					$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_profiles')->delete();
					$addon = new AdsAddOnFeatures();
					$addon->feature_name = "featured_profiles";
					//$today = time();
					$today = date('Y-m-d');
					$explodeDays = explode(',',$order->featured_profile_days);
					//$addOnExpiryDateMultiple = '';
					foreach ($explodeDays as $key => $daysvals) {
						$newdaysVal = $daysvals - 1 ;
						$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
						if($key < (count($explodeDays)-1)){
							$addOnExpiryDateMultiple .= ",";
						}
						//var_dump($daysvals);
					}
					$addon->multiple_expiry = $addOnExpiryDateMultiple;
					$addOnExpiryDate = strtotime('+'.$order->featured_profile_days.' days', $todaytime);
					$addon->expiry = $addOnExpiryDate;
					$addon->status = 1;
					$addon->ad_id = $order->ad_id;
					$addon->save();
				
				}

				if(!empty($order->teaser_video_price)){
					$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video')->first();
					if(count($getOrderfeature)>0){
						if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
						{
								$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
						}else{
							$addOnExpiryDateMultiple = '';	
						}	
					}else{
						$addOnExpiryDateMultiple = '';
					}
					$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video')->delete();
					$addon = new AdsAddOnFeatures();
					$addon->feature_name = "teaser_video";
					//$today = time();
					$today = date('Y-m-d');
					$explodeDays = explode(',',$order->teaser_video_days);
					//$addOnExpiryDateMultiple = '';
					foreach ($explodeDays as $key => $daysvals) {
						$newdaysVal = $daysvals - 1 ;
						$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
						if($key < (count($explodeDays)-1)){
							$addOnExpiryDateMultiple .= ",";
						}
						//var_dump($daysvals);
					}
					$addon->multiple_expiry = $addOnExpiryDateMultiple;
					$addOnExpiryDate = strtotime('+'.$order->teaser_video_days.' days', $todaytime);
					$addon->expiry = $addOnExpiryDate;
					$addon->status = 1;
					$addon->ad_id = $order->ad_id;
					$addon->save();
				
				}
				// if(!empty($order->teaser_video_price)){
				// 	$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video')->delete();
				// 	$addon = new AdsAddOnFeatures();
				// 	$addon->feature_name = "teaser_video";
				// 	$today = time();
				// 	$addOnExpiryDate = strtotime('+'.$order->teaser_video_day.' days', $todaytime);
				// 	$addon->expiry = $addOnExpiryDate;
				// 	$addon->status = 1;
				// 	$addon->ad_id = $order->ad_id;
				// 	$addon->save();
				
				// }

				if(!empty($order->teaser_video_two_price)){
					$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video_two')->first();
					if(count($getOrderfeature)>0){
						if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
						{
								$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
						}else{
							$addOnExpiryDateMultiple = '';	
						}	
					}else{
						$addOnExpiryDateMultiple = '';
					}
					$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video_two')->delete();
					$addon = new AdsAddOnFeatures();
					$addon->feature_name = "teaser_video_two";
					//$today = time();
					$today = date('Y-m-d');
					$explodeDays = explode(',',$order->teaser_video_two_days);
					//$addOnExpiryDateMultiple = '';
					foreach ($explodeDays as $key => $daysvals) {
						$newdaysVal = $daysvals - 1 ;
						$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
						if($key < (count($explodeDays)-1)){
							$addOnExpiryDateMultiple .= ",";
						}
						//var_dump($daysvals);
					}
					$addon->multiple_expiry = $addOnExpiryDateMultiple;
					$addOnExpiryDate = strtotime('+'.$order->teaser_video_two_days.' days', $todaytime);
					$addon->expiry = $addOnExpiryDate;
					$addon->status = 1;
					$addon->ad_id = $order->ad_id;
					$addon->save();
				
				}
				// if(!empty($order->teaser_video_two_price)){
				// 	$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video_two')->delete();
				// 	$addon = new AdsAddOnFeatures();
				// 	$addon->feature_name = "teaser_video_two";
				// 	$today = time();
				// 	$addOnExpiryDate = strtotime('+'.$order->teaser_video_two_day.' days', $todaytime);
				// 	$addon->expiry = $addOnExpiryDate;
				// 	$addon->status = 1;
				// 	$addon->ad_id = $order->ad_id;
				// 	$addon->save();
				
				// }
				if(!empty($order->super_speed_boost_price)){
					$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'super_speed_boost')->first();
					if(count($getOrderfeature)>0){
						if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
						{
								$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
						}else{
							$addOnExpiryDateMultiple = '';	
						}	
					}else{
						$addOnExpiryDateMultiple = '';
					}
					$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'super_speed_boost')->delete();
					$addon = new AdsAddOnFeatures();
					$addon->feature_name = "super_speed_boost";
					//$today = time();
					$today = date('Y-m-d');
					$explodeDays = explode(',',$order->super_speed_boost_days);
					//$addOnExpiryDateMultiple = '';
					foreach ($explodeDays as $key => $daysvals) {
						$newdaysVal = $daysvals - 1 ;
						$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
						if($key < (count($explodeDays)-1)){
							$addOnExpiryDateMultiple .= ",";
						}
						//var_dump($daysvals);
					}
					$addon->multiple_expiry = $addOnExpiryDateMultiple;
					$addOnExpiryDate = strtotime('+'.$order->super_speed_boost_days.' days', $todaytime);
					$addon->expiry = $addOnExpiryDate;
					$addon->status = 1;
					$addon->ad_id = $order->ad_id;
					$addon->save();
				
				}
				// if(!empty($order->super_speed_boost_price)){
				// 	$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'super_speed_boost')->delete();
				// 	$addon = new AdsAddOnFeatures();
				// 	$addon->feature_name = "super_speed_boost";
				// 	$today = time();
				// 	$addOnExpiryDate = strtotime('+'.$order->super_speed_boost_day.' days', $todaytime);
				// 	$addon->expiry = $addOnExpiryDate;
				// 	$addon->status = 1;
				// 	$addon->ad_id = $order->ad_id;
				// 	$addon->save();
				
				// }
				if(!empty($order->featured_banner_price)){
					$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_banner')->first();
					if(count($getOrderfeature)>0){
						if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
						{
								$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
						}else{
							$addOnExpiryDateMultiple = '';	
						}	
					}else{
						$addOnExpiryDateMultiple = '';
					}
					$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_banner')->delete();
					$addon = new AdsAddOnFeatures();
					$addon->feature_name = "featured_banner";
					//$today = time();
					$today = $order->plan_purchased;
					$explodeDays = explode(',',$order->featured_banner_days);
					//$addOnExpiryDateMultiple = '';
					foreach ($explodeDays as $key => $daysvals) {
						$newdaysVal = $daysvals - 1 ;
						$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
						if($key < (count($explodeDays)-1)){
							$addOnExpiryDateMultiple .= ",";
						}
						//var_dump($daysvals);
					}
					$addon->multiple_expiry = $addOnExpiryDateMultiple;
					$addOnExpiryDate = strtotime('+'.$order->featured_banner_days.' days', $todaytime);
					$addon->expiry = $addOnExpiryDate;
					$addon->status = 1;
					$addon->ad_id = $order->ad_id;
					$addon->save();
				
				}
				// if(!empty($order->featured_banner_price)){
				// 	$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_banner')->delete();
				// 	$addon = new AdsAddOnFeatures();
				// 	$addon->feature_name = "featured_banner";
				// 	$today = time();
				// 	$addOnExpiryDate = strtotime('+'.$order->featured_banner_day.' days', $todaytime);
				// 	$addon->expiry = $addOnExpiryDate;
				// 	$addon->status = 1;
				// 	$addon->ad_id = $order->ad_id;
				// 	$addon->save();
				
				// }


				
				
				$todaydate =strtotime(date("Y-m-d H:i"));
				$order->plan_purchased = $todaytime;
				$order->plan_expired = $userPlanExpire;
				$order->user_id = $userId;
				$order->order_status = 'Success';
				$order->txntype = $TxnId;
				$order->response_text = $ResponseText;
				$order->merchant_reference = $MerchantReference;
				$order->email = $EmailAddress;
				$order->client_ip = $ClientInfo;
				$order->paid_amount = $AmountSettlement;
				$order->bank_auth_code = $AuthCode;
			 	$order->save();

				$payment = new Payment();
				$payment->order_id = $order->id;
				$payment->amount = $AmountSettlement;
				$payment->status = "Success";
				$payment->save();

				//save transection  data to invoices table
				if($order->order_status ='Success'){
					$invoice = new Invoices();
					$invoice->ad_id = $order->ad_id;
					$invoice->order_id = $order->id;
					$invoice->user_id = $order->user_id;
					$invoice->plan_id = $order->plan_id;
					$invoice->plan_purchased = $order->plan_purchased;
					$invoice->plan_expired = $order->plan_expired;
					$invoice->featured_profile_price = $order->featured_profile_price;
					$invoice->teaser_video_price = $order->teaser_video_price;
					$invoice->featured_banner_price = $order->featured_banner_price;
					$invoice->teaser_video_two_price = $order->teaser_video_two_price;
					$invoice->super_speed_boost_price = $order->super_speed_boost_price;
					$invoice->total_amount = $AmountSettlement;
					$invoice->order_status ='Success' ;
					$invoice->txntype = $TxnId;
					$invoice->response_text = $ResponseText;
					$invoice->merchant_reference = $MerchantReference;
					$invoice->paid_amount = $AmountSettlement;
					$invoice->client_ip = $ClientInfo;
					$invoice->email = $order->email;
					$invoice->plan_actual_price = $order->plan_actual_price;
					$invoice->bank_auth_code = $AuthCode;
					$invoice->save();
				}

		
				$admin_notification_email = $this->generalSettings['admin_notification_email'];

				 $site_name = $this->generalSettings['master_agency_name'];
				  $address = $this->generalSettings['master_agency_address'];
				   $site_address = html_entity_decode($address);

				  	$encrypted_link = Crypt::encryptString($invoice->id."&".$invoice->ad_id);
				  // 	$dump_data3 = json_encode($encrypted_link);
		 			// $insert_DUmpDAta3 =  DB::table('dump_data')->insert(['dump_data' => $dump_data3]);
				    

				if ($this->isProcessed($TxnId) )
				{
					
					# Send emails, generate invoices, update order status etc.
						$email_content = array();
						$email_content["user_name"] = ucwords( $user->name );		
						$email_content["expiry_date"] = date("j<\s\up>S<\/\s\up> M Y", $userPlanExpire);
						$email_content["amount"] = $AmountSettlement;

						$email_content2 = array();
						$email_content2["user_name"] = ucwords( $user->name );
						$email_content2["user_email"] = $user->email;
						$email_content2["user_phone"] = $user->phone;
						$email_content2["invoice_no"] =  'HOSG'.'-'. $invoice->id;;
						$email_content2["site_name"] = $site_name;
						$email_content2["site_address"] = $site_address;

						if($invoice->plan_actual_price != ''){
						$email_content2["plan_name"] = $planDetails->plan_name;
						$email_content2["plan_details"] = substr($planDetails->plan_features, 0, 100);
						$email_content2["plan_unit_price"] = $invoice->plan_actual_price;
						}else{
						$email_content2["plan_name"] = '';
						$email_content2["plan_details"] = '';
						$email_content2["plan_unit_price"] = '';
						}

						if($invoice->featured_profile_price != ''){
							$email_content2["featured_sexy_profile"] = 'Featured Sexy Girl';
							$email_content2["featured_sexy_price"] = $invoice->featured_profile_price;
						}else{
							$email_content2["featured_sexy_profile"] = '';
							$email_content2["featured_sexy_price"] = '';
						}

						if($invoice->teaser_video_price != ''){
							$email_content2["featured_sexy_teaser_video"] = "Sexy Girl Teaser Video";
							$email_content2["featured_sexy_teaser_price"] = $invoice->teaser_video_price;
						}else{
							$email_content2["featured_sexy_teaser_video"] = "";
							$email_content2["featured_sexy_teaser_price"] = '';
						}
						if($invoice->teaser_video_two_price != ''){
							$email_content2["dedicated_sexy_teaser_video"] = 'Dedicated Teaser Video';
							$email_content2["dedicated_sexy_teaser_price"] = $invoice->teaser_video_two_price;
						}else{
							$email_content2["dedicated_sexy_teaser_video"] = '';
							$email_content2["dedicated_sexy_teaser_price"] = '';
						}
						if($invoice->super_speed_boost_price != ''){
							$email_content2["super_boost"] = "Super Boost";
							$email_content2["super_boost_price"] = $invoice->super_speed_boost_price;
						}else{
							$email_content2["super_boost"] = "";
							$email_content2["super_boost_price"] = '';
						}
						if($invoice->featured_banner_price != ''){
							$email_content2["featured_banner"] = "Featured Banner";
							$email_content2["featured_banner_price"] = $invoice->featured_banner_price;
						}else{
							$email_content2["featured_banner"] = "";
							$email_content2["featured_banner_price"] = '';
						}	
						
						$email_content2["total_price"] = $invoice->total_amount;
						 $email_content2["ad_id"] = $invoice->ad_id;
						$email_content2["order_id"] = $invoice->order_id;
						$email_content2["invoice_date"] = date('d-m-y h:i A', strtotime($invoice->created_at));
						$email_content2["download_pdf"] = route('downloadAsPdf',$encrypted_link);
						
						

						$email_content1 = array();
						$email_content1["user_name"] = "Admin";
						$email_content1["expiry_date"] = date("j<\s\up>S<\/\s\up> M Y", $userPlanExpire);
						$email_content1["amount"] = $AmountSettlement;
						//$email_message = new EmailMessage();
						$email_message = new EmailMessage();
						
						$email_message->singleMailSendIntegration( $user->email, "PaymentConfirm", $email_content );
						$email_message->singleMailSendIntegration( $user->email, "Invoice", $email_content2 );
		
						$email_message->singleMailSendIntegration( $admin_notification_email, "PaymentConfirm", $email_content1 );
						$email_message->singleMailSendIntegration( $admin_notification_email, "Invoice", $email_content2 );
					
				}

			}

			
			
	
		}
		else
		{
			$admin_notification_email = $this->generalSettings['admin_notification_email'];
			$order = Order::findOrFail($orderId);
			$user =  User::where('id', $userId)->first();
			$planDetails = Plans::findOrFail($order->plan_id);
			$plansDuration = $planDetails->plan_duration;
			$plansDurationUnit = $planDetails->plan_duration_unit;
			$today = time();
			$expiryDate = strtotime('+'.$plansDuration.' '.$plansDurationUnit, $today);

			$order->plan_purchased = $today;
			$order->plan_expired = $expiryDate; 
			$order->order_status = 'Cancelled/Failed';
			$order->txntype = $TxnId;
			$order->user_id = $userId;
			$order->response_text = $ResponseText;
			$order->merchant_reference = $MerchantReference;
			$order->email = $EmailAddress;
			$order->client_ip = $ClientInfo;
			$order->paid_amount = $AmountSettlement;
			$order->bank_auth_code = $AuthCode;
			$order->save();
			# Send emails, generate invoices, update order status etc.
			$email_content = array();
			$email_content["user_name"] = 'Admin';
			$email_content["amount"] = $AmountSettlement;
			$email_message = new EmailMessage();
			$email_message->singleMailSendIntegration($admin_notification_email, "PaymentCancelled", $email_content );
			$email_content1 = array();
			$email_content1["user_name"] = $user->name;
			$email_content1["amount"] = $AmountSettlement;
			//$email_message1 = new EmailMessage();
			$email_message->singleMailSendIntegration( $user->email, "PaymentCancelled", $email_content1 );
		}
	}

	function paypaxAddOnsIpn(Request $request){
		//$myfile = fopen(public_path('uploads/test.txt'),  "w") or die("Unable to open file!");
	

		$data = $request->all();
		$enc_hex = $data["result"];
	
		$rsp = $this->pxpay->getResponse($enc_hex);
		# the following are the fields available in the PxPayResponse object
		// $dump_data = json_encode($rsp);
		//  $insert_DUmpDAta =  DB::table('dump_data')->insert(['dump_data' => $dump_data]);

		$Success           = $rsp->getSuccess();   # =1 when request succeeds
		$AmountSettlement  = $rsp->getAmountSettlement();
		$AuthCode          = $rsp->getAuthCode();  # from bank
		$CardName          = $rsp->getCardName();  # e.g. "Visa"
		$CardNumber        = $rsp->getCardNumber(); # Truncated card number
		$DateExpiry        = $rsp->getDateExpiry(); # in mmyy format
		$DpsBillingId      = $rsp->getDpsBillingId();
		$BillingId    	 = $rsp->getBillingId();
		$CardHolderName    = $rsp->getCardHolderName();
		$DpsTxnRef	     = $rsp->getDpsTxnRef();
		$TxnType           = $rsp->getTxnType();
		$orderId          = $rsp->getTxnData1();
		$userId          = $rsp->getTxnData2();
		$TxnData3          = $rsp->getTxnData3();
		$CurrencySettlement= $rsp->getCurrencySettlement();
		$ClientInfo        = $rsp->getClientInfo(); # The IP address of the user who submitted the transaction
		$TxnId             = $rsp->getTxnId();
		$CurrencyInput     = $rsp->getCurrencyInput();
		$EmailAddress      = $rsp->getEmailAddress();
		$MerchantReference = $rsp->getMerchantReference();
		$ResponseText		 = $rsp->getResponseText();
		$TxnMac            = $rsp->getTxnMac(); # An indication as to the uniqueness of a card used in relation to others

		if ($rsp->getSuccess() == "1")
		{
			$user =  User::where('id', $userId)->first();
			/*$addsData = json_decode($TxnData3, true);
			$teaser_plan_day = $addsData['teaser_plan_day'];
			$teaser_plan_price =  $addsData['teaser_plan_price'];
			$fetaured_plan_day =  $addsData['fetaured_plan_day'];
			$featured_profile_price =  $addsData['featured_profile_price'];
			$featured_banner_day =  $addsData['featured_banner_day'];
			$featured_banner_price =  $addsData['featured_banner_price'];
			*/	


			$addOnsUpgrade = addOnsUpgrade::findOrFail($orderId);
			$order = Order::findOrFail($addOnsUpgrade->order_id);
			$addOnsUpgrade->order_status ='Success' ;
			$addOnsUpgrade->txntype = $TxnId;
			$addOnsUpgrade->response_text = $ResponseText;
			$addOnsUpgrade->merchant_reference = $MerchantReference;
			$addOnsUpgrade->order_id =$addOnsUpgrade->order_id;
			$addOnsUpgrade->total_paid_amount = $AmountSettlement;
			$addOnsUpgrade->client_ip = $ClientInfo;
			$addOnsUpgrade->bank_auth_code = $AuthCode;
			$addOnsUpgrade->save();

//save transection  data to invoices table
	if($addOnsUpgrade->order_status ='Success'){
		$invoice = new Invoices();
		$invoice->ad_id = $order->ad_id;
		$invoice->order_id = $order->id;
		$invoice->user_id = $order->user_id;
		$invoice->plan_id = $order->plan_id;
		$invoice->plan_purchased = $order->plan_purchased;
		$invoice->plan_expired = $order->plan_expired;
		$invoice->featured_profile_price = $addOnsUpgrade->featured_profile_price;
		$invoice->teaser_video_price = $addOnsUpgrade->teaser_video_price;
		$invoice->featured_banner_price = $addOnsUpgrade->featured_banner_price;
		$invoice->teaser_video_two_price = $addOnsUpgrade->teaser_video_two_price;
		$invoice->super_speed_boost_price = $addOnsUpgrade->super_speed_boost_price;
		$invoice->total_amount = $AmountSettlement;
		$invoice->order_status ='Success' ;
		$invoice->txntype = $TxnId;
		$invoice->response_text = $ResponseText;
		$invoice->merchant_reference = $MerchantReference;
		$invoice->paid_amount = $AmountSettlement;
		$invoice->client_ip = $ClientInfo;
		$invoice->email = $order->email;
		$invoice->bank_auth_code = $AuthCode;
		$invoice->save();
}

		// $dump_data = json_encode($invoice);
		//  $insert_DUmpDAta =  DB::table('dump_data')->insert(['dump_data' => $dump_data]);
//end invoices table data 
			
			
			$addonsDetailsArray = array();

			if(!empty($addOnsUpgrade->featured_profile_price) && !empty($addOnsUpgrade->featured_profile_day) && !empty($addOnsUpgrade->featured_profile_days)){
				$order->featured_profile_price  = $addOnsUpgrade->featured_profile_price;
				$order->featured_profile_day = $addOnsUpgrade->featured_profile_day;
				if($order->featured_profile_days != '' || $order->featured_profile_days != null){
					$order->featured_profile_days = $order->featured_profile_days.','.$addOnsUpgrade->featured_profile_days;
				}else{
					$order->featured_profile_days = $addOnsUpgrade->featured_profile_days;
				}
			}
			if(!empty($addOnsUpgrade->teaser_video_price) && !empty($addOnsUpgrade->teaser_video_day) && !empty($addOnsUpgrade->teaser_video_days)){
				$order->teaser_video_day = $addOnsUpgrade->teaser_video_day;
				$order->teaser_video_price = $addOnsUpgrade->teaser_video_price;
				if($order->teaser_video_days != '' || $order->teaser_video_days != null){
					$order->teaser_video_days = $order->teaser_video_days.','.$addOnsUpgrade->teaser_video_days;
				}else{
					$order->teaser_video_days = $addOnsUpgrade->teaser_video_days;
				}
			}
			if(!empty($addOnsUpgrade->teaser_video_two_price) && !empty($addOnsUpgrade->teaser_video_two_price) && !empty($addOnsUpgrade->teaser_video_two_days)){
				$order->teaser_video_two_day = $addOnsUpgrade->teaser_video_two_day;
				$order->teaser_video_two_price = $addOnsUpgrade->teaser_video_two_price;

				if($order->teaser_video_two_days != '' || $order->teaser_video_two_days != null){
					$order->teaser_video_two_days = $order->teaser_video_two_days.','.$addOnsUpgrade->teaser_video_two_days;
				}else{
					$order->teaser_video_two_days = $addOnsUpgrade->teaser_video_two_days;
				}

			}
			if(!empty($addOnsUpgrade->super_speed_boost_day) && !empty($addOnsUpgrade->super_speed_boost_price) && !empty($addOnsUpgrade->super_speed_boost_days)){
				$order->super_speed_boost_day = $addOnsUpgrade->super_speed_boost_day;
				$order->super_speed_boost_price = $addOnsUpgrade->super_speed_boost_price;

				if($order->super_speed_boost_days != '' || $order->super_speed_boost_days != null){
					$order->super_speed_boost_days = $order->super_speed_boost_days.','.$addOnsUpgrade->super_speed_boost_days;
				}else{
					$order->super_speed_boost_days = $addOnsUpgrade->super_speed_boost_days;
				}
			}
			if(!empty($addOnsUpgrade->featured_banner_price) && !empty($addOnsUpgrade->featured_banner_day) && !empty($addOnsUpgrade->featured_banner_days)){
				$order->featured_banner_price = $addOnsUpgrade->featured_banner_price;
				$order->featured_banner_day = $addOnsUpgrade->featured_banner_day;

				if($order->featured_banner_days != '' || $order->featured_banner_days != null){
					$order->featured_banner_days = $order->featured_banner_days.','.$addOnsUpgrade->featured_banner_days;
				}else{
					$order->featured_banner_days = $addOnsUpgrade->featured_banner_days;
				}
			}
			$order->save();
			
		
			$today = date('Y-m-d',$order->plan_purchased);
			if(!empty($addOnsUpgrade->featured_profile_price) && !empty($addOnsUpgrade->featured_profile_day) && !empty($addOnsUpgrade->featured_profile_days)){
				$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_profiles')->first();
				if(count($getOrderfeature)>0){
					if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
					{
							$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
					}else{
						$addOnExpiryDateMultiple = '';	
					}	
				}else{
					$addOnExpiryDateMultiple = '';	
				}				
				$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_profiles')->delete();
				$addon = new AdsAddOnFeatures();
				$addon->feature_name = "featured_profiles";
				
				$explodeDays = explode(',',$addOnsUpgrade->featured_profile_days);
				
				foreach ($explodeDays as $key => $daysvals) {

					$newdaysVal = $daysvals - 1 ;
					$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
					$addonsDetailsArray['featured_profiles'][] = date('Y-m-d',strtotime("$today +$newdaysVal days"));
					if($key < (count($explodeDays)-1)){
						$addOnExpiryDateMultiple .= ",";
					}
					//var_dump($daysvals);
				}
				/*var_dump($explodeDays);
				var_dump($addOnExpiryDateMultiple);
				exit;*/
				$addon->multiple_expiry = $addOnExpiryDateMultiple;
				$addOnExpiryDate = strtotime('+'.($addOnsUpgrade->featured_profile_day-1).' days', $today);
				$featuredExp = $addOnExpiryDate;
				$addon->expiry = $addOnExpiryDate;
				$addon->status = 1;
				$addon->ad_id = $order->ad_id;
				$addon->add_on_updrgrade_id = $addOnsUpgrade->id;
				$addon->save();
			
			}
			if(!empty($addOnsUpgrade->teaser_video_price) && !empty($addOnsUpgrade->teaser_video_day) && !empty($addOnsUpgrade->teaser_video_days)){
				$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video')->first();
				if(count($getOrderfeature)>0){
					if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
					{
							$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
					}else{
						$addOnExpiryDateMultiple = '';	
					}	
				}else{
					$addOnExpiryDateMultiple ='';
				}			
				$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video')->delete();
				$addon = new AdsAddOnFeatures();
				$addon->feature_name = "teaser_video";
				//$today = time();
				$explodeDays = explode(',',$addOnsUpgrade->teaser_video_days);
				//$addOnExpiryDateMultiple = "";
				foreach ($explodeDays as $key => $daysvals) {
					$newdaysVal = $daysvals - 1 ;
					$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
					$addonsDetailsArray['teaser_video'][] = date('Y-m-d',strtotime("$today +$newdaysVal days"));
					if($key < (count($explodeDays)-1)){
						$addOnExpiryDateMultiple .= ",";
					}
					//var_dump($daysvals);
				}
				$addon->multiple_expiry = $addOnExpiryDateMultiple;
				$addOnExpiryDate = strtotime('+'.($addOnsUpgrade->teaser_video_day-1).' days', $today);
				$teaserExp = $addOnExpiryDate;
				$addon->expiry = $addOnExpiryDate;
				$addon->status = 1;
				$addon->ad_id = $order->ad_id;
				$addon->add_on_updrgrade_id = $addOnsUpgrade->id;
				$addon->save();
			
			}
			if(!empty($addOnsUpgrade->featured_banner_price) && !empty($addOnsUpgrade->featured_banner_day) && !empty($addOnsUpgrade->featured_banner_days)){
				$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_banner')->first();
				if(count($getOrderfeature)>0){
					if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
					{
							$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
					}else{
						$addOnExpiryDateMultiple = '';	
					}	
				}else{
					$addOnExpiryDateMultiple = '';
				}			
				$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'featured_banner')->delete();
				$addon = new AdsAddOnFeatures();
				$addon->feature_name = "featured_banner";
				//$today = time();
				$explodeDays = explode(',',$addOnsUpgrade->featured_banner_days);
				//$addOnExpiryDateMultiple = "";
				foreach ($explodeDays as $key => $daysvals) {
					$newdaysVal = $daysvals - 1 ;
					$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
					$addonsDetailsArray['featured_banner'][] = date('Y-m-d',strtotime("$today +$newdaysVal days"));
					if($key < (count($explodeDays)-1)){
						$addOnExpiryDateMultiple .= ",";
					}
					//var_dump($daysvals);
				}
				$addon->multiple_expiry = $addOnExpiryDateMultiple;
				$addOnExpiryDate = strtotime('+'.($addOnsUpgrade->featured_banner_day-1).' days', $today);
				$fBannerExp = $addOnExpiryDate;
				$addon->expiry = $addOnExpiryDate;
				$addon->status = 1;
				$addon->ad_id = $order->ad_id;
				$addon->add_on_updrgrade_id = $addOnsUpgrade->id;
				$addon->save();
			
			}

			
			if(!empty($addOnsUpgrade->teaser_video_two_price) && !empty($addOnsUpgrade->teaser_video_two_day) && !empty($addOnsUpgrade->teaser_video_two_days)){
				$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video_two')->first();
				if(count($getOrderfeature)>0){
					if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
					{
							$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
					}else{
						$addOnExpiryDateMultiple = '';	
					}	
				}else{
					$addOnExpiryDateMultiple='';
				}			
				$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'teaser_video_two')->delete();
				$addon = new AdsAddOnFeatures();
				$addon->feature_name = "teaser_video_two";
				//$today = time();
				$explodeDays = explode(',',$addOnsUpgrade->teaser_video_two_days);
				//$addOnExpiryDateMultiple = "";
				foreach ($explodeDays as $key => $daysvals) {
					$newdaysVal = $daysvals - 1 ;
					$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
					$addonsDetailsArray['teaser_video_two'][] = date('Y-m-d',strtotime("$today +$newdaysVal days"));
					if($key < (count($explodeDays)-1)){
						$addOnExpiryDateMultiple .= ",";
					}
					//var_dump($daysvals);
				}
				$addon->multiple_expiry = $addOnExpiryDateMultiple;
				$addOnExpiryDate = strtotime('+'.($order->teaser_video_two_day-1).' days', $today);
				$addon->expiry = $addOnExpiryDate;
				$addon->status = 1;
				$addon->ad_id = $order->ad_id;
				$addon->add_on_updrgrade_id = $addOnsUpgrade->id;
				$addon->save();
			
			}

			if(!empty($addOnsUpgrade->super_speed_boost_price) && !empty($addOnsUpgrade->super_speed_boost_day) && !empty($addOnsUpgrade->super_speed_boost_days)){
				$getOrderfeature = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'super_speed_boost')->first();
				if(count($getOrderfeature)>0){
					if(!empty($getOrderfeature->multiple_expiry) || $getOrderfeature->multiple_expiry != '' || $getOrderfeature->multiple_expiry != null)
					{
							$addOnExpiryDateMultiple = $getOrderfeature->multiple_expiry.",";	
					}else{
						$addOnExpiryDateMultiple = '';	
					}	
				}else{
					$addOnExpiryDateMultiple ='';
				}							
				$deletedRows = AdsAddOnFeatures::where('ad_id', $order->ad_id)->where('feature_name', 'super_speed_boost')->delete();
				$addon = new AdsAddOnFeatures();
				$addon->feature_name = "super_speed_boost";
				//$today = time();
				$explodeDays = explode(',',$addOnsUpgrade->super_speed_boost_days);
				//$addOnExpiryDateMultiple = "";
				foreach ($explodeDays as $key => $daysvals) {
					$newdaysVal = $daysvals - 1 ;
					$addOnExpiryDateMultiple .= date('Y-m-d',strtotime("$today +$newdaysVal days"));
					$addonsDetailsArray['super_speed_boost'][] = date('Y-m-d',strtotime("$today +$newdaysVal days"));
					if($key < (count($explodeDays)-1)){
						$addOnExpiryDateMultiple .= ",";
					}
					//var_dump($daysvals);
				}
				$addon->multiple_expiry = $addOnExpiryDateMultiple;
				$addOnExpiryDate = strtotime('+'.($order->super_speed_boost_day -1).' days', $today);
				$addon->expiry = $addOnExpiryDate;
				$addon->status = 1;
				$addon->ad_id = $order->ad_id;
				$addon->add_on_updrgrade_id = $addOnsUpgrade->id;
				$addon->save();
			
			}
			//$updateData = DB::statement($insertQuery);


		 	$admin_notification_email = $this->generalSettings['admin_notification_email'];
			 $site_name = $this->generalSettings['master_agency_name'];
			  $address = $this->generalSettings['master_agency_address'];
			   $site_address = html_entity_decode($address);
				$encrypted_link = Crypt::encryptString($invoice->id."&".$invoice->ad_id);
		
			if (!$this->isProcessed($TxnId))
			{
				
				# Send emails, generate invoices, update order status etc.
					$email_content = array();
					$email_content["user_name"] = ucwords( $user->name );
					if(!empty($featured_profile_price) && !empty($fetaured_plan_day)){
						$email_content['featured_add_on_name'] = 'Featrured Sexy Girls';
						$email_content["featured_expiry_date"] = date("j<\s\up>S<\/\s\up> M Y", $featuredExp); 
					}
					if(!empty($teaser_plan_day) && !empty($teaser_plan_price)){
						$email_content['featured_add_on_name'] = 'Teaser Sexy Video';
						$email_content["featured_expiry_date"] = date("j<\s\up>S<\/\s\up> M Y", $teaserExp); 
					}
					if(!empty($featured_banner_day) && !empty($featured_banner_price)){
						$email_content['featured_add_on_name'] = 'Fetured Banner';
						$email_content["featured_expiry_date"] = date("j<\s\up>S<\/\s\up> M Y", $fBannerExp); 
					}
					$email_content["amount"] = $AmountSettlement;

					// invoice data 

					$email_content2 = array();
					$email_content2["user_name"] = ucwords( $user->name );
					$email_content2["user_email"] = $user->email;
					$email_content2["user_phone"] = $user->phone;
					$email_content2["invoice_no"] = 'HOSG'.'-'. $invoice->id;
					$email_content2["site_name"] = $site_name;
					$email_content2["site_address"] = $site_address;
					$email_content2["plan_name"] = $planDetails->plan_name;
					$email_content2["plan_details"] = substr($planDetails->plan_features, 0, 100);
					

					if($invoice->plan_actual_price != ''){
						$email_content2["plan_unit_price"] = $invoice->plan_actual_price;
					}else{
						$email_content2["plan_unit_price"] = '';
					}

					if($invoice->featured_profile_price != ''){
						$email_content2["featured_sexy_profile"] = 'Featured Sexy Girl';
						$email_content2["featured_sexy_price"] = $invoice->featured_profile_price;
					}else{
						$email_content2["featured_sexy_profile"] = '';
						$email_content2["featured_sexy_price"] = '';
					}

					if($invoice->teaser_video_price != ''){
						$email_content2["featured_sexy_teaser_video"] = "Sexy Girl Teaser Video";
						$email_content2["featured_sexy_teaser_price"] = $invoice->teaser_video_price;
					}else{
						$email_content2["featured_sexy_teaser_video"] = "";
						$email_content2["featured_sexy_teaser_price"] = '';
					}
					if($invoice->teaser_video_two_price != ''){
						$email_content2["dedicated_sexy_teaser_video"] = 'Dedicated Teaser Video';
						$email_content2["dedicated_sexy_teaser_price"] = $invoice->teaser_video_two_price;
					}else{
						$email_content2["dedicated_sexy_teaser_video"] = '';
						$email_content2["dedicated_sexy_teaser_price"] = '';
					}
					if($invoice->super_speed_boost_price != ''){
						$email_content2["super_boost"] = "Super Boost";
						$email_content2["super_boost_price"] = $invoice->super_speed_boost_price;
					}else{
						$email_content2["super_boost"] = "";
						$email_content2["super_boost_price"] = '';
					}
					if($invoice->featured_banner_price != ''){
						$email_content2["featured_banner"] = "Featured Banner";
						$email_content2["featured_banner_price"] = $invoice->featured_banner_price;
					}else{
						$email_content2["featured_banner"] = "";
						$email_content2["featured_banner_price"] = '';
					}	
					
					$email_content2["total_price"] = $invoice->total_amount;
					 $email_content2["ad_id"] = $invoice->ad_id;
					$email_content2["order_id"] = $invoice->order_id;
					$email_content2["invoice_date"] = date('d-m-y h:i A', strtotime($invoice->created_at));
					$email_content2["download_pdf"] = route('downloadAsPdf',$encrypted_link);
					///end invoice data

					$email_content1 = array();
					$email_content1["user_name"] = "Admin";
					$email_content1["amount"] = $AmountSettlement;

					$email_message = new EmailMessage();
					
					$email_message->singleMailSendIntegration( $user->email, "AddOnsPaymentConfirm", $email_content );
					$email_message->singleMailSendIntegration( $user->email, "Invoice", $email_content2 );
	
					$email_message->singleMailSendIntegration( $admin_notification_email, "AddOnsPaymentConfirm", $email_content1 );
					$email_message->singleMailSendIntegration( $admin_notification_email, "Invoice", $email_content2 );
				

					// $email_message = new EmailMessage();
					// $email_message->singleMailSendIntegration(  $user->email, "AddOnsPaymentConfirm", $email_content );
					// $email_message->singleMailSendIntegration( $admin_notification_email, "AddOnsPaymentConfirm", $email_content1 );
					
			}

		}
		else
		{

			$addsData = json_decode($TxnData3, true);
			$teaser_plan_pricelan_day = $addsData['teaser_plan_day'];
			$teaser_plan_price =  $addsData['teaser_plan_price'];
			$fetaured_plan_day =  $addsData['fetaured_plan_day'];
			$featured_profile_price =  $addsData['featured_profile_price'];
			$featured_banner_day =  $addsData['featured_banner_day'];
			$featured_banner_price =  $addsData['featured_banner_price'];
			$admin_notification_email = $this->generalSettings['admin_notification_email'];
		
			$user =  User::where('id', $userId)->first();
			
			$plansDuration = $planDetails->plan_duration;
			$plansDurationUnit = $planDetails->plan_duration_unit;
			$today = time();
			$addOnsUpgrade = addOnsUpgrade::findOrFail($orderId);
			$addOnsUpgrade->order_status = 'Cancelled/Failed';
			$addOnsUpgrade->txntype = $TxnId;	
			$addOnsUpgrade->response_text = $ResponseText;
			$addOnsUpgrade->merchant_reference = $MerchantReference;
			$addOnsUpgrade->order_id = $addOnsUpgrade->order_id;
			$addOnsUpgrade->client_ip = $ClientInfo;
			$addOnsUpgrade->bank_auth_code = $AuthCode;
			$addOnsUpgrade->save();
			# Send emails, generate invoices, update order status etc.
			$email_content = array();
			$email_content["user_name"] = 'Admin';
			$email_content["amount"] = $AmountSettlement;
			$email_message = new EmailMessage();
			$email_message->singleMailSendIntegration($admin_notification_email, "PaymentCancelled", $email_content );
			$email_content1 = array();
			$email_content1["user_name"] = $user->name;
			$email_content1["amount"] = $AmountSettlement;
			//$email_message1 = new EmailMessage();
			$email_message->singleMailSendIntegration( $user->email, "PaymentCancelled", $email_content1 );
		}
		$createadons = AddOnDetails::create([
				'data' => json_encode($addonsDetailsArray),
				'order_id' => "1"
			]);
			$createadons->save();
			 $insert_DUmpDAta =  DB::table('dump_data')->insert(['dump_data' => json_encode($addonsDetailsArray)]);
	}

	function isProcessed($TxnId)
	{
		$res = Order::where('txntype', $TxnId)->first();
		if(count($res) == 0){
			return false;
		}
		return true;
		
	}

	function redirectForm(Request $request){
		
		$pxrequest = new PxPayRequest();
		$http_host   = getenv("HTTP_HOST");
		$request_uri = getenv("SCRIPT_NAME");
		$server_url  = "http://$http_host";
		$script_url = (version_compare(PHP_VERSION, "4.3.4", ">=")) ?"$server_url$request_uri" : "$server_url/$request_uri";
		$Quantity = $request->input("Quantity");
		$MerchantReference =$request->input("Reference");  
		$Address1 = $request->input("Address1");
		$Address2 =  $request->input("Address2");
		$Address3 = $request->input("Address3");
		$returnURL = $request->input("returnURL");
		if(!empty($Address3)){
			$UrlCallback = route('paypaxaddonipn');
			//$returnURL =route('paypaxaddonipn');
		}else{
			
			$UrlCallback = route('paypaxipn');
			
		}
			 // $request->input("returnURL");
		#Calculate AmountInput
		$AmountInput = $request->input("Price") * $Quantity;
		

		#Generate a unique identifier for the transaction
		$TxnId = uniqid("ID");

		#Set PxPay properties
		$pxrequest->setMerchantReference($MerchantReference);
		$pxrequest->setAmountInput($AmountInput);
		$pxrequest->setTxnData1($Address1);
		$pxrequest->setTxnData2($Address2);
		$pxrequest->setTxnData3($Address3);
		$pxrequest->setTxnType("Purchase");
		$pxrequest->setOrderUserId($request->input("Userid"));
		$pxrequest->setCurrencyInput($request->input("CurrencyCode"));
		$pxrequest->setEmailAddress($request->input("EmailAddress"));
		$pxrequest->setUrlFail($returnURL);			# can be a dedicated failure page
		//$pxrequest->setForcePaymentMethod($request->input("ForcePaymentMethod"));
		$pxrequest->setUrlSuccess($returnURL);			# can be a dedicated success page
		$pxrequest->setUrlCallback($UrlCallback);
		$pxrequest->setTxnId($TxnId);  
  
  #The following properties are not used in this case
  # $request->setEnableAddBillCard($EnableAddBillCard);    
  # $request->setBillingId($BillingId);
  # $request->setOpt($Opt);
  

 	$request_string = $this->pxpay->makeRequest($pxrequest);
 	/*var_dump($request_string);
 	exit;*/
 	  $response = new MifMessage($request_string);
 	  $url = $response->get_element_text("URI");
 	  /*var_dump($UrlCallback);
 	  exit;*/
	  $valid = $response->get_attribute("valid");
	  // var_dump($valid);
	  // exit;
	  return Redirect::to($url);
	  
	}


}
