@extends('frontend.layouts.front_layout')


@section('content')
<section class="padding-80">
<div class="container">
<div class="content_block">
                <div class="thanks_box text-center crackers-video">


<video playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">
      <source src="https://www.houseofsexygirls.co.nz/uploads/videos/congrats-fireworks.mp4" type="video/mp4">
    
  </video>

        <div class="finish-text">
				<h2 class="welcome-msg">Great &nbsp;{{$adData->ad_name}}</h2>
          @php
         

           $teaser_sexy_video = getAdOnsStatus('teaser_video',$adData->id);
           $featured_banner = getAdOnsStatus('featured_banner',$adData->id);
           $second_teaser_video = getAdOnsStatus('teaser_video_two',$adData->id);
           $featured_sexy_girls = getAdOnsStatus('featured_profiles',$adData->id);
           $super_speed_boost = getAdOnsStatus('super_speed_boost',$adData->id);

           $listing_slug = DB::table('listing_type')->where('id', $adData->ad_listing_type_id)->first()->slug;    
           $editLink = route('edit-profile', ['slug1' => $listing_slug,'slug2'=>$adData->slug]);
           $totalAddons= count($teaser_sexy_video) +count($featured_banner) +count($second_teaser_video) +count($featured_sexy_girls) +count($super_speed_boost);

       @endphp
            
             @if($type == 'addOns')

               {{--  redirect to step 3  --}}

               {{-- for individual escorts  --}}
           

               @if($listing_slug == 'independent-female-escort' || $listing_slug == 'sensual-massage' || $listing_slug == 'independent-male-escort' || $listing_slug == 'independent-trans-escort' || $listing_slug == 'bdsm' || $listing_slug == 'fetish' )

               {{-- start teaser section  --}}
               @if(empty($second_teaser_video)  && !empty($teaser_sexy_video) && empty($featured_sexy_girls) && empty($super_speed_boost) )
               <p>Your Add-on has been upgraded.&nbsp;&nbsp;Please upload  Teaser Video.</p>
               <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                @elseif(empty($second_teaser_video) && empty(!$teaser_sexy_video) && !empty($featured_sexy_girls) && empty($super_speed_boost))
               <p>Your Add-ons has been upgraded.&nbsp;Please upload  Teaser Video.</p>
               <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                 @elseif(empty($second_teaser_video) && empty(!$teaser_sexy_video) && empty($featured_sexy_girls) && !empty($super_speed_boost))
               <p>Your Add-ons has been upgraded.&nbsp;Please upload  Teaser Video.</p>
               <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                @elseif(empty($second_teaser_video) && empty(!$teaser_sexy_video) && !empty($featured_sexy_girls) && !empty($super_speed_boost))
               <p>Your Add-ons has been upgraded.&nbsp;Please upload  Teaser Video.</p>
               <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>
               {{-- end teaser section  --}}

               {{-- start dedicated section  --}}
              @elseif(!empty($second_teaser_video) && empty($teaser_sexy_video) && empty($featured_sexy_girls) && empty($super_speed_boost))
               <p>Your Add-on has been upgraded.&nbsp;Please upload Dedicated Teaser Video.</p>
               <a href="{{$editLink}}?step=4#Dedicated_section" class="green_gredient_btn gr_pink">Upload  Now </a>
               
                @elseif(!empty($second_teaser_video) && empty($teaser_sexy_video) && !empty($featured_sexy_girls) && empty($super_speed_boost))
                 <p>Your Add-ons has been upgraded.&nbsp;Please upload  Dedicated Teaser Video.</p>
                 <a href="{{$editLink}}?step=4#Dedicated_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                  @elseif(!empty($second_teaser_video) && empty($teaser_sexy_video) && empty($featured_sexy_girls) && !empty($super_speed_boost))
                 <p>Your Add-ons has been upgraded.&nbsp;Please upload  Dedicated Teaser Video.</p>
                 <a href="{{$editLink}}?step=4#Dedicated_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                  @elseif(!empty($second_teaser_video) && empty($teaser_sexy_video) && !empty($featured_sexy_girls) && !empty($super_speed_boost))
                 <p>Your Add-ons has been upgraded.&nbsp;Please upload  Dedicated Teaser Video.</p>
                 <a href="{{$editLink}}?step=4#Dedicated_section" class="green_gredient_btn gr_pink">Upload  Now </a>
                 {{-- end dedicated section  --}}

                 {{-- start overall section  --}}
                  @elseif(!empty($second_teaser_video) && !empty($teaser_sexy_video) && empty($featured_sexy_girls) && empty($super_speed_boost))
                 <p>Your Add-ons has been upgraded.&nbsp;Please upload Teaser and  Dedicated Teaser Video.</p>
                 <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                  @elseif(!empty($second_teaser_video) && !empty($teaser_sexy_video) && !empty($featured_sexy_girls) && empty($super_speed_boost))
                 <p>Your Add-ons has been upgraded.&nbsp;Please upload Teaser and  Dedicated Teaser Video.</p>
                 <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                  @elseif(!empty($second_teaser_video) && !empty($teaser_sexy_video) && empty($featured_sexy_girls) && !empty($super_speed_boost))
                 <p>Your Add-ons has been upgraded.&nbsp;Please upload Teaser and  Dedicated Teaser Video.</p>
                 <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>

                  @elseif(!empty($second_teaser_video) && !empty($teaser_sexy_video) && !empty($featured_sexy_girls) && !empty($super_speed_boost))
                 <p>Your Add-ons has been upgraded.&nbsp;Please upload Teaser and  Dedicated Teaser Video.</p>
                 <a href="{{$editLink}}?step=4#Teaser_section" class="green_gredient_btn gr_pink">Upload  Now </a>
                 {{-- Overall  section end --}}
                  @else
                   @if( $totalAddons > 1)
                    <p>Your Add-ons has been upgraded.
                      @else
                       <p>Your Add-on has been upgraded.</p>
                      @endif
                <a href="{{route('dashboard')}}" class="green_gredient_btn gr_pink">Go to Dashboard</a>
               @endif

               @endif
               {{-- end for individual escorts  --}}

               {{-- For Photographer and job escort --}}
               @if($listing_slug == 'photographer' || $listing_slug == 'adult-jobs' )

                @if(!empty($featured_banner) && empty($second_teaser_video))
                 <p>Your Add-on has been upgraded.&nbsp;Please upload Featured Banner Video</p>
                 <a href="{{$editLink}}?step=3#Banner_section" class="green_gredient_btn gr_pink">Upload  Now </a>
                

                  @elseif(empty($featured_banner) && !empty($second_teaser_video))
                   <p>Your Add-on has been upgraded.&nbsp;Please upload Dedicated Teaser Video.</p>
                   <a href="{{$editLink}}?step=3#Dedicated_section" class="green_gredient_btn gr_pink">Upload  Now </a>
                  
                  @elseif(!empty($featured_banner) && !empty($second_teaser_video) )
                   <p>Your Add-ons has been upgraded.&nbsp;Please upload Featured Banner and Dedicated Teaser Video.</p>
                   <a href="{{$editLink}}?step=3#Banner_section" class="green_gredient_btn gr_pink">Upload  Now </a>
                    @else
                     @if( $totalAddons > 1)
                    <p>Your Add-ons has been upgraded.
                      @else
                       <p>Your Add-on has been upgraded.</p>
                      @endif
                     <a href="{{route('dashboard')}}" class="green_gredient_btn gr_pink">Go to Dashboard</a>
                  @endif

                  @endif
                 {{-- end fpr job and photographer --}}

                  {{--  end redirect to step 3  --}}

               {{-- @if( $totalAddons > 1)
                 <p>Your Add-ons has been upgraded.</p>
               @else
                <p>Your Add-on has been upgraded.</p>
               @endif
               
               <a href="{{route('dashboard')}}" class="green_gredient_btn gr_pink">Go to Dashboard</a> --}}
             
              @elseif($countOrderData > 1)
             @php
              $teaser_sexy_video = getAdOnsStatus('teaser_video',$adData->id);
              $second_teaser_video = getAdOnsStatus('teaser_video_two',$adData->id);
               $featured_banner = getAdOnsStatus('featured_banner',$adData->id);
               
             @endphp
             @if($listing_slug == 'independent-female-escort' || $listing_slug == 'sensual-massage' || $listing_slug == 'independent-male-escort' || $listing_slug == 'independent-trans-escort' || $listing_slug == 'bdsm' || $listing_slug == 'fetish' )

             @if(!empty($teaser_sexy_video) && empty($second_teaser_video))
              <p>Your subscriptions has been successfully renewed. Please set your working days/hrs and upload teaser video at step 4. Check your email for invoice.</p>
              @elseif(empty($teaser_sexy_video) && !empty($second_teaser_video))
               <p>Your subscriptions has been successfully renewed. Please set your working days/hrs and upload dedicated video at step 4. Check your email for invoice.</p>
              @elseif(!empty($teaser_sexy_video) && !empty($second_teaser_video))
               <p>Your subscriptions has been successfully renewed. Please set your working days/hrs, upload teaser and dedicated  video at step 4. Check your email for invoice.</p>
               @else
               <p>Your subscriptions has been successfully renewed. Please set your working days/hrs. Check your email for invoice.</p>
               @endif

               <div class="clearfix"></div>     
              <a href="{{$profile_edit_link}}" class="green_gredient_btn gr_pink">Please Continue</a>
              @else

              @if(!empty($teaser_sexy_video) && empty($second_teaser_video))
              <p>Your subscriptions has been  upgraded successfully. Please set your working days/hrs and upload teaser video at step 4. Check your email for invoice.</p>
              @elseif(empty($teaser_sexy_video) && !empty($second_teaser_video))
               <p>Your subscriptions has been  upgraded successfully. Please set your working days/hrs and upload dedicated video at step 4. Check your email for invoice.</p>
              @elseif(!empty($teaser_sexy_video) && !empty($second_teaser_video))
               <p>Your subscriptions has been  upgraded successfully. Please set your working days/hrs, upload teaser and dedicated  video at step 4. Check your email for invoice.</p>
               
               @else
               <p>Your subscription has been upgraded successfully. Please check your working days/hrs. Check your email for invoice.</p>
               @endif

             

                    <div class="clearfix"></div>
                   <a href="{{$profile_edit_link}}" class="green_gredient_btn gr_pink">Please Continue</a>
                @endif

                 @if($listing_slug == 'photographer' || $listing_slug == 'adult-jobs' )

              @if(!empty($featured_banner) && empty($second_teaser_video))
              <p>Your subscriptions has been  upgraded successfully. Please set your working days/hrs and upload featured  banner at step 3. Check your email for invoice.</p>
              @elseif(empty($featured_banner) && !empty($second_teaser_video))
               <p>Your subscriptions has been  upgraded successfully. Please set your working days/hrs and upload dedicated video at step 3. Check your email for invoice.</p>
              @elseif(!empty($featured_banner) && !empty($second_teaser_video))
               <p>Your subscriptions has been  upgraded successfully. Please set your working days/hrs, upload featured banner and dedicated  video at step 3. Check your email for invoice.</p>
               
               @else
               <p>Your subscription has been upgraded successfully. Please check your working days/hrs. Check your email for invoice.</p>
               @endif


             @endif
			
                </div>
                </div>
				
				
				
			</div>
            </div>
			</section>
			
			
			<script>
			let width = window.innerWidth;
  let height = window.innerHeight;
  let particles = [];
  
  // particle canvas
  const canvas = document.createElement( 'canvas' );
  const context = canvas.getContext( '2d' );
  canvas.id = 'firework-canvas';
  canvas.width = width;
  canvas.height = height;
  canvas.style.display = 'block';
  canvas.style.pointerEvents = 'none';
  canvas.style.position = 'fixed';
  canvas.style.zIndex = '1';
  canvas.style.left = '0';
  canvas.style.top = '0';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.opacity = '.85';
  document.getElementById("finished_crackerss").appendChild( canvas );
  
  // on resize 
  window.addEventListener( 'resize', e => {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;
  });
  
  // add particles slowly over time 
  const create = () => {
    if ( particles.length > 2 ) return; 
    particles.push( new FireworkParticle1( context, width, height, 100 ) ); 
    setTimeout( create, 600 );  
  }; 
  
  // animation loop 
  const loop = () => {
    requestAnimationFrame( loop );
    context.fillStyle = 'rgba(0,0,0,0.2)';
    context.fillRect( 0, 0, width, height );
    
    for ( let p of particles ) {
      if ( p.complete() ) p.reset();
      p.update( width, height );
      p.draw();
    }
  };
 
  // init 
  create();
  loop();
			</script>
			
			
@endsection			
			
			
			